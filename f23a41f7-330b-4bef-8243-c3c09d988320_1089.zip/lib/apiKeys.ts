
export const FMP_KEY = "2Grb1estWna696ugA4ahGsLMlNGTNzJl";
export const EODHD_KEY = "demo";
