
export interface WordPressPost {
  id: number;
  date: string;
  slug: string;
  status: string;
  title: {
    rendered: string;
  };
  content: {
    rendered: string;
  };
  excerpt: {
    rendered: string;
  };
  author: number;
  featured_media: number;
  categories: number[];
  tags: number[];
  _embedded?: {
    author: Array<{
      id: number;
      name: string;
      avatar_urls: {
        96: string;
      };
    }>;
    'wp:featuredmedia': Array<{
      id: number;
      source_url: string;
      alt_text: string;
    }>;
    'wp:term': Array<Array<{
      id: number;
      name: string;
      slug: string;
    }>>;
  };
}

export interface WordPressCategory {
  id: number;
  name: string;
  slug: string;
  description: string;
  count: number;
}

export interface WordPressAuthor {
  id: number;
  name: string;
  description: string;
  avatar_urls: {
    96: string;
  };
}

class WordPressAPI {
  private baseUrl: string;

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl.replace(/\/$/, '');
  }

  async getPosts(params: {
    page?: number;
    per_page?: number;
    categories?: string;
    search?: string;
    status?: string;
  } = {}): Promise<{ posts: WordPressPost[], totalPages: number }> {
    // Mode démo si pas de WordPress configuré
    if (!this.baseUrl || this.baseUrl === 'https://votre-wordpress.com') {
      return this.getDemoPosts(params);
    }

    const queryParams = new URLSearchParams({
      _embed: 'true',
      per_page: (params.per_page || 10).toString(),
      page: (params.page || 1).toString(),
      status: params.status || 'publish',
      ...params
    });

    try {
      const response = await fetch(`${this.baseUrl}/wp-json/wp/v2/posts?${queryParams}`);
      
      if (!response.ok) {
        throw new Error(`WordPress API error: ${response.status}`);
      }

      const posts = await response.json();
      const totalPages = parseInt(response.headers.get('X-WP-TotalPages') || '1');

      return { posts, totalPages };
    } catch (error) {
      console.error('Erreur lors de la récupération des articles:', error);
      return this.getDemoPosts(params);
    }
  }

  async getPost(slug: string): Promise<WordPressPost | null> {
    // Mode démo si pas de WordPress configuré
    if (!this.baseUrl || this.baseUrl === 'https://votre-wordpress.com') {
      return this.getDemoPost(slug);
    }

    try {
      const response = await fetch(`${this.baseUrl}/wp-json/wp/v2/posts?slug=${slug}&_embed=true`);
      
      if (!response.ok) {
        throw new Error(`WordPress API error: ${response.status}`);
      }

      const posts = await response.json();
      return posts.length > 0 ? posts[0] : null;
    } catch (error) {
      console.error('Erreur lors de la récupération de l\'article:', error);
      return this.getDemoPost(slug);
    }
  }

  async getCategories(): Promise<WordPressCategory[]> {
    // Mode démo si pas de WordPress configuré
    if (!this.baseUrl || this.baseUrl === 'https://votre-wordpress.com') {
      return this.getDemoCategories();
    }

    try {
      const response = await fetch(`${this.baseUrl}/wp-json/wp/v2/categories?per_page=100`);
      
      if (!response.ok) {
        throw new Error(`WordPress API error: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Erreur lors de la récupération des catégories:', error);
      return this.getDemoCategories();
    }
  }

  async getAuthors(): Promise<WordPressAuthor[]> {
    // Mode démo si pas de WordPress configuré
    if (!this.baseUrl || this.baseUrl === 'https://votre-wordpress.com') {
      return this.getDemoAuthors();
    }

    try {
      const response = await fetch(`${this.baseUrl}/wp-json/wp/v2/users?per_page=100`);
      
      if (!response.ok) {
        throw new Error(`WordPress API error: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Erreur lors de la récupération des auteurs:', error);
      return this.getDemoAuthors();
    }
  }

  async searchPosts(query: string, page: number = 1): Promise<{ posts: WordPressPost[], totalPages: number }> {
    return this.getPosts({
      search: query,
      page,
      per_page: 10
    });
  }

  // Données de démonstration
  private getDemoPosts(params: any): { posts: WordPressPost[], totalPages: number } {
    const demoPosts: WordPressPost[] = [
      {
        id: 1,
        date: '2024-01-15T10:00:00',
        slug: 'analyse-marches-janvier-2024',
        status: 'publish',
        title: { rendered: 'Analyse des marchés financiers - Janvier 2024' },
        content: { rendered: '<p>L\'année 2024 commence avec des perspectives intéressantes pour les marchés financiers. Les banques centrales continuent leur politique monétaire restrictive...</p>' },
        excerpt: { rendered: 'L\'année 2024 commence avec des perspectives intéressantes pour les marchés financiers.' },
        author: 1,
        featured_media: 1,
        categories: [1],
        tags: [],
        _embedded: {
          author: [{
            id: 1,
            name: 'Expert CMV Finance',
            avatar_urls: { 96: 'https://readdy.ai/api/search-image?query=professional%20financial%20analyst%20avatar%20portrait%20modern%20business%20style&width=96&height=96&seq=1&orientation=squarish' }
          }],
          'wp:featuredmedia': [{
            id: 1,
            source_url: 'https://readdy.ai/api/search-image?query=financial%20markets%20analysis%20charts%20graphs%20trading%20floor%20modern%20office%20setting%20professional%20atmosphere&width=800&height=400&seq=2&orientation=landscape',
            alt_text: 'Analyse des marchés financiers'
          }]
        }
      },
      {
        id: 2,
        date: '2024-01-12T14:30:00',
        slug: 'strategies-diversification-portefeuille',
        status: 'publish',
        title: { rendered: 'Stratégies de diversification pour optimiser votre portefeuille' },
        content: { rendered: '<p>La diversification reste l\'un des principes fondamentaux de l\'investissement. Dans un contexte économique incertain...</p>' },
        excerpt: { rendered: 'La diversification reste l\'un des principes fondamentaux de l\'investissement.' },
        author: 1,
        featured_media: 2,
        categories: [2],
        tags: [],
        _embedded: {
          author: [{
            id: 1,
            name: 'Expert CMV Finance',
            avatar_urls: { 96: 'https://readdy.ai/api/search-image?query=professional%20financial%20analyst%20avatar%20portrait%20modern%20business%20style&width=96&height=96&seq=3&orientation=squarish' }
          }],
          'wp:featuredmedia': [{
            id: 2,
            source_url: 'https://readdy.ai/api/search-image?query=portfolio%20diversification%20investment%20strategy%20pie%20charts%20asset%20allocation%20modern%20clean%20background&width=800&height=400&seq=4&orientation=landscape',
            alt_text: 'Diversification de portefeuille'
          }]
        }
      },
      {
        id: 3,
        date: '2024-01-10T09:15:00',
        slug: 'impact-intelligence-artificielle-finance',
        status: 'publish',
        title: { rendered: 'L\'impact de l\'intelligence artificielle sur la finance moderne' },
        content: { rendered: '<p>L\'intelligence artificielle révolutionne le secteur financier. Des algorithmes de trading aux conseillers robotiques...</p>' },
        excerpt: { rendered: 'L\'intelligence artificielle révolutionne le secteur financier.' },
        author: 1,
        featured_media: 3,
        categories: [3],
        tags: [],
        _embedded: {
          author: [{
            id: 1,
            name: 'Expert CMV Finance',
            avatar_urls: { 96: 'https://readdy.ai/api/search-image?query=professional%20financial%20analyst%20avatar%20portrait%20modern%20business%20style&width=96&height=96&seq=5&orientation=squarish' }
          }],
          'wp:featuredmedia': [{
            id: 3,
            source_url: 'https://readdy.ai/api/search-image?query=artificial%20intelligence%20finance%20technology%20neural%20networks%20digital%20transformation%20modern%20fintech%20concept&width=800&height=400&seq=6&orientation=landscape',
            alt_text: 'Intelligence artificielle en finance'
          }]
        }
      }
    ];

    return { posts: demoPosts, totalPages: 1 };
  }

  private getDemoPost(slug: string): WordPressPost | null {
    const posts = this.getDemoPosts({}).posts;
    return posts.find(post => post.slug === slug) || null;
  }

  private getDemoCategories(): WordPressCategory[] {
    return [
      { id: 1, name: 'Analyse de marché', slug: 'analyse-marche', description: 'Analyses et tendances des marchés financiers', count: 5 },
      { id: 2, name: 'Stratégies d\'investissement', slug: 'strategies-investissement', description: 'Conseils et stratégies pour optimiser vos investissements', count: 8 },
      { id: 3, name: 'Technologie financière', slug: 'fintech', description: 'Innovations et technologies dans la finance', count: 3 },
      { id: 4, name: 'Actualités économiques', slug: 'actualites-economiques', description: 'Dernières nouvelles du monde économique', count: 12 }
    ];
  }

  private getDemoAuthors(): WordPressAuthor[] {
    return [
      {
        id: 1,
        name: 'Expert CMV Finance',
        description: 'Analyste financier senior avec plus de 15 ans d\'expérience',
        avatar_urls: { 96: 'https://readdy.ai/api/search-image?query=professional%20financial%20analyst%20avatar%20portrait%20modern%20business%20style&width=96&height=96&seq=7&orientation=squarish' }
      }
    ];
  }
}

export const wordpressApi = new WordPressAPI(
  process.env.NEXT_PUBLIC_WORDPRESS_URL || 'https://votre-wordpress.com'
);
