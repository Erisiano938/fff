'use client';

import { useState, useEffect } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

interface ServiceStatus {
  name: string;
  status: 'operational' | 'degraded' | 'outage';
  lastUpdated: string;
  uptime: string;
  responseTime: string;
  description: string;
}

interface Incident {
  id: string;
  title: string;
  status: 'investigating' | 'identified' | 'monitoring' | 'resolved';
  severity: 'minor' | 'major' | 'critical';
  createdAt: string;
  updatedAt: string;
  description: string;
  updates: {
    timestamp: string;
    status: string;
    message: string;
  }[];
}

export default function SystemStatusPage() {
  const [services, setServices] = useState<ServiceStatus[]>([]);
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [overallStatus, setOverallStatus] = useState<'operational' | 'degraded' | 'outage'>('operational');

  useEffect(() => {
    fetchSystemStatus();
    const interval = setInterval(fetchSystemStatus, 30000); // Update every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const fetchSystemStatus = () => {
    // Simulate real-time system status data
    const mockServices: ServiceStatus[] = [
      {
        name: 'Trading Platform',
        status: 'operational',
        lastUpdated: new Date().toISOString(),
        uptime: '99.9%',
        responseTime: '120ms',
        description: 'Main trading interface and order execution'
      },
      {
        name: 'Market Data Feed',
        status: 'operational',
        lastUpdated: new Date().toISOString(),
        uptime: '99.8%',
        responseTime: '45ms',
        description: 'Real-time market data and price feeds'
      },
      {
        name: 'Portfolio Analytics',
        status: 'operational',
        lastUpdated: new Date().toISOString(),
        uptime: '99.7%',
        responseTime: '200ms',
        description: 'Portfolio analysis and risk calculations'
      },
      {
        name: 'User Authentication',
        status: 'operational',
        lastUpdated: new Date().toISOString(),
        uptime: '99.9%',
        responseTime: '80ms',
        description: 'Login and user session management'
      },
      {
        name: 'Payment Processing',
        status: 'operational',
        lastUpdated: new Date().toISOString(),
        uptime: '99.6%',
        responseTime: '300ms',
        description: 'Payment gateway and transaction processing'
      },
      {
        name: 'Academy Platform',
        status: 'operational',
        lastUpdated: new Date().toISOString(),
        uptime: '99.5%',
        responseTime: '150ms',
        description: 'Educational content and course delivery'
      },
      {
        name: 'Mobile API',
        status: 'degraded',
        lastUpdated: new Date().toISOString(),
        uptime: '98.2%',
        responseTime: '450ms',
        description: 'Mobile application backend services'
      },
      {
        name: 'Notification System',
        status: 'operational',
        lastUpdated: new Date().toISOString(),
        uptime: '99.4%',
        responseTime: '100ms',
        description: 'Email and push notification delivery'
      }
    ];

    const mockIncidents: Incident[] = [
      {
        id: '1',
        title: 'Mobile API Performance Degradation',
        status: 'monitoring',
        severity: 'minor',
        createdAt: '2024-01-15T14:30:00Z',
        updatedAt: '2024-01-15T16:45:00Z',
        description: 'We are experiencing slower response times on our mobile API endpoints.',
        updates: [
          {
            timestamp: '2024-01-15T16:45:00Z',
            status: 'monitoring',
            message: 'Performance has improved. We continue to monitor the situation closely.'
          },
          {
            timestamp: '2024-01-15T15:20:00Z',
            status: 'identified',
            message: 'Issue identified as increased database load. Implementing optimization measures.'
          },
          {
            timestamp: '2024-01-15T14:30:00Z',
            status: 'investigating',
            message: 'We are investigating reports of slower mobile app performance.'
          }
        ]
      }
    ];

    setServices(mockServices);
    setIncidents(mockIncidents);
    
    // Determine overall status
    const hasOutage = mockServices.some(s => s.status === 'outage');
    const hasDegraded = mockServices.some(s => s.status === 'degraded');
    
    if (hasOutage) {
      setOverallStatus('outage');
    } else if (hasDegraded) {
      setOverallStatus('degraded');
    } else {
      setOverallStatus('operational');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'operational':
        return 'text-green-400 bg-green-400/20 border-green-400/30';
      case 'degraded':
        return 'text-yellow-400 bg-yellow-400/20 border-yellow-400/30';
      case 'outage':
        return 'text-red-400 bg-red-400/20 border-red-400/30';
      default:
        return 'text-gray-400 bg-gray-400/20 border-gray-400/30';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'operational':
        return 'ri-check-line';
      case 'degraded':
        return 'ri-alert-line';
      case 'outage':
        return 'ri-close-line';
      default:
        return 'ri-question-line';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'minor':
        return 'text-blue-400 bg-blue-400/20 border-blue-400/30';
      case 'major':
        return 'text-orange-400 bg-orange-400/20 border-orange-400/30';
      case 'critical':
        return 'text-red-400 bg-red-400/20 border-red-400/30';
      default:
        return 'text-gray-400 bg-gray-400/20 border-gray-400/30';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <Header />

      <div className="pt-32 pb-16">
        <div className="container mx-auto px-6">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              System <span className="text-yellow-400">Status</span>
            </h1>
            <div className={`inline-flex items-center space-x-2 px-6 py-3 rounded-full border ${getStatusColor(overallStatus)}`}>
              <i className={`${getStatusIcon(overallStatus)} text-xl`}></i>
              <span className="font-semibold text-lg capitalize">{overallStatus === 'operational' ? 'All Systems Operational' : overallStatus}</span>
            </div>
            <p className="text-gray-400 mt-4 max-w-2xl mx-auto">
              Real-time status of CMV Finance platform services and infrastructure
            </p>
          </div>

          {/* Current Incidents */}
          {incidents.filter(i => i.status !== 'resolved').length > 0 && (
            <div className="mb-12">
              <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
                <i className="ri-alert-line text-yellow-400 mr-3"></i>
                Active Incidents
              </h2>
              <div className="space-y-4">
                {incidents.filter(i => i.status !== 'resolved').map((incident) => (
                  <div key={incident.id} className="bg-gray-900 rounded-xl p-6 border border-gray-700/50">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${getSeverityColor(incident.severity)}`}>
                            {incident.severity.toUpperCase()}
                          </span>
                          <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${getStatusColor(incident.status)}`}>
                            {incident.status.toUpperCase()}
                          </span>
                        </div>
                        <h3 className="text-white font-bold text-lg mb-2">{incident.title}</h3>
                        <p className="text-gray-400 mb-4">{incident.description}</p>
                      </div>
                      <div className="text-right text-sm text-gray-400">
                        <p>Started: {formatDate(incident.createdAt)}</p>
                        <p>Updated: {formatDate(incident.updatedAt)}</p>
                      </div>
                    </div>
                    
                    <div className="border-t border-gray-700 pt-4">
                      <h4 className="text-white font-semibold mb-3">Updates</h4>
                      <div className="space-y-3">
                        {incident.updates.map((update, index) => (
                          <div key={index} className="flex items-start space-x-3">
                            <div className="w-2 h-2 bg-yellow-400 rounded-full mt-2 flex-shrink-0"></div>
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-1">
                                <span className="text-yellow-400 font-semibold text-sm">{formatDate(update.timestamp)}</span>
                                <span className={`px-2 py-1 rounded text-xs font-semibold border ${getStatusColor(update.status)}`}>
                                  {update.status.toUpperCase()}
                                </span>
                              </div>
                              <p className="text-gray-300 text-sm">{update.message}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Services Status */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
              <i className="ri-server-line text-yellow-400 mr-3"></i>
              Services Status
            </h2>
            <div className="grid lg:grid-cols-2 gap-6">
              {services.map((service, index) => (
                <div key={index} className="bg-gray-900 rounded-xl p-6 border border-gray-700/50">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-white font-bold text-lg">{service.name}</h3>
                    <div className={`flex items-center space-x-2 px-3 py-1 rounded-full border ${getStatusColor(service.status)}`}>
                      <i className={`${getStatusIcon(service.status)}`}></i>
                      <span className="font-semibold text-sm capitalize">{service.status}</span>
                    </div>
                  </div>
                  <p className="text-gray-400 text-sm mb-4">{service.description}</p>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center">
                      <div className="text-green-400 font-bold text-lg">{service.uptime}</div>
                      <div className="text-gray-400 text-xs">Uptime</div>
                    </div>
                    <div className="text-center">
                      <div className="text-blue-400 font-bold text-lg">{service.responseTime}</div>
                      <div className="text-gray-400 text-xs">Response Time</div>
                    </div>
                    <div className="text-center">
                      <div className="text-gray-300 font-bold text-xs">
                        {formatDate(service.lastUpdated)}
                      </div>
                      <div className="text-gray-400 text-xs">Last Check</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Metrics Overview */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
              <i className="ri-bar-chart-line text-yellow-400 mr-3"></i>
              Platform Metrics
            </h2>
            <div className="grid md:grid-cols-4 gap-6">
              <div className="bg-gray-900 rounded-xl p-6 border border-gray-700/50 text-center">
                <div className="w-16 h-16 bg-green-400/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-check-line text-2xl text-green-400"></i>
                </div>
                <div className="text-green-400 font-bold text-2xl mb-2">99.7%</div>
                <div className="text-gray-400 text-sm">Overall Uptime</div>
              </div>

              <div className="bg-gray-900 rounded-xl p-6 border border-gray-700/50 text-center">
                <div className="w-16 h-16 bg-blue-400/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-time-line text-2xl text-blue-400"></i>
                </div>
                <div className="text-blue-400 font-bold text-2xl mb-2">145ms</div>
                <div className="text-gray-400 text-sm">Avg Response</div>
              </div>

              <div className="bg-gray-900 rounded-xl p-6 border border-gray-700/50 text-center">
                <div className="w-16 h-16 bg-purple-400/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-user-line text-2xl text-purple-400"></i>
                </div>
                <div className="text-purple-400 font-bold text-2xl mb-2">12.5K</div>
                <div className="text-gray-400 text-sm">Active Users</div>
              </div>

              <div className="bg-gray-900 rounded-xl p-6 border border-gray-700/50 text-center">
                <div className="w-16 h-16 bg-orange-400/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-exchange-line text-2xl text-orange-400"></i>
                </div>
                <div className="text-orange-400 font-bold text-2xl mb-2">2.3M</div>
                <div className="text-gray-400 text-sm">Daily Transactions</div>
              </div>
            </div>
          </div>

          {/* Status History */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
              <i className="ri-history-line text-yellow-400 mr-3"></i>
              Recent Incidents
            </h2>
            <div className="bg-gray-900 rounded-xl p-6 border border-gray-700/50">
              {incidents.length > 0 ? (
                <div className="space-y-4">
                  {incidents.map((incident) => (
                    <div key={incident.id} className="flex items-center justify-between py-3 border-b border-gray-700/50 last:border-b-0">
                      <div className="flex items-center space-x-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${getSeverityColor(incident.severity)}`}>
                          {incident.severity}
                        </span>
                        <div>
                          <h4 className="text-white font-medium">{incident.title}</h4>
                          <p className="text-gray-400 text-sm">{formatDate(incident.createdAt)}</p>
                        </div>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${getStatusColor(incident.status)}`}>
                        {incident.status}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <i className="ri-check-line text-4xl text-green-400 mb-4"></i>
                  <p className="text-gray-400">No recent incidents. All systems operating normally.</p>
                </div>
              )}
            </div>
          </div>

          {/* Subscribe to Updates */}
          <div className="bg-gradient-to-r from-yellow-400/10 to-yellow-500/10 rounded-2xl p-8 border border-yellow-500/20 text-center">
            <h2 className="text-2xl font-bold text-white mb-4">Stay Updated</h2>
            <p className="text-gray-400 mb-6">
              Subscribe to receive notifications about system status updates and planned maintenance.
            </p>
            <div className="flex justify-center space-x-4">
              <button className="px-6 py-3 bg-yellow-400 text-black rounded-lg font-semibold hover:bg-yellow-500 transition-colors cursor-pointer whitespace-nowrap">
                <i className="ri-notification-line mr-2"></i>
                Subscribe to Updates
              </button>
              <button className="px-6 py-3 border border-gray-600 text-white rounded-lg hover:border-gray-500 transition-colors cursor-pointer whitespace-nowrap">
                <i className="ri-rss-line mr-2"></i>
                RSS Feed
              </button>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}