
'use client';

import { useState, useEffect, Suspense } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { verifyEmailCode, resendVerificationCode } from '../../lib/userAuth';

function VerifyEmailContent() {
  const [verificationCode, setVerificationCode] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [email, setEmail] = useState('');
  const [resendLoading, setResendLoading] = useState(false);
  const [resendSuccess, setResendSuccess] = useState(false);
  const [timeLeft, setTimeLeft] = useState(600);

  const router = useRouter();
  const searchParams = useSearchParams();

  useEffect(() => {
    const emailParam = searchParams.get('email');
    if (emailParam) {
      setEmail(decodeURIComponent(emailParam));
    } else {
      router.push('/auth/register');
    }
  }, [searchParams, router]);

  useEffect(() => {
    const emailParam = searchParams.get('email');
    if (emailParam) {
      setEmail(decodeURIComponent(emailParam));
    } else {
      router.push('/auth/register');
    }
  }, [searchParams, router]);

  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [timeLeft]);

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    if (verificationCode.length !== 6) {
      setError('Le code doit contenir 6 chiffres');
      setLoading(false);
      return;
    }

    const result = verifyEmailCode(email, verificationCode);

    if (result.success) {
      setSuccess(true);
      setTimeout(() => {
        router.push('/auth/login');
      }, 2000);
    } else {
      setError(result.error || 'Erreur lors de la vérification');
    }

    setLoading(false);
  };

  const handleResendCode = async () => {
    setResendLoading(true);
    setError('');

    const result = resendVerificationCode(email);

    if (result.success) {
      setResendSuccess(true);
      setTimeLeft(600);
      setTimeout(() => setResendSuccess(false), 3000);
    } else {
      setError(result.error || 'Erreur lors du renvoi du code');
    }

    setResendLoading(false);
  };

  const handleCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '').slice(0, 6);
    setVerificationCode(value);
  };

  if (success) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center px-4">
        <div className="w-full max-w-md">
          <div className="bg-gray-900 p-8 rounded-xl border border-green-500/20 text-center">
            <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-check-line text-2xl text-green-400"></i>
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">Email vérifié !</h2>
            <p className="text-green-400 mb-4">
              Votre compte a été activé avec succès.
            </p>
            <p className="text-gray-400 text-sm">
              Redirection vers la page de connexion...
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-md">
        <div className="bg-gray-900 p-8 rounded-xl border border-yellow-500/20">
          <div className="text-center mb-8">
            <Link href="/" className="inline-block">
              <div className="text-2xl font-bold text-yellow-400 mb-4" style={{ fontFamily: 'Pacifico, serif' }}>
                CMV FINANCE
              </div>
            </Link>
            <h1 className="text-2xl font-bold text-white mb-2">Vérification Email</h1>
            <p className="text-gray-400 mb-4">
              Saisissez le code de vérification envoyé à :
            </p>
            <p className="text-yellow-400 font-semibold">{email}</p>
          </div>

          <form onSubmit={handleVerify} className="space-y-6" id="email-verification-form">
            <div>
              <label className="block text-gray-400 text-sm mb-2">Code de vérification</label>
              <input
                type="text"
                name="verificationCode"
                value={verificationCode}
                onChange={handleCodeChange}
                className="w-full p-4 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-500 focus:outline-none text-center text-2xl font-mono tracking-widest"
                placeholder="000000"
                maxLength={6}
                required
              />
              <p className="text-xs text-gray-500 mt-2 text-center">
                Saisissez le code à 6 chiffres reçu par email
              </p>
            </div>

            {timeLeft > 0 && (
              <div className="bg-blue-500/10 p-3 rounded-lg border border-blue-500/20 text-center">
                <p className="text-blue-400 text-sm">
                  <i className="ri-time-line mr-2"></i>
                  Code valide pendant : <span className="font-mono font-bold">{formatTime(timeLeft)}</span>
                </p>
              </div>
            )}

            {error && (
              <div className="text-red-400 text-sm text-center bg-red-500/10 p-3 rounded-lg border border-red-500/20">
                {error}
              </div>
            )}

            {resendSuccess && (
              <div className="text-green-400 text-sm text-center bg-green-500/10 p-3 rounded-lg border border-green-500/20">
                Nouveau code envoyé avec succès !
              </div>
            )}

            <button
              type="submit"
              disabled={loading || verificationCode.length !== 6}
              className="w-full bg-yellow-500 hover:bg-yellow-600 text-black py-3 rounded-lg font-semibold transition-colors disabled:opacity-50 whitespace-nowrap cursor-pointer"
            >
              {loading ? 'Vérification...' : 'Vérifier le code'}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-400 text-sm mb-4">
              Vous n'avez pas reçu le code ?
            </p>
            <button
              onClick={handleResendCode}
              disabled={resendLoading || timeLeft > 540}
              className="text-yellow-400 hover:text-yellow-300 text-sm cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {resendLoading ? 'Envoi...' : timeLeft > 540 ? `Renvoyer dans ${formatTime(timeLeft - 540)}` : 'Renvoyer le code'}
            </button>
          </div>

          <div className="mt-6 text-center">
            <Link href="/auth/register" className="text-gray-400 hover:text-yellow-400 text-sm cursor-pointer">
              ← Retour à l'inscription
            </Link>
          </div>
        </div>

        <div className="mt-6 p-4 bg-blue-500/10 rounded-lg border border-blue-500/20">
          <p className="text-blue-400 text-sm text-center">
            <strong>Mode démonstration :</strong><br />
            Le code de vérification s'affiche dans la console de développement (F12)
          </p>
        </div>
      </div>
    </div>
  );
}

function LoadingFallback() {
  return (
    <div className="min-h-screen bg-black flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="bg-gray-900 p-8 rounded-xl border border-yellow-500/20 text-center">
          <div className="animate-spin w-8 h-8 border-2 border-yellow-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-400">Chargement...</p>
        </div>
      </div>
    </div>
  );
}

export default function VerifyEmailPage() {
  return (
    <Suspense fallback={<LoadingFallback />}>
      <VerifyEmailContent />
    </Suspense>
  );
}
