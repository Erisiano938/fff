
'use client';

import { useState, useEffect } from 'react';

export default function IndicatorMarketplace() {
  const [selectedCategory, setSelectedCategory] = useState('Tous');
  const [sortBy, setSortBy] = useState('Popularité');
  const [indicators, setIndicators] = useState([]);

  useEffect(() => {
    // Charger les indicateurs depuis le localStorage
    const loadIndicators = () => {
      const savedIndicators = localStorage.getItem('cmv_indicators');
      if (savedIndicators) {
        const indicatorData = JSON.parse(savedIndicators);
        
        // Adapter le format pour le composant marketplace
        const formattedIndicators = indicatorData.map(ind => ({
          name: ind.name,
          developer: ind.author,
          category: getCategoryLabel(ind.category),
          price: `${ind.price}€`,
          rating: (ind.accuracy / 20 + 3).toFixed(1), // Convertir accuracy en rating
          sales: ind.downloads.toString(),
          status: ind.status,
          image: ind.imageUrl || getDefaultImageByCategory(ind.category)
        }));
        
        setIndicators(formattedIndicators);
      } else {
        // Données par défaut si aucun indicateur sauvegardé
        setIndicators(getDefaultIndicators());
      }
    };

    loadIndicators();

    // Écouter les changements du localStorage
    const handleStorageChange = () => {
      loadIndicators();
    };

    window.addEventListener('storage', handleStorageChange);
    
    // Également écouter les changements personnalisés
    window.addEventListener('indicatorsUpdated', handleStorageChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('indicatorsUpdated', handleStorageChange);
    };
  }, []);

  const getCategoryLabel = (category) => {
    const categoryMap = {
      'trend': 'Tendance',
      'momentum': 'Oscillateurs',
      'volume': 'Volume',
      'levels': 'Support/Résistance',
      'flow': 'Signaux'
    };
    return categoryMap[category] || 'Technique';
  };

  const getDefaultImageByCategory = (category) => {
    const imageMap = {
      'trend': 'https://readdy.ai/api/search-image?query=Trading%20trend%20indicator%20with%20golden%20theme%2C%20professional%20dark%20interface%20showing%20trend%20analysis&width=300&height=200&seq=trend_default&orientation=landscape',
      'momentum': 'https://readdy.ai/api/search-image?query=RSI%20momentum%20oscillator%20indicator%20with%20dark%20theme%20and%20golden%20accents%2C%20professional%20trading%20interface&width=300&height=200&seq=momentum_default&orientation=landscape',
      'volume': 'https://readdy.ai/api/search-image?query=Volume%20analysis%20indicator%20with%20professional%20dark%20interface%2C%20golden%20volume%20bars%20and%20trading%20metrics&width=300&height=200&seq=volume_default&orientation=landscape',
      'levels': 'https://readdy.ai/api/search-image?query=Support%20resistance%20levels%20indicator%20with%20golden%20lines%20on%20dark%20trading%20chart%2C%20professional%20analysis%20tool&width=300&height=200&seq=levels_default&orientation=landscape',
      'flow': 'https://readdy.ai/api/search-image?query=Trading%20signals%20indicator%20with%20professional%20dark%20interface%2C%20golden%20signal%20arrows%20and%20market%20analysis&width=300&height=200&seq=flow_default&orientation=landscape'
    };
    return imageMap[category] || 'https://readdy.ai/api/search-image?query=Professional%20trading%20indicator%20with%20dark%20theme%20and%20golden%20accents&width=300&height=200&seq=default_indicator&orientation=landscape';
  };

  const getDefaultIndicators = () => [
    {
      name: 'SuperTrend Advanced',
      developer: 'TechTrader Pro',
      category: 'Tendance',
      price: '35€',
      rating: '4.7',
      sales: '1,234',
      status: 'active',
      image: 'https://readdy.ai/api/search-image?query=SuperTrend%20indicator%20chart%20with%20professional%20trading%20interface%2C%20dark%20theme%20with%20golden%20accents%20showing%20trend%20following%20signals%20and%20price%20action&width=300&height=200&seq=market1&orientation=landscape'
    }
  ];

  const categories = ['Tous', 'Tendance', 'Oscillateurs', 'Volume', 'Patterns', 'Signaux'];
  const sortOptions = ['Popularité', 'Prix croissant', 'Prix décroissant', 'Note', 'Récents'];

  // Filtrer les indicateurs actifs seulement
  const activeIndicators = indicators.filter(ind => ind.status === 'active');
  
  const filteredIndicators = selectedCategory === 'Tous' 
    ? activeIndicators 
    : activeIndicators.filter(indicator => indicator.category === selectedCategory);

  return (
    <section className="py-16 bg-gray-900">
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="lg:w-1/4">
            <div className="bg-black/50 p-6 rounded-xl border border-yellow-500/20 mb-6">
              <h3 className="text-xl font-bold text-white mb-4">Filtres</h3>
              
              <div className="mb-6">
                <label className="block text-gray-400 text-sm mb-2">Catégorie</label>
                <div className="space-y-2">
                  {categories.map((category, index) => (
                    <button
                      key={index}
                      onClick={() => setSelectedCategory(category)}
                      className={`w-full text-left p-2 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                        selectedCategory === category 
                          ? 'bg-yellow-500/20 text-yellow-400' 
                          : 'text-gray-400 hover:bg-gray-800'
                      }`}
                    >
                      {category}
                    </button>
                  ))}
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-gray-400 text-sm mb-2">Trier par</label>
                <select 
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none pr-8"
                >
                  {sortOptions.map((option, index) => (
                    <option key={index} value={option}>{option}</option>
                  ))}
                </select>
              </div>

              <div className="mb-6">
                <label className="block text-gray-400 text-sm mb-2">Prix</label>
                <div className="space-y-2">
                  <label className="flex items-center text-gray-400">
                    <input type="checkbox" className="mr-2" />
                    Gratuit
                  </label>
                  <label className="flex items-center text-gray-400">
                    <input type="checkbox" className="mr-2" />
                    0€ - 50€
                  </label>
                  <label className="flex items-center text-gray-400">
                    <input type="checkbox" className="mr-2" />
                    50€ - 100€
                  </label>
                  <label className="flex items-center text-gray-400">
                    <input type="checkbox" className="mr-2" />
                    100€+
                  </label>
                </div>
              </div>
            </div>

            <div className="bg-black/50 p-6 rounded-xl border border-yellow-500/20">
              <h3 className="text-xl font-bold text-white mb-4">Devenir Vendeur</h3>
              <p className="text-gray-400 text-sm mb-4">
                Vendez vos propres indicateurs et générez des revenus passifs.
              </p>
              <button className="w-full bg-yellow-500 text-black px-4 py-2 rounded-lg font-semibold hover:bg-yellow-400 transition-colors cursor-pointer whitespace-nowrap">
                Commencer
              </button>
            </div>
          </div>

          <div className="lg:w-3/4">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-white">
                {filteredIndicators.length} indicateurs trouvés
              </h2>
              <div className="flex gap-2">
                <button className="p-2 bg-gray-800 text-gray-400 rounded-lg hover:bg-gray-700 cursor-pointer">
                  <i className="ri-layout-grid-line"></i>
                </button>
                <button className="p-2 bg-yellow-500/20 text-yellow-400 rounded-lg cursor-pointer">
                  <i className="ri-layout-row-line"></i>
                </button>
              </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredIndicators.map((indicator, index) => (
                <div key={index} className="bg-black/50 rounded-xl overflow-hidden border border-yellow-500/20 hover:border-yellow-500/40 transition-all duration-300 hover:scale-105 cursor-pointer">
                  <div 
                    className="h-40 bg-cover bg-center"
                    style={{ backgroundImage: `url('${indicator.image}')` }}
                  />
                  <div className="p-4">
                    <h3 className="text-lg font-bold text-white mb-1">{indicator.name}</h3>
                    <p className="text-gray-400 text-sm mb-2">Par {indicator.developer}</p>
                    
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center text-yellow-400 text-sm">
                        <i className="ri-star-fill mr-1"></i>
                        {indicator.rating}
                      </div>
                      <span className="text-gray-500 text-sm">{indicator.sales} ventes</span>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="text-xl font-bold text-yellow-400">{indicator.price}</div>
                      <div className="flex items-center gap-2">
                        <div className="flex items-center text-xs text-gray-400">
                          <img 
                            src="https://readdy.ai/api/search-image?query=TradingView%20logo%20on%20dark%20background%2C%20professional%20trading%20platform%20logo%20with%20clean%20design&width=60&height=20&seq=tradingview_logo&orientation=landscape" 
                            alt="TradingView" 
                            className="h-4 w-auto mr-1"
                          />
                          <span>TradingView</span>
                        </div>
                        <button className="bg-yellow-500 text-black px-4 py-1 rounded-lg font-semibold hover:bg-yellow-400 transition-colors cursor-pointer whitespace-nowrap text-sm">
                          Acheter
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {filteredIndicators.length === 0 && (
              <div className="text-center py-12">
                <div className="w-24 h-24 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-search-line text-3xl text-gray-500"></i>
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Aucun indicateur trouvé</h3>
                <p className="text-gray-400">Essayez de modifier vos filtres de recherche</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
