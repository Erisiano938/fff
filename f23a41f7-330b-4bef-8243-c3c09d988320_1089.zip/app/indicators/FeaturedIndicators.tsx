
'use client';

import { useState, useEffect } from 'react';

export default function FeaturedIndicators() {
  const [showModal, setShowModal] = useState(false);
  const [selectedIndicator, setSelectedIndicator] = useState(null);
  const [featuredIndicators, setFeaturedIndicators] = useState([]);

  useEffect(() => {
    // Charger les indicateurs depuis le localStorage
    const loadIndicators = () => {
      const savedIndicators = localStorage.getItem('cmv_indicators');
      if (savedIndicators) {
        const indicators = JSON.parse(savedIndicators);
        // Prendre seulement les 3 premiers indicateurs actifs pour la section featured
        const activeIndicators = indicators.filter(ind => ind.status === 'active').slice(0, 3);
        
        // Adapter le format pour le composant
        const formattedIndicators = activeIndicators.map(ind => ({
          name: ind.name,
          developer: ind.author,
          category: getCategoryLabel(ind.category),
          rating: '4.8',
          reviews: ind.downloads.toString(),
          price: `${ind.price}€`,
          description: ind.description,
          longDescription: `${ind.description} Cet indicateur professionnel offre des performances exceptionnelles avec une précision de ${ind.accuracy}% et plus de ${ind.downloads} téléchargements.`,
          features: getFeaturesByCategory(ind.category),
          technicalSpecs: {
            timeframes: ['1M', '5M', '15M', '1H', '4H', '1D', '1W'],
            markets: ['Forex', 'Crypto', 'Actions', 'Indices', 'Matières premières'],
            alerts: ['Pop-up', 'Email', 'SMS', 'Webhook'],
            languages: ['Français', 'Anglais', 'Espagnol', 'Allemand']
          },
          performance: {
            winRate: `${ind.accuracy}%`,
            avgProfit: '+145 pips/mois',
            maxDrawdown: '12%',
            signals: '15-25/mois'
          },
          screenshots: [
            ind.imageUrl || 'https://readdy.ai/api/search-image?query=Professional%20trading%20indicator%20interface%20showing%20buy%20sell%20signals%2C%20dark%20theme%20with%20golden%20accents%2C%20sophisticated%20technical%20analysis%20tool&width=800&height=450&seq=screen1&orientation=landscape',
            'https://readdy.ai/api/search-image?query=Trading%20indicator%20settings%20and%20configuration%20panel%2C%20professional%20dark%20themed%20interface%20with%20golden%20accents%20showing%20customizable%20parameters&width=800&height=450&seq=screen2&orientation=landscape',
            'https://readdy.ai/api/search-image?query=Trading%20indicator%20performance%20statistics%20dashboard%20showing%20win%20rate%20and%20profit%20metrics%2C%20elegant%20dark%20interface%20with%20golden%20highlights&width=800&height=450&seq=screen3&orientation=landscape'
          ],
          image: ind.imageUrl || 'https://readdy.ai/api/search-image?query=Professional%20trading%20indicator%20chart%20display%20with%20clean%20golden%20and%20dark%20theme%2C%20sophisticated%20interface%20showing%20trend%20lines%20and%20signals&width=400&height=250&seq=default&orientation=landscape'
        }));
        
        setFeaturedIndicators(formattedIndicators);
      } else {
        // Données par défaut si aucun indicateur sauvegardé
        setFeaturedIndicators(getDefaultIndicators());
      }
    };

    loadIndicators();

    // Écouter les changements du localStorage
    const handleStorageChange = () => {
      loadIndicators();
    };

    window.addEventListener('storage', handleStorageChange);
    
    // Également écouter les changements personnalisés
    window.addEventListener('indicatorsUpdated', handleStorageChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('indicatorsUpdated', handleStorageChange);
    };
  }, []);

  const getCategoryLabel = (category) => {
    const categoryMap = {
      'trend': 'Tendance',
      'momentum': 'Momentum',
      'volume': 'Volume',
      'levels': 'Support/Résistance',
      'flow': 'Flow Analysis'
    };
    return categoryMap[category] || 'Technique';
  };

  const getFeaturesByCategory = (category) => {
    const featureMap = {
      'trend': ['Signaux Buy/Sell', 'Multi-timeframe', 'Alertes personnalisées'],
      'momentum': ['Oscillateur RSI', 'Divergences', 'Signaux momentum'],
      'volume': ['Volume Profile', 'POC Detection', 'Value Area Analysis'],
      'levels': ['Support/Résistance', 'Niveaux automatiques', 'Zones de prix'],
      'flow': ['Institution Tracking', 'Order Flow', 'Market Structure']
    };
    return featureMap[category] || ['Signaux avancés', 'Multi-timeframe', 'Alertes'];
  };

  const getDefaultIndicators = () => [
    {
      name: 'CMV Trend Master Pro',
      developer: 'Trading Expert CMV',
      category: 'Tendance',
      rating: '4.9',
      reviews: '2,450',
      price: '49€',
      originalPrice: '79€',
      description: 'Indicateur de tendance avancé avec signaux d\'entrée et de sortie précis',
      longDescription: 'Le CMV Trend Master Pro est un indicateur révolutionnaire qui combine plusieurs algorithmes d\'analyse technique pour identifier les tendances de marché avec une précision exceptionnelle.',
      features: ['Signaux Buy/Sell', 'Multi-timeframe', 'Alertes personnalisées', 'Filtres anti-faux signaux'],
      technicalSpecs: {
        timeframes: ['1M', '5M', '15M', '1H', '4H', '1D', '1W'],
        markets: ['Forex', 'Crypto', 'Actions', 'Indices', 'Matières premières'],
        alerts: ['Pop-up', 'Email', 'SMS', 'Webhook'],
        languages: ['Français', 'Anglais', 'Espagnol', 'Allemand']
      },
      performance: {
        winRate: '78%',
        avgProfit: '+145 pips/mois',
        maxDrawdown: '12%',
        signals: '15-25/mois'
      },
      screenshots: [
        'https://readdy.ai/api/search-image?query=Professional%20CMV%20Trend%20Master%20Pro%20indicator%20interface%20showing%20buy%20sell%20signals%20on%20trading%20chart%2C%20dark%20theme%20with%20golden%20trend%20lines%20and%20clear%20entry%20exit%20points&width=800&height=450&seq=cmv1&orientation=landscape',
        'https://readdy.ai/api/search-image?query=CMV%20Trend%20Master%20Pro%20settings%20and%20configuration%20panel%2C%20professional%20dark%20themed%20interface%20with%20golden%20accents%20showing%20customizable%20parameters&width=800&height=450&seq=cmv2&orientation=landscape',
        'https://readdy.ai/api/search-image?query=CMV%20Trend%20Master%20Pro%20performance%20statistics%20dashboard%20showing%20win%20rate%2C%20profit%20metrics%20and%20signal%20history&width=800&height=450&seq=cmv3&orientation=landscape'
      ],
      image: 'https://readdy.ai/api/search-image?query=Professional%20trend%20indicator%20chart%20display%20with%20clean%20golden%20and%20dark%20theme%2C%20sophisticated%20trading%20interface%20showing%20trend%20lines%20and%20buy%20sell%20signals&width=400&height=250&seq=indicator1&orientation=landscape'
    }
  ];

  const handleIndicatorClick = (indicator) => {
    setSelectedIndicator(indicator);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setTimeout(() => {
      setSelectedIndicator(null);
    }, 300);
  };

  return (
    <>
      <section className="py-16 bg-black">
        <div className="container mx-auto px-6">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-4xl font-bold text-white mb-4">
                Indicateurs <span className="text-yellow-400">Populaires</span>
              </h2>
              <p className="text-xl text-gray-400">
                Les indicateurs les plus performants de notre marketplace.
              </p>
            </div>
            <button className="text-yellow-400 hover:text-yellow-300 font-semibold cursor-pointer whitespace-nowrap">
              Voir tous les indicateurs →
            </button>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredIndicators.map((indicator, index) => (
              <div 
                key={index} 
                onClick={() => handleIndicatorClick(indicator)}
                className="bg-gray-900/50 rounded-xl overflow-hidden border border-yellow-500/20 hover:border-yellow-500/40 transition-all duration-300 hover:scale-105 cursor-pointer"
              >
                <div 
                  className="h-48 bg-cover bg-center"
                  style={{ backgroundImage: `url('${indicator.image}')` }}
                />
                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <span className="px-3 py-1 bg-yellow-500/20 text-yellow-400 rounded-full text-xs font-semibold">
                      {indicator.category}
                    </span>
                    <div className="flex items-center text-yellow-400 text-sm">
                      <i className="ri-star-fill mr-1"></i>
                      {indicator.rating}
                      <span className="text-gray-500 ml-1">({indicator.reviews})</span>
                    </div>
                  </div>
                  
                  <h3 className="text-xl font-bold text-white mb-2">{indicator.name}</h3>
                  <p className="text-gray-400 text-sm mb-3">Par {indicator.developer}</p>
                  <p className="text-gray-400 text-sm mb-4 leading-relaxed">{indicator.description}</p>
                  
                  <div className="mb-4">
                    <div className="text-sm text-gray-500 mb-2">Fonctionnalités:</div>
                    <div className="flex flex-wrap gap-2">
                      {indicator.features.map((feature, idx) => (
                        <span key={idx} className="px-2 py-1 bg-gray-800 text-gray-400 rounded text-xs">
                          {feature}
                        </span>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="text-2xl font-bold text-yellow-400">{indicator.price}</div>
                      {indicator.originalPrice && (
                        <div className="text-sm text-gray-500 line-through">{indicator.originalPrice}</div>
                      )}
                    </div>
                    <button className="bg-yellow-500 text-black px-6 py-2 rounded-lg font-semibold hover:bg-yellow-400 transition-colors cursor-pointer whitespace-nowrap">
                      Voir Détails
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Modal Détaillée */}
      {showModal && selectedIndicator && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 rounded-xl max-w-6xl w-full max-h-[95vh] overflow-y-auto border border-yellow-500/20">
            <div className="flex items-center justify-between p-6 border-b border-gray-800">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-yellow-500/20 rounded-xl flex items-center justify-center">
                  <i className="ri-line-chart-line text-2xl text-yellow-400"></i>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white">{selectedIndicator.name}</h3>
                  <div className="flex items-center space-x-4 text-sm text-gray-400">
                    <span>Par {selectedIndicator.developer}</span>
                    <div className="flex items-center text-yellow-400">
                      <i className="ri-star-fill mr-1"></i>
                      {selectedIndicator.rating} ({selectedIndicator.reviews} avis)
                    </div>
                  </div>
                </div>
              </div>
              <button 
                onClick={closeModal}
                className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-gray-800 transition-colors cursor-pointer"
              >
                <i className="ri-close-line text-xl text-gray-400 hover:text-white"></i>
              </button>
            </div>
            
            <div className="p-6 space-y-8">
              {selectedIndicator.longDescription && (
                <div>
                  <h4 className="text-xl font-bold text-white mb-4">Description Complète</h4>
                  <p className="text-gray-300 leading-relaxed">{selectedIndicator.longDescription}</p>
                </div>
              )}

              {selectedIndicator.screenshots && (
                <div>
                  <h4 className="text-xl font-bold text-white mb-4">Captures d'Écran</h4>
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {selectedIndicator.screenshots.map((screenshot, idx) => (
                      <div key={idx} className="rounded-lg overflow-hidden border border-gray-700">
                        <img
                          src={screenshot}
                          alt={`Capture ${idx + 1}`}
                          className="w-full h-48 object-cover hover:scale-105 transition-transform cursor-pointer"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {selectedIndicator.performance && (
                <div>
                  <h4 className="text-xl font-bold text-white mb-4">Performances</h4>
                  <div className="grid md:grid-cols-4 gap-4">
                    <div className="bg-black/30 p-4 rounded-lg border border-green-500/20">
                      <div className="text-2xl font-bold text-green-400">{selectedIndicator.performance.winRate}</div>
                      <div className="text-sm text-gray-400">Taux de Réussite</div>
                    </div>
                    <div className="bg-black/30 p-4 rounded-lg border border-yellow-500/20">
                      <div className="text-2xl font-bold text-yellow-400">{selectedIndicator.performance.avgProfit}</div>
                      <div className="text-sm text-gray-400">Profit Moyen</div>
                    </div>
                    <div className="bg-black/30 p-4 rounded-lg border border-red-500/20">
                      <div className="text-2xl font-bold text-red-400">{selectedIndicator.performance.maxDrawdown}</div>
                      <div className="text-sm text-gray-400">Drawdown Max</div>
                    </div>
                    <div className="bg-black/30 p-4 rounded-lg border border-blue-500/20">
                      <div className="text-2xl font-bold text-blue-400">{selectedIndicator.performance.signals}</div>
                      <div className="text-sm text-gray-400">Signaux/Mois</div>
                    </div>
                  </div>
                </div>
              )}

              {selectedIndicator.technicalSpecs && (
                <div>
                  <h4 className="text-xl font-bold text-white mb-4">Spécifications Techniques</h4>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="bg-black/30 p-6 rounded-lg border border-gray-700">
                      <h5 className="font-semibold text-white mb-3">Unités de Temps</h5>
                      <div className="flex flex-wrap gap-2">
                        {selectedIndicator.technicalSpecs.timeframes.map((tf, idx) => (
                          <span key={idx} className="px-3 py-1 bg-yellow-500/20 text-yellow-400 rounded-full text-sm">
                            {tf}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="bg-black/30 p-6 rounded-lg border border-gray-700">
                      <h5 className="font-semibold text-white mb-3">Marchés Compatibles</h5>
                      <div className="space-y-2">
                        {selectedIndicator.technicalSpecs.markets.map((market, idx) => (
                          <div key={idx} className="flex items-center space-x-2">
                            <i className="ri-check-line text-green-400"></i>
                            <span className="text-gray-300">{market}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="bg-black/30 p-6 rounded-lg border border-gray-700">
                      <h5 className="font-semibold text-white mb-3">Types d'Alertes</h5>
                      <div className="space-y-2">
                        {selectedIndicator.technicalSpecs.alerts.map((alert, idx) => (
                          <div key={idx} className="flex items-center space-x-2">
                            <i className="ri-notification-line text-blue-400"></i>
                            <span className="text-gray-300">{alert}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="bg-black/30 p-6 rounded-lg border border-gray-700">
                      <h5 className="font-semibold text-white mb-3">Langues Disponibles</h5>
                      <div className="space-y-2">
                        {selectedIndicator.technicalSpecs.languages.map((lang, idx) => (
                          <div key={idx} className="flex items-center space-x-2">
                            <i className="ri-global-line text-purple-400"></i>
                            <span className="text-gray-300">{lang}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="bg-gradient-to-r from-yellow-500/20 to-yellow-600/20 p-6 rounded-xl border border-yellow-500/30">
                <h4 className="text-xl font-bold text-white mb-4 flex items-center">
                  <i className="ri-gift-line text-yellow-400 mr-3"></i>
                  Offre Spéciale
                </h4>
                <p className="text-gray-300 mb-4">
                  🎯 Garantie satisfait ou remboursé 30 jours<br/>
                  📚 Formation vidéo incluse (valeur 29€)<br/>
                  🔄 Mises à jour gratuites à vie<br/>
                  💬 Support technique prioritaire
                </p>
              </div>

              <div className="flex items-center justify-between p-6 bg-black/30 rounded-xl border border-gray-700">
                <div className="flex items-center space-x-4">
                  <div>
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="text-3xl font-bold text-yellow-400">{selectedIndicator.price}</span>
                      {selectedIndicator.originalPrice && (
                        <>
                          <span className="text-lg text-gray-500 line-through">{selectedIndicator.originalPrice}</span>
                          <span className="px-2 py-1 bg-red-500 text-white text-xs rounded-full">
                            -38%
                          </span>
                        </>
                      )}
                    </div>
                    <div className="text-sm text-gray-400">Achat unique • Licence à vie</div>
                  </div>
                </div>
                <div className="flex space-x-4">
                  <button className="bg-gray-700 hover:bg-gray-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap">
                    Essai Gratuit 7j
                  </button>
                  <button className="bg-yellow-500 hover:bg-yellow-400 text-black px-8 py-3 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap">
                    <i className="ri-shopping-cart-line mr-2"></i>
                    Acheter Maintenant
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
