
'use client';

import { useState, useEffect } from 'react';

interface Indicator {
  id: string;
  name: string;
  author: string;
  price: number;
  category: string;
  description: string;
  accuracy: number;
  downloads: number;
  tags: string[];
  image: string;
  features: string[];
  active: boolean;
}

export default function IndicatorCategories() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [indicators, setIndicators] = useState<Indicator[]>([]);
  const [categories, setCategories] = useState([
    'Tendance',
    'Oscillateurs', 
    'Volume',
    'Support/Résistance',
    'Signaux'
  ]);

  useEffect(() => {
    // Charger les catégories personnalisées
    const storedCategories = localStorage.getItem('cmv_indicator_categories');
    if (storedCategories) {
      setCategories(JSON.parse(storedCategories));
    }

    // Charger les indicateurs
    const loadIndicators = () => {
      const storedIndicators = localStorage.getItem('cmv_indicators');
      if (storedIndicators) {
        const allIndicators = JSON.parse(storedIndicators);
        const activeIndicators = allIndicators.filter((indicator: Indicator) => indicator.active);
        setIndicators(activeIndicators);
      }
    };

    loadIndicators();

    // Écouter les mises à jour des catégories
    const handleCategoriesUpdate = (event: CustomEventInit) => {
      if (event.detail?.categories) {
        setCategories(event.detail.categories);
      }
    };

    // Écouter les mises à jour des indicateurs
    const handleIndicatorsUpdate = () => {
      loadIndicators();
    };

    window.addEventListener('categoriesUpdated', handleCategoriesUpdate);
    window.addEventListener('indicatorsUpdated', handleIndicatorsUpdate);

    return () => {
      window.removeEventListener('categoriesUpdated', handleCategoriesUpdate);
      window.removeEventListener('indicatorsUpdated', handleIndicatorsUpdate);
    };
  }, []);

  const getCategoryIndicators = (category: string) => {
    return indicators.filter(indicator => indicator.category === category);
  };

  const allCategories = [
    { id: 'all', name: 'Toutes les Catégories', icon: 'ri-apps-line' },
    ...categories.map(cat => ({
      id: cat,
      name: cat,
      icon: getCategoryIcon(cat)
    }))
  ];

  function getCategoryIcon(category: string) {
    const iconMap: { [key: string]: string } = {
      'Tendance': 'ri-trending-up-line',
      'Oscillateurs': 'ri-pulse-line',
      'Volume': 'ri-bar-chart-box-line',
      'Support/Résistance': 'ri-line-chart-line',
      'Signaux': 'ri-notification-3-line'
    };
    return iconMap[category] || 'ri-folder-line';
  }

  const filteredIndicators = selectedCategory === 'all' 
    ? indicators 
    : indicators.filter(indicator => indicator.category === selectedCategory);

  return (
    <section className="py-20 bg-gray-950">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-6">
            Catégories d'Indicateurs
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Explorez nos indicateurs organisés par spécialité pour trouver les outils parfaits pour votre stratégie de trading
          </p>
        </div>

        {/* Filtres de catégories */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {allCategories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-6 py-3 rounded-full font-medium transition-all whitespace-nowrap cursor-pointer ${
                selectedCategory === category.id
                  ? 'bg-yellow-500 text-black'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700 hover:text-white'
              }`}
            >
              <i className={`${category.icon} mr-2`}></i>
              {category.name}
              {category.id !== 'all' && (
                <span className="ml-2 px-2 py-1 bg-black/20 rounded-full text-xs">
                  {getCategoryIndicators(category.id).length}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Affichage par catégorie */}
        {selectedCategory === 'all' ? (
          <div className="space-y-16">
            {categories.map((category) => {
              const categoryIndicators = getCategoryIndicators(category);
              if (categoryIndicators.length === 0) return null;

              return (
                <div key={category}>
                  <div className="flex items-center mb-8">
                    <div className="w-12 h-12 bg-yellow-500/20 rounded-xl flex items-center justify-center mr-4">
                      <i className={`${getCategoryIcon(category)} text-2xl text-yellow-400`}></i>
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-white">{category}</h3>
                      <p className="text-gray-400">{categoryIndicators.length} indicateur{categoryIndicators.length > 1 ? 's' : ''} disponible{categoryIndicators.length > 1 ? 's' : ''}</p>
                    </div>
                  </div>
                  
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {categoryIndicators.map((indicator) => (
                      <div key={indicator.id} className="bg-gray-900 p-6 rounded-xl border border-yellow-500/20 hover:border-yellow-500/40 transition-all">
                        <div className="flex items-center justify-between mb-4">
                          <div className="w-12 h-12 bg-yellow-500/20 rounded-lg overflow-hidden">
                            {indicator.image ? (
                              <img 
                                src={indicator.image} 
                                alt={indicator.name}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center">
                                <i className={`${getCategoryIcon(indicator.category)} text-xl text-yellow-400`}></i>
                              </div>
                            )}
                          </div>
                          <div className="text-2xl font-bold text-yellow-400">
                            {indicator.price}€
                          </div>
                        </div>
                        
                        <h4 className="text-lg font-semibold text-white mb-2">
                          {indicator.name}
                        </h4>
                        
                        <p className="text-gray-400 text-sm mb-4">
                          Par {indicator.author}
                        </p>
                        
                        <p className="text-gray-300 text-sm mb-4 line-clamp-2">
                          {indicator.description}
                        </p>
                        
                        <div className="mb-4">
                          <div className="flex items-center justify-between text-sm mb-2">
                            <span className="text-gray-400">Précision</span>
                            <span className="text-white font-semibold">{indicator.accuracy}%</span>
                          </div>
                          <div className="w-full bg-gray-800 rounded-full h-2">
                            <div 
                              className="bg-green-500 h-2 rounded-full transition-all" 
                              style={{ width: `${indicator.accuracy}%` }}
                            ></div>
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="text-sm text-gray-400">
                            <i className="ri-download-line mr-1"></i>
                            {indicator.downloads.toLocaleString()}
                          </div>
                          <button className="bg-yellow-500 hover:bg-yellow-400 text-black px-4 py-2 rounded-lg font-semibold transition-colors text-sm whitespace-nowrap cursor-pointer">
                            Voir Détails
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredIndicators.map((indicator) => (
              <div key={indicator.id} className="bg-gray-900 p-6 rounded-xl border border-yellow-500/20 hover:border-yellow-500/40 transition-all">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-yellow-500/20 rounded-lg overflow-hidden">
                    {indicator.image ? (
                      <img 
                        src={indicator.image} 
                        alt={indicator.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <i className={`${getCategoryIcon(indicator.category)} text-xl text-yellow-400`}></i>
                      </div>
                    )}
                  </div>
                  <div className="text-2xl font-bold text-yellow-400">
                    {indicator.price}€
                  </div>
                </div>
                
                <h4 className="text-lg font-semibold text-white mb-2">
                  {indicator.name}
                </h4>
                
                <p className="text-gray-400 text-sm mb-4">
                  Par {indicator.author}
                </p>
                
                <p className="text-gray-300 text-sm mb-4 line-clamp-2">
                  {indicator.description}
                </p>
                
                <div className="mb-4">
                  <div className="flex items-center justify-between text-sm mb-2">
                    <span className="text-gray-400">Précision</span>
                    <span className="text-white font-semibold">{indicator.accuracy}%</span>
                  </div>
                  <div className="w-full bg-gray-800 rounded-full h-2">
                    <div 
                      className="bg-green-500 h-2 rounded-full transition-all" 
                      style={{ width: `${indicator.accuracy}%` }}
                    ></div>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="text-sm text-gray-400">
                    <i className="ri-download-line mr-1"></i>
                    {indicator.downloads.toLocaleString()}
                  </div>
                  <button className="bg-yellow-500 hover:bg-yellow-400 text-black px-4 py-2 rounded-lg font-semibold transition-colors text-sm whitespace-nowrap cursor-pointer">
                    Voir Détails
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {filteredIndicators.length === 0 && selectedCategory !== 'all' && (
          <div className="text-center py-16">
            <div className="w-24 h-24 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="ri-folder-open-line text-4xl text-gray-600"></i>
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">Aucun indicateur dans cette catégorie</h3>
            <p className="text-gray-400 mb-8">
              Cette catégorie ne contient pas encore d'indicateurs actifs.
            </p>
            <button
              onClick={() => setSelectedCategory('all')}
              className="bg-yellow-500 hover:bg-yellow-400 text-black px-6 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
            >
              Voir Tous les Indicateurs
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
