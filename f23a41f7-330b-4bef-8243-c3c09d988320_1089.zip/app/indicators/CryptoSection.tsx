
'use client';

import { useState, useEffect } from 'react';

interface CryptoData {
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  high24h: number;
  low24h: number;
  volume: number;
  icon: string;
}

interface CandleData {
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export default function CryptoSection() {
  const [selectedCrypto, setSelectedCrypto] = useState('BTCUSDT');
  const [selectedTimeframe, setSelectedTimeframe] = useState('1h');
  const [cryptoList, setCryptoList] = useState<CryptoData[]>([]);
  const [candleData, setCandleData] = useState<CandleData[]>([]);
  const [isLive, setIsLive] = useState(true);

  const timeframes = [
    { label: '1m', value: '1m' },
    { label: '5m', value: '5m' },
    { label: '15m', value: '15m' },
    { label: '1h', value: '1h' },
    { label: '4h', value: '4h' },
    { label: '1d', value: '1d' }
  ];

  const cryptoSymbols = [
    { symbol: 'BTCUSDT', name: 'Bitcoin', icon: 'ri-bit-coin-line' },
    { symbol: 'ETHUSDT', name: 'Ethereum', icon: 'ri-currency-line' },
    { symbol: 'BNBUSDT', name: 'BNB', icon: 'ri-money-dollar-circle-line' },
    { symbol: 'ADAUSDT', name: 'Cardano', icon: 'ri-coin-line' },
    { symbol: 'SOLUSDT', name: 'Solana', icon: 'ri-copper-coin-line' },
    { symbol: 'XRPUSDT', name: 'Ripple', icon: 'ri-money-cny-circle-line' }
  ];

  // Générer des données réalistes
  const generateCandleData = () => {
    const data: CandleData[] = [];
    let basePrice = selectedCrypto === 'BTCUSDT' ? 67420 : 
                   selectedCrypto === 'ETHUSDT' ? 3890 :
                   selectedCrypto === 'BNBUSDT' ? 612 :
                   selectedCrypto === 'ADAUSDT' ? 1.08 :
                   selectedCrypto === 'SOLUSDT' ? 189 : 0.68;

    const candleCount = 50;
    for (let i = 0; i < candleCount; i++) {
      const open = basePrice + (Math.random() - 0.5) * basePrice * 0.02;
      const variation = (Math.random() - 0.5) * basePrice * 0.015;
      const close = open + variation;
      const high = Math.max(open, close) + Math.random() * basePrice * 0.005;
      const low = Math.min(open, close) - Math.random() * basePrice * 0.005;
      
      const now = new Date();
      const timeMultiplier = selectedTimeframe === '1m' ? 1 : 
                           selectedTimeframe === '5m' ? 5 :
                           selectedTimeframe === '15m' ? 15 :
                           selectedTimeframe === '1h' ? 60 :
                           selectedTimeframe === '4h' ? 240 : 1440;
      
      now.setMinutes(now.getMinutes() - (candleCount - i) * timeMultiplier);
      
      data.push({
        time: selectedTimeframe === '1d' ? 
              now.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' }) :
              now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
        open: parseFloat(open.toFixed(selectedCrypto.includes('ADA') || selectedCrypto.includes('XRP') ? 4 : 2)),
        high: parseFloat(high.toFixed(selectedCrypto.includes('ADA') || selectedCrypto.includes('XRP') ? 4 : 2)),
        low: parseFloat(low.toFixed(selectedCrypto.includes('ADA') || selectedCrypto.includes('XRP') ? 4 : 2)),
        close: parseFloat(close.toFixed(selectedCrypto.includes('ADA') || selectedCrypto.includes('XRP') ? 4 : 2)),
        volume: Math.floor(Math.random() * 1000 + 500)
      });
      
      basePrice = close;
    }
    
    return data;
  };

  // Fonction pour récupérer les données de prix
  const fetchCryptoData = async () => {
    try {
      const promises = cryptoSymbols.map(async (crypto) => {
        const response = await fetch(`https://api.binance.com/api/v3/ticker/24hr?symbol=${crypto.symbol}`);
        if (response.ok) {
          const data = await response.json();
          return {
            symbol: crypto.symbol,
            name: crypto.name,
            price: parseFloat(data.lastPrice),
            change24h: parseFloat(data.priceChangePercent),
            high24h: parseFloat(data.highPrice),
            low24h: parseFloat(data.lowPrice),
            volume: parseFloat(data.volume),
            icon: crypto.icon
          };
        }
        return null;
      });

      const results = await Promise.all(promises);
      const validResults = results.filter(result => result !== null) as CryptoData[];
      setCryptoList(validResults);
    } catch (error) {
      console.log('Using fallback data');
      setCryptoList([
        { symbol: 'BTCUSDT', name: 'Bitcoin', price: 67420.50, change24h: 2.45, high24h: 68500, low24h: 65800, volume: 28450, icon: 'ri-bit-coin-line' },
        { symbol: 'ETHUSDT', name: 'Ethereum', price: 3890.25, change24h: 1.87, high24h: 3950, low24h: 3820, volume: 15680, icon: 'ri-currency-line' },
        { symbol: 'BNBUSDT', name: 'BNB', price: 612.80, change24h: 0.95, high24h: 625, low24h: 608, volume: 8920, icon: 'ri-money-dollar-circle-line' },
        { symbol: 'ADAUSDT', name: 'Cardano', price: 1.08, change24h: 3.12, high24h: 1.12, low24h: 1.04, volume: 12340, icon: 'ri-coin-line' },
        { symbol: 'SOLUSDT', name: 'Solana', price: 189.45, change24h: -1.23, high24h: 195, low24h: 186, volume: 5670, icon: 'ri-copper-coin-line' },
        { symbol: 'XRPUSDT', name: 'Ripple', price: 0.6789, change24h: 4.56, high24h: 0.69, low24h: 0.65, volume: 18900, icon: 'ri-money-cny-circle-line' }
      ]);
    }
  };

  // Composant graphique style TradingView
  const TradingViewChart = ({ data }: { data: CandleData[] }) => {
    if (data.length === 0) return null;

    const maxPrice = Math.max(...data.map(d => d.high));
    const minPrice = Math.min(...data.map(d => d.low));
    const priceRange = maxPrice - minPrice;
    const padding = priceRange * 0.1;
    const chartMax = maxPrice + padding;
    const chartMin = minPrice - padding;
    const chartRange = chartMax - chartMin;

    const getY = (price: number) => ((chartMax - price) / chartRange) * 400;
    const candleWidth = 8;
    const candleSpacing = 2;

    return (
      <div className="bg-black/50 rounded-xl p-6 border border-yellow-500/10">
        <div className="mb-4">
          <svg width="100%" height="450" viewBox="0 0 800 450" className="overflow-visible">
            {/* Grille */}
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#374151" strokeWidth="0.5" opacity="0.3"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
            
            {/* Lignes de prix horizontales */}
            {[0, 1, 2, 3, 4, 5].map((i) => {
              const price = chartMax - (chartRange * i / 5);
              const y = (i / 5) * 400;
              return (
                <g key={i}>
                  <line x1="0" y1={y} x2="800" y2={y} stroke="#4B5563" strokeWidth="0.5" opacity="0.7" />
                  <text x="810" y={y + 4} fill="#9CA3AF" fontSize="12" className="font-mono">
                    {price.toFixed(selectedCrypto.includes('ADA') || selectedCrypto.includes('XRP') ? 4 : 2)}
                  </text>
                </g>
              );
            })}

            {/* Chandeliers */}
            {data.map((candle, index) => {
              const isGreen = candle.close >= candle.open;
              const x = index * (candleWidth + candleSpacing) + candleWidth / 2;
              
              const openY = getY(candle.open);
              const closeY = getY(candle.close);
              const highY = getY(candle.high);
              const lowY = getY(candle.low);
              
              const bodyTop = Math.min(openY, closeY);
              const bodyHeight = Math.max(2, Math.abs(closeY - openY));

              return (
                <g key={index} className="cursor-pointer group">
                  {/* Mèche */}
                  <line
                    x1={x}
                    y1={highY}
                    x2={x}
                    y2={lowY}
                    stroke={isGreen ? '#10b981' : '#ef4444'}
                    strokeWidth="1"
                  />
                  
                  {/* Corps de la bougie */}
                  <rect
                    x={x - candleWidth/2}
                    y={bodyTop}
                    width={candleWidth}
                    height={bodyHeight}
                    fill={isGreen ? '#10b981' : '#ef4444'}
                    stroke={isGreen ? '#10b981' : '#ef4444'}
                    strokeWidth="1"
                    className="group-hover:opacity-80"
                  />
                  
                  {/* Zone invisible pour tooltip */}
                  <rect
                    x={x - (candleWidth + candleSpacing)/2}
                    y="0"
                    width={candleWidth + candleSpacing}
                    height="400"
                    fill="transparent"
                    className="group-hover:fill-yellow-500/5"
                  >
                    <title>
                      {`${candle.time}
Ouverture: ${candle.open}
Plus Haut: ${candle.high}
Plus Bas: ${candle.low}
Clôture: ${candle.close}
Volume: ${candle.volume}`}
                    </title>
                  </rect>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Échelle de temps */}
        <div className="flex justify-between text-xs text-gray-400 px-2">
          {data.filter((_, i) => i % 8 === 0).map((candle, i) => (
            <span key={i}>{candle.time}</span>
          ))}
        </div>
      </div>
    );
  };

  useEffect(() => {
    fetchCryptoData();
    setCandleData(generateCandleData());

    const interval = setInterval(() => {
      if (isLive) {
        fetchCryptoData();
        setCandleData(generateCandleData());
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [selectedCrypto, selectedTimeframe, isLive]);

  const selectedCryptoData = cryptoList.find(crypto => crypto.symbol === selectedCrypto);

  return (
    <section className="py-16 bg-gray-900">
      <div className="container mx-auto px-6">
        <div className="bg-black/50 rounded-xl border border-yellow-500/20 overflow-hidden">
          {/* Header */}
          <div className="bg-gray-800/50 p-6 border-b border-yellow-500/20">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-2xl font-bold text-white flex items-center">
                <i className="ri-line-chart-line text-yellow-400 mr-3"></i>
                Graphique Crypto TradingView
              </h3>
              <div className="flex items-center space-x-4">
                <div className={`flex items-center space-x-2 text-sm ${isLive ? 'text-green-400' : 'text-gray-400'}`}>
                  <div className={`w-2 h-2 rounded-full ${isLive ? 'bg-green-400 animate-pulse' : 'bg-gray-400'}`}></div>
                  <span>{isLive ? 'Live' : 'Pause'}</span>
                </div>
                <button
                  onClick={() => setIsLive(!isLive)}
                  className={`px-4 py-2 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                    isLive ? 'bg-red-500 hover:bg-red-600 text-white' : 'bg-green-500 hover:bg-green-600 text-white'
                  }`}
                >
                  {isLive ? 'Pause' : 'Reprendre'}
                </button>
              </div>
            </div>

            {/* Contrôles */}
            <div className="flex flex-wrap items-center gap-6">
              {/* Sélection de paire */}
              <div className="flex items-center space-x-3">
                <span className="text-gray-400 text-sm">Paire:</span>
                <select
                  value={selectedCrypto}
                  onChange={(e) => setSelectedCrypto(e.target.value)}
                  className="bg-gray-700 text-white px-4 py-2 rounded-lg border border-yellow-500/20 focus:border-yellow-500 outline-none pr-8"
                >
                  {cryptoSymbols.map((crypto) => (
                    <option key={crypto.symbol} value={crypto.symbol}>
                      {crypto.name} ({crypto.symbol})
                    </option>
                  ))}
                </select>
              </div>

              {/* Timeframes */}
              <div className="flex items-center space-x-3">
                <span className="text-gray-400 text-sm">Période:</span>
                <div className="flex space-x-1">
                  {timeframes.map((tf) => (
                    <button
                      key={tf.value}
                      onClick={() => setSelectedTimeframe(tf.value)}
                      className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                        selectedTimeframe === tf.value
                          ? 'bg-yellow-500 text-black'
                          : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                      }`}
                    >
                      {tf.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Prix actuel */}
          {selectedCryptoData && (
            <div className="bg-gray-800/30 p-4 border-b border-yellow-500/10">
              <div className="flex items-center space-x-8">
                <div className="flex items-center space-x-3">
                  <i className={`${selectedCryptoData.icon} text-2xl text-yellow-400`}></i>
                  <div>
                    <h4 className="text-xl font-bold text-white">{selectedCryptoData.name}</h4>
                    <span className="text-gray-400 text-sm">{selectedCryptoData.symbol}</span>
                  </div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-white">
                    ${selectedCryptoData.price.toLocaleString('fr-FR', { 
                      minimumFractionDigits: selectedCrypto.includes('ADA') || selectedCrypto.includes('XRP') ? 4 : 2,
                      maximumFractionDigits: selectedCrypto.includes('ADA') || selectedCrypto.includes('XRP') ? 4 : 2
                    })}
                  </div>
                  <div className="text-sm text-gray-400">Prix Actuel</div>
                </div>
                <div className={`flex items-center space-x-2 ${selectedCryptoData.change24h >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  <i className={`ri-arrow-${selectedCryptoData.change24h >= 0 ? 'up' : 'down'}-line text-lg`}></i>
                  <span className="text-xl font-semibold">
                    {selectedCryptoData.change24h >= 0 ? '+' : ''}{selectedCryptoData.change24h.toFixed(2)}%
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Graphique principal */}
          <div className="p-6">
            <TradingViewChart data={candleData} />

            {/* Statistiques */}
            {selectedCryptoData && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                <div className="bg-black/50 p-4 rounded-lg border border-yellow-500/10">
                  <div className="text-gray-400 text-sm">Plus Haut 24h</div>
                  <div className="text-white text-lg font-bold">
                    ${selectedCryptoData.high24h.toLocaleString('fr-FR', { maximumFractionDigits: 2 })}
                  </div>
                </div>
                <div className="bg-black/50 p-4 rounded-lg border border-yellow-500/10">
                  <div className="text-gray-400 text-sm">Plus Bas 24h</div>
                  <div className="text-white text-lg font-bold">
                    ${selectedCryptoData.low24h.toLocaleString('fr-FR', { maximumFractionDigits: 2 })}
                  </div>
                </div>
                <div className="bg-black/50 p-4 rounded-lg border border-yellow-500/10">
                  <div className="text-gray-400 text-sm">Volume 24h</div>
                  <div className="text-white text-lg font-bold">
                    {selectedCryptoData.volume.toLocaleString('fr-FR')}M
                  </div>
                </div>
                <div className="bg-black/50 p-4 rounded-lg border border-yellow-500/10">
                  <div className="text-gray-400 text-sm">Amplitude</div>
                  <div className="text-white text-lg font-bold">
                    {(((selectedCryptoData.high24h - selectedCryptoData.low24h) / selectedCryptoData.low24h) * 100).toFixed(2)}%
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
