
'use client';

import Link from 'next/link';
import IndicatorsHero from './IndicatorsHero';
import FeaturedIndicators from './FeaturedIndicators';
import IndicatorCategories from './IndicatorCategories';
import IndicatorMarketplace from './IndicatorMarketplace';

export default function IndicatorsPage() {
  return (
    <div className="min-h-screen bg-black text-white">
      <div className="container mx-auto px-6 py-8">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">
              Indicateurs <span className="text-yellow-400">Techniques</span>
            </h1>
            <p className="text-gray-400">Outils d'analyse avancés pour le trading</p>
          </div>
          <Link href="/" className="flex items-center space-x-2 bg-gray-900 hover:bg-gray-800 px-4 py-2 rounded-lg transition-colors cursor-pointer">
            <i className="ri-home-line text-yellow-400"></i>
            <span className="text-white whitespace-nowrap">Retour à l'accueil</span>
          </Link>
        </div>
        
        <IndicatorsHero />
        <FeaturedIndicators />
        <IndicatorCategories />
        <IndicatorMarketplace />
      </div>
    </div>
  );
}
