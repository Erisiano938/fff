
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Indicateurs Techniques',
  description: 'Bibliothèque complète d\'indicateurs techniques professionnels. RSI, MACD, Moyennes mobiles, Bollinger et bien plus pour optimiser vos analyses.',
  keywords: 'indicateurs techniques, RSI, MACD, moyennes mobiles, bollinger bands, analyse technique, trading, indicateurs personnalisés',
  openGraph: {
    title: 'Indicateurs Techniques | CMV Finance',
    description: 'Accédez à notre bibliothèque d\'indicateurs techniques professionnels pour optimiser vos analyses de marché.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Indicateurs Techniques | CMV Finance',
    description: 'Accédez à notre bibliothèque d\'indicateurs techniques professionnels pour optimiser vos analyses de marché.',
  },
};

export default function IndicatorsLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            "name": "Indicateurs Techniques CMV",
            "description": "Bibliothèque complète d'indicateurs techniques professionnels",
            "url": `${process.env.NEXT_PUBLIC_SITE_URL}/indicators`,
            "applicationCategory": "FinanceApplication",
            "operatingSystem": "Web",
            "provider": {
              "@type": "Organization",
              "name": "CMV Finance",
              "url": process.env.NEXT_PUBLIC_SITE_URL
            },
            "hasOfferCatalog": {
              "@type": "OfferCatalog",
              "name": "Indicateurs Techniques",
              "itemListElement": [
                {
                  "@type": "SoftwareApplication",
                  "name": "RSI (Relative Strength Index)",
                  "description": "Indicateur de momentum pour identifier les zones de surachat et survente"
                },
                {
                  "@type": "SoftwareApplication",
                  "name": "MACD",
                  "description": "Indicateur de convergence-divergence des moyennes mobiles"
                },
                {
                  "@type": "SoftwareApplication",
                  "name": "Bandes de Bollinger",
                  "description": "Indicateur de volatilité et de retournement de tendance"
                }
              ]
            }
          })
        }}
      />
      {children}
    </>
  );
}
