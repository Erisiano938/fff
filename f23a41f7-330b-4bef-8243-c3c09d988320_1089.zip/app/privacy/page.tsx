
'use client';

export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-16">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-4xl font-bold mb-4">Politique de Confidentialité</h1>
          <p className="text-blue-100 text-lg">
            Dernière mise à jour : {new Date().toLocaleDateString('fr-FR')}
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="prose prose-lg max-w-none">
          
          {/* Introduction */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">1. Introduction</h2>
            <p className="text-gray-700 mb-4">
              Nous, [Nom de l'entreprise], nous engageons à protéger votre vie privée et vos données personnelles. 
              Cette politique de confidentialité explique comment nous collectons, utilisons, stockons et protégeons 
              vos informations personnelles lorsque vous utilisez notre plateforme de trading et d'investissement.
            </p>
            <p className="text-gray-700 mb-4">
              En utilisant nos services, vous acceptez les pratiques décrites dans cette politique. Nous vous 
              encourageons à lire attentivement ce document pour comprendre comment nous traitons vos données.
            </p>
            <p className="text-gray-700">
              Cette politique s'applique à tous les utilisateurs de notre plateforme, qu'ils soient clients, 
              visiteurs ou partenaires commerciaux.
            </p>
          </div>

          {/* Données collectées */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">2. Données que nous collectons</h2>
            
            <h3 className="text-xl font-semibold text-gray-800 mb-4">2.1 Informations personnelles</h3>
            <ul className="list-disc pl-6 text-gray-700 mb-6">
              <li>Nom, prénom et coordonnées (adresse, téléphone, email)</li>
              <li>Date de naissance et informations d'identité</li>
              <li>Informations financières (revenus, patrimoine, expérience d'investissement)</li>
              <li>Documents d'identité et justificatifs</li>
              <li>Profil d'investisseur et tolérance au risque</li>
            </ul>

            <h3 className="text-xl font-semibold text-gray-800 mb-4">2.2 Données techniques</h3>
            <ul className="list-disc pl-6 text-gray-700 mb-6">
              <li>Adresse IP et informations de géolocalisation</li>
              <li>Type de navigateur et système d'exploitation</li>
              <li>Cookies et technologies de suivi</li>
              <li>Données de navigation et d'utilisation de la plateforme</li>
              <li>Logs de connexion et historique des transactions</li>
            </ul>

            <h3 className="text-xl font-semibold text-gray-800 mb-4">2.3 Données de trading</h3>
            <ul className="list-disc pl-6 text-gray-700 mb-6">
              <li>Historique des ordres et des transactions</li>
              <li>Positions ouvertes et fermées</li>
              <li>Stratégies d'investissement utilisées</li>
              <li>Performances et résultats de trading</li>
              <li>Utilisation des indicateurs techniques</li>
            </ul>
          </div>

          {/* Utilisation des données */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">3. Comment nous utilisons vos données</h2>
            
            <h3 className="text-xl font-semibold text-gray-800 mb-4">3.1 Fourniture des services</h3>
            <ul className="list-disc pl-6 text-gray-700 mb-6">
              <li>Exécution des ordres de trading et gestion de portefeuille</li>
              <li>Fourniture d'analyses techniques et recommandations</li>
              <li>Calculs fiscaux et optimisation patrimoniale</li>
              <li>Support client et assistance technique</li>
              <li>Formation et ressources éducatives personnalisées</li>
            </ul>

            <h3 className="text-xl font-semibold text-gray-800 mb-4">3.2 Conformité réglementaire</h3>
            <ul className="list-disc pl-6 text-gray-700 mb-6">
              <li>Vérification d'identité (KYC - Know Your Customer)</li>
              <li>Lutte contre le blanchiment d'argent (AML)</li>
              <li>Déclarations fiscales et rapports FATCA/CRS</li>
              <li>Surveillance des transactions suspectes</li>
              <li>Respect des directives MiFID II</li>
            </ul>

            <h3 className="text-xl font-semibold text-gray-800 mb-4">3.3 Amélioration des services</h3>
            <ul className="list-disc pl-6 text-gray-700 mb-6">
              <li>Analyse des performances de la plateforme</li>
              <li>Développement de nouveaux outils et fonctionnalités</li>
              <li>Personnalisation de l'expérience utilisateur</li>
              <li>Études de marché et recherche quantitative</li>
              <li>Optimisation des algorithmes de trading</li>
            </ul>
          </div>

          {/* Partage des données */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">4. Partage de vos données</h2>
            
            <p className="text-gray-700 mb-4">
              Nous ne vendons jamais vos données personnelles à des tiers. Cependant, nous pouvons 
              partager certaines informations dans les cas suivants :
            </p>

            <h3 className="text-xl font-semibold text-gray-800 mb-4">4.1 Partenaires de service</h3>
            <ul className="list-disc pl-6 text-gray-700 mb-6">
              <li>Fournisseurs de données financières (Bloomberg, Reuters)</li>
              <li>Processeurs de paiement et établissements bancaires</li>
              <li>Courtiers et contreparties pour l'exécution d'ordres</li>
              <li>Prestataires informatiques et de sécurité</li>
              <li>Services de vérification d'identité</li>
            </ul>

            <h3 className="text-xl font-semibold text-gray-800 mb-4">4.2 Obligations légales</h3>
            <ul className="list-disc pl-6 text-gray-700 mb-6">
              <li>Autorités de régulation financière (AMF, ACPR)</li>
              <li>Administrations fiscales nationales et internationales</li>
              <li>Forces de l'ordre en cas d'enquête judiciaire</li>
              <li>Organismes de lutte contre le blanchiment</li>
              <li>Tribunaux et autorités compétentes</li>
            </ul>
          </div>

          {/* Sécurité */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">5. Sécurité de vos données</h2>
            
            <p className="text-gray-700 mb-6">
              Nous mettons en œuvre des mesures techniques et organisationnelles robustes pour 
              protéger vos données personnelles contre tout accès non autorisé, perte ou altération.
            </p>

            <h3 className="text-xl font-semibold text-gray-800 mb-4">5.1 Mesures techniques</h3>
            <ul className="list-disc pl-6 text-gray-700 mb-6">
              <li>Chiffrement SSL/TLS pour toutes les communications</li>
              <li>Chiffrement des données sensibles en base</li>
              <li>Authentification multi-facteurs (2FA)</li>
              <li>Pare-feu et systèmes de détection d'intrusion</li>
              <li>Sauvegardes sécurisées et redondantes</li>
            </ul>

            <h3 className="text-xl font-semibold text-gray-800 mb-4">5.2 Mesures organisationnelles</h3>
            <ul className="list-disc pl-6 text-gray-700 mb-6">
              <li>Accès aux données limité au personnel autorisé</li>
              <li>Formation régulière du personnel à la sécurité</li>
              <li>Audits de sécurité périodiques</li>
              <li>Politiques strictes de gestion des accès</li>
              <li>Procédures d'incident et de notification de violation</li>
            </ul>
          </div>

          {/* Conservation */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">6. Conservation des données</h2>
            
            <p className="text-gray-700 mb-6">
              Nous conservons vos données personnelles uniquement aussi longtemps que nécessaire 
              pour les finalités décrites dans cette politique ou pour respecter nos obligations légales.
            </p>

            <div className="bg-blue-50 p-6 rounded-lg mb-6">
              <h3 className="text-lg font-semibold text-blue-900 mb-3">Durées de conservation</h3>
              <ul className="list-disc pl-6 text-blue-800">
                <li><strong>Données de compte :</strong> 5 ans après fermeture du compte</li>
                <li><strong>Transactions financières :</strong> 10 ans (obligation légale)</li>
                <li><strong>Documents KYC :</strong> 5 ans après fin de relation commerciale</li>
                <li><strong>Données de navigation :</strong> 13 mois maximum</li>
                <li><strong>Communications :</strong> 7 ans (MiFID II)</li>
              </ul>
            </div>

            <p className="text-gray-700">
              À l'expiration de ces délais, vos données sont supprimées de manière sécurisée, 
              sauf si leur conservation est requise par la loi ou pour la défense de nos intérêts légitimes.
            </p>
          </div>

          {/* Droits */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">7. Vos droits</h2>
            
            <p className="text-gray-700 mb-6">
              Conformément au Règlement Général sur la Protection des Données (RGPD), vous disposez 
              des droits suivants concernant vos données personnelles :
            </p>

            <div className="grid md:grid-cols-2 gap-6 mb-6">
              <div className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">
                  <i className="ri-eye-line text-blue-600 mr-2"></i>
                  Droit d'accès
                </h3>
                <p className="text-gray-700 text-sm">
                  Vous pouvez demander l'accès à vos données personnelles et obtenir une copie 
                  des informations que nous détenons sur vous.
                </p>
              </div>

              <div className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">
                  <i className="ri-edit-line text-blue-600 mr-2"></i>
                  Droit de rectification
                </h3>
                <p className="text-gray-700 text-sm">
                  Vous pouvez demander la correction des données inexactes ou incomplètes 
                  vous concernant.
                </p>
              </div>

              <div className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">
                  <i className="ri-delete-bin-line text-blue-600 mr-2"></i>
                  Droit à l'effacement
                </h3>
                <p className="text-gray-700 text-sm">
                  Vous pouvez demander la suppression de vos données dans certaines conditions, 
                  sous réserve de nos obligations légales.
                </p>
              </div>

              <div className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">
                  <i className="ri-pause-line text-blue-600 mr-2"></i>
                  Droit à la limitation
                </h3>
                <p className="text-gray-700 text-sm">
                  Vous pouvez demander la limitation du traitement de vos données dans 
                  certaines circonstances.
                </p>
              </div>

              <div className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">
                  <i className="ri-download-line text-blue-600 mr-2"></i>
                  Droit à la portabilité
                </h3>
                <p className="text-gray-700 text-sm">
                  Vous pouvez demander à recevoir vos données dans un format structuré 
                  et les transférer à un autre responsable de traitement.
                </p>
              </div>

              <div className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">
                  <i className="ri-close-line text-blue-600 mr-2"></i>
                  Droit d'opposition
                </h3>
                <p className="text-gray-700 text-sm">
                  Vous pouvez vous opposer au traitement de vos données pour des raisons 
                  tenant à votre situation particulière.
                </p>
              </div>
            </div>

            <div className="bg-blue-100 p-6 rounded-lg">
              <h3 className="text-lg font-semibold text-blue-900 mb-3">Comment exercer vos droits</h3>
              <p className="text-blue-800 mb-3">
                Pour exercer vos droits, vous pouvez nous contacter par :
              </p>
              <ul className="list-disc pl-6 text-blue-800">
                <li>Email : privacy@[votredomaine].com</li>
                <li>Courrier : Service Protection des Données, [Adresse complète]</li>
                <li>Téléphone : +33 (0)1 XX XX XX XX</li>
              </ul>
              <p className="text-blue-800 mt-3 text-sm">
                Nous nous engageons à répondre à votre demande dans un délai d'un mois.
              </p>
            </div>
          </div>

          {/* Cookies */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">8. Cookies et technologies similaires</h2>
            
            <p className="text-gray-700 mb-6">
              Notre site utilise des cookies et d'autres technologies de suivi pour améliorer 
              votre expérience utilisateur et analyser l'utilisation de notre plateforme.
            </p>

            <h3 className="text-xl font-semibold text-gray-800 mb-4">8.1 Types de cookies utilisés</h3>
            
            <div className="space-y-4 mb-6">
              <div className="border-l-4 border-green-500 pl-4">
                <h4 className="font-semibold text-gray-900">Cookies essentiels</h4>
                <p className="text-gray-700 text-sm">
                  Nécessaires au fonctionnement du site (authentification, sécurité, préférences)
                </p>
              </div>
              
              <div className="border-l-4 border-blue-500 pl-4">
                <h4 className="font-semibold text-gray-900">Cookies de performance</h4>
                <p className="text-gray-700 text-sm">
                  Collectent des informations sur l'utilisation du site pour améliorer les performances
                </p>
              </div>
              
              <div className="border-l-4 border-yellow-500 pl-4">
                <h4 className="font-semibold text-gray-900">Cookies fonctionnels</h4>
                <p className="text-gray-700 text-sm">
                  Permettent de mémoriser vos choix et personnaliser votre expérience
                </p>
              </div>
              
              <div className="border-l-4 border-purple-500 pl-4">
                <h4 className="font-semibold text-gray-900">Cookies publicitaires</h4>
                <p className="text-gray-700 text-sm">
                  Utilisés pour afficher des publicités pertinentes (avec votre consentement)
                </p>
              </div>
            </div>

            <p className="text-gray-700">
              Vous pouvez gérer vos préférences de cookies à tout moment via les paramètres 
              de votre navigateur ou notre centre de préférences.
            </p>
          </div>

          {/* Transferts internationaux */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">9. Transferts internationaux</h2>
            
            <p className="text-gray-700 mb-6">
              Certains de nos prestataires de services peuvent être situés en dehors de l'Union Européenne. 
              Dans ce cas, nous nous assurons que vos données bénéficient d'un niveau de protection adéquat.
            </p>

            <h3 className="text-xl font-semibold text-gray-800 mb-4">9.1 Garanties mises en place</h3>
            <ul className="list-disc pl-6 text-gray-700 mb-6">
              <li>Décision d'adéquation de la Commission européenne</li>
              <li>Clauses contractuelles types approuvées par la Commission</li>
              <li>Règles d'entreprise contraignantes (BCR)</li>
              <li>Codes de conduite et mécanismes de certification</li>
              <li>Évaluation d'impact sur la protection des données (EIPD)</li>
            </ul>

            <div className="bg-yellow-50 p-6 rounded-lg">
              <h3 className="text-lg font-semibold text-yellow-900 mb-3">
                <i className="ri-information-line text-yellow-600 mr-2"></i>
                Pays de transfert principaux
              </h3>
              <p className="text-yellow-800 mb-3">
                Vos données peuvent être transférées vers :
              </p>
              <ul className="list-disc pl-6 text-yellow-800 text-sm">
                <li>États-Unis (fournisseurs cloud certifiés Privacy Shield ou DPF)</li>
                <li>Royaume-Uni (décision d'adéquation)</li>
                <li>Suisse (décision d'adéquation)</li>
                <li>Canada (décision d'adéquation partielle)</li>
              </ul>
            </div>
          </div>

          {/* Mineurs */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">10. Protection des mineurs</h2>
            
            <div className="bg-red-50 p-6 rounded-lg">
              <h3 className="text-lg font-semibold text-red-900 mb-3">
                <i className="ri-shield-user-line text-red-600 mr-2"></i>
                Services réservés aux majeurs
              </h3>
              <p className="text-red-800 mb-3">
                Nos services de trading et d'investissement sont exclusivement destinés aux personnes 
                majeures (18 ans et plus). Nous ne collectons pas sciemment de données personnelles 
                auprès de mineurs.
              </p>
              <p className="text-red-800 text-sm">
                Si vous avez connaissance qu'un mineur a fourni des informations personnelles, 
                veuillez nous contacter immédiatement pour que nous puissions supprimer ces données.
              </p>
            </div>
          </div>

          {/* Modifications */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">11. Modifications de cette politique</h2>
            
            <p className="text-gray-700 mb-6">
              Nous pouvons mettre à jour cette politique de confidentialité périodiquement pour 
              refléter les changements dans nos pratiques, nos services ou les exigences légales.
            </p>

            <div className="bg-blue-50 p-6 rounded-lg mb-6">
              <h3 className="text-lg font-semibold text-blue-900 mb-3">Notification des changements</h3>
              <ul className="list-disc pl-6 text-blue-800 text-sm">
                <li>Notification par email pour les modifications importantes</li>
                <li>Bannière d'information sur la plateforme</li>
                <li>Publication de la nouvelle version avec date de mise à jour</li>
                <li>Conservation des versions antérieures pour référence</li>
              </ul>
            </div>

            <p className="text-gray-700">
              Nous vous encourageons à consulter régulièrement cette politique pour rester 
              informé de la façon dont nous protégeons vos données.
            </p>
          </div>

          {/* Contact */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">12. Nous contacter</h2>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">
                  <i className="ri-shield-user-line text-blue-600 mr-2"></i>
                  Délégué à la Protection des Données
                </h3>
                <div className="space-y-2 text-gray-700">
                  <p><strong>Email :</strong> dpo@[votredomaine].com</p>
                  <p><strong>Téléphone :</strong> +33 (0)1 XX XX XX XX</p>
                  <p><strong>Adresse :</strong></p>
                  <address className="text-sm not-italic">
                    [Nom de l'entreprise]<br/>
                    Service Protection des Données<br/>
                    [Adresse complète]<br/>
                    [Code postal] [Ville]<br/>
                    France
                  </address>
                </div>
              </div>

              <div className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">
                  <i className="ri-government-line text-blue-600 mr-2"></i>
                  Autorité de contrôle
                </h3>
                <p className="text-gray-700 mb-3">
                  Vous avez le droit de déposer une réclamation auprès de la CNIL :
                </p>
                <div className="space-y-2 text-gray-700 text-sm">
                  <p><strong>CNIL</strong></p>
                  <p>3 Place de Fontenoy</p>
                  <p>TSA 80715</p>
                  <p>75334 Paris Cedex 07</p>
                  <p><strong>Téléphone :</strong> 01 53 73 22 22</p>
                  <p><strong>Site web :</strong> www.cnil.fr</p>
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="border-t pt-8">
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-lg">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">
                <i className="ri-shield-check-line text-green-600 mr-2"></i>
                Notre engagement
              </h3>
              <p className="text-gray-700 text-sm">
                Nous nous engageons à respecter les plus hauts standards de protection des données 
                et à maintenir la confiance que vous nous accordez. Cette politique de confidentialité 
                fait partie intégrante de nos conditions générales d'utilisation et de notre 
                engagement envers la sécurité et la confidentialité de vos informations.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
