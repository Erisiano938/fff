
import type { Metadata } from "next";
import { Geist, Geist_Mono, Pacifico } from "next/font/google";
import "./globals.css";
import Breadcrumb from "../components/Breadcrumb";

const pacifico = Pacifico({
  weight: '400',
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-pacifico',
});

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: {
    default: "CMV Finance - Plateforme de Trading et d'Investissement",
    template: "%s | CMV Finance"
  },
  description: "Plateforme professionnelle de trading, d'investissement et de gestion patrimoniale. Outils d'analyse technique, académie de formation, allocation d'actifs et opportunités d'investissement.",
  keywords: "trading, investissement, finance, bourse, analyse technique, gestion patrimoniale, ETF, actions, obligations, formation financière",
  authors: [{ name: "CMV Finance" }],
  creator: "CMV Finance",
  publisher: "CMV Finance",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'https://example.com'),
  alternates: {
    canonical: "/",
  },
  openGraph: {
    type: "website",
    locale: "fr_FR",
    url: process.env.NEXT_PUBLIC_SITE_URL,
    siteName: "CMV Finance",
    title: "CMV Finance - Plateforme de Trading et d'Investissement",
    description: "Plateforme professionnelle de trading, d'investissement et de gestion patrimoniale.",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "CMV Finance - Plateforme de Trading",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "CMV Finance - Plateforme de Trading et d'Investissement",
    description: "Plateforme professionnelle de trading, d'investissement et de gestion patrimoniale.",
    images: ["/og-image.jpg"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
};

export const viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr" suppressHydrationWarning={true}>
      <head>
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
        <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
        <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" />
        <link rel="manifest" href="/site.webmanifest" />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${pacifico.variable} antialiased`}
      >
        <Breadcrumb />
        {children}
      </body>
    </html>
  );
}
