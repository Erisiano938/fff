
'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Header from '../components/Header';
import Footer from '../components/Footer';
import TradingDashboard from './TradingDashboard';
import { isAuthenticated } from '../lib/auth';

export default function TradingPage() {
  const [authenticated, setAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const checkAuth = () => {
      if (typeof window !== 'undefined') {
        const authStatus = localStorage.getItem('cmv_admin_auth') === 'true';
        setAuthenticated(authStatus);
        setLoading(false);
        
        if (!authStatus) {
          router.push('/admin/login');
        }
      }
    };
    checkAuth();
  }, [router]);

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-yellow-500 mx-auto mb-4"></div>
          <p className="text-white">Vérification des accès administrateur...</p>
        </div>
      </div>
    );
  }

  if (!authenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <Header />
      <div className="pt-8">
        <TradingDashboard />
      </div>
      <Footer />
    </div>
  );
}
