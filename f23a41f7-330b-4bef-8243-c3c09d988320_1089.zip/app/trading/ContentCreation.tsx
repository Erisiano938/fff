
'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { isAuthenticated, getCurrentUser } from '../lib/auth';
import { saveBlogPost } from '../lib/blogStorage';

export default function ContentCreation() {
  const [selectedTab, setSelectedTab] = useState('blog');
  const [showPreview, setShowPreview] = useState(false);
  const [authenticated, setAuthenticated] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const checkAuth = () => {
      if (typeof window !== 'undefined') {
        const authStatus = localStorage.getItem('cmv_admin_auth') === 'true';
        setAuthenticated(authStatus);
        if (!authStatus) {
          router.push('/admin/login');
        }
      }
    };
    checkAuth();
  }, [router]);

  if (!authenticated) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-yellow-500 mx-auto mb-4"></div>
          <p className="text-white">Vérification des accès...</p>
        </div>
      </div>
    );
  }

  const BlogEditor = () => {
    const [blogData, setBlogData] = useState({
      title: '',
      category: 'debutant',
      tags: '',
      content: '',
      excerpt: '',
      featured: false,
      imageUrl: '',
      imagePrompt: ''
    });

    const generateImage = useCallback(() => {
      if (!blogData.imagePrompt.trim()) {
        alert('Veuillez décrire l\'image que vous souhaitez générer');
        return;
      }

      const imageUrl = `https://readdy.ai/api/search-image?query=$%7BencodeURIComponent%28blogData.imagePrompt%29%7D&width=800&height=450&seq=${Date.now()}&orientation=landscape`;
      setBlogData(prev => ({...prev, imageUrl}));
    }, [blogData.imagePrompt]);

    const handlePublish = useCallback((status: 'published' | 'draft') => {
      if (!blogData.title || !blogData.content) {
        alert('Veuillez remplir au moins le titre et le contenu');
        return;
      }

      try {
        const user = getCurrentUser();
        const postData = {
          title: blogData.title,
          content: blogData.content,
          category: blogData.category,
          isFeatured: blogData.featured,
          isPublished: status === 'published'
        };

        saveBlogPost(postData);

        setShowSuccess(true);
        const timeoutId = setTimeout(() => setShowSuccess(false), 3000);

        setBlogData({
          title: '',
          category: 'debutant',
          tags: '',
          content: '',
          excerpt: '',
          featured: false,
          imageUrl: '',
          imagePrompt: ''
        });

        return () => clearTimeout(timeoutId);
      } catch (error) {
        console.error('Erreur lors de la publication:', error);
        alert('Erreur lors de la publication de l\'article');
      }
    }, [blogData]);

    return (
      <div className="space-y-6">
        {showSuccess && (
          <div className="bg-green-500/20 border border-green-500/40 text-green-400 p-4 rounded-lg">
            ✅ Article publié avec succès ! Il apparaîtra maintenant dans la section Académie.
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <label className="block text-gray-400 text-sm mb-2">Titre de l'article</label>
            <input
              type="text"
              value={blogData.title}
              onChange={(e) => setBlogData(prev => ({...prev, title: e.target.value}))}
              placeholder="Ex: Les 5 erreurs à éviter en trading"
              className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-gray-400 text-sm mb-2">Catégorie</label>
            <select
              value={blogData.category}
              onChange={(e) => setBlogData(prev => ({...prev, category: e.target.value}))}
              className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none pr-8"
            >
              <option value="debutant">Débutant</option>
              <option value="intermediaire">Intermédiaire</option>
              <option value="avance">Avancé</option>
              <option value="strategie">Stratégies</option>
              <option value="psychologie">Psychologie</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-gray-400 text-sm mb-2">Image de présentation</label>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-400 text-xs mb-2">Télécharger une image</label>
              <div className="border-2 border-dashed border-gray-700 rounded-lg p-6 text-center hover:border-yellow-500/50 transition-colors cursor-pointer">
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = (event) => {
                        const result = event.target?.result;
                        if (result) {
                          setBlogData(prev => ({...prev, imageUrl: result as string}));
                        }
                      };
                      reader.readAsDataURL(file);
                    }
                  }}
                  className="hidden"
                  id="image-upload"
                />
                <label htmlFor="image-upload" className="cursor-pointer">
                  <i className="ri-image-add-line text-4xl text-gray-500 mb-3"></i>
                  <p className="text-gray-400">Cliquez pour sélectionner une image</p>
                  <p className="text-xs text-gray-500 mt-2">JPG, PNG, WebP (max 5MB)</p>
                </label>
              </div>
            </div>
            <div>
              {blogData.imageUrl ? (
                <div className="space-y-3">
                  <img
                    src={blogData.imageUrl}
                    alt="Aperçu de l'image"
                    className="w-full h-40 object-cover rounded-lg border border-gray-700"
                  />
                  <button
                    type="button"
                    onClick={() => setBlogData(prev => ({...prev, imageUrl: ''}))}
                    className="w-full bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg font-semibold transition-colors whitespace-nowrap"
                  >
                    <i className="ri-delete-bin-line mr-2"></i>
                    Supprimer l'image
                  </button>
                </div>
              ) : (
                <div className="h-40 border-2 border-dashed border-gray-700 rounded-lg flex items-center justify-center">
                  <div className="text-center text-gray-500">
                    <i className="ri-image-line text-3xl mb-2"></i>
                    <p className="text-sm">L'image sélectionnée apparaîtra ici</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        <div>
          <label className="block text-gray-400 text-sm mb-2">Tags (séparés par des virgules)</label>
          <input
            type="text"
            value={blogData.tags}
            onChange={(e) => setBlogData(prev => ({...prev, tags: e.target.value}))}
            placeholder="forex, analyse technique, débutant"
            className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-gray-400 text-sm mb-2">Résumé</label>
          <textarea
            value={blogData.excerpt}
            onChange={(e) => setBlogData(prev => ({...prev, excerpt: e.target.value}))}
            placeholder="Résumé de votre article..."
            rows={3}
            maxLength={200}
            className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none resize-none"
          />
          <div className="text-xs text-gray-500 mt-1">{blogData.excerpt.length}/200 caractères</div>
        </div>

        <div>
          <label className="block text-gray-400 text-sm mb-2">Contenu de l'article</label>
          <textarea
            value={blogData.content}
            onChange={(e) => setBlogData(prev => ({...prev, content: e.target.value}))}
            placeholder="Rédigez votre article ici..."
            rows={12}
            maxLength={5000}
            className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none resize-none"
          />
          <div className="text-xs text-gray-500 mt-1">{blogData.content.length}/5000 caractères</div>
        </div>

        <div className="flex items-center space-x-3">
          <input
            type="checkbox"
            id="featured"
            checked={blogData.featured}
            onChange={(e) => setBlogData(prev => ({...prev, featured: e.target.checked}))}
            className="w-4 h-4 text-yellow-500 bg-gray-800 border-gray-700 rounded focus:ring-yellow-500"
          />
          <label htmlFor="featured" className="text-gray-400 text-sm">Article à la une</label>
        </div>

        <div className="flex space-x-4">
          <button
            onClick={() => setShowPreview(!showPreview)}
            className="bg-gray-700 hover:bg-gray-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap"
          >
            {showPreview ? 'Masquer Aperçu' : 'Aperçu'}
          </button>
          <button 
            onClick={() => handlePublish('draft')}
            className="bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-400 border border-yellow-500/40 px-6 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap"
          >
            Sauvegarder Brouillon
          </button>
          <button 
            onClick={() => handlePublish('published')}
            className="bg-yellow-500 hover:bg-yellow-600 text-black px-6 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap"
          >
            Publier Article
          </button>
        </div>

        {showPreview && (
          <div className="mt-8 bg-gray-900 rounded-xl p-8 border border-yellow-500/20">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-white">Aperçu de l'article</h3>
              <button
                onClick={() => setShowPreview(false)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            <div className="prose prose-invert max-w-none">
              {blogData.imageUrl && (
                <img
                  src={blogData.imageUrl}
                  alt={blogData.title}
                  className="w-full h-64 object-cover rounded-lg mb-6"
                />
              )}
              <h1 className="text-2xl font-bold text-white mb-4">{blogData.title || 'Titre de l\'article'}</h1>
              <p className="text-gray-400 mb-6">{blogData.excerpt || 'Résumé de l\'article...'}</p>
              <div className="text-white whitespace-pre-wrap">{blogData.content || 'Contenu de l\'article...'}</div>
            </div>
          </div>
        )}
      </div>
    );
  };

  const VideoEditor = () => {
    const [videoData, setVideoData] = useState({
      title: '',
      description: '',
      category: 'tutorial',
      duration: '',
      thumbnailUrl: '',
      videoUrl: ''
    });

    const [localShowSuccess, setLocalShowSuccess] = useState(false);

    const handleVideoUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
        if (file.size > 500 * 1024 * 1024) {
          alert('Le fichier est trop volumineux (max 500MB)');
          return;
        }

        try {
          const videoUrl = URL.createObjectURL(file);
          setVideoData(prev => ({...prev, videoUrl}));
        } catch (error) {
          console.error('Erreur lors du chargement de la vidéo:', error);
          alert('Erreur lors du chargement du fichier vidéo');
        }
      }
    }, []);

    const handleThumbnailUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
          const result = event.target?.result;
          if (result) {
            setVideoData(prev => ({...prev, thumbnailUrl: result as string}));
          }
        };
        reader.onerror = () => {
          console.error('Erreur lors de la lecture du fichier');
          alert('Erreur lors du chargement de la miniature');
        };
        reader.readAsDataURL(file);
      }
    }, []);

    const handlePublishVideo = useCallback((status: 'published' | 'draft') => {
      if (!videoData.title || !videoData.videoUrl) {
        alert('Veuillez remplir au moins le titre et ajouter une vidéo');
        return;
      }

      try {
        const videoPost = {
          id: Date.now().toString(),
          title: videoData.title,
          description: videoData.description,
          category: videoData.category,
          duration: videoData.duration,
          thumbnailUrl: videoData.thumbnailUrl,
          videoUrl: videoData.videoUrl,
          videoType: 'upload',
          status,
          createdAt: new Date().toISOString(),
          views: Math.floor(Math.random() * 5000) + 100
        };

        const existingVideos = JSON.parse(localStorage.getItem('cmv_videos') || '[]');
        existingVideos.push(videoPost);
        localStorage.setItem('cmv_videos', JSON.stringify(existingVideos));

        setLocalShowSuccess(true);
        const timeoutId = setTimeout(() => setLocalShowSuccess(false), 3000);

        setVideoData({
          title: '',
          description: '',
          category: 'tutorial',
          duration: '',
          thumbnailUrl: '',
          videoUrl: ''
        });

        return () => clearTimeout(timeoutId);
      } catch (error) {
        console.error('Erreur lors de la publication de la vidéo:', error);
        alert('Erreur lors de la publication de la vidéo');
      }
    }, [videoData]);

    useEffect(() => {
      return () => {
        if (videoData.videoUrl && videoData.videoUrl.startsWith('blob:')) {
          URL.revokeObjectURL(videoData.videoUrl);
        }
      };
    }, [videoData.videoUrl]);

    return (
      <div className="space-y-6">
        {localShowSuccess && (
          <div className="bg-green-500/20 border border-green-500/40 text-green-400 p-4 rounded-lg">
            ✅ Vidéo publiée avec succès ! Elle apparaîtra maintenant dans la section Académie.
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <label className="block text-gray-400 text-sm mb-2">Titre de la vidéo</label>
            <input
              type="text"
              value={videoData.title}
              onChange={(e) => setVideoData(prev => ({...prev, title: e.target.value}))}
              placeholder="Ex: Comment analyser un graphique en 5 minutes"
              className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-gray-400 text-sm mb-2">Catégorie</label>
            <select
              value={videoData.category}
              onChange={(e) => setVideoData(prev => ({...prev, category: e.target.value}))}
              className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none pr-8"
            >
              <option value="tutorial">Tutoriel</option>
              <option value="analyse">Analyse</option>
              <option value="strategie">Stratégie</option>
              <option value="live">Live Trading</option>
              <option value="formation">Formation</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-gray-400 text-sm mb-2">Description</label>
          <textarea
            value={videoData.description}
            onChange={(e) => setVideoData(prev => ({...prev, description: e.target.value}))}
            placeholder="Description de votre vidéo..."
            rows={4}
            maxLength={1000}
            className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none resize-none"
          />
          <div className="text-xs text-gray-500 mt-1">{videoData.description.length}/1000 caractères</div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <label className="block text-gray-400 text-sm mb-2">Fichier vidéo</label>
            <div className="border-2 border-dashed border-gray-700 rounded-lg p-8 text-center hover:border-yellow-500/50 transition-colors">
              <input
                type="file"
                accept="video/mp4,video/avi,video/mov,video/wmv"
                onChange={handleVideoUpload}
                className="hidden"
                id="video-upload"
              />
              <label htmlFor="video-upload" className="cursor-pointer">
                <i className="ri-video-upload-line text-4xl text-gray-500 mb-4"></i>
                <p className="text-gray-400">Cliquez pour sélectionner une vidéo</p>
                <p className="text-xs text-gray-500 mt-2">MP4, AVI, MOV (max 500MB)</p>
              </label>
            </div>
            {videoData.videoUrl && (
              <div className="mt-4">
                <video
                  src={videoData.videoUrl}
                  controls
                  className="w-full h-40 rounded-lg bg-black"
                  onError={(e) => {
                    console.error('Erreur de lecture vidéo:', e);
                  }}
                />
                <button
                  type="button"
                  onClick={() => {
                    if (videoData.videoUrl.startsWith('blob:')) {
                      URL.revokeObjectURL(videoData.videoUrl);
                    }
                    setVideoData(prev => ({...prev, videoUrl: ''}));
                  }}
                  className="w-full mt-2 bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg font-semibold transition-colors whitespace-nowrap"
                >
                  <i className="ri-delete-bin-line mr-2"></i>
                  Supprimer la vidéo
                </button>
              </div>
            )}
          </div>
          <div>
            <label className="block text-gray-400 text-sm mb-2">Miniature personnalisée</label>
            <div className="border-2 border-dashed border-gray-700 rounded-lg p-8 text-center hover:border-yellow-500/50 transition-colors">
              <input
                type="file"
                accept="image/*"
                onChange={handleThumbnailUpload}
                className="hidden"
                id="thumbnail-upload"
              />
              <label htmlFor="thumbnail-upload" className="cursor-pointer">
                <i className="ri-image-add-line text-4xl text-gray-500 mb-4"></i>
                <p className="text-gray-400">Ajoutez une miniature</p>
                <p className="text-xs text-gray-500 mt-2">JPG, PNG (1280x720 recommandé)</p>
              </label>
            </div>
            {videoData.thumbnailUrl && (
              <div className="mt-4">
                <img
                  src={videoData.thumbnailUrl}
                  alt="Miniature"
                  className="w-full h-40 object-cover rounded-lg border border-gray-700"
                />
                <button
                  type="button"
                  onClick={() => setVideoData(prev => ({...prev, thumbnailUrl: ''}))}
                  className="w-full mt-2 bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg font-semibold transition-colors whitespace-nowrap"
                >
                  <i className="ri-delete-bin-line mr-2"></i>
                  Supprimer la miniature
                </button>
              </div>
            )}
          </div>
        </div>

        <div>
          <label className="block text-gray-400 text-sm mb-2">Durée de la vidéo</label>
          <input
            type="text"
            value={videoData.duration}
            onChange={(e) => setVideoData(prev => ({...prev, duration: e.target.value}))}
            placeholder="Ex: 15:30"
            className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
          />
        </div>

        <div className="flex space-x-4">
          <button 
            onClick={() => handlePublishVideo('draft')}
            className="bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-400 border border-yellow-500/40 px-6 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap"
          >
            Sauvegarder Brouillon
          </button>
          <button 
            onClick={() => handlePublishVideo('published')}
            className="bg-yellow-500 hover:bg-yellow-600 text-black px-6 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap"
          >
            Publier Vidéo
          </button>
        </div>
      </div>
    );
  };

  const tabs = [
    { id: 'blog', name: 'Article Blog', icon: 'ri-article-line' },
    { id: 'video', name: 'Vidéo', icon: 'ri-video-line' }
  ];

  return (
    <section className="py-12 bg-black">
      <div className="container mx-auto px-6">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-bold text-white">
            Créer du <span className="text-yellow-400">Contenu</span>
          </h2>
          <div className="flex items-center space-x-4">
            <span className="text-gray-400 text-sm">👨🏻💼 Mode Administrateur</span>
            <button
              onClick={() => router.push('/admin/dashboard')}
              className="bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 rounded-lg font-semibold transition-colors"
            >
              Tableau de Bord
            </button>
          </div>
        </div>

        <div className="bg-gray-900 rounded-xl border border-yellow-500/20 overflow-hidden">
          <div className="border-b border-gray-800">
            <div className="flex space-x-1 p-2">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setSelectedTab(tab.id)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-semibold transition-colors whitespace-nowrap ${
                    selectedTab === tab.id
                      ? 'bg-yellow-500 text-black'
                      : 'text-gray-400 hover:text-white hover:bg-gray-800'
                  }`}
                >
                  <i className={`${tab.icon} text-lg`}></i>
                  <span>{tab.name}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="p-8">
            {selectedTab === 'blog' && <BlogEditor />}
            {selectedTab === 'video' && <VideoEditor />}
          </div>
        </div>
      </div>
    </section>
  );
}
