
'use client';

export default function TradingDashboard() {
  const recentContent = [
    { 
      title: 'Guide complet : Débuter en trading Forex', 
      type: 'Blog', 
      date: '15 Jan 2024', 
      views: '2.3k',
      status: 'Publié'
    },
    { 
      title: 'Les bases de l\'analyse technique', 
      type: 'Vidéo', 
      date: '12 Jan 2024', 
      views: '1.8k',
      status: 'Publié'
    },
    { 
      title: 'Comment gérer ses émotions en trading', 
      type: 'Blog', 
      date: '10 Jan 2024', 
      views: '987',
      status: 'Brouillon'
    },
    { 
      title: 'Stratégies pour débutants : Day Trading vs Swing', 
      type: 'Vidéo', 
      date: '8 Jan 2024', 
      views: '3.2k',
      status: 'Publié'
    }
  ];

  const stats = [
    { label: 'Articles publiés', value: '24', icon: 'ri-article-line' },
    { label: 'Vidéos créées', value: '16', icon: 'ri-video-line' },
    { label: 'Vues totales', value: '45.2k', icon: 'ri-eye-line' },
    { label: 'Abonnés', value: '1.2k', icon: 'ri-user-follow-line' }
  ];

  return (
    <section className="py-12 bg-gray-900">
      <div className="container mx-auto px-6">
        <div className="mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 text-white">
            Trading pour <span className="text-yellow-400">Débutants</span>
          </h1>
          <p className="text-xl text-gray-400 max-w-3xl">
            Créez et partagez du contenu éducatif pour aider les débutants à maîtriser le trading.
          </p>
        </div>

        <div className="grid lg:grid-cols-4 gap-6 mb-12">
          {stats.map((stat, index) => (
            <div key={index} className="bg-black/50 rounded-xl p-6 border border-yellow-500/20">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center">
                  <i className={`${stat.icon} text-2xl text-yellow-400`}></i>
                </div>
                <div>
                  <div className="text-2xl font-bold text-white">{stat.value}</div>
                  <div className="text-gray-400 text-sm">{stat.label}</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-black/50 rounded-xl p-6 border border-yellow-500/20">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-white">Contenu Récent</h3>
                <button className="bg-yellow-500 hover:bg-yellow-600 text-black px-4 py-2 rounded-lg font-semibold transition-colors whitespace-nowrap">
                  Nouveau Contenu
                </button>
              </div>
              <div className="space-y-4">
                {recentContent.map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-gray-800/50 rounded-lg hover:bg-gray-800/70 transition-colors cursor-pointer">
                    <div className="flex items-center space-x-4">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        item.type === 'Blog' ? 'bg-blue-500/20' : 'bg-red-500/20'
                      }`}>
                        <i className={`${item.type === 'Blog' ? 'ri-article-line' : 'ri-video-line'} text-lg ${
                          item.type === 'Blog' ? 'text-blue-400' : 'text-red-400'
                        }`}></i>
                      </div>
                      <div>
                        <div className="text-white font-semibold">{item.title}</div>
                        <div className="text-gray-400 text-sm">{item.date} • {item.views} vues</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className={`px-2 py-1 rounded text-xs font-semibold ${
                        item.status === 'Publié' ? 'bg-green-500/20 text-green-400' : 'bg-orange-500/20 text-orange-400'
                      }`}>
                        {item.status}
                      </span>
                      <button className="text-gray-400 hover:text-white transition-colors">
                        <i className="ri-more-line text-lg"></i>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div>
            <div className="bg-black/50 rounded-xl p-6 border border-yellow-500/20 mb-6">
              <h3 className="text-xl font-bold text-white mb-4">Actions Rapides</h3>
              <div className="space-y-3">
                <button className="w-full bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-lg font-semibold transition-colors text-left flex items-center space-x-3">
                  <i className="ri-article-line text-xl"></i>
                  <span>Nouvel Article</span>
                </button>
                <button className="w-full bg-red-600 hover:bg-red-700 text-white p-3 rounded-lg font-semibold transition-colors text-left flex items-center space-x-3">
                  <i className="ri-video-add-line text-xl"></i>
                  <span>Nouvelle Vidéo</span>
                </button>
                <button className="w-full bg-green-600 hover:bg-green-700 text-white p-3 rounded-lg font-semibold transition-colors text-left flex items-center space-x-3">
                  <i className="ri-live-line text-xl"></i>
                  <span>Live Stream</span>
                </button>
              </div>
            </div>

            <div className="bg-black/50 rounded-xl p-6 border border-yellow-500/20">
              <h3 className="text-xl font-bold text-white mb-4">Tendances</h3>
              <div className="space-y-3">
                <div className="text-sm">
                  <div className="text-gray-400 mb-1">Sujet populaire</div>
                  <div className="text-white font-semibold">Analyse technique pour débutants</div>
                  <div className="text-yellow-400 text-xs">+45% d'intérêt</div>
                </div>
                <div className="text-sm">
                  <div className="text-gray-400 mb-1">Mot-clé tendance</div>
                  <div className="text-white font-semibold">Trading psychologie</div>
                  <div className="text-yellow-400 text-xs">+32% de recherches</div>
                </div>
                <div className="text-sm">
                  <div className="text-gray-400 mb-1">Format demandé</div>
                  <div className="text-white font-semibold">Tutoriels vidéo courts</div>
                  <div className="text-yellow-400 text-xs">+28% d'engagement</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}