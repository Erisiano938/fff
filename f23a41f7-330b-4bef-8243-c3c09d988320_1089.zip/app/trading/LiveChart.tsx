
'use client';

import { useState, useEffect } from 'react';

interface CandlestickData {
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export default function LiveChart() {
  const [selectedTimeframe, setSelectedTimeframe] = useState('1h');
  const [selectedPair, setSelectedPair] = useState('BTCUSDT');
  const [candleData, setCandleData] = useState<CandlestickData[]>([]);
  const [currentPrice, setCurrentPrice] = useState(0);
  const [priceChange, setPriceChange] = useState(0);
  const [isLive, setIsLive] = useState(true);

  const timeframes = [
    { label: '1m', value: '1m' },
    { label: '5m', value: '5m' },
    { label: '15m', value: '15m' },
    { label: '1h', value: '1h' },
    { label: '4h', value: '4h' },
    { label: '1d', value: '1d' }
  ];

  const tradingPairs = [
    { symbol: 'BTCUSDT', name: 'Bitcoin' },
    { symbol: 'ETHUSDT', name: 'Ethereum' },
    { symbol: 'BNBUSDT', name: 'BNB' },
    { symbol: 'ADAUSDT', name: 'Cardano' },
    { symbol: 'SOLUSDT', name: 'Solana' },
    { symbol: 'XRPUSDT', name: 'Ripple' }
  ];

  // Générer des données réalistes pour les chandeliers
  const generateCandleData = () => {
    const data: CandlestickData[] = [];
    let basePrice = selectedPair === 'BTCUSDT' ? 43500 : 
                   selectedPair === 'ETHUSDT' ? 2450 :
                   selectedPair === 'BNBUSDT' ? 315 :
                   selectedPair === 'ADAUSDT' ? 0.485 :
                   selectedPair === 'SOLUSDT' ? 68.5 : 0.52;

    for (let i = 0; i < 50; i++) {
      const open = basePrice + (Math.random() - 0.5) * basePrice * 0.02;
      const variation = (Math.random() - 0.5) * basePrice * 0.015;
      const close = open + variation;
      const high = Math.max(open, close) + Math.random() * basePrice * 0.005;
      const low = Math.min(open, close) - Math.random() * basePrice * 0.005;
      
      const now = new Date();
      now.setHours(now.getHours() - (49 - i) * (selectedTimeframe === '1m' ? 1/60 : 
                                                selectedTimeframe === '5m' ? 5/60 :
                                                selectedTimeframe === '15m' ? 15/60 :
                                                selectedTimeframe === '1h' ? 1 :
                                                selectedTimeframe === '4h' ? 4 : 24));
      
      data.push({
        time: selectedTimeframe === '1m' || selectedTimeframe === '5m' || selectedTimeframe === '15m' ? 
              now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) :
              selectedTimeframe === '1h' || selectedTimeframe === '4h' ?
              now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) :
              now.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' }),
        open: parseFloat(open.toFixed(selectedPair.includes('USD') && !selectedPair.includes('BTC') && !selectedPair.includes('ETH') && !selectedPair.includes('BNB') ? 4 : 2)),
        high: parseFloat(high.toFixed(selectedPair.includes('USD') && !selectedPair.includes('BTC') && !selectedPair.includes('ETH') && !selectedPair.includes('BNB') ? 4 : 2)),
        low: parseFloat(low.toFixed(selectedPair.includes('USD') && !selectedPair.includes('BTC') && !selectedPair.includes('ETH') && !selectedPair.includes('BNB') ? 4 : 2)),
        close: parseFloat(close.toFixed(selectedPair.includes('USD') && !selectedPair.includes('BTC') && !selectedPair.includes('ETH') && !selectedPair.includes('BNB') ? 4 : 2)),
        volume: Math.floor(Math.random() * 1000 + 500)
      });
      
      basePrice = close;
    }
    
    return data;
  };

  useEffect(() => {
    const newData = generateCandleData();
    setCandleData(newData);
    
    if (newData.length > 0) {
      const latest = newData[newData.length - 1];
      const previous = newData[newData.length - 2];
      setCurrentPrice(latest.close);
      setPriceChange(((latest.close - previous.close) / previous.close) * 100);
    }
  }, [selectedTimeframe, selectedPair]);

  // Mise à jour en temps réel
  useEffect(() => {
    if (!isLive) return;
    
    const interval = setInterval(() => {
      setCandleData(prev => {
        const newData = [...prev];
        if (newData.length > 0) {
          const last = newData[newData.length - 1];
          const variation = (Math.random() - 0.5) * last.close * 0.002;
          const newClose = last.close + variation;
          
          newData[newData.length - 1] = {
            ...last,
            close: parseFloat(newClose.toFixed(selectedPair.includes('USD') && !selectedPair.includes('BTC') && !selectedPair.includes('ETH') && !selectedPair.includes('BNB') ? 4 : 2)),
            high: Math.max(last.high, newClose),
            low: Math.min(last.low, newClose)
          };
          
          setCurrentPrice(newClose);
          setPriceChange(((newClose - prev[prev.length - 2]?.close || newClose) / (prev[prev.length - 2]?.close || newClose)) * 100);
        }
        return newData;
      });
    }, 2000);

    return () => clearInterval(interval);
  }, [isLive, selectedPair]);

  const renderCandlestick = (candle: CandlestickData, index: number) => {
    const isGreen = candle.close > candle.open;
    const bodyHeight = Math.abs(candle.close - candle.open);
    const bodyTop = Math.max(candle.close, candle.open);
    const wickTop = candle.high;
    const wickBottom = candle.low;
    
    const maxPrice = Math.max(...candleData.map(c => c.high));
    const minPrice = Math.min(...candleData.map(c => c.low));
    const priceRange = maxPrice - minPrice;
    
    const getY = (price: number) => ((maxPrice - price) / priceRange) * 300;
    
    return (
      <g key={index} className="cursor-pointer group">
        {/* Mèche */}
        <line
          x1={index * 8 + 4}
          y1={getY(wickTop)}
          x2={index * 8 + 4}
          y2={getY(wickBottom)}
          stroke={isGreen ? '#10b981' : '#ef4444'}
          strokeWidth="1"
        />
        
        {/* Corps de la bougie */}
        <rect
          x={index * 8 + 1}
          y={getY(bodyTop)}
          width="6"
          height={Math.max(1, (bodyHeight / priceRange) * 300)}
          fill={isGreen ? '#10b981' : '#ef4444'}
          stroke={isGreen ? '#10b981' : '#ef4444'}
          className="group-hover:opacity-80"
        />
        
        {/* Tooltip au survol */}
        <rect
          x={index * 8}
          y="0"
          width="8"
          height="300"
          fill="transparent"
          className="group-hover:fill-yellow-500/10"
        >
          <title>
            {`Heure: ${candle.time}\nOuverture: ${candle.open}\nPlus Haut: ${candle.high}\nPlus Bas: ${candle.low}\nClôture: ${candle.close}\nVolume: ${candle.volume}`}
          </title>
        </rect>
      </g>
    );
  };

  return (
    <section className="py-12 bg-black">
      <div className="container mx-auto px-6">
        <div className="bg-gray-900/50 rounded-xl border border-yellow-500/20 overflow-hidden">
          {/* Header avec contrôles */}
          <div className="bg-gray-800/50 p-4 border-b border-yellow-500/20">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-4">
                <h3 className="text-xl font-bold text-white">Graphique Trading</h3>
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${isLive ? 'bg-green-500 animate-pulse' : 'bg-gray-500'}`}></div>
                  <span className="text-sm text-gray-400">{isLive ? 'En Direct' : 'Pause'}</span>
                </div>
              </div>
              
              <button
                onClick={() => setIsLive(!isLive)}
                className="px-4 py-2 bg-yellow-500 text-black rounded-lg font-semibold hover:bg-yellow-400 transition-colors cursor-pointer whitespace-nowrap"
              >
                {isLive ? 'Pause' : 'Reprendre'}
              </button>
            </div>
            
            <div className="flex flex-wrap items-center gap-4">
              {/* Sélection de la paire */}
              <div className="flex items-center space-x-2">
                <span className="text-gray-400 text-sm">Paire:</span>
                <select
                  value={selectedPair}
                  onChange={(e) => setSelectedPair(e.target.value)}
                  className="bg-gray-700 text-white px-4 py-2 rounded-lg border border-yellow-500/20 focus:border-yellow-500 outline-none pr-8"
                >
                  {tradingPairs.map((pair) => (
                    <option key={pair.symbol} value={pair.symbol}>
                      {pair.name} ({pair.symbol})
                    </option>
                  ))}
                </select>
              </div>
              
              {/* Timeframes */}
              <div className="flex items-center space-x-2">
                <span className="text-gray-400 text-sm">Période:</span>
                <div className="flex space-x-1">
                  {timeframes.map((tf) => (
                    <button
                      key={tf.value}
                      onClick={() => setSelectedTimeframe(tf.value)}
                      className={`px-3 py-2 rounded-lg text-sm font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                        selectedTimeframe === tf.value
                          ? 'bg-yellow-500 text-black'
                          : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                      }`}
                    >
                      {tf.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Prix actuel et variation */}
          <div className="bg-gray-800/30 p-4 border-b border-yellow-500/10">
            <div className="flex items-center space-x-6">
              <div>
                <div className="text-2xl font-bold text-white">
                  {currentPrice.toFixed(selectedPair.includes('USD') && !selectedPair.includes('BTC') && !selectedPair.includes('ETH') && !selectedPair.includes('BNB') ? 4 : 2)}
                </div>
                <div className="text-sm text-gray-400">Prix Actuel</div>
              </div>
              <div className={`flex items-center space-x-2 ${priceChange >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                <i className={`ri-arrow-${priceChange >= 0 ? 'up' : 'down'}-line`}></i>
                <span className="font-semibold">
                  {priceChange >= 0 ? '+' : ''}{priceChange.toFixed(2)}%
                </span>
              </div>
            </div>
          </div>

          {/* Graphique principal */}
          <div className="p-6">
            <div className="bg-black/50 rounded-lg p-4 border border-yellow-500/10">
              <div className="relative">
                <svg width="100%" height="320" viewBox="0 0 400 320" className="overflow-visible">
                  {/* Grille */}
                  <defs>
                    <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                      <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#374151" strokeWidth="0.5" opacity="0.3"/>
                    </pattern>
                  </defs>
                  <rect width="100%" height="100%" fill="url(#grid)" />
                  
                  {/* Axes Y (prix) */}
                  {candleData.length > 0 && (
                    <>
                      {[0, 1, 2, 3, 4].map((i) => {
                        const maxPrice = Math.max(...candleData.map(c => c.high));
                        const minPrice = Math.min(...candleData.map(c => c.low));
                        const price = maxPrice - ((maxPrice - minPrice) * i / 4);
                        return (
                          <g key={i}>
                            <line x1="0" y1={i * 75} x2="400" y2={i * 75} stroke="#374151" strokeWidth="0.5" />
                            <text x="405" y={i * 75 + 4} fill="#9CA3AF" fontSize="12">
                              {price.toFixed(selectedPair.includes('USD') && !selectedPair.includes('BTC') && !selectedPair.includes('ETH') && !selectedPair.includes('BNB') ? 4 : 2)}
                            </text>
                          </g>
                        );
                      })}
                    </>
                  )}
                  
                  {/* Chandeliers */}
                  {candleData.slice(-50).map((candle, index) => renderCandlestick(candle, index))}
                </svg>
              </div>
            </div>

            {/* Statistiques du marché */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
              {candleData.length > 0 && (
                <>
                  <div className="bg-black/50 p-4 rounded-lg border border-yellow-500/10">
                    <div className="text-gray-400 text-sm">Plus Haut 24h</div>
                    <div className="text-white text-lg font-bold">
                      {Math.max(...candleData.map(c => c.high)).toFixed(selectedPair.includes('USD') && !selectedPair.includes('BTC') && !selectedPair.includes('ETH') && !selectedPair.includes('BNB') ? 4 : 2)}
                    </div>
                  </div>
                  <div className="bg-black/50 p-4 rounded-lg border border-yellow-500/10">
                    <div className="text-gray-400 text-sm">Plus Bas 24h</div>
                    <div className="text-white text-lg font-bold">
                      {Math.min(...candleData.map(c => c.low)).toFixed(selectedPair.includes('USD') && !selectedPair.includes('BTC') && !selectedPair.includes('ETH') && !selectedPair.includes('BNB') ? 4 : 2)}
                    </div>
                  </div>
                  <div className="bg-black/50 p-4 rounded-lg border border-yellow-500/10">
                    <div className="text-gray-400 text-sm">Volume</div>
                    <div className="text-white text-lg font-bold">
                      {candleData.reduce((sum, candle) => sum + candle.volume, 0).toLocaleString()}
                    </div>
                  </div>
                  <div className="bg-black/50 p-4 rounded-lg border border-yellow-500/10">
                    <div className="text-gray-400 text-sm">Amplitude</div>
                    <div className="text-white text-lg font-bold">
                      {(((Math.max(...candleData.map(c => c.high)) - Math.min(...candleData.map(c => c.low))) / Math.min(...candleData.map(c => c.low))) * 100).toFixed(2)}%
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
