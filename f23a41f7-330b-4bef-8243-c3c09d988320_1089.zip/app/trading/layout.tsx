
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Plateforme de Trading',
  description: 'Plateforme de trading professionnelle avec outils d\'analyse technique avancés, graphiques en temps réel et indicateurs personnalisés.',
  keywords: 'trading, analyse technique, graphiques, indicateurs, forex, actions, crypto',
  openGraph: {
    title: 'Plateforme de Trading | CMV Finance',
    description: 'Accédez à notre plateforme de trading professionnelle avec des outils d\'analyse avancés.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Plateforme de Trading | CMV Finance',
    description: 'Accédez à notre plateforme de trading professionnelle avec des outils d\'analyse avancés.',
  },
  robots: {
    index: false,
    follow: false,
  },
};

export default function TradingLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            "name": "Plateforme de Trading CMV",
            "description": "Plateforme de trading professionnelle avec outils d'analyse technique avancés",
            "url": `${process.env.NEXT_PUBLIC_SITE_URL}/trading`,
            "applicationCategory": "FinanceApplication",
            "operatingSystem": "Web",
            "provider": {
              "@type": "Organization",
              "name": "CMV Finance",
              "url": process.env.NEXT_PUBLIC_SITE_URL
            },
            "featureList": [
              "Analyse technique avancée",
              "Graphiques en temps réel",
              "Indicateurs personnalisés",
              "Alertes de trading",
              "Gestion des risques"
            ]
          })
        }}
      />
      {children}
    </>
  );
}
