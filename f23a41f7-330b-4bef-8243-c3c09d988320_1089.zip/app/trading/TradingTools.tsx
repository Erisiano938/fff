
'use client';

import { useState } from 'react';

export default function TradingTools() {
  const [selectedTool, setSelectedTool] = useState('calculator');

  const tools = [
    {
      id: 'calculator',
      name: 'Calculateur de Position',
      description: 'Calculez la taille optimale de vos positions',
      icon: 'ri-calculator-line'
    },
    {
      id: 'calendar',
      name: 'Calendrier Économique',
      description: 'Suivez les événements économiques importants',
      icon: 'ri-calendar-line'
    },
    {
      id: 'analysis',
      name: 'Analyse Technique',
      description: 'Outils d\'analyse technique avancés',
      icon: 'ri-line-chart-line'
    },
    {
      id: 'risk',
      name: 'Gestion des Risques',
      description: 'Gérez et optimisez vos risques',
      icon: 'ri-shield-line'
    }
  ];

  const PositionCalculator = () => {
    const [capital, setCapital] = useState(10000);
    const [riskPercent, setRiskPercent] = useState(2);
    const [entryPrice, setEntryPrice] = useState(1.0845);
    const [stopLoss, setStopLoss] = useState(1.0800);

    const riskAmount = (capital * riskPercent) / 100;
    const priceDiff = Math.abs(entryPrice - stopLoss);
    const positionSize = priceDiff > 0 ? riskAmount / priceDiff : 0;
    const lotSize = positionSize / 100000;

    return (
      <div className="space-y-6">
        <div>
          <label className="block text-gray-400 text-sm mb-2">Capital Total (€)</label>
          <input
            type="number"
            value={capital}
            onChange={(e) => setCapital(Number(e.target.value))}
            className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
          />
        </div>
        <div>
          <label className="block text-gray-400 text-sm mb-2">Risque (%)</label>
          <input
            type="number"
            value={riskPercent}
            onChange={(e) => setRiskPercent(Number(e.target.value))}
            step="0.1"
            max="10"
            className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
          />
        </div>
        <div>
          <label className="block text-gray-400 text-sm mb-2">Prix d'entrée</label>
          <input
            type="number"
            value={entryPrice}
            onChange={(e) => setEntryPrice(Number(e.target.value))}
            step="0.0001"
            className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
          />
        </div>
        <div>
          <label className="block text-gray-400 text-sm mb-2">Stop Loss</label>
          <input
            type="number"
            value={stopLoss}
            onChange={(e) => setStopLoss(Number(e.target.value))}
            step="0.0001"
            className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
          />
        </div>
        <div className="bg-yellow-500/10 p-4 rounded-lg border border-yellow-500/20">
          <h4 className="text-yellow-400 font-semibold mb-2">Résultats</h4>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-400">Montant à risquer:</span>
              <span className="text-white font-semibold">{riskAmount.toFixed(2)} €</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Taille position:</span>
              <span className="text-white font-semibold">{positionSize.toFixed(0)} unités</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Lots:</span>
              <span className="text-white font-semibold">{lotSize.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const EconomicCalendar = () => {
    const events = [
      { time: '14:30', currency: 'USD', event: 'Taux de Chômage', impact: 'high', actual: '3.7%', forecast: '3.8%' },
      { time: '16:00', currency: 'USD', event: 'Confiance Consommateurs', impact: 'medium', actual: '102.3', forecast: '101.5' },
      { time: '20:00', currency: 'EUR', event: 'Réunion BCE', impact: 'high', actual: '-', forecast: '4.0%' },
    ];

    return (
      <div className="space-y-4">
        {events.map((event, index) => (
          <div key={index} className="bg-gray-800/50 p-4 rounded-lg border border-gray-700">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-3">
                <span className="text-yellow-400 font-bold">{event.time}</span>
                <span className="bg-blue-600 text-white px-2 py-1 rounded text-xs">{event.currency}</span>
                <span className={`w-3 h-3 rounded-full ${
                  event.impact === 'high' ? 'bg-red-500' : event.impact === 'medium' ? 'bg-yellow-500' : 'bg-green-500'
                }`}></span>
              </div>
            </div>
            <h4 className="text-white font-semibold mb-2">{event.event}</h4>
            <div className="flex space-x-4 text-sm">
              <span className="text-gray-400">Actuel: <span className="text-white">{event.actual}</span></span>
              <span className="text-gray-400">Prévu: <span className="text-white">{event.forecast}</span></span>
            </div>
          </div>
        ))}
      </div>
    );
  };

  const renderToolContent = () => {
    switch(selectedTool) {
      case 'calculator':
        return <PositionCalculator />;
      case 'calendar':
        return <EconomicCalendar />;
      case 'analysis':
        return (
          <div className="text-center py-12">
            <i className="ri-line-chart-line text-6xl text-yellow-400 mb-4"></i>
            <h3 className="text-xl font-bold text-white mb-2">Analyse Technique</h3>
            <p className="text-gray-400">Outils d'analyse avancés en cours de développement</p>
          </div>
        );
      case 'risk':
        return (
          <div className="text-center py-12">
            <i className="ri-shield-line text-6xl text-yellow-400 mb-4"></i>
            <h3 className="text-xl font-bold text-white mb-2">Gestion des Risques</h3>
            <p className="text-gray-400">Module de gestion des risques en cours de développement</p>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <section className="py-12 bg-gray-900">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-white mb-8">
          Outils de <span className="text-yellow-400">Trading</span>
        </h2>

        <div className="grid lg:grid-cols-4 gap-8">
          <div>
            <div className="space-y-3">
              {tools.map((tool) => (
                <button
                  key={tool.id}
                  onClick={() => setSelectedTool(tool.id)}
                  className={`w-full p-4 rounded-xl border text-left transition-all cursor-pointer ${
                    selectedTool === tool.id
                      ? 'bg-yellow-500/20 border-yellow-500/40 text-white'
                      : 'bg-black/50 border-yellow-500/20 text-gray-400 hover:border-yellow-500/40'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      selectedTool === tool.id ? 'bg-yellow-500/30' : 'bg-yellow-500/20'
                    }`}>
                      <i className={`${tool.icon} text-xl text-yellow-400`}></i>
                    </div>
                    <div>
                      <h3 className="font-semibold">{tool.name}</h3>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="lg:col-span-3">
            <div className="bg-black/50 p-6 rounded-xl border border-yellow-500/20">
              <div className="mb-6">
                <h3 className="text-2xl font-bold text-white mb-2">
                  {tools.find(t => t.id === selectedTool)?.name}
                </h3>
                <p className="text-gray-400">
                  {tools.find(t => t.id === selectedTool)?.description}
                </p>
              </div>
              {renderToolContent()}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
