'use client';

import Link from 'next/link';
import CookieAssistant from '../components/CookieAssistant';

export default function CookiesPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-gray-900 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl font-bold mb-4">Politique des Cookies</h1>
            <p className="text-xl text-gray-300">
              Informations sur l'utilisation des cookies sur CMV Finance
            </p>
            <p className="text-gray-400 mt-4">
              Dernière mise à jour : {new Date().toLocaleDateString('fr-FR')}
            </p>
            <div className="mt-6 p-4 bg-blue-600/20 border border-blue-500/30 rounded-lg">
              <div className="flex items-center justify-center space-x-3">
                <i className="ri-customer-service-line text-blue-400 text-xl"></i>
                <div className="text-left">
                  <p className="text-blue-300 font-medium">Besoin d'aide ?</p>
                  <p className="text-blue-200 text-sm">Notre assistant virtuel peut répondre à vos questions sur les cookies</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          {/* Navigation */}
          <div className="mb-8 p-4 bg-gray-50 rounded-lg">
            <h3 className="font-semibold text-gray-900 mb-3">Navigation rapide :</h3>
            <div className="flex flex-wrap gap-4">
              <a href="#definition" className="text-blue-600 hover:text-blue-800 text-sm">Qu'est-ce qu'un cookie ?</a>
              <a href="#types" className="text-blue-600 hover:text-blue-800 text-sm">Types de cookies</a>
              <a href="#utilisation" className="text-blue-600 hover:text-blue-800 text-sm">Notre utilisation</a>
              <a href="#gestion" className="text-blue-600 hover:text-blue-800 text-sm">Gestion des cookies</a>
              <a href="#tiers" className="text-blue-600 hover:text-blue-800 text-sm">Cookies tiers</a>
              <a href="#contact" className="text-blue-600 hover:text-blue-800 text-sm">Contact</a>
            </div>
          </div>

          <div className="space-y-12">
            {/* Introduction */}
            <section>
              <div className="bg-blue-50 p-6 rounded-lg mb-6">
                <div className="flex items-start space-x-3">
                  <i className="ri-information-line text-blue-600 text-xl mt-1"></i>
                  <div>
                    <h3 className="font-semibold text-blue-900 mb-2">Information importante</h3>
                    <p className="text-blue-800">
                      CMV Finance utilise des cookies pour améliorer votre expérience utilisateur, 
                      personnaliser le contenu et analyser notre trafic. Cette page explique en détail 
                      notre utilisation des cookies et vos droits concernant ces données.
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* Définition */}
            <section id="definition">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">1. Qu'est-ce qu'un cookie ?</h2>
              <div className="prose max-w-none">
                <p className="text-gray-700 mb-4">
                  Un cookie est un petit fichier texte stocké sur votre ordinateur, tablette ou smartphone 
                  lorsque vous visitez un site web. Les cookies permettent au site de mémoriser vos actions 
                  et préférences pendant une période donnée.
                </p>
                <p className="text-gray-700 mb-4">
                  Les cookies ne contiennent aucune information permettant de vous identifier personnellement, 
                  mais peuvent nous aider à vous fournir une expérience plus personnalisée et pertinente.
                </p>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-900 mb-2">Informations typiques stockées :</h4>
                  <ul className="list-disc list-inside space-y-1 text-gray-700">
                    <li>Préférences de langue et de région</li>
                    <li>Informations de connexion (si vous choisissez de rester connecté)</li>
                    <li>Contenu de votre panier ou de vos favoris</li>
                    <li>Paramètres d'affichage et de navigation</li>
                  </ul>
                </div>
              </div>
            </section>

            {/* Types de cookies */}
            <section id="types">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">2. Types de cookies que nous utilisons</h2>
              
              <div className="grid gap-6">
                {/* Cookies essentiels */}
                <div className="border border-gray-200 rounded-lg p-6">
                  <div className="flex items-center mb-3">
                    <i className="ri-shield-check-line text-green-600 text-xl mr-3"></i>
                    <h3 className="text-lg font-semibold text-gray-900">Cookies strictement nécessaires</h3>
                    <span className="ml-auto bg-green-100 text-green-800 px-2 py-1 rounded text-sm">Obligatoires</span>
                  </div>
                  <p className="text-gray-700 mb-3">
                    Ces cookies sont indispensables au fonctionnement du site et ne peuvent pas être désactivés.
                  </p>
                  <div className="bg-gray-50 p-3 rounded">
                    <strong className="text-sm text-gray-900">Exemples :</strong>
                    <ul className="list-disc list-inside text-sm text-gray-700 mt-1">
                      <li>Cookies de session et d'authentification</li>
                      <li>Cookies de sécurité et de prévention des fraudes</li>
                      <li>Cookies de répartition de charge</li>
                    </ul>
                  </div>
                </div>

                {/* Cookies fonctionnels */}
                <div className="border border-gray-200 rounded-lg p-6">
                  <div className="flex items-center mb-3">
                    <i className="ri-settings-3-line text-blue-600 text-xl mr-3"></i>
                    <h3 className="text-lg font-semibold text-gray-900">Cookies fonctionnels</h3>
                    <span className="ml-auto bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">Recommandés</span>
                  </div>
                  <p className="text-gray-700 mb-3">
                    Ces cookies améliorent les fonctionnalités et la personnalisation du site.
                  </p>
                  <div className="bg-gray-50 p-3 rounded">
                    <strong className="text-sm text-gray-900">Exemples :</strong>
                    <ul className="list-disc list-inside text-sm text-gray-700 mt-1">
                      <li>Mémorisation de vos préférences (langue, devise)</li>
                      <li>Sauvegarde de vos paramètres de trading</li>
                      <li>Personnalisation de l'interface utilisateur</li>
                    </ul>
                  </div>
                </div>

                {/* Cookies analytiques */}
                <div className="border border-gray-200 rounded-lg p-6">
                  <div className="flex items-center mb-3">
                    <i className="ri-bar-chart-line text-purple-600 text-xl mr-3"></i>
                    <h3 className="text-lg font-semibold text-gray-900">Cookies analytiques</h3>
                    <span className="ml-auto bg-purple-100 text-purple-800 px-2 py-1 rounded text-sm">Optionnels</span>
                  </div>
                  <p className="text-gray-700 mb-3">
                    Ces cookies nous aident à comprendre comment vous utilisez notre site pour l'améliorer.
                  </p>
                  <div className="bg-gray-50 p-3 rounded">
                    <strong className="text-sm text-gray-900">Exemples :</strong>
                    <ul className="list-disc list-inside text-sm text-gray-700 mt-1">
                      <li>Google Analytics (trafic et comportement)</li>
                      <li>Statistiques de performance</li>
                      <li>Tests A/B et optimisation</li>
                    </ul>
                  </div>
                </div>

                {/* Cookies marketing */}
                <div className="border border-gray-200 rounded-lg p-6">
                  <div className="flex items-center mb-3">
                    <i className="ri-megaphone-line text-orange-600 text-xl mr-3"></i>
                    <h3 className="text-lg font-semibold text-gray-900">Cookies marketing</h3>
                    <span className="ml-auto bg-orange-100 text-orange-800 px-2 py-1 rounded text-sm">Optionnels</span>
                  </div>
                  <p className="text-gray-700 mb-3">
                    Ces cookies servent à vous proposer des publicités et du contenu pertinents.
                  </p>
                  <div className="bg-gray-50 p-3 rounded">
                    <strong className="text-sm text-gray-900">Exemples :</strong>
                    <ul className="list-disc list-inside text-sm text-gray-700 mt-1">
                      <li>Suivi des conversions publicitaires</li>
                      <li>Retargeting et personnalisation des annonces</li>
                      <li>Réseaux sociaux (Facebook Pixel, LinkedIn Insight)</li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>

            {/* Notre utilisation */}
            <section id="utilisation">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">3. Comment nous utilisons les cookies</h2>
              
              <div className="space-y-6">
                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-lg">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Finalités principales :</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="flex items-start space-x-3">
                      <i className="ri-user-settings-line text-blue-600 text-xl mt-1"></i>
                      <div>
                        <h4 className="font-medium text-gray-900">Personnalisation</h4>
                        <p className="text-sm text-gray-700">Adapter l'interface à vos préférences</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <i className="ri-shield-user-line text-blue-600 text-xl mt-1"></i>
                      <div>
                        <h4 className="font-medium text-gray-900">Sécurité</h4>
                        <p className="text-sm text-gray-700">Protéger votre compte et vos données</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <i className="ri-line-chart-line text-blue-600 text-xl mt-1"></i>
                      <div>
                        <h4 className="font-medium text-gray-900">Performance</h4>
                        <p className="text-sm text-gray-700">Optimiser la vitesse et la fiabilité</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <i className="ri-lightbulb-line text-blue-600 text-xl mt-1"></i>
                      <div>
                        <h4 className="font-medium text-gray-900">Amélioration</h4>
                        <p className="text-sm text-gray-700">Développer de nouvelles fonctionnalités</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="border-l-4 border-yellow-400 bg-yellow-50 p-4">
                  <div className="flex">
                    <i className="ri-alert-line text-yellow-600 text-xl mr-3 mt-1"></i>
                    <div>
                      <h4 className="font-medium text-yellow-800">Données financières</h4>
                      <p className="text-yellow-700 text-sm mt-1">
                        Les cookies ne stockent jamais d'informations financières sensibles 
                        (numéros de compte, mots de passe, données de cartes de crédit). 
                        Ces informations sont traitées via des connexions sécurisées séparées.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Gestion des cookies */}
            <section id="gestion">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">4. Gestion et contrôle des cookies</h2>
              
              <div className="space-y-6">
                {/* Paramètres du navigateur */}
                <div className="bg-gray-50 p-6 rounded-lg">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">
                    <i className="ri-settings-line text-gray-600 mr-2"></i>
                    Paramètres de votre navigateur
                  </h3>
                  <p className="text-gray-700 mb-4">
                    Vous pouvez configurer votre navigateur pour contrôler les cookies :
                  </p>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <h4 className="font-medium text-gray-900">Chrome :</h4>
                      <p className="text-sm text-gray-700">
                        Paramètres → Confidentialité et sécurité → Cookies et autres données de sites
                      </p>
                    </div>
                    <div className="space-y-2">
                      <h4 className="font-medium text-gray-900">Firefox :</h4>
                      <p className="text-sm text-gray-700">
                        Options → Vie privée et sécurité → Cookies et données de sites
                      </p>
                    </div>
                    <div className="space-y-2">
                      <h4 className="font-medium text-gray-900">Safari :</h4>
                      <p className="text-sm text-gray-700">
                        Préférences → Confidentialité → Gérer les données de sites web
                      </p>
                    </div>
                    <div className="space-y-2">
                      <h4 className="font-medium text-gray-900">Edge :</h4>
                      <p className="text-sm text-gray-700">
                        Paramètres → Cookies et autorisations de site → Cookies et données stockées
                      </p>
                    </div>
                  </div>
                </div>

                {/* Centre de préférences */}
                <div className="border border-blue-200 bg-blue-50 p-6 rounded-lg">
                  <h3 className="text-lg font-semibold text-blue-900 mb-3">
                    <i className="ri-dashboard-line text-blue-600 mr-2"></i>
                    Centre de préférences CMV Finance
                  </h3>
                  <p className="text-blue-800 mb-4">
                    Gérez vos préférences de cookies directement depuis notre plateforme :
                  </p>
                  <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors cursor-pointer">
                    Gérer mes préférences
                  </button>
                </div>

                {/* Conséquences */}
                <div className="border border-orange-200 bg-orange-50 p-4 rounded-lg">
                  <h4 className="font-medium text-orange-800 mb-2">
                    <i className="ri-alert-line text-orange-600 mr-2"></i>
                    Impact de la désactivation des cookies
                  </h4>
                  <ul className="list-disc list-inside text-sm text-orange-700 space-y-1">
                    <li>Certaines fonctionnalités peuvent ne plus être disponibles</li>
                    <li>Vos préférences ne seront pas mémorisées</li>
                    <li>L'expérience utilisateur peut être dégradée</li>
                    <li>Vous devrez vous reconnecter à chaque visite</li>
                  </ul>
                </div>
              </div>
            </section>

            {/* Cookies tiers */}
            <section id="tiers">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">5. Cookies de services tiers</h2>
              
              <div className="space-y-4">
                <p className="text-gray-700">
                  Nous utilisons des services tiers qui peuvent déposer leurs propres cookies. 
                  Voici la liste des principaux partenaires :
                </p>

                <div className="overflow-x-auto">
                  <table className="w-full border border-gray-200 rounded-lg">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="text-left p-4 font-semibold text-gray-900">Service</th>
                        <th className="text-left p-4 font-semibold text-gray-900">Finalité</th>
                        <th className="text-left p-4 font-semibold text-gray-900">Durée</th>
                        <th className="text-left p-4 font-semibold text-gray-900">Politique</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      <tr>
                        <td className="p-4 font-medium">Google Analytics</td>
                        <td className="p-4 text-gray-700">Analyse d'audience</td>
                        <td className="p-4 text-gray-700">24 mois</td>
                        <td className="p-4">
                          <a href="https://policies.google.com/privacy" target="_blank" rel="noopener noreferrer" 
                             className="text-blue-600 hover:text-blue-800">
                            Voir la politique
                          </a>
                        </td>
                      </tr>
                      <tr>
                        <td className="p-4 font-medium">Google Tag Manager</td>
                        <td className="p-4 text-gray-700">Gestion des tags</td>
                        <td className="p-4 text-gray-700">Session</td>
                        <td className="p-4">
                          <a href="https://policies.google.com/privacy" target="_blank" rel="noopener noreferrer" 
                             className="text-blue-600 hover:text-blue-800">
                            Voir la politique
                          </a>
                        </td>
                      </tr>
                      <tr>
                        <td className="p-4 font-medium">Hotjar</td>
                        <td className="p-4 text-gray-700">Analyse comportementale</td>
                        <td className="p-4 text-gray-700">12 mois</td>
                        <td className="p-4">
                          <a href="https://www.hotjar.com/legal/policies/privacy/" target="_blank" rel="noopener noreferrer" 
                             className="text-blue-600 hover:text-blue-800">
                            Voir la politique
                          </a>
                        </td>
                      </tr>
                      <tr>
                        <td className="p-4 font-medium">LinkedIn Insight</td>
                        <td className="p-4 text-gray-700">Publicité ciblée</td>
                        <td className="p-4 text-gray-700">6 mois</td>
                        <td className="p-4">
                          <a href="https://www.linkedin.com/legal/privacy-policy" target="_blank" rel="noopener noreferrer" 
                             className="text-blue-600 hover:text-blue-800">
                            Voir la politique
                          </a>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </section>

            {/* Durées de conservation */}
            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-6">6. Durées de conservation</h2>
              
              <div className="grid md:grid-cols-3 gap-4">
                <div className="bg-green-50 border border-green-200 p-4 rounded-lg">
                  <h3 className="font-semibold text-green-800 mb-2">Cookies de session</h3>
                  <p className="text-green-700 text-sm">
                    Supprimés automatiquement à la fermeture du navigateur
                  </p>
                </div>
                <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
                  <h3 className="font-semibold text-blue-800 mb-2">Cookies fonctionnels</h3>
                  <p className="text-blue-700 text-sm">
                    Conservés jusqu'à 12 mois ou suppression manuelle
                  </p>
                </div>
                <div className="bg-purple-50 border border-purple-200 p-4 rounded-lg">
                  <h3 className="font-semibold text-purple-800 mb-2">Cookies analytiques</h3>
                  <p className="text-purple-700 text-sm">
                    Conservés jusqu'à 24 mois maximum
                  </p>
                </div>
              </div>
            </section>

            {/* Modifications */}
            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-6">7. Modifications de cette politique</h2>
              <div className="bg-gray-50 p-6 rounded-lg">
                <p className="text-gray-700 mb-4">
                  Nous nous réservons le droit de modifier cette politique des cookies à tout moment. 
                  Les modifications importantes vous seront notifiées par :
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2">
                  <li>Une notification sur notre site web</li>
                  <li>Un email d'information (si vous êtes inscrit)</li>
                  <li>Une mise à jour de la date de "dernière modification"</li>
                </ul>
                <p className="text-gray-700 mt-4">
                  Nous vous encourageons à consulter régulièrement cette page pour rester informé 
                  de nos pratiques concernant les cookies.
                </p>
              </div>
            </section>

            {/* Contact */}
            <section id="contact">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">8. Contact et questions</h2>
              
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-lg">
                <p className="text-gray-700 mb-6">
                  Pour toute question concernant notre utilisation des cookies ou pour exercer vos droits :
                </p>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <i className="ri-mail-line text-blue-600 text-xl"></i>
                      <div>
                        <h4 className="font-medium text-gray-900">Email</h4>
                        <p className="text-gray-700">privacy@cmvfinance.com</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <i className="ri-phone-line text-blue-600 text-xl"></i>
                      <div>
                        <h4 className="font-medium text-gray-900">Téléphone</h4>
                        <p className="text-gray-700">+33 1 23 45 67 89</p>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <i className="ri-map-pin-line text-blue-600 text-xl"></i>
                      <div>
                        <h4 className="font-medium text-gray-900">Adresse</h4>
                        <p className="text-gray-700">
                          123 Avenue de la Finance<br />
                          75001 Paris, France
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 pt-6 border-t border-blue-200">
                  <Link href="/contact" 
                        className="inline-flex items-center bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors">
                    <i className="ri-customer-service-line mr-2"></i>
                    Nous contacter
                  </Link>
                </div>
              </div>
            </section>

            {/* Retour */}
            <div className="text-center pt-8 border-t border-gray-200">
              <Link href="/" 
                    className="inline-flex items-center text-blue-600 hover:text-blue-800 font-medium">
                <i className="ri-arrow-left-line mr-2"></i>
                Retour à l'accueil
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Assistant virtuel intégré */}
      <CookieAssistant />
    </div>
  );
}
