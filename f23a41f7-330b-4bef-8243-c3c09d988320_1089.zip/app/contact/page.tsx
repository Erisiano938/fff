
'use client';

import { useState, useEffect } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

export default function ContactPage() {
  const [formData, setFormData] = useState({
    nom: '',
    prenom: '',
    email: '',
    telephone: '',
    message: '',
    typeConseil: '',
    patrimoine: '',
    urgence: 'normale'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState('');
  const [creneauxDisponibles, setCreneauxDisponibles] = useState([]);
  const [conseillerSelectionne, setConseillerSelectionne] = useState('');
  const [showCalendrier, setShowCalendrier] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  useEffect(() => {
    fetchCreneauxDisponibles();
  }, []);

  const fetchCreneauxDisponibles = async () => {
    const creneaux = [
      { 
        conseiller: 'Marie Lefèvre', 
        specialite: 'Épargne retraite & Optimisation fiscale',
        dates: [
          { date: '2024-01-17', heures: ['09:00', '10:30', '14:00', '15:30'] },
          { date: '2024-01-18', heures: ['09:00', '11:00', '16:00'] },
          { date: '2024-01-19', heures: ['10:00', '14:30'] }
        ]
      },
      { 
        conseiller: 'Jean Dupuis', 
        specialite: 'Transmission patrimoniale & Immobilier',
        dates: [
          { date: '2024-01-17', heures: ['10:00', '14:30', '16:00'] },
          { date: '2024-01-18', heures: ['09:30', '13:30', '15:00'] },
          { date: '2024-01-19', heures: ['09:00', '11:30'] }
        ]
      },
      { 
        conseiller: 'Paul Bernard', 
        specialite: 'Gestion de fortune & Investissements',
        dates: [
          { date: '2024-01-17', heures: ['08:30', '11:30', '15:00'] },
          { date: '2024-01-18', heures: ['10:00', '14:00', '17:00'] },
          { date: '2024-01-19', heures: ['09:30', '13:00', '16:30'] }
        ]
      }
    ];
    setCreneauxDisponibles(creneaux);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });

    if (name === 'typeConseil') {
      let conseillerSuggere = '';
      switch (value) {
        case 'retraite':
        case 'fiscalite':
          conseillerSuggere = 'Marie Lefèvre';
          break;
        case 'transmission':
        case 'immobilier':
          conseillerSuggere = 'Jean Dupuis';
          break;
        case 'investissement':
        case 'gestion':
          conseillerSuggere = 'Paul Bernard';
          break;
      }
      setConseillerSelectionne(conseillerSuggere);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const demandeData = {
        ...formData,
        conseillerSuggere: conseillerSelectionne,
        dateCreation: new Date().toISOString(),
        statut: 'nouveau',
        origine: 'Formulaire site web',
        priorite: formData.urgence === 'urgent' ? 'haute' : 'normale',
        syncUnifiedDashboard: true
      };

      console.log('Demande synchronisée:', demandeData);

      await notifierConseillerUnifie(demandeData);

      setSubmitStatus('success');
      setShowCalendrier(true);

    } catch (error) {
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const notifierConseillerUnifie = async (demande) => {
    return new Promise(resolve => {
      setTimeout(() => {
        console.log('Notification envoyée au tableau de bord unifié');
        resolve(true);
      }, 1000);
    });
  };

  const reserverCreneau = async (conseiller, date, heure) => {
    try {
      const reservationData = {
        client: formData,
        conseiller,
        date,
        heure,
        type: 'prospection',
        origine: 'site_web',
        statut: 'programme',
        syncUnifiedDashboard: true
      };

      console.log('Réservation synchronisée:', reservationData);

      setSubmitStatus('rdv_confirmed');
      setShowCalendrier(false);

      fetchCreneauxDisponibles();

    } catch (error) {
      console.error('Erreur lors de la réservation:', error);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <Header />

      <div className="pt-32 pb-16">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Contactez nos <span className="text-yellow-400">Experts</span>
            </h1>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto mb-8">
              Bénéficiez d'un conseil personnalisé avec nos conseillers en gestion de patrimoine. 
              Prise de rendez-vous en temps réel selon leurs disponibilités.
            </p>
            <div className="flex items-center justify-center space-x-4 text-sm text-green-400">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span>Agenda synchronisé en temps réel</span>
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            <div className="bg-gray-900 rounded-2xl p-8 border border-yellow-500/20">
              <h2 className="text-2xl font-bold text-white mb-6">Demande de Conseil</h2>

              {submitStatus === 'success' && !showCalendrier && (
                <div className="bg-green-500/20 border border-green-500/30 rounded-lg p-4 mb-6">
                  <div className="flex items-center space-x-2 text-green-400">
                    <i className="ri-check-line"></i>
                    <span>Demande envoyée ! Votre conseiller a été notifié automatiquement.</span>
                  </div>
                </div>
              )}

              {submitStatus === 'rdv_confirmed' && (
                <div className="bg-blue-500/20 border border-blue-500/30 rounded-lg p-4 mb-6">
                  <div className="flex items-center space-x-2 text-blue-400">
                    <i className="ri-calendar-check-line"></i>
                    <span>Rendez-vous confirmé ! Vous recevrez une confirmation par email.</span>
                  </div>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="prenom" className="block text-gray-300 font-medium mb-2">
                      Prénom *
                    </label>
                    <input
                      type="text"
                      id="prenom"
                      name="prenom"
                      value={formData.prenom}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-400 focus:outline-none transition-colors"
                      placeholder="Votre prénom"
                    />
                  </div>
                  <div>
                    <label htmlFor="nom" className="block text-gray-300 font-medium mb-2">
                      Nom *
                    </label>
                    <input
                      type="text"
                      id="nom"
                      name="nom"
                      value={formData.nom}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-400 focus:outline-none transition-colors"
                      placeholder="Votre nom"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="email" className="block text-gray-300 font-medium mb-2">
                      Email *
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-400 focus:outline-none transition-colors"
                      placeholder="votre@email.com"
                    />
                  </div>
                  <div>
                    <label htmlFor="telephone" className="block text-gray-300 font-medium mb-2">
                      Téléphone
                    </label>
                    <input
                      type="tel"
                      id="telephone"
                      name="telephone"
                      value={formData.telephone}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-400 focus:outline-none transition-colors"
                      placeholder="06.12.34.56.78"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="typeConseil" className="block text-gray-300 font-medium mb-2">
                      Type de conseil souhaité
                    </label>
                    <select
                      id="typeConseil"
                      name="typeConseil"
                      value={formData.typeConseil}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-400 focus:outline-none transition-colors pr-8"
                    >
                      <option value="">Sélectionnez un domaine</option>
                      <option value="retraite">Épargne retraite</option>
                      <option value="fiscalite">Optimisation fiscale</option>
                      <option value="transmission">Transmission patrimoniale</option>
                      <option value="immobilier">Investissement immobilier</option>
                      <option value="investissement">Gestion d'investissements</option>
                      <option value="gestion">Gestion de fortune</option>
                      <option value="autre">Autre</option>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="patrimoine" className="block text-gray-300 font-medium mb-2">
                      Estimation patrimoine
                    </label>
                    <select
                      id="patrimoine"
                      name="patrimoine"
                      value={formData.patrimoine}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-400 focus:outline-none transition-colors pr-8"
                    >
                      <option value="">Sélectionnez une tranche</option>
                      <option value="<100k">Moins de 100k€</option>
                      <option value="100k-300k">100k€ - 300k€</option>
                      <option value="300k-500k">300k€ - 500k€</option>
                      <option value="500k-1M">500k€ - 1M€</option>
                      <option value="1M-2M">1M€ - 2M€</option>
                      <option value=">2M">Plus de 2M€</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label htmlFor="urgence" className="block text-gray-300 font-medium mb-2">
                    Urgence de la demande
                  </label>
                  <div className="flex space-x-4">
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="radio"
                        name="urgence"
                        value="normale"
                        checked={formData.urgence === 'normale'}
                        onChange={handleInputChange}
                        className="text-yellow-400"
                      />
                      <span className="text-gray-300">Normale</span>
                    </label>
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="radio"
                        name="urgence"
                        value="urgent"
                        checked={formData.urgence === 'urgent'}
                        onChange={handleInputChange}
                        className="text-yellow-400"
                      />
                      <span className="text-gray-300">Urgent (sous 24h)</span>
                    </label>
                  </div>
                </div>

                {conseillerSelectionne && (
                  <div className="bg-blue-500/20 border border-blue-500/30 rounded-lg p-4">
                    <div className="flex items-center space-x-2 text-blue-400 mb-2">
                      <i className="ri-user-star-line"></i>
                      <span className="font-semibold">Conseiller suggéré</span>
                    </div>
                    <div className="text-white font-medium">{conseillerSelectionne}</div>
                    <div className="text-gray-300 text-sm">
                      {creneauxDisponibles.find(c => c.conseiller === conseillerSelectionne)?.specialite}
                    </div>
                  </div>
                )}

                <div>
                  <label htmlFor="message" className="block text-gray-300 font-medium mb-2">
                    Message *
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    required
                    rows={5}
                    maxLength={500}
                    className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-400 focus:outline-none transition-colors resize-vertical"
                    placeholder="Décrivez votre situation et vos objectifs patrimoniaux..."
                  />
                  <div className="text-right text-xs text-gray-400 mt-1">
                    {formData.message.length}/500 caractères
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-gradient-to-r from-yellow-400 to-yellow-500 text-black py-4 px-6 rounded-lg font-bold text-lg hover:from-yellow-500 hover:to-yellow-600 transition-all cursor-pointer whitespace-nowrap disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <span className="flex items-center justify-center space-x-2">
                      <i className="ri-loader-4-line animate-spin"></i>
                      <span>Envoi en cours...</span>
                    </span>
                  ) : (
                    'Envoyer ma demande'
                  )}
                </button>
              </form>
            </div>

            <div className="bg-gray-900 rounded-2xl p-8 border border-yellow-500/20">
              <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
                <i className="ri-calendar-line text-yellow-400 mr-3"></i>
                Disponibilités en Temps Réel
              </h2>

              {showCalendrier && (
                <div className="mb-6 bg-green-500/20 border border-green-500/30 rounded-lg p-4">
                  <div className="flex items-center space-x-2 text-green-400 mb-2">
                    <i className="ri-check-line"></i>
                    <span className="font-semibold">Demande enregistrée !</span>
                  </div>
                  <p className="text-gray-300 text-sm">
                    Vous pouvez maintenant réserver directement un créneau avec {conseillerSelectionne || 'nos conseillers'}.
                  </p>
                </div>
              )}

              <div className="space-y-6">
                {creneauxDisponibles.map((conseiller, index) => (
                  <div key={index} className="bg-black/30 rounded-xl p-6 border border-gray-700/50">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-12 h-12 bg-yellow-400/20 rounded-full flex items-center justify-center">
                        <i className="ri-user-line text-yellow-400 text-xl"></i>
                      </div>
                      <div>
                        <h3 className="text-white font-bold text-lg">{conseiller.conseiller}</h3>
                        <p className="text-gray-400 text-sm">{conseiller.specialite}</p>
                      </div>
                      {conseillerSelectionne === conseiller.conseiller && (
                        <span className="bg-blue-500/20 text-blue-400 px-3 py-1 rounded-full text-xs font-semibold">
                          Suggéré
                        </span>
                      )}
                    </div>

                    <div className="space-y-3">
                      {conseiller.dates.map((jour, jourIndex) => (
                        <div key={jourIndex}>
                          <div className="text-blue-400 font-semibold mb-2">
                            {new Date(jour.date).toLocaleDateString('fr-FR', { 
                              weekday: 'long', 
                              day: 'numeric', 
                              month: 'long' 
                            })}
                          </div>
                          <div className="grid grid-cols-3 gap-2">
                            {jour.heures.map((heure) => (
                              <button
                                key={`${jour.date}-${heure}`}
                                onClick={() => reserverCreneau(conseiller.conseiller, jour.date, heure)}
                                disabled={!showCalendrier && submitStatus !== 'success'}
                                className={`px-3 py-2 rounded-lg text-sm font-semibold transition-all cursor-pointer whitespace-nowrap ${
                                  showCalendrier || submitStatus === 'success'
                                    ? 'bg-green-500 hover:bg-green-600 text-white'
                                    : 'bg-gray-700 text-gray-400 cursor-not-allowed'
                                }`}
                              >
                                {heure}
                              </button>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4">
                <div className="flex items-start space-x-2">
                  <i className="ri-information-line text-yellow-400 mt-0.5"></i>
                  <div className="text-yellow-300 text-sm">
                    <strong>Agenda synchronisé</strong><br />
                    Les créneaux affichés sont mis à jour en temps réel depuis notre tableau de bord unifié. 
                    Une fois votre demande envoyée, vous pouvez réserver directement un créneau disponible.
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-16 grid md:grid-cols-3 gap-8">
            <div className="bg-gray-900 rounded-xl p-6 border border-gray-700/50 text-center">
              <div className="w-16 h-16 bg-yellow-400/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-phone-line text-2xl text-yellow-400"></i>
              </div>
              <h3 className="text-white font-bold text-lg mb-2">Téléphone</h3>
              <p className="text-gray-400 mb-4">Contactez-nous directement</p>
              <a href="tel:+33123456789" className="text-yellow-400 hover:text-yellow-300 transition-colors">
                01 23 45 67 89
              </a>
            </div>

            <div className="bg-gray-900 rounded-xl p-6 border border-gray-700/50 text-center">
              <div className="w-16 h-16 bg-yellow-400/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-mail-line text-2xl text-yellow-400"></i>
              </div>
              <h3 className="text-white font-bold text-lg mb-2">Email</h3>
              <p className="text-gray-400 mb-4">Écrivez-nous</p>
              <a href="mailto:contact@cmvfinance.com" className="text-yellow-400 hover:text-yellow-300 transition-colors">
                contact@cmvfinance.com
              </a>
            </div>

            <div className="bg-gray-900 rounded-xl p-6 border border-gray-700/50 text-center">
              <div className="w-16 h-16 bg-yellow-400/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-map-pin-line text-2xl text-yellow-400"></i>
              </div>
              <h3 className="text-white font-bold text-lg mb-2">Adresse</h3>
              <p className="text-gray-400 mb-4">Venez nous voir</p>
              <p className="text-yellow-400">
                123 Avenue des Champs<br />
                75008 Paris
              </p>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
