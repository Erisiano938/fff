
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Contact',
  description: 'Contactez notre équipe d\'experts en finance et trading. Nous sommes là pour répondre à toutes vos questions sur nos services et solutions.',
  keywords: 'contact, support, équipe, experts finance, conseil, assistance',
  openGraph: {
    title: 'Contact | CMV Finance',
    description: 'Contactez notre équipe d\'experts pour bénéficier de nos conseils personnalisés.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Contact | CMV Finance',
    description: 'Contactez notre équipe d\'experts pour bénéficier de nos conseils personnalisés.',
  },
};

export default function ContactLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "ContactPage",
            "name": "Contact CMV Finance",
            "description": "Page de contact pour CMV Finance",
            "url": `${process.env.NEXT_PUBLIC_SITE_URL}/contact`,
            "mainEntity": {
              "@type": "Organization",
              "name": "CMV Finance",
              "url": process.env.NEXT_PUBLIC_SITE_URL,
              "contactPoint": {
                "@type": "ContactPoint",
                "contactType": "customer service",
                "availableLanguage": "French"
              }
            }
          })
        }}
      />
      {children}
    </>
  );
}
