
export interface Article {
  id: string;
  title: string;
  content: string;
  markdownContent?: string;
  category: string;
  tags?: string[];
  coverImage?: string;
  image?: string;
  author: string;
  createdAt: string;
  publishedAt?: string;
  views: number;
  isPublished: boolean;
  readingTime?: number;
  description?: string;
  excerpt?: string;
  status?: 'published' | 'draft';
  featured?: boolean;  
  isFeatured?: boolean;
}

// Articles par défaut pour le rendu serveur
const defaultArticles: Record<string, Article> = {
  'introduction-trading': {
    id: 'introduction-trading',
    title: 'Introduction au Trading',
    content: `
      <h2>Bienvenue dans le monde du trading</h2>
      <p>Le trading est l'art d'acheter et de vendre des instruments financiers pour réaliser des profits à court ou moyen terme. Cette discipline demande une solide compréhension des marchés, une stratégie claire et une gestion rigoureuse des risques.</p>
      
      <h3>Les bases du trading</h3>
      <p>Avant de commencer à trader, il est essentiel de comprendre :</p>
      <ul>
        <li>Les différents types de marchés (actions, forex, crypto, matières premières)</li>
        <li>Les ordres de base (market, limit, stop)</li>
        <li>L'analyse technique et fondamentale</li>
        <li>La gestion du capital et des risques</li>
      </ul>
      
      <h3>Choisir sa stratégie</h3>
      <p>Il existe plusieurs approches de trading :</p>
      <ul>
        <li><strong>Day trading</strong> : positions ouvertes et fermées dans la journée</li>
        <li><strong>Swing trading</strong> : positions gardées quelques jours à semaines</li>
        <li><strong>Position trading</strong> : investissements à plus long terme</li>
      </ul>
      <p>Chaque stratégie a ses avantages et inconvénients selon votre profil et vos objectifs.</p>
      
      <h3>Premiers pas pratiques</h3>
      <p>Pour commencer en trading :</p>
      <ul>
        <li>Formez-vous avant d'investir</li>
        <li>Commencez avec un compte démo</li>
        <li>Définissez votre plan de trading</li>
        <li>Ne risquez que ce que vous pouvez vous permettre de perdre</li>
      </ul>
    `,
    category: 'Débutant',
    author: 'Expert CMV',
    createdAt: new Date().toISOString(),
    views: 245,
    isPublished: true,
    readingTime: 8,
    description: 'Une introduction complète aux bases du trading financier',
    tags: ['trading', 'débutant', 'bases'],
    coverImage: 'https://readdy.ai/api/search-image?query=professional%20trading%20desk%20with%20multiple%20monitors%20showing%20financial%20charts%20and%20market%20data%2C%20modern%20office%20environment%2C%20blue%20and%20gold%20color%20scheme%2C%20clean%20minimalist%20background&width=800&height=400&seq=1&orientation=landscape'
  },
  'gestion-risques-bases': {
    id: 'gestion-risques-bases',
    title: 'Les Bases de la Gestion des Risques',
    content: `
      <h2>Pourquoi la gestion des risques est cruciale</h2>
      <p>Dans le trading, la gestion des risques est plus importante que la recherche de profits. C'est elle qui détermine votre survie à long terme sur les marchés financiers.</p>
      
      <h3>Les règles fondamentales</h3>
      <ul>
        <li><strong>Ne jamais risquer plus de 2% par trade</strong> : Cette règle d'or protège votre capital</li>
        <li><strong>Utiliser des stop-loss</strong> : Définissez toujours votre point de sortie avant d'entrer en position</li>
        <li><strong>Diversifier</strong> : Ne mettez pas tous vos œufs dans le même panier</li>
        <li><strong>Ratio risque/récompense</strong> : Visez au minimum 1:2 (risquer 1 pour gagner 2)</li>
      </ul>
      
      <h3>Calcul de la taille de position</h3>
      <p>La formule de base :</p>
      <p><strong>Taille = (Capital × % risque) / (Prix entrée - Stop loss)</strong></p>
      
      <h3>Psychologie du risque</h3>
      <p>La gestion des risques est aussi psychologique :</p>
      <ul>
        <li>Accepter les pertes comme faisant partie du jeu</li>
        <li>Ne pas laisser les émotions guider vos décisions</li>
        <li>Tenir un journal de trading pour analyser vos erreurs</li>
      </ul>
      
      <h3>Outils de gestion des risques</h3>
      <p>Utilisez ces outils pour protéger votre capital :</p>
      <ul>
        <li>Stop-loss : limite les pertes</li>
        <li>Take-profit : sécurise les gains</li>
        <li>Position sizing : calcule la taille optimale</li>
        <li>Trailing stop : suit le mouvement favorable</li>
      </ul>
    `,
    category: 'Gestion des Risques',
    author: 'Expert CMV',
    createdAt: new Date().toISOString(),
    views: 189,
    isPublished: true,
    readingTime: 12,
    description: 'Apprenez à protéger votre capital avec les bonnes stratégies',
    tags: ['risques', 'gestion', 'capital', 'protection'],
    coverImage: 'https://readdy.ai/api/search-image?query=risk%20management%20concept%20with%20financial%20charts%2C%20calculator%20and%20protective%20shield%20symbol%2C%20professional%20blue%20and%20gold%20theme%2C%20clean%20minimalist%20background&width=800&height=400&seq=2&orientation=landscape'
  },
  'analyse-technique-fondamentale': {
    id: 'analyse-technique-fondamentale',
    title: 'Analyse Technique vs Analyse Fondamentale',
    content: `
      <h2>Deux approches complémentaires</h2>
      <p>L'analyse technique et l'analyse fondamentale sont deux méthodes différentes pour évaluer les opportunités de trading.</p>
      
      <h3>L'Analyse Technique</h3>
      <p>Se base sur l'étude des graphiques et indicateurs :</p>
      <ul>
        <li><strong>Moyennes mobiles</strong> : identifier les tendances</li>
        <li><strong>RSI</strong> : détecter les zones de surachat/survente</li>
        <li><strong>Support et résistance</strong> : niveaux clés de prix</li>
        <li><strong>Chandeliers japonais</strong> : patterns de retournement</li>
      </ul>
      
      <h3>L'Analyse Fondamentale</h3>
      <p>Évalue la valeur intrinsèque basée sur :</p>
      <ul>
        <li><strong>Résultats financiers</strong> : chiffre d'affaires, bénéfices, dette</li>
        <li><strong>Contexte économique</strong> : taux d'intérêt, inflation, croissance</li>
        <li><strong>Secteur d'activité</strong> : perspectives du marché</li>
        <li><strong>Management</strong> : qualité de l'équipe dirigeante</li>
      </ul>
      
      <h3>Comment les combiner</h3>
      <p>La meilleure approche consiste souvent à :</p>
      <ul>
        <li>Utiliser l'analyse fondamentale pour choisir QUOI trader</li>
        <li>Utiliser l'analyse technique pour décider QUAND trader</li>
        <li>Adapter votre approche selon l'horizon de temps</li>
      </ul>
      
      <h3>Avantages et limites</h3>
      <p><strong>Analyse technique :</strong></p>
      <ul>
        <li>✅ Réactive aux changements de prix</li>
        <li>✅ Applicable à tous les marchés</li>
        <li>❌ Peut donner de faux signaux</li>
      </ul>
      <p><strong>Analyse fondamentale :</strong></p>
      <ul>
        <li>✅ Base solide pour investir</li>
        <li>✅ Vision long terme</li>
        <li>❌ Moins réactive aux mouvements court terme</li>
      </ul>
    `,
    category: 'Analyse',
    author: 'Expert CMV',
    createdAt: new Date(Date.now() - 86400000).toISOString(),
    views: 156,
    isPublished: true,
    readingTime: 10,
    description: 'Comprendre et maîtriser les deux piliers de l\'analyse de marché',
    tags: ['analyse', 'technique', 'fondamentale', 'méthodes'],
    coverImage: 'https://readdy.ai/api/search-image?query=split%20screen%20showing%20technical%20analysis%20charts%20with%20candlesticks%20and%20fundamental%20analysis%20with%20financial%20reports%2C%20professional%20trading%20environment%2C%20clean%20minimalist%20background&width=800&height=400&seq=3&orientation=landscape'
  }
};

// Service principal pour récupérer un article - RENDU DYNAMIQUE
export async function getArticle(slug: string): Promise<Article | null> {
  console.log('🔍 [DYNAMIQUE] Recherche article:', slug);
  
  // Protection contre les valeurs invalides
  if (!slug || slug === 'undefined' || slug === 'null' || slug.trim() === '') {
    console.warn('❌ Slug invalide:', slug);
    return null;
  }

  try {
    // CÔTÉ CLIENT - LECTURE DIRECTE DU SYSTÈME UNIFIÉ
    if (typeof window !== 'undefined') {
      console.log('💻 Mode client, lecture localStorage');
      
      // Lecture prioritaire de blog_posts (source unique de vérité)
      const blogPosts = localStorage.getItem('blog_posts');
      if (blogPosts) {
        try {
          const posts = JSON.parse(blogPosts);
          console.log('📦 Posts trouvés dans blog_posts:', posts.length);
          
          const foundPost = posts.find((post: any) => {
            const match = post.id === slug && 
                         post.id !== 'undefined' && 
                         post.title &&
                         (post.isPublished !== false && post.status !== 'draft');
            
            if (match) {
              console.log('✅ Article trouvé:', { id: post.id, title: post.title });
            }
            
            return match;
          });
          
          if (foundPost) {
            return convertBlogPostToArticle(foundPost);
          }
        } catch (e) {
          console.error('❌ Erreur parsing blog_posts:', e);
        }
      }
    }

    // Fallback vers les articles par défaut
    const defaultArticle = defaultArticles[slug];
    if (defaultArticle) {
      console.log('✅ Article trouvé dans defaults:', defaultArticle.title);
      return defaultArticle;
    }

    console.log('❌ Article non trouvé:', slug);
    return null;
    
  } catch (error) {
    console.error('💥 Erreur lors du chargement de l\'article:', error);
    return null;
  }
}

// Service pour récupérer tous les articles publiés
export async function getAllPublishedArticles(): Promise<Article[]> {
  console.log('📚 [DYNAMIQUE] Chargement de tous les articles publiés');
  
  try {
    let allArticles: Article[] = [];
    
    // CÔTÉ CLIENT - SYSTÈME UNIFIÉ
    if (typeof window !== 'undefined') {
      console.log('💻 Mode client, lecture localStorage...');

      // 1. LECTURE PRIORITAIRE de blog_posts (source unique de vérité)
      const blogPosts = localStorage.getItem('blog_posts');
      if (blogPosts) {
        try {
          const posts = JSON.parse(blogPosts);
          console.log(`📦 ${posts.length} posts trouvés dans blog_posts`);
          
          const publishedPosts = posts
            .filter((post: any) => {
              const isValid = post && 
                             post.id && 
                             post.id !== 'undefined' && 
                             post.title &&
                             typeof post.title === 'string' &&
                             (post.isPublished !== false && post.status !== 'draft');
              
              return isValid;
            })
            .map(convertBlogPostToArticle);
          
          allArticles = [...publishedPosts];
          console.log(`✅ ${publishedPosts.length} articles valides chargés depuis blog_posts`);
          
        } catch (e) {
          console.error('❌ Erreur lecture blog_posts:', e);
        }
      }
    }

    // 2. Ajouter les articles par défaut (seulement si pas déjà présents)
    Object.values(defaultArticles).forEach(defaultArticle => {
      const exists = allArticles.some(article => article.id === defaultArticle.id);
      if (!exists) {
        allArticles.push(defaultArticle);
      }
    });

    // 3. Nettoyage et tri final
    const uniqueArticles = allArticles.filter((article, index, self) => 
      index === self.findIndex(a => a.id === article.id)
    );

    const sortedArticles = uniqueArticles.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );

    console.log(`🎯 RÉSULTAT FINAL: ${sortedArticles.length} articles uniques`);
    
    return sortedArticles;
    
  } catch (error) {
    console.error('💥 Erreur critique lors du chargement des articles:', error);
    return Object.values(defaultArticles);
  }
}

// Fonction pour convertir un BlogPost en Article
function convertBlogPostToArticle(post: any): Article {
  return {
    id: post.id,
    title: post.title,
    content: post.content || post.markdownContent || '',
    markdownContent: post.markdownContent || post.content,
    category: post.category || 'Général',
    tags: Array.isArray(post.tags) ? post.tags : [],
    coverImage: post.coverImage || post.image || post.imageUrl,
    author: post.author || 'Expert CMV',
    createdAt: post.createdAt || post.publishedAt || post.publishedDate || new Date().toISOString(),
    publishedAt: post.publishedAt || post.createdAt || post.publishedDate,
    views: typeof post.views === 'number' ? post.views : 0,
    isPublished: post.isPublished !== false && post.status !== 'draft',
    readingTime: post.readingTime || Math.ceil((post.content || post.markdownContent || '').split(' ').length / 200),
    description: post.description || post.excerpt,
    featured: post.featured || post.isFeatured || false,
    status: post.status || 'published'
  };
}

// Génère un ID unique pour les nouveaux articles
export function generateUniqueArticleId(title: string): string {
  const timestamp = Date.now();
  const cleanTitle = title
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .substring(0, 30);
  
  return `${cleanTitle}-${timestamp}`;
}

// SAUVEGARDE UNIFIÉE
export function saveArticle(article: Omit<Article, 'id'> & { id?: string }): string {
  if (typeof window === 'undefined') {
    console.log('🖥️ Mode serveur, sauvegarde ignorée');
    return '';
  }

  console.log('💾 [DYNAMIQUE] SAUVEGARDE UNIFIÉE');
  console.log('📝 Article à sauvegarder:', { title: article.title, category: article.category });

  try {
    // 1. Générer un ID unique si non fourni
    const articleId = article.id || generateUniqueArticleId(article.title);
    console.log('🆔 ID utilisé:', articleId);
    
    // 2. Créer l'article final avec tous les champs requis
    const finalArticle: Article = {
      ...article,
      id: articleId,
      createdAt: article.createdAt || new Date().toISOString(),
      publishedAt: article.publishedAt || new Date().toISOString(),
      views: article.views || 0,
      isPublished: article.isPublished !== false,
      status: article.status || 'published',
      tags: Array.isArray(article.tags) ? article.tags : [],
      readingTime: article.readingTime || Math.ceil((article.content || '').split(' ').length / 200)
    };

    // 3. SAUVEGARDE DANS LE SYSTÈME UNIFIÉ (blog_posts uniquement)
    let posts: any[] = [];
    
    try {
      const existing = localStorage.getItem('blog_posts');
      posts = existing ? JSON.parse(existing) : [];
      console.log(`📦 ${posts.length} articles existants trouvés`);
    } catch (e) {
      console.warn('⚠️ Erreur lecture blog_posts, initialisation:', e);
      posts = [];
    }

    // 4. Supprimer l'ancien article s'il existe
    const oldIndex = posts.findIndex((post: any) => post.id === articleId);
    if (oldIndex !== -1) {
      console.log('🔄 Mise à jour d\'un article existant');
      posts.splice(oldIndex, 1);
    } else {
      console.log('✨ Création d\'un nouvel article');
    }

    // 5. Ajouter le nouvel article en première position
    posts.unshift(finalArticle);

    // 6. SAUVEGARDE IMMÉDIATE
    const dataToSave = JSON.stringify(posts);
    localStorage.setItem('blog_posts', dataToSave);
    console.log(`✅ SAUVEGARDE RÉUSSIE: ${posts.length} articles dans blog_posts`);

    // 7. NOTIFICATION IMMÉDIATE pour actualiser les vues
    window.dispatchEvent(new CustomEvent('articlesUpdated'));
    window.dispatchEvent(new CustomEvent('storage'));

    console.log('🎉 SAUVEGARDE DYNAMIQUE TERMINÉE AVEC SUCCÈS');
    return articleId;
    
  } catch (error) {
    console.error('💥 ERREUR LORS DE LA SAUVEGARDE DYNAMIQUE:', error);
    throw error;
  }
}

// Services additionnels...
export async function getArticlesByCategory(category: string): Promise<Article[]> {
  const allArticles = await getAllPublishedArticles();
  return allArticles.filter(article => 
    article.category.toLowerCase() === category.toLowerCase()
  );
}

export async function getFeaturedArticles(): Promise<Article[]> {
  const allArticles = await getAllPublishedArticles();
  return allArticles.filter(article => article.featured || article.isFeatured).slice(0, 6);
}

export async function searchArticles(query: string): Promise<Article[]> {
  const allArticles = await getAllPublishedArticles();
  const searchTerm = query.toLowerCase();
  
  return allArticles.filter(article => 
    article.title.toLowerCase().includes(searchTerm) ||
    article.description?.toLowerCase().includes(searchTerm) ||
    article.category.toLowerCase().includes(searchTerm) ||
    article.tags?.some(tag => tag.toLowerCase().includes(searchTerm))
  );
}

export function incrementArticleViews(articleId: string): void {
  if (typeof window === 'undefined' || !articleId || articleId === 'undefined') return;

  try {
    const blogPosts = localStorage.getItem('blog_posts');
    if (blogPosts) {
      const posts = JSON.parse(blogPosts);
      const index = posts.findIndex((post: any) => post.id === articleId);
      if (index !== -1) {
        posts[index].views = (posts[index].views || 0) + 1;
        localStorage.setItem('blog_posts', JSON.stringify(posts));
        console.log(`👁️ Vues incrémentées pour l'article ${articleId}`);
        return;
      }
    }
  } catch (error) {
    console.error('❌ Erreur lors de la mise à jour des vues:', error);
  }
}

export function deleteArticle(articleId: string): void {
  if (typeof window === 'undefined' || !articleId || articleId === 'undefined') return;

  try {
    const blogPosts = localStorage.getItem('blog_posts');
    if (blogPosts) {
      const posts = JSON.parse(blogPosts);
      const filteredPosts = posts.filter((post: any) => post.id !== articleId);
      localStorage.setItem('blog_posts', JSON.stringify(filteredPosts));
      
      // Déclencher un événement pour notifier les autres composants
      window.dispatchEvent(new CustomEvent('articlesUpdated'));
      
      console.log(`🗑️ Article ${articleId} supprimé`);
    }
  } catch (error) {
    console.error('❌ Erreur lors de la suppression de l\'article:', error);
  }
}
