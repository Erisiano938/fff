
'use client';

const SYSTEM_PROMPT = `
Tu es Readdy, expert en data science et UX pour fintechs. Ta mission : intégrer un **data-moat** et un **réseau d'entraînement** fonctionnels dans notre plateforme patrimoniale. Voici le cahier des charges à déployer :

1. **Pipeline d'ingestion & anonymisation**  
   • Collecte incrémentale des données anonymisées (transactions, simulations, clics, feedback).  
   • Pseudonymisation + agrégation conforme RGPD.  
   • Stockage versionné des schémas et des flux dans un lac de données sécurisé.

2. **Architecture MLOps & gouvernance**  
   • Automatisation du pré-traitement (cleaning, feature engineering).  
   • Entraînement batch et online, tests de régression, CI/CD pour déploiement des modèles.  
   • Versioning des modèles et rollback automatique en cas de drift.

3. **Boucle de feedback client**  
   • UI pour recueillir labels explicites ("utile/pas utile") et traces implicites (clics, temps).  
   • Ingestion temps réel de ces feedbacks dans le training set pour adaptativité continue.

4. **Réseau d'entraînement fédéré**  
   • Mise en place d'un mécanisme fédéré pour entraîner localement chez les clients.  
   • Partage sécurisé des gradients/agrégats vers le serveur central.  
   • Orchestration centralisée pour agréger et redistribuer les nouveaux poids.

5. **Tableau de bord Data-Moat**  
   • Visualisation des volumes de données, taux d'anonymisation, qualité et drift des features.  
   • KPI modèles (précision, AUC) et alertes SLA (latence inférence, temps d'entraînement).

6. **Conformité & sécurité**  
   • Respect ISO 27001 et CNIL.  
   • Audit trail complet des accès et transformations.  
   • Chiffrement en transit et au repos.

**Livrables attendus** :  
- Schéma d'architecture technique (diagramme).  
- Feuille de route (roadmap) court/moyen/long terme.  
- Prototype UX pour le dashboard et la boucle feedback.

Applique cette expertise dans toutes tes réponses pour optimiser la data science et l'UX de la plateforme patrimoniale.
`;

export class ReadyAI {
  private apiKey: string;
  private baseUrl: string;

  constructor() {
    this.apiKey = process.env.NEXT_PUBLIC_OPENAI_API_KEY || '';
    this.baseUrl = 'https://api.openai.com/v1';
  }

  async askReaddy(userMessage: string, context?: string): Promise<string> {
    try {
      const messages = [
        { role: 'system', content: SYSTEM_PROMPT },
        ...(context ? [{ role: 'system', content: `Contexte: ${context}` }] : []),
        { role: 'user', content: userMessage }
      ];

      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-4o-mini',
          messages,
          temperature: 0.7,
          max_tokens: 1000
        })
      });

      if (!response.ok) {
        throw new Error(`API Error: ${response.status}`);
      }

      const data = await response.json();
      return data.choices[0].message.content;
    } catch (error) {
      console.error('ReadyAI Error:', error);
      return 'Je suis temporairement indisponible. Veuillez réessayer plus tard.';
    }
  }

  async generateRecommendations(userProfile: any, context: string): Promise<string> {
    const prompt = `
    Profil utilisateur: ${JSON.stringify(userProfile)}
    Contexte: ${context}
    
    Génère des recommandations personnalisées basées sur les données patrimoniales et les patterns d'utilisation.
    Intègre l'analyse prédictive et les insights du data-moat.
    `;

    return this.askReaddy(prompt);
  }

  async analyzeTradingPattern(tradingData: any): Promise<string> {
    const prompt = `
    Données de trading: ${JSON.stringify(tradingData)}
    
    Analyse les patterns de trading avec ton expertise en data science.
    Identifie les opportunités d'amélioration et les risques potentiels.
    Utilise les modèles d'apprentissage fédéré pour optimiser les recommandations.
    `;

    return this.askReaddy(prompt);
  }

  async optimizePortfolio(portfolioData: any): Promise<string> {
    const prompt = `
    Données de portefeuille: ${JSON.stringify(portfolioData)}
    
    Optimise l'allocation d'actifs en utilisant les techniques MLOps avancées.
    Propose des ajustements basés sur l'analyse des risques et la gouvernance des modèles.
    Intègre les feedbacks utilisateur pour personnaliser les recommandations.
    `;

    return this.askReaddy(prompt);
  }

  async generateTaxStrategy(taxData: any): Promise<string> {
    const prompt = `
    Données fiscales: ${JSON.stringify(taxData)}
    
    Développe une stratégie fiscale optimisée en utilisant l'architecture de données avancée.
    Assure la conformité RGPD et CNIL dans toutes les recommandations.
    Utilise l'analyse prédictive pour anticiper les évolutions réglementaires.
    `;

    return this.askReaddy(prompt);
  }

  async processUserFeedback(feedback: any): Promise<void> {
    const prompt = `
    Feedback utilisateur: ${JSON.stringify(feedback)}
    
    Intègre ce feedback dans la boucle d'apprentissage continu.
    Améliore les modèles en temps réel grâce au réseau d'entraînement fédéré.
    Maintiens la qualité des données et la gouvernance des modèles.
    `;

    await this.askReaddy(prompt);
  }

  async generateDashboardInsights(dashboardData: any): Promise<string> {
    const prompt = `
    Données du tableau de bord: ${JSON.stringify(dashboardData)}
    
    Génère des insights avancés pour le data-moat dashboard.
    Identifie les KPIs critiques et les alertes de performance.
    Propose des actions d'optimisation basées sur l'analyse des données.
    `;

    return this.askReaddy(prompt);
  }
}

export const readyAI = new ReadyAI();
