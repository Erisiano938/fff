
import { useState, useEffect } from 'react';

export interface SiteTexts {
  // Page d'accueil
  heroTitle: string;
  heroSubtitle: string;
  heroDescription: string;
  heroButtonPrimary: string;
  heroButtonSecondary: string;

  // Section Features
  featuresTitle: string;
  featuresHighlight: string;
  featuresDescription: string;

  // Features individuelles
  feature1Title: string;
  feature1Description: string;
  feature2Title: string;
  feature2Description: string;
  feature3Title: string;
  feature3Description: string;
  feature4Title: string;
  feature4Description: string;

  // Navigation
  navDashboard: string;
  navTrading: string;
  navAcademy: string;
  navIndicators: string;
  navAllocation: string;
  navOpportunities: string;
  navContact: string;

  // Boutons généraux
  btnLogin: string;
  btnRegister: string;
  btnDiscover: string;
  btnLearnMore: string;
  btnGetStarted: string;

  // Footer
  footerDescription: string;
  footerQuickLinks: string;
  footerServices: string;
  footerSupport: string;
  footerRights: string;

  // Messages communs
  loading: string;
  comingSoon: string;
  error: string;
  success: string;

  // Academy
  academyTitle: string;
  academyDescription: string;

  // Dashboard
  dashboardTitle: string;
  dashboardWelcome: string;

  // Trading
  tradingTitle: string;
  tradingDescription: string;
}

// Textes par défaut
const defaultTexts: SiteTexts = {
  // Page d'accueil
  heroTitle: 'cmv l\'art de fructifier et protéger votre avenir financier',
  heroSubtitle: 'Conseil en Gestion de Patrimoine & Trading',
  heroDescription: 'Nous accompagnons nos clients dans l\'optimisation de leur patrimoine financier grâce à une expertise reconnue en investissement et une approche personnalisée de la gestion de portefeuille.',
  heroButtonPrimary: 'Prendre Rendez-vous',
  heroButtonSecondary: 'Nos Services',

  // Section Features
  featuresTitle: 'Fonctionnalités',
  featuresHighlight: 'Principales',
  featuresDescription: 'Découvrez tous nos outils financiers conçus pour optimiser vos investissements et améliorer vos performances',

  // Features individuelles
  feature1Title: 'Gestion de Patrimoine',
  feature1Description: 'Suivez vos investissements en temps réel avec des analyses détaillées et des simulateurs avancés.',
  feature2Title: 'Académie de Trading',
  feature2Description: 'Apprenez le trading et l\'investissement avec nos formations complètes et interactives.',
  feature3Title: 'Marketplace d\'Indicateurs',
  feature3Description: 'Découvrez et achetez les meilleurs indicateurs TradingView créés par notre communauté.',
  feature4Title: 'Formation interactive et simulateurs "ludo-éducatifs"',
  feature4Description: 'Modules gamifiés pour comprendre la Bourse, les crypto-actifs ou l\'immobilier locatif via des cas pratiques. Quiz, challenges et certification interne pour valider vos connaissances.',

  // Navigation
  navDashboard: 'Dashboard',
  navTrading: 'Trading',
  navAcademy: 'Académie',
  navIndicators: 'Indicateurs',
  navAllocation: 'Allocation',
  navOpportunities: 'Opportunités',
  navContact: 'Contact',

  // Boutons généraux
  btnLogin: 'Connexion',
  btnRegister: 'Inscription',
  btnDiscover: 'Découvrir',
  btnLearnMore: 'En savoir plus',
  btnGetStarted: 'Commencer',

  // Footer
  footerDescription: 'Plateforme complète de trading et formation financière pour optimiser votre patrimoine.',
  footerQuickLinks: 'Liens Rapides',
  footerServices: 'Services',
  footerSupport: 'Support',
  footerRights: 'Tous droits réservés',

  // Messages communs
  loading: 'Chargement...',
  comingSoon: 'Bientôt disponible',
  error: 'Une erreur s\'est produite',
  success: 'Opération réussie',

  // Academy
  academyTitle: 'Académie de Trading',
  academyDescription: 'Maîtrisez les marchés financiers avec nos formations complètes',

  // Dashboard
  dashboardTitle: 'Tableau de Bord',
  dashboardWelcome: 'Bienvenue sur votre dashboard',

  // Trading
  tradingTitle: 'Plateforme de Trading',
  tradingDescription: 'Tradez en toute confiance avec nos outils professionnels'
};

// Fonction pour charger les textes depuis le localStorage
export function getSiteTexts(): SiteTexts {
  if (typeof window === 'undefined') return defaultTexts;
  
  try {
    const savedTexts = localStorage.getItem('cmv_site_texts');
    if (savedTexts) {
      return { ...defaultTexts, ...JSON.parse(savedTexts) };
    }
  } catch (error) {
    console.error('Erreur lors du chargement des textes:', error);
  }
  return defaultTexts;
}

// Fonction pour sauvegarder les textes
export function saveSiteTexts(texts: SiteTexts) {
  if (typeof window === 'undefined') return;
  
  try {
    localStorage.setItem('cmv_site_texts', JSON.stringify(texts));
    
    // Déclencher un événement pour notifier les composants
    const event = new CustomEvent('siteTextsUpdated', {
      detail: texts
    });
    window.dispatchEvent(event);
  } catch (error) {
    console.error('Erreur lors de la sauvegarde des textes:', error);
  }
}

// Fonction pour réinitialiser les textes
export function resetSiteTexts() {
  if (typeof window === 'undefined') return;
  
  localStorage.removeItem('cmv_site_texts');
  
  // Déclencher un événement pour notifier les composants
  const event = new CustomEvent('siteTextsUpdated', {
    detail: defaultTexts
  });
  window.dispatchEvent(event);
}

// Hook corrigé pour éviter les erreurs de mise à jour d'état
export function useSiteTexts() {
  const [texts, setTexts] = useState<SiteTexts>(defaultTexts);
  const [mounted, setMounted] = useState(false);
  
  useEffect(() => {
    setMounted(true);
    
    // Charger les textes uniquement après le montage
    if (typeof window !== 'undefined') {
      const loadedTexts = getSiteTexts();
      setTexts(loadedTexts);
      
      const handleTextsUpdate = (event: CustomEvent) => {
        setTexts(event.detail);
      };
      
      window.addEventListener('siteTextsUpdated', handleTextsUpdate as EventListener);
      
      return () => {
        window.removeEventListener('siteTextsUpdated', handleTextsUpdate as EventListener);
      };
    }
  }, []);
  
  // Retourner les textes par défaut jusqu'au montage complet
  return texts;
}
