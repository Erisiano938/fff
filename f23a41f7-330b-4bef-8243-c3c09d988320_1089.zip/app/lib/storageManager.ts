// Gestionnaire optimisé pour éviter les erreurs de quota localStorage

export interface StorageStats {
  used: number;
  available: number;
  percentage: number;
}

// Calculer la taille utilisée du localStorage
export function calculateStorageSize(): StorageStats {
  let totalSize = 0;
  
  for (let key in localStorage) {
    if (localStorage.hasOwnProperty(key)) {
      const value = localStorage.getItem(key) || '';
      totalSize += key.length + value.length;
    }
  }
  
  // Limite approximative du localStorage (5-10MB selon navigateur)
  const limit = 5 * 1024 * 1024; // 5MB
  
  return {
    used: totalSize,
    available: limit - totalSize,
    percentage: (totalSize / limit) * 100
  };
}

// Nettoyer les données dupliquées ou obsolètes
export function cleanupDuplicateData(): void {
  try {
    // Supprimer les clés problématiques qui causent les erreurs de quota
    const problematicKeys = [
      'cmv_academy_content',
      'cached_academy_content',
      'temp_academy_data'
    ];
    
    problematicKeys.forEach(key => {
      if (localStorage.getItem(key)) {
        localStorage.removeItem(key);
        console.log(`Clé ${key} supprimée pour libérer l'espace`);
      }
    });

    // Nettoyer les doublons dans blog_posts
    const blogPosts = localStorage.getItem('blog_posts');
    if (blogPosts) {
      const posts = JSON.parse(blogPosts);
      const uniquePosts = posts.reduce((acc: any[], current: any) => {
        const exists = acc.find(item => item.id === current.id);
        if (!exists) {
          acc.push(current);
        }
        return acc;
      }, []);
      
      if (uniquePosts.length !== posts.length) {
        localStorage.setItem('blog_posts', JSON.stringify(uniquePosts));
        console.log(`${posts.length - uniquePosts.length} doublons supprimés de blog_posts`);
      }
    }

    // Nettoyer les doublons dans academyPosts
    const academyPosts = localStorage.getItem('academyPosts');
    if (academyPosts) {
      const posts = JSON.parse(academyPosts);
      const uniquePosts = posts.reduce((acc: any[], current: any) => {
        const exists = acc.find(item => item.id === current.id);
        if (!exists) {
          acc.push(current);
        }
        return acc;
      }, []);
      
      if (uniquePosts.length !== posts.length) {
        localStorage.setItem('academyPosts', JSON.stringify(uniquePosts));
        console.log(`${posts.length - uniquePosts.length} doublons supprimés de academyPosts`);
      }
    }

  } catch (error) {
    console.error('Erreur lors du nettoyage:', error);
  }
}

// Vérifier si on peut sauvegarder sans dépasser la limite
export function canSaveData(dataSize: number): boolean {
  const stats = calculateStorageSize();
  return stats.available > dataSize * 1.2; // Marge de sécurité de 20%
}

// Sauvegarder de manière sécurisée
export function safeSave(key: string, data: any): boolean {
  try {
    const jsonData = JSON.stringify(data);
    
    if (!canSaveData(jsonData.length)) {
      console.warn('Espace insuffisant, nettoyage en cours...');
      cleanupDuplicateData();
      
      if (!canSaveData(jsonData.length)) {
        console.error('Impossible de sauvegarder, quota dépassé');
        return false;
      }
    }
    
    localStorage.setItem(key, jsonData);
    return true;
  } catch (error) {
    console.error('Erreur de sauvegarde:', error);
    cleanupDuplicateData();
    return false;
  }
}

// Obtenir les statistiques de stockage pour l'interface admin
export function getStorageReport(): {
  stats: StorageStats;
  recommendations: string[];
} {
  const stats = calculateStorageSize();
  const recommendations: string[] = [];
  
  if (stats.percentage > 80) {
    recommendations.push('Espace de stockage critique (>80%)');
    recommendations.push('Supprimez les anciens articles non publiés');
  } else if (stats.percentage > 60) {
    recommendations.push('Espace de stockage élevé (>60%)');
    recommendations.push('Considérez archiver les anciens contenus');
  }
  
  return { stats, recommendations };
}

// Initialiser le gestionnaire de stockage
export function initStorageManager(): void {
  // Nettoyer au démarrage
  cleanupDuplicateData();
  
  // Vérifier régulièrement l'espace (toutes les 5 minutes)
  setInterval(() => {
    const stats = calculateStorageSize();
    if (stats.percentage > 90) {
      console.warn('Espace de stockage critique, nettoyage automatique...');
      cleanupDuplicateData();
    }
  }, 5 * 60 * 1000);
}