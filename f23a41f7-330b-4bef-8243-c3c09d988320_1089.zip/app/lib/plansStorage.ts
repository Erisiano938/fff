export interface Plan {
  id: string;
  name: string;
  price: string;
  period: string;
  features: string[];
  popular: boolean;
  color: string;
  icon: string;
  description: string;
  order: number;
  active: boolean;
  buttonText: string;
  badge?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PaymentPageSettings {
  title: string;
  subtitle: string;
  headerText: string;
  securityFeatures: {
    text: string;
    icon: string;
  }[];
  backgroundColor: string;
  textColor: string;
  accentColor: string;
}

const defaultPlans: Plan[] = [
  {
    id: 'basic',
    name: 'Accès Basique',
    price: '29€',
    period: '/mois',
    features: [
      'Accès aux cours débutants',
      'Support email',
      'Communauté Discord',
      'Mises à jour mensuelles'
    ],
    popular: false,
    color: '#3B82F6',
    icon: 'ri-user-line',
    description: 'Parfait pour débuter dans le trading',
    order: 1,
    active: true,
    buttonText: 'Commencer',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'premium',
    name: 'Accès Premium',
    price: '79€',
    period: '/mois',
    features: [
      'Accès à tous les cours',
      'Sessions de coaching privé',
      'Analyses de marché en direct',
      'Outils de trading avancés',
      'Support prioritaire 24/7',
      'Webinaires exclusifs'
    ],
    popular: true,
    color: '#EAB308',
    icon: 'ri-vip-crown-line',
    description: 'Le choix le plus populaire pour les traders sérieux',
    order: 2,
    active: true,
    buttonText: 'Choisir Premium',
    badge: 'POPULAIRE',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: 'vip',
    name: 'Accès VIP',
    price: '199€',
    period: '/mois',
    features: [
      'Tout du plan Premium',
      'Signaux de trading en temps réel',
      'Appels de trading personnalisés',
      'Accès aux stratégies privées',
      'Mentorat 1-on-1',
      'Groupe Telegram VIP'
    ],
    popular: false,
    color: '#8B5CF6',
    icon: 'ri-vip-diamond-line',
    description: 'Pour les traders professionnels exigeants',
    order: 3,
    active: true,
    buttonText: 'Devenir VIP',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

const defaultPaymentSettings: PaymentPageSettings = {
  title: 'Choisissez votre Plan',
  subtitle: 'Accédez à nos formations premium et développez vos compétences en trading',
  headerText: 'Plan',
  securityFeatures: [
    { text: 'Paiement Sécurisé', icon: 'ri-shield-check-line' },
    { text: 'Remboursement 30 jours', icon: 'ri-refund-line' },
    { text: 'Support 24/7', icon: 'ri-customer-service-line' }
  ],
  backgroundColor: '#000000',
  textColor: '#FFFFFF',
  accentColor: '#EAB308'
};

export const getPlans = (): Plan[] => {
  if (typeof window === 'undefined') return defaultPlans;
  
  const stored = localStorage.getItem('cmv_payment_plans');
  if (stored) {
    return JSON.parse(stored);
  }
  
  localStorage.setItem('cmv_payment_plans', JSON.stringify(defaultPlans));
  return defaultPlans;
};

export const savePlan = (plan: Omit<Plan, 'id' | 'createdAt' | 'updatedAt'>): Plan => {
  const plans = getPlans();
  const newPlan: Plan = {
    ...plan,
    id: Date.now().toString(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  const updatedPlans = [...plans, newPlan].sort((a, b) => a.order - b.order);
  localStorage.setItem('cmv_payment_plans', JSON.stringify(updatedPlans));
  return newPlan;
};

export const updatePlan = (id: string, updates: Partial<Plan>): Plan | null => {
  const plans = getPlans();
  const index = plans.findIndex(p => p.id === id);
  
  if (index === -1) return null;
  
  const updatedPlan = {
    ...plans[index],
    ...updates,
    updatedAt: new Date().toISOString()
  };
  
  plans[index] = updatedPlan;
  const sortedPlans = plans.sort((a, b) => a.order - b.order);
  localStorage.setItem('cmv_payment_plans', JSON.stringify(sortedPlans));
  return updatedPlan;
};

export const deletePlan = (id: string): boolean => {
  const plans = getPlans();
  const filtered = plans.filter(p => p.id !== id);
  
  if (filtered.length === plans.length) return false;
  
  localStorage.setItem('cmv_payment_plans', JSON.stringify(filtered));
  return true;
};

export const getPaymentSettings = (): PaymentPageSettings => {
  if (typeof window === 'undefined') return defaultPaymentSettings;
  
  const stored = localStorage.getItem('cmv_payment_settings');
  if (stored) {
    return JSON.parse(stored);
  }
  
  localStorage.setItem('cmv_payment_settings', JSON.stringify(defaultPaymentSettings));
  return defaultPaymentSettings;
};

export const updatePaymentSettings = (settings: PaymentPageSettings): void => {
  localStorage.setItem('cmv_payment_settings', JSON.stringify(settings));
};