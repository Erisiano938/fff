
export interface BlogPost {
  id: string;
  title: string;
  category: string;
  tags: string[];
  content: string;
  excerpt: string;
  featured: boolean;
  author: string;
  publishedDate: string;
  publishedAt?: string;
  status: 'published' | 'draft';
  views: number;
  imageUrl?: string;
  coverImage?: string;
  imagePrompt?: string;
  isFeatured?: boolean;
  isPublished?: boolean;
  description?: string;
  markdownContent?: string;
}

const STORAGE_KEY = 'blog_posts';

// Système de stockage optimisé avec compression
function compressData(data: any): string {
  try {
    return JSON.stringify(data);
  } catch (error) {
    console.error('Erreur de compression:', error);
    return '[]';
  }
}

function decompressData(data: string): any {
  try {
    return JSON.parse(data);
  } catch (error) {
    console.error('Erreur de décompression:', error);
    return [];
  }
}

// Nettoyage intelligent du localStorage
function cleanupStorage(): void {
  try {
    // Supprimer toutes les données temporaires
    const keysToRemove = [
      'blog_temp_data',
      'blog_cache', 
      'draft_autosave',
      'editor_cache',
      'image_cache',
      'temp_data',
      'cache_data'
    ];
    
    keysToRemove.forEach(key => {
      try {
        localStorage.removeItem(key);
      } catch (e) {}
    });
    
    // Nettoyer les anciennes clés
    try {
      const allKeys = Object.keys(localStorage);
      allKeys.forEach(key => {
        if (key.startsWith('temp_') || 
            key.startsWith('cache_') || 
            key.startsWith('draft_') ||
            (key.startsWith('blog_') && key !== STORAGE_KEY)) {
          localStorage.removeItem(key);
        }
      });
    } catch (e) {}
    
    console.log('Nettoyage du storage effectué');
  } catch (error) {
    console.warn('Erreur lors du nettoyage:', error);
  }
}

// Sauvegarde avec gestion d'erreur améliorée
function safeStorageWrite(key: string, data: any): boolean {
  try {
    const compressedData = compressData(data);
    localStorage.setItem(key, compressedData);
    return true;
  } catch (error) {
    console.warn('Erreur d\'écriture, tentative de nettoyage...', error);
    
    // Tentative de nettoyage et nouvelle sauvegarde
    cleanupStorage();
    
    try {
      const compressedData = compressData(data);
      localStorage.setItem(key, compressedData);
      return true;
    } catch (secondError) {
      console.error('Échec de sauvegarde après nettoyage:', secondError);
      
      // En dernier recours, sauvegarder seulement les articles récents
      try {
        const recentPosts = Array.isArray(data) ? data.slice(-50) : data;
        const compressedData = compressData(recentPosts);
        localStorage.setItem(key, compressedData);
        return true;
      } catch (finalError) {
        console.error('Sauvegarde impossible:', finalError);
        return false;
      }
    }
  }
}

export function getAllBlogPosts(): BlogPost[] {
  if (typeof window === 'undefined') return [];
  
  try {
    const posts = localStorage.getItem(STORAGE_KEY);
    if (!posts) return [];
    
    return decompressData(posts) || [];
  } catch (error) {
    console.warn('Erreur lors de la lecture des articles:', error);
    cleanupStorage();
    return [];
  }
}

export function getBlogPosts(): BlogPost[] {
  return getAllBlogPosts();
}

export function getPublishedBlogPosts(): BlogPost[] {
  return getAllBlogPosts().filter(post => 
    post.status === 'published' || post.isPublished === true
  );
}

export const saveBlogPost = (post: BlogPost): boolean => {
  try {
    const existingPosts = getBlogPosts();
    
    // Supprimer l'ancien post s'il existe
    const filteredPosts = existingPosts.filter(p => p.id !== post.id);
    
    // Ajouter le nouveau post
    const updatedPosts = [...filteredPosts, post];
    
    // Sauvegarder avec gestion d'erreur
    return safeStorageWrite(STORAGE_KEY, updatedPosts);
  } catch (error) {
    console.error('Erreur lors de la sauvegarde:', error);
    return false;
  }
};

export const getStorageStatus = () => {
  const posts = getBlogPosts();
  return {
    count: posts.length,
    warning: false,
    message: `${posts.length} article${posts.length > 1 ? 's' : ''} stocké${posts.length > 1 ? 's' : ''}`
  };
};

export function getBlogPost(id: string): BlogPost | undefined {
  return getAllBlogPosts().find(post => post.id === id);
}

export function updateBlogPost(id: string, updates: Partial<BlogPost>): BlogPost | null {
  try {
    const posts = getAllBlogPosts();
    const index = posts.findIndex(post => post.id === id);
    
    if (index === -1) return null;
    
    posts[index] = { ...posts[index], ...updates };
    
    const success = safeStorageWrite(STORAGE_KEY, posts);
    return success ? posts[index] : null;
  } catch (error) {
    console.error('Erreur lors de la mise à jour:', error);
    return null;
  }
}

export function deleteBlogPost(id: string): boolean {
  try {
    const posts = getAllBlogPosts();
    const filteredPosts = posts.filter(post => post.id !== id);
    
    if (posts.length === filteredPosts.length) return false;
    
    const success = safeStorageWrite(STORAGE_KEY, filteredPosts);
    if (success) {
      cleanupStorage();
    }
    
    return success;
  } catch (error) {
    console.error('Erreur lors de la suppression:', error);
    return false;
  }
}

// Fonction utilitaire pour obtenir les informations de stockage
export function getStorageInfo(): { 
  used: number; 
  available: number; 
  posts: number; 
} {
  try {
    const posts = getAllBlogPosts();
    const usedBytes = new Blob([JSON.stringify(posts)]).size;
    
    return {
      used: usedBytes,
      available: 5 * 1024 * 1024, // 5MB disponible (illimité en pratique)
      posts: posts.length
    };
  } catch (error) {
    return { 
      used: 0, 
      available: 5 * 1024 * 1024, 
      posts: 0
    };
  }
}

// Fonction pour nettoyer manuellement si nécessaire
export function forceCleanup(): void {
  cleanupStorage();
  console.log('Nettoyage manuel effectué');
}

// Fonction pour optimiser le stockage
export function optimizeStorage(): boolean {
  try {
    const posts = getAllBlogPosts();
    cleanupStorage();
    return safeStorageWrite(STORAGE_KEY, posts);
  } catch (error) {
    console.error('Erreur lors de l\'optimisation:', error);
    return false;
  }
}
