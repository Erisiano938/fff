
export interface Video {
  id: string;
  title: string;
  description: string;
  category: string;
  duration: string;
  videoFile?: File;
  videoUrl?: string;
  thumbnail?: string;
  views: number;
  publishedAt: string;
  isPublished: boolean;
}

let videos: Video[] = [
  {
    id: '1',
    title: 'Introduction au Trading pour Débutants',
    description: 'Apprenez les bases du trading financier, les concepts fondamentaux et les premières étapes pour débuter dans le monde du trading.',
    category: 'trading-debutant',
    duration: '12:45',
    thumbnail: 'https://readdy.ai/api/search-image?query=Professional%20trading%20desk%20setup%20with%20multiple%20monitors%20displaying%20financial%20charts%20and%20graphs%2C%20modern%20office%20environment%2C%20clean%20and%20professional%20atmosphere%2C%20blue%20and%20white%20color%20scheme%2C%20trading%20workspace%2C%20financial%20technology&width=640&height=360&seq=trading-intro&orientation=landscape',
    views: 1247,
    publishedAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    isPublished: true,
  },
  {
    id: '2',
    title: 'Analyse Technique - Les Supports et Résistances',
    description: 'Découvrez comment identifier et utiliser les niveaux de support et de résistance dans vos analyses techniques pour améliorer vos prises de décision.',
    category: 'analyse-technique',
    duration: '18:30',
    thumbnail: 'https://readdy.ai/api/search-image?query=Financial%20chart%20analysis%20with%20support%20and%20resistance%20levels%20marked%2C%20candlestick%20patterns%2C%20technical%20indicators%2C%20professional%20trading%20interface%2C%20green%20and%20red%20colors%2C%20stock%20market%20data%20visualization&width=640&height=360&seq=technical-analysis&orientation=landscape',
    views: 856,
    publishedAt: new Date(Date.now() - 86400000 * 5).toISOString(),
    isPublished: true,
  },
  {
    id: '3',
    title: 'Gestion des Risques et Money Management',
    description: 'Les principes essentiels de la gestion des risques en trading, comment protéger votre capital et gérer la taille de vos positions.',
    category: 'gestion-risques',
    duration: '15:22',
    thumbnail: 'https://readdy.ai/api/search-image?query=Risk%20management%20concept%20with%20financial%20calculator%2C%20charts%20showing%20portfolio%20allocation%2C%20pie%20charts%2C%20risk%20assessment%20graphs%2C%20professional%20financial%20planning%2C%20blue%20and%20orange%20color%20scheme&width=640&height=360&seq=risk-management&orientation=landscape',
    views: 1103,
    publishedAt: new Date(Date.now() - 86400000 * 7).toISOString(),
    isPublished: true,
  },
  {
    id: '4',
    title: 'Psychologie du Trading - Contrôler ses Émotions',
    description: 'Comment maîtriser vos émotions en trading, gérer le stress et développer un mindset de trader professionnel.',
    category: 'psychologie',
    duration: '21:15',
    thumbnail: 'https://readdy.ai/api/search-image?query=Trading%20psychology%20concept%20with%20zen%20meditation%20elements%2C%20balanced%20scales%2C%20brain%20and%20heart%20balance%2C%20calm%20and%20focused%20atmosphere%2C%20minimalist%20design%2C%20blue%20and%20green%20calming%20colors&width=640&height=360&seq=trading-psychology&orientation=landscape',
    views: 674,
    publishedAt: new Date(Date.now() - 86400000 * 10).toISOString(),
    isPublished: true,
  },
  {
    id: '5',
    title: 'Les Indicateurs Techniques Essentiels',
    description: 'Tour d\'horizon des indicateurs techniques les plus utilisés : RSI, MACD, moyennes mobiles et comment les interpréter.',
    category: 'analyse-technique',
    duration: '16:48',
    thumbnail: 'https://readdy.ai/api/search-image?query=Technical%20indicators%20dashboard%20with%20RSI%2C%20MACD%2C%20moving%20averages%2C%20colorful%20charts%20and%20graphs%2C%20professional%20trading%20platform%20interface%2C%20multiple%20indicator%20windows%2C%20financial%20data%20visualization&width=640&height=360&seq=technical-indicators&orientation=landscape',
    views: 932,
    publishedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    isPublished: true,
  },
  {
    id: '6',
    title: 'Trading Forex - Comprendre les Paires de Devises',
    description: 'Introduction au marché des changes, comment fonctionnent les paires de devises et les stratégies de base pour trader le Forex.',
    category: 'trading-debutant',
    duration: '14:33',
    thumbnail: 'https://readdy.ai/api/search-image?query=Forex%20trading%20concept%20with%20world%20currencies%2C%20EUR%20USD%20GBP%20JPY%20symbols%2C%20global%20financial%20markets%2C%20currency%20exchange%20rates%2C%20international%20trading%2C%20professional%20financial%20background&width=640&height=360&seq=forex-trading&orientation=landscape',
    views: 1189,
    publishedAt: new Date(Date.now() - 86400000 * 1).toISOString(),
    isPublished: true,
  }
];

export function saveVideo(video: Omit<Video, 'id' | 'views' | 'publishedAt'>): Video {
  const newVideo: Video = {
    ...video,
    id: Date.now().toString(),
    views: 0,
    publishedAt: new Date().toISOString(),
  };
  
  // Charger les vidéos existantes du localStorage
  if (typeof window !== 'undefined') {
    const storedVideos = localStorage.getItem('videos');
    if (storedVideos) {
      try {
        const existingVideos = JSON.parse(storedVideos);
        const updatedVideos = [...existingVideos, newVideo];
        localStorage.setItem('videos', JSON.stringify(updatedVideos));
      } catch (e) {
        localStorage.setItem('videos', JSON.stringify([newVideo]));
      }
    } else {
      localStorage.setItem('videos', JSON.stringify([newVideo]));
    }
  }
  
  videos.push(newVideo);
  return newVideo;
}

export function getVideos(): Video[] {
  if (typeof window !== 'undefined') {
    const storedVideos = localStorage.getItem('videos');
    if (storedVideos) {
      try {
        const parsedVideos = JSON.parse(storedVideos);
        // Fusionner les vidéos par défaut avec les vidéos stockées
        const allVideos = [...videos];
        parsedVideos.forEach((stored: Video) => {
          if (!allVideos.find(v => v.id === stored.id)) {
            allVideos.push(stored);
          }
        });
        return allVideos;
      } catch (e) {
        console.log('Erreur lors du chargement des vidéos stockées');
      }
    }
  }
  return videos;
}

export function getPublishedVideos(): Video[] {
  return getVideos().filter(video => video.isPublished);
}

export function deleteVideo(id: string): void {
  if (typeof window !== 'undefined') {
    const storedVideos = localStorage.getItem('videos');
    if (storedVideos) {
      try {
        const parsedVideos = JSON.parse(storedVideos);
        const filteredVideos = parsedVideos.filter((video: Video) => video.id !== id);
        localStorage.setItem('videos', JSON.stringify(filteredVideos));
      } catch (e) {
        console.log('Erreur lors de la suppression de la vidéo');
      }
    }
  }
  
  videos = videos.filter(video => video.id !== id);
}

export function updateVideo(id: string, updates: Partial<Video>): Video | null {
  if (typeof window !== 'undefined') {
    const storedVideos = localStorage.getItem('videos');
    if (storedVideos) {
      try {
        const parsedVideos = JSON.parse(storedVideos);
        const videoIndex = parsedVideos.findIndex((video: Video) => video.id === id);
        if (videoIndex !== -1) {
          parsedVideos[videoIndex] = { ...parsedVideos[videoIndex], ...updates };
          localStorage.setItem('videos', JSON.stringify(parsedVideos));
          return parsedVideos[videoIndex];
        }
      } catch (e) {
        console.log('Erreur lors de la mise à jour de la vidéo');
      }
    }
  }
  
  const videoIndex = videos.findIndex(video => video.id === id);
  if (videoIndex === -1) return null;
  
  videos[videoIndex] = { ...videos[videoIndex], ...updates };
  return videos[videoIndex];
}
