
// Gestionnaire de fichiers pour l'éditeur côté client
export interface FileNode {
  name: string;
  path: string;
  type: 'file' | 'directory';
  children?: FileNode[];
  content?: string;
}

export interface FileTree {
  [key: string]: {
    type: 'file' | 'folder';
    children?: FileTree;
  };
}

export class FileManager {
  private static instance: FileManager;
  private fileCache = new Map<string, string>();
  
  static getInstance(): FileManager {
    if (!FileManager.instance) {
      FileManager.instance = new FileManager();
    }
    return FileManager.instance;
  }

  // Nouvelle méthode pour obtenir l'arbre des fichiers
  async getFileTree(): Promise<FileTree> {
    // Structure des fichiers basée sur votre projet réel
    return {
      'app': {
        type: 'folder',
        children: {
          'page.tsx': { type: 'file' },
          'layout.tsx': { type: 'file' },
          'globals.css': { type: 'file' },
          'not-found.tsx': { type: 'file' },
          'components': {
            type: 'folder',
            children: {
              'Header.tsx': { type: 'file' },
              'Footer.tsx': { type: 'file' },
              'Hero.tsx': { type: 'file' },
              'Features.tsx': { type: 'file' },
              'TradingSection.tsx': { type: 'file' },
              'ShinyText.tsx': { type: 'file' },
              'ObfuscationSettings.tsx': { type: 'file' }
            }
          },
          'dashboard': {
            type: 'folder',
            children: {
              'page.tsx': { type: 'file' },
              'DashboardOverview.tsx': { type: 'file' },
              'PortfolioChart.tsx': { type: 'file' },
              'RecentTransactions.tsx': { type: 'file' },
              'UserProfile.tsx': { type: 'file' }
            }
          },
          'admin': {
            type: 'folder',
            children: {
              'dashboard': {
                type: 'folder',
                children: {
                  'page.tsx': { type: 'file' }
                }
              },
              'site-builder': {
                type: 'folder',
                children: {
                  'page.tsx': { type: 'file' },
                  'FileExplorer.tsx': { type: 'file' },
                  'VisualEditor.tsx': { type: 'file' },
                  'ComponentPanel.tsx': { type: 'file' },
                  'PropertiesPanel.tsx': { type: 'file' }
                }
              }
            }
          },
          'auth': {
            type: 'folder',
            children: {
              'login': {
                type: 'folder',
                children: {
                  'page.tsx': { type: 'file' }
                }
              },
              'register': {
                type: 'folder',
                children: {
                  'page.tsx': { type: 'file' }
                }
              }
            }
          },
          'lib': {
            type: 'folder',
            children: {
              'auth.ts': { type: 'file' },
              'fileManager.ts': { type: 'file' },
              'permissions.ts': { type: 'file' },
              'userAuth.ts': { type: 'file' }
            }
          }
        }
      },
      'components': {
        type: 'folder',
        children: {
          'PermissionGuard.tsx': { type: 'file' },
          'RoleBasedLayout.tsx': { type: 'file' }
        }
      },
      'lib': {
        type: 'folder',
        children: {
          'permissions.ts': { type: 'file' }
        }
      },
      'package.json': { type: 'file' },
      '.env': { type: 'file' }
    };
  }

  // Structure des fichiers du projet (simulée pour le client)
  getProjectStructure(): FileNode[] {
    return [
      {
        name: 'app',
        path: 'app',
        type: 'directory',
        children: [
          { name: 'page.tsx', path: 'app/page.tsx', type: 'file' },
          { name: 'layout.tsx', path: 'app/layout.tsx', type: 'file' },
          {
            name: 'components',
            path: 'app/components',
            type: 'directory',
            children: [
              { name: 'Header.tsx', path: 'app/components/Header.tsx', type: 'file' },
              { name: 'Footer.tsx', path: 'app/components/Footer.tsx', type: 'file' },
              { name: 'Hero.tsx', path: 'app/components/Hero.tsx', type: 'file' },
              { name: 'Features.tsx', path: 'app/components/Features.tsx', type: 'file' },
            ]
          },
          {
            name: 'dashboard',
            path: 'app/dashboard',
            type: 'directory',
            children: [
              { name: 'page.tsx', path: 'app/dashboard/page.tsx', type: 'file' },
            ]
          },
          {
            name: 'admin',
            path: 'app/admin',
            type: 'directory',
            children: [
              { name: 'dashboard', path: 'app/admin/dashboard', type: 'directory' },
              { name: 'site-builder', path: 'app/admin/site-builder', type: 'directory' },
            ]
          }
        ]
      },
      {
        name: 'components',
        path: 'components',
        type: 'directory',
        children: [
          { name: 'PermissionGuard.tsx', path: 'components/PermissionGuard.tsx', type: 'file' },
        ]
      }
    ];
  }

  async readFile(filePath: string): Promise<string> {
    // Vérifier le cache d'abord
    if (this.fileCache.has(filePath)) {
      return this.fileCache.get(filePath)!;
    }

    // Pour une vraie implémentation, vous pourriez utiliser une API
    // Ici, on retourne du contenu par défaut basé sur le type de fichier
    const defaultContent = this.getDefaultContent(filePath);
    this.fileCache.set(filePath, defaultContent);
    return defaultContent;
  }

  async writeFile(filePath: string, content: string): Promise<{ success: boolean; error?: string }> {
    try {
      // Sauvegarder dans le cache local
      this.fileCache.set(filePath, content);
      
      // Dans une vraie implémentation, vous feriez un appel API pour sauvegarder
      console.log(`Sauvegarde simulée de ${filePath}:`, content.substring(0, 100) + '...');
      
      // Simuler un délai de sauvegarde
      await new Promise(resolve => setTimeout(resolve, 200));
      
      return { success: true };
    } catch (error) {
      return { success: false, error: 'Erreur lors de la sauvegarde' };
    }
  }

  async createFile(filePath: string, content: string = ''): Promise<{ success: boolean; error?: string }> {
    try {
      await this.writeFile(filePath, content);
      return { success: true };
    } catch (error) {
      return { success: false, error: 'Erreur lors de la création du fichier' };
    }
  }

  async deleteFile(filePath: string): Promise<void> {
    this.fileCache.delete(filePath);
    console.log(`Suppression simulée de ${filePath}`);
  }

  private getDefaultContent(filePath: string): string {
    const extension = filePath.split('.').pop();
    
    switch (extension) {
      case 'tsx':
        return `'use client';

export default function ${this.getComponentName(filePath)}() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Nouveau Composant</h1>
      <p className="text-gray-600">
        Contenu du composant à modifier...
      </p>
    </div>
  );
}`;
      
      case 'ts':
        return `// ${filePath}
export default function() {
  // Code TypeScript à implémenter
}`;
      
      case 'css':
        return `/* ${filePath} */
.container {
  /* Styles CSS à définir */
}`;
      
      default:
        return `// ${filePath}
// Contenu par défaut`;
    }
  }

  private getComponentName(filePath: string): string {
    const fileName = filePath.split('/').pop()?.replace('.tsx', '') || 'Component';
    return fileName.charAt(0).toUpperCase() + fileName.slice(1);
  }

  // Méthodes utilitaires pour l'éditeur
  isValidFilePath(filePath: string): boolean {
    return filePath.match(/^[a-zA-Z0-9\/\-_.]+$/) !== null;
  }

  getFileExtension(filePath: string): string {
    return filePath.split('.').pop() || '';
  }

  isEditableFile(filePath: string): boolean {
    const editableExtensions = ['tsx', 'ts', 'js', 'jsx', 'css', 'json', 'md'];
    return editableExtensions.includes(this.getFileExtension(filePath));
  }
}

// Instance singleton exportée
export const fileManager = FileManager.getInstance();
