
export interface UploadedImage {
  id: string;
  url: string;
  name?: string;
  originalName?: string;
  prompt?: string;
  uploadedAt: string;
  type: 'upload' | 'generated';
  size?: number;
}

// Fonction pour compresser une image
const compressImage = (file: File, maxWidth: number = 800, quality: number = 0.8): Promise<string> => {
  return new Promise((resolve, reject) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = document.createElement('img'); // Utilisation correcte de l'élément img natif

    img.onload = () => {
      // Calculer les nouvelles dimensions
      let { width, height } = img;

      if (width > maxWidth) {
        height = (height * maxWidth) / width;
        width = maxWidth;
      }

      canvas.width = width;
      canvas.height = height;

      // Dessiner l'image redimensionnée
      ctx?.drawImage(img, 0, 0, width, height);

      // Convertir en base64 avec compression
      const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
      resolve(compressedDataUrl);
    };

    img.onerror = () => reject(new Error('Erreur lors du traitement de l\'image'));

    // Créer l'URL de l'image
    const reader = new FileReader();
    reader.onload = (e) => {
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('Erreur lors de la lecture du fichier'));
    reader.readAsDataURL(file);
  });
};

// Fonction pour uploader une image avec compression
export const uploadImage = async (file: File): Promise<string> => {
  try {
    // Vérifier le type de fichier
    if (!file.type.startsWith('image/')) {
      throw new Error('Le fichier doit être une image');
    }

    // Limiter la taille initiale (10MB max)
    if (file.size > 10 * 1024 * 1024) {
      throw new Error('Fichier trop volumineux (max 10MB)');
    }

    // Compresser l'image
    const compressedDataUrl = await compressImage(file, 800, 0.7);

    // Vérifier la taille après compression (500KB max pour localStorage)
    if (compressedDataUrl.length > 500 * 1024) {
      // Compresser encore plus si nécessaire
      const extraCompressed = await compressImage(file, 600, 0.5);
      if (extraCompressed.length > 500 * 1024) {
        throw new Error('Image trop volumineuse après compression');
      }
      const finalDataUrl = extraCompressed;
      await saveImageToStorage(file, finalDataUrl);
      return finalDataUrl;
    }

    // Sauvegarder l'image compressée
    await saveImageToStorage(file, compressedDataUrl);
    return compressedDataUrl;

  } catch (error) {
    console.error('Erreur upload image:', error);
    throw error;
  }
};

// Fonction pour sauvegarder dans le localStorage avec gestion d'erreurs
const saveImageToStorage = async (file: File, dataUrl: string): Promise<void> => {
  try {
    const imageId = Date.now().toString();
    const uploadedImages = getUploadedImages();

    const newImage: UploadedImage = {
      id: imageId,
      url: dataUrl,
      name: file.name,
      originalName: file.name,
      uploadedAt: new Date().toISOString(),
      type: 'upload',
      size: file.size
    };

    // Ajouter en début de liste
    uploadedImages.unshift(newImage);

    // Limiter à 15 images maximum pour éviter les problèmes de stockage
    const limitedImages = uploadedImages.slice(0, 15);

    localStorage.setItem('uploaded_images', JSON.stringify(limitedImages));

  } catch (error) {
    // Si erreur de quota, nettoyer et réessayer
    console.warn('Quota localStorage atteint, nettoyage automatique...');
    autoCleanStorage();

    try {
      const cleanedImages = getUploadedImages();
      const imageId = Date.now().toString();

      const newImage: UploadedImage = {
        id: imageId,
        url: dataUrl,
        name: file.name,
        originalName: file.name,
        uploadedAt: new Date().toISOString(),
        type: 'upload',
        size: file.size
      };

      cleanedImages.unshift(newImage);
      const limitedImages = cleanedImages.slice(0, 10); // Encore plus restrictif après nettoyage

      localStorage.setItem('uploaded_images', JSON.stringify(limitedImages));
    } catch (secondError) {
      throw new Error('Impossible de sauvegarder l\'image (stockage plein)');
    }
  }
};

// Fonction pour nettoyer automatiquement le stockage
const autoCleanStorage = (): void => {
  try {
    const uploadedImages = getUploadedImages();
    if (uploadedImages.length === 0) return;

    // Trier par date (plus récent en premier)
    uploadedImages.sort((a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime());

    // Garder seulement les 8 images les plus récentes
    const cleanedImages = uploadedImages.slice(0, 8);
    localStorage.setItem('uploaded_images', JSON.stringify(cleanedImages));

  } catch (error) {
    // En cas d'erreur, vider complètement le storage
    localStorage.removeItem('uploaded_images');
  }
};

// Fonction pour générer une image avec IA
export const generateImage = async (prompt: string): Promise<string> => {
  try {
    const imageId = Date.now().toString();

    // Générer l'URL avec Stable Diffusion
    const width = 800;
    const height = 600;
    const orientation = 'landscape';
    const seq = imageId;

    const imageUrl = `https://readdy.ai/api/search-image?query=${encodeURIComponent(prompt)}&width=${width}&height=${height}&seq=${seq}&orientation=${orientation}`;

    // Sauvegarder dans localStorage
    const uploadedImages = getUploadedImages();
    const newImage: UploadedImage = {
      id: imageId,
      url: imageUrl,
      name: prompt.substring(0, 50) + '...',
      prompt: prompt,
      uploadedAt: new Date().toISOString(),
      type: 'generated'
    };

    uploadedImages.unshift(newImage);

    // Limiter à 15 images maximum
    const limitedImages = uploadedImages.slice(0, 15);

    try {
      localStorage.setItem('uploaded_images', JSON.stringify(limitedImages));
    } catch (error) {
      // Si erreur de quota, nettoyer et réessayer
      autoCleanStorage();
      const cleanedImages = getUploadedImages();
      cleanedImages.unshift(newImage);
      const finalImages = cleanedImages.slice(0, 10);
      localStorage.setItem('uploaded_images', JSON.stringify(finalImages));
    }

    return imageUrl;
  } catch (error) {
    console.error('Erreur génération image:', error);
    throw new Error('Erreur lors de la génération de l\'image');
  }
};

// Fonction pour récupérer toutes les images uploadées
export const getUploadedImages = (): UploadedImage[] => {
  try {
    const stored = localStorage.getItem('uploaded_images');
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Erreur lecture localStorage:', error);
    // En cas d'erreur, nettoyer le localStorage
    localStorage.removeItem('uploaded_images');
    return [];
  }
};

// Fonction pour supprimer une image
export const deleteImage = (imageId: string): void => {
  try {
    const uploadedImages = getUploadedImages();
    const filteredImages = uploadedImages.filter(img => img.id !== imageId);
    localStorage.setItem('uploaded_images', JSON.stringify(filteredImages));
  } catch (error) {
    console.error('Erreur suppression image:', error);
  }
};

// Fonction pour nettoyer les anciennes images
export const cleanOldImages = (daysOld: number = 7): void => {
  try {
    const uploadedImages = getUploadedImages();
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysOld);

    const filteredImages = uploadedImages.filter(img => {
      const uploadDate = new Date(img.uploadedAt);
      return uploadDate > cutoffDate;
    });

    localStorage.setItem('uploaded_images', JSON.stringify(filteredImages));
  } catch (error) {
    console.error('Erreur nettoyage images:', error);
  }
};

// Fonction pour obtenir la taille du stockage utilisé
export const getStorageUsage = (): { used: number; max: number; percentage: number } => {
  try {
    const stored = localStorage.getItem('uploaded_images') || '[]';
    const usedBytes = stored.length;
    const maxBytes = 2 * 1024 * 1024; // 2MB limite pratique
    const percentage = (usedBytes / maxBytes) * 100;

    return {
      used: usedBytes,
      max: maxBytes,
      percentage: Math.round(percentage)
    };
  } catch {
    return { used: 0, max: 2 * 1024 * 1024, percentage: 0 };
  }
};

// Fonction pour vider complètement le stockage
export const clearAllImages = (): void => {
  try {
    localStorage.removeItem('uploaded_images');
  } catch (error) {
    console.error('Erreur vidage stockage:', error);
  }
};

// Aliases pour compatibilité
export const saveUploadedImage = uploadImage;
export const generateAIImage = generateImage;
export const getAllUploadedImages = getUploadedImages;
