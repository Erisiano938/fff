'use client';

// Gestion des données réelles du constructeur no-code

export interface SiteProject {
  id: string;
  name: string;
  status: 'published' | 'draft';
  lastModified: Date;
  description: string;
  domain: string;
  pages: SitePage[];
  theme: SiteTheme;
  settings: SiteSettings;
  components: SiteComponent[];
}

export interface SitePage {
  id: string;
  name: string;
  slug: string;
  title: string;
  content: PageElement[];
  seo: {
    metaTitle: string;
    metaDescription: string;
    keywords: string[];
  };
  isHomepage: boolean;
  status: 'published' | 'draft';
  lastModified: Date;
}

export interface PageElement {
  id: string;
  type: 'header' | 'text' | 'image' | 'button' | 'form' | 'container' | 'section';
  content: any;
  styles: ElementStyles;
  children?: PageElement[];
}

export interface ElementStyles {
  width: string;
  height: string;
  backgroundColor: string;
  color: string;
  padding: string;
  margin: string;
  borderRadius: string;
  fontSize: string;
  fontWeight: string;
}

export interface SiteTheme {
  id: string;
  name: string;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
    text: string;
  };
  fonts: {
    primary: string;
    secondary: string;
  };
}

export interface SiteSettings {
  siteName: string;
  siteDescription: string;
  domain: string;
  language: string;
  seo: {
    metaTitle: string;
    metaDescription: string;
    keywords: string[];
  };
  integrations: {
    googleAnalytics?: string;
    facebookPixel?: string;
    mailchimp?: string;
  };
}

export interface SiteComponent {
  id: string;
  name: string;
  type: string;
  category: string;
  element: PageElement;
}

class SiteBuilderStorage {
  private storageKey = 'cmv_site_builder_data';

  // Récupérer toutes les données
  getAllData(): {
    projects: SiteProject[];
    currentProject: SiteProject | null;
    stats: any;
  } {
    try {
      const data = localStorage.getItem(this.storageKey);
      if (data && data.trim()) {
        // Vérifier que les données commencent bien par { ou [
        const trimmedData = data.trim();
        if (!trimmedData.startsWith('{') && !trimmedData.startsWith('[')) {
          console.warn('Données localStorage corrompues, réinitialisation');
          localStorage.removeItem(this.storageKey);
          return this.getDefaultData();
        }
        
        const parsed = JSON.parse(trimmedData);
        return {
          projects: parsed.projects || [],
          currentProject: parsed.currentProject || null,
          stats: parsed.stats || this.generateStats(parsed.projects || [])
        };
      }
    } catch (error) {
      console.error('Erreur lecture données:', error);
      // Nettoyer le localStorage corrompu
      localStorage.removeItem(this.storageKey);
    }
    
    return this.getDefaultData();
  }

  // Données par défaut
  private getDefaultData() {
    const defaultProject = this.createDefaultProject();
    return {
      projects: [defaultProject],
      currentProject: defaultProject,
      stats: this.generateStats([defaultProject])
    };
  }

  // Sauvegarder les données avec validation
  saveData(data: { projects: SiteProject[]; currentProject: SiteProject | null }): void {
    try {
      const saveData = {
        ...data,
        stats: this.generateStats(data.projects),
        lastUpdated: new Date().toISOString()
      };
      
      // Validation avant sauvegarde
      const jsonString = JSON.stringify(saveData);
      if (jsonString && jsonString.length > 0) {
        localStorage.setItem(this.storageKey, jsonString);
      }
    } catch (error) {
      console.error('Erreur sauvegarde données:', error);
    }
  }

  // Réinitialiser le storage
  resetStorage(): void {
    try {
      localStorage.removeItem(this.storageKey);
    } catch (error) {
      console.error('Erreur reset storage:', error);
    }
  }

  // Créer un nouveau projet
  createProject(name: string, template?: string): SiteProject {
    const project: SiteProject = {
      id: this.generateId(),
      name,
      status: 'draft',
      lastModified: new Date(),
      description: `Site web ${name}`,
      domain: `${name.toLowerCase().replace(/\s+/g, '-')}.com`,
      pages: [this.createDefaultPage(true)],
      theme: this.getDefaultTheme(),
      settings: this.getDefaultSettings(name),
      components: []
    };

    const data = this.getAllData();
    data.projects.push(project);
    data.currentProject = project;
    this.saveData(data);

    return project;
  }

  // Mettre à jour un projet
  updateProject(projectId: string, updates: Partial<SiteProject>): void {
    const data = this.getAllData();
    const projectIndex = data.projects.findIndex(p => p.id === projectId);
    
    if (projectIndex !== -1) {
      data.projects[projectIndex] = {
        ...data.projects[projectIndex],
        ...updates,
        lastModified: new Date()
      };
      
      if (data.currentProject?.id === projectId) {
        data.currentProject = data.projects[projectIndex];
      }
      
      this.saveData(data);
    }
  }

  // Supprimer un projet
  deleteProject(projectId: string): void {
    const data = this.getAllData();
    data.projects = data.projects.filter(p => p.id !== projectId);
    
    if (data.currentProject?.id === projectId) {
      data.currentProject = data.projects[0] || null;
    }
    
    this.saveData(data);
  }

  // Créer une nouvelle page
  createPage(projectId: string, pageName: string): SitePage {
    const page = this.createDefaultPage(false, pageName);
    
    const data = this.getAllData();
    const project = data.projects.find(p => p.id === projectId);
    
    if (project) {
      project.pages.push(page);
      project.lastModified = new Date();
      this.saveData(data);
    }
    
    return page;
  }

  // Mettre à jour une page
  updatePage(projectId: string, pageId: string, updates: Partial<SitePage>): void {
    const data = this.getAllData();
    const project = data.projects.find(p => p.id === projectId);
    
    if (project) {
      const pageIndex = project.pages.findIndex(p => p.id === pageId);
      if (pageIndex !== -1) {
        project.pages[pageIndex] = {
          ...project.pages[pageIndex],
          ...updates,
          lastModified: new Date()
        };
        project.lastModified = new Date();
        this.saveData(data);
      }
    }
  }

  // Publier un projet
  publishProject(projectId: string): void {
    this.updateProject(projectId, { status: 'published' });
  }

  // Appliquer un thème
  applyTheme(projectId: string, theme: SiteTheme): void {
    this.updateProject(projectId, { theme });
  }

  // Générer des statistiques
  private generateStats(projects: SiteProject[]) {
    const totalPages = projects.reduce((sum, p) => sum + p.pages.length, 0);
    const publishedProjects = projects.filter(p => p.status === 'published').length;
    
    return {
      projectsCreated: projects.length,
      pagesCreated: totalPages,
      componentsUsed: Math.floor(Math.random() * 100) + 20, // Simulé pour l'instant
      visitors: Math.floor(Math.random() * 5000) + 1000, // Simulé pour l'instant
      performance: Math.floor(Math.random() * 20) + 80, // Simulé pour l'instant
      publishedProjects
    };
  }

  // Créer un projet par défaut
  private createDefaultProject(): SiteProject {
    return {
      id: this.generateId(),
      name: 'Mon Premier Site',
      status: 'published',
      lastModified: new Date(),
      description: 'Site web professionnel',
      domain: 'monpremiersite.com',
      pages: [
        this.createDefaultPage(true, 'Accueil'),
        this.createDefaultPage(false, 'À propos'),
        this.createDefaultPage(false, 'Services'),
        this.createDefaultPage(false, 'Contact')
      ],
      theme: this.getDefaultTheme(),
      settings: this.getDefaultSettings('Mon Premier Site'),
      components: []
    };
  }

  // Créer une page par défaut
  private createDefaultPage(isHomepage: boolean = false, name: string = 'Nouvelle Page'): SitePage {
    return {
      id: this.generateId(),
      name,
      slug: name.toLowerCase().replace(/\s+/g, '-'),
      title: name,
      content: [],
      seo: {
        metaTitle: name,
        metaDescription: `Page ${name}`,
        keywords: []
      },
      isHomepage,
      status: 'draft',
      lastModified: new Date()
    };
  }

  // Thème par défaut
  private getDefaultTheme(): SiteTheme {
    return {
      id: 'corporate',
      name: 'Corporate',
      colors: {
        primary: '#F59E0B',
        secondary: '#EA580C',
        accent: '#FCD34D',
        background: '#FFFFFF',
        text: '#1F2937'
      },
      fonts: {
        primary: 'Inter',
        secondary: 'Inter'
      }
    };
  }

  // Paramètres par défaut
  private getDefaultSettings(siteName: string): SiteSettings {
    return {
      siteName,
      siteDescription: 'Un site web moderne et professionnel',
      domain: `${siteName.toLowerCase().replace(/\s+/g, '-')}.com`,
      language: 'fr',
      seo: {
        metaTitle: siteName,
        metaDescription: 'Un site web moderne et professionnel',
        keywords: ['site web', 'professionnel', 'moderne']
      },
      integrations: {}
    };
  }

  // Générer un ID unique
  private generateId(): string {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }

  // Obtenir les thèmes disponibles
  getAvailableThemes(): SiteTheme[] {
    return [
      {
        id: 'minimal',
        name: 'Minimal',
        colors: { primary: '#000000', secondary: '#FFFFFF', accent: '#F3F4F6', background: '#FFFFFF', text: '#000000' },
        fonts: { primary: 'Inter', secondary: 'Inter' }
      },
      {
        id: 'colorful',
        name: 'Colorful',
        colors: { primary: '#EF4444', secondary: '#3B82F6', accent: '#10B981', background: '#FFFFFF', text: '#1F2937' },
        fonts: { primary: 'Poppins', secondary: 'Inter' }
      },
      {
        id: 'nature',
        name: 'Nature',
        colors: { primary: '#059669', secondary: '#84CC16', accent: '#FCD34D', background: '#F9FAFB', text: '#1F2937' },
        fonts: { primary: 'Nunito', secondary: 'Inter' }
      },
      {
        id: 'sunset',
        name: 'Sunset',
        colors: { primary: '#F97316', secondary: '#EF4444', accent: '#F59E0B', background: '#FFF7ED', text: '#1F2937' },
        fonts: { primary: 'Roboto', secondary: 'Inter' }
      },
      {
        id: 'ocean',
        name: 'Ocean',
        colors: { primary: '#0EA5E9', secondary: '#06B6D4', accent: '#3B82F6', background: '#F0F9FF', text: '#1F2937' },
        fonts: { primary: 'Open Sans', secondary: 'Inter' }
      },
      {
        id: 'purple',
        name: 'Purple',
        colors: { primary: '#8B5CF6', secondary: '#A855F7', accent: '#C084FC', background: '#FAFAFA', text: '#1F2937' },
        fonts: { primary: 'Montserrat', secondary: 'Inter' }
      }
    ];
  }

  // Obtenir les composants disponibles
  getAvailableComponents(): SiteComponent[] {
    return [
      {
        id: 'header-simple',
        name: 'En-tête Simple',
        type: 'header',
        category: 'Layout',
        element: {
          id: this.generateId(),
          type: 'header',
          content: { text: 'Mon Site Web' },
          styles: { width: '100%', height: 'auto', backgroundColor: '#FFFFFF', color: '#1F2937', padding: '1rem', margin: '0', borderRadius: '0', fontSize: '2rem', fontWeight: 'bold' }
        }
      },
      {
        id: 'text-paragraph',
        name: 'Paragraphe',
        type: 'text',
        category: 'Contenu',
        element: {
          id: this.generateId(),
          type: 'text',
          content: { text: 'Votre texte ici...' },
          styles: { width: '100%', height: 'auto', backgroundColor: 'transparent', color: '#1F2937', padding: '0.5rem', margin: '0.5rem 0', borderRadius: '0', fontSize: '1rem', fontWeight: 'normal' }
        }
      },
      {
        id: 'button-primary',
        name: 'Bouton Principal',
        type: 'button',
        category: 'Interactif',
        element: {
          id: this.generateId(),
          type: 'button',
          content: { text: 'Cliquer ici', link: '#' },
          styles: { width: 'auto', height: 'auto', backgroundColor: '#F59E0B', color: '#FFFFFF', padding: '0.75rem 1.5rem', margin: '0.5rem', borderRadius: '0.5rem', fontSize: '1rem', fontWeight: '600' }
        }
      }
    ];
  }
}

export const siteBuilderStorage = new SiteBuilderStorage();