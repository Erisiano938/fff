
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Footer() {
  const [email, setEmail] = useState('');
  const [subscriptionStatus, setSubscriptionStatus] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscriptionStatus('Merci pour votre inscription !');
      setEmail('');
      setTimeout(() => setSubscriptionStatus(''), 3000);
    }
  };

  return (
    <footer className="bg-gray-900 border-t border-gray-800">
      <div className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Logo et Description */}
          <div className="space-y-4">
            <Link href="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
                <span className="text-black font-bold text-xl">C</span>
              </div>
              <span className="text-2xl font-bold text-white font-['Pacifico']">CMV Finance</span>
            </Link>
            <p className="text-gray-400 text-sm leading-relaxed">
              Plateforme complète pour optimiser vos investissements et développer vos compétences en trading.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors cursor-pointer">
                <i className="ri-facebook-fill text-white"></i>
              </a>
              <a href="#" className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors cursor-pointer">
                <i className="ri-twitter-fill text-white"></i>
              </a>
              <a href="#" className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors cursor-pointer">
                <i className="ri-linkedin-fill text-white"></i>
              </a>
              <a href="#" className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors cursor-pointer">
                <i className="ri-youtube-fill text-white"></i>
              </a>
            </div>
          </div>

          {/* Plateforme */}
          <div>
            <h4 className="text-white font-semibold mb-4">Plateforme</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/dashboard" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Dashboard
                </Link>
              </li>
              <li>
                <Link href="/academy" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Formation
                </Link>
              </li>
              <li>
                <Link href="/indicators" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Indicateurs
                </Link>
              </li>
              <li>
                <Link href="/trading" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Trading
                </Link>
              </li>
              <li>
                <Link href="/allocation" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Allocation
                </Link>
              </li>
              <li>
                <Link href="/opportunities" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Opportunités
                </Link>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="text-white font-semibold mb-4">Support</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/contact" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Contact
                </Link>
              </li>
              <li>
                <Link href="/academy" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Centre d'aide
                </Link>
              </li>
              <li>
                <Link href="/academy" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Documentation
                </Link>
              </li>
              <li>
                <Link href="/status" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Statut système
                </Link>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="text-white font-semibold mb-4">Newsletter</h4>
            <p className="text-gray-400 text-sm mb-4">
              Recevez les dernières actualités et analyses de marché.
            </p>
            <form onSubmit={handleSubscribe} className="space-y-3">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Votre email"
                className="w-full px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:border-white focus:outline-none"
                required
              />
              <button
                type="submit"
                className="w-full px-4 py-2 bg-white text-black rounded-lg hover:bg-gray-200 transition-colors font-medium whitespace-nowrap"
              >
                S'abonner
              </button>
            </form>
            {subscriptionStatus && (
              <p className="text-green-400 text-sm mt-2">{subscriptionStatus}</p>
            )}
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">
            © 2024 CMV Finance. Tous droits réservés.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <Link href="/privacy" className="text-gray-400 hover:text-white transition-colors text-sm">
              Confidentialité
            </Link>
            <a href="#" className="text-gray-400 hover:text-white transition-colors text-sm">
              Conditions
            </a>
            <Link href="/cookies" className="text-gray-400 hover:text-white transition-colors text-sm">
              Cookies
            </Link>
            <Link href="/admin/login" className="text-gray-400 hover:text-yellow-400 transition-colors text-sm">
              Admin
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
