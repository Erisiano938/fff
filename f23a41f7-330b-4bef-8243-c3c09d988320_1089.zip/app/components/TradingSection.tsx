
'use client';
import Link from 'next/link';

export default function TradingSection() {
  return (
    <>
      <section className="py-20 bg-black">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-white">
                Allocations <span className="text-yellow-400">d'Actifs</span>
              </h2>
              <p className="text-xl text-gray-400 mb-8">
                Optimisez votre portefeuille avec nos stratégies d'allocation d'actifs personnalisées et nos outils de gestion de patrimoine avancés.
              </p>
              <div className="space-y-6 mb-8">
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-yellow-500/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <i className="ri-check-line text-yellow-400"></i>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-white mb-2">Modèles d'Allocation Personnalisés</h4>
                    <p className="text-gray-400">Stratégies d'investissement adaptées à votre profil de risque et vos objectifs financiers.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-yellow-500/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <i className="ri-check-line text-yellow-400"></i>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-white mb-2">Rééquilibrage Automatique</h4>
                    <p className="text-gray-400">Outils intelligents pour maintenir l'allocation optimale de votre portefeuille.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-yellow-500/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <i className="ri-check-line text-yellow-400"></i>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-white mb-2">Analyse de Performance</h4>
                    <p className="text-gray-400">Suivi détaillé de la performance avec indicateurs de risque et recommandations.</p>
                  </div>
                </div>
              </div>
              <Link href="/allocation">
                <button className="bg-yellow-500 text-black px-8 py-4 rounded-lg font-semibold text-lg hover:bg-yellow-400 transition-colors cursor-pointer whitespace-nowrap">
                  Découvrir les Allocations
                </button>
              </Link>
            </div>
            <div className="relative">
              <div 
                className="w-full h-96 bg-cover bg-center rounded-xl"
                style={{
                  backgroundImage: `url('https://static.readdy.ai/image/2fd303749c7ebdaed28729a47deb56cb/16782ac53927f65123a4ac1afc2c2ece.png')`
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent rounded-xl" />
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-br from-blue-900 to-purple-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/30"></div>
        <div className="container mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <div 
                className="w-full h-96 bg-cover bg-center rounded-xl shadow-2xl"
                style={{
                  backgroundImage: `url('https://readdy.ai/api/search-image?query=professional%20business%20data%20analysis%20dashboard%20with%20charts%20graphs%20and%20financial%20market%20trends%2C%20modern%20digital%20interface%20showing%20sector%20growth%20opportunities%2C%20clean%20minimalist%20design%20with%20blue%20and%20purple%20color%20scheme%2C%20technology%20and%20finance%20concept&width=600&height=400&seq=sector-detector-001&orientation=landscape')`
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-blue-900/40 to-transparent rounded-xl" />
            </div>
            <div className="order-first lg:order-last">
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-white">
                Détecteur d' <span className="text-yellow-400">Opportunités</span> Sectorielles
              </h2>
              <p className="text-xl text-gray-200 mb-8">
                Identifiez les secteurs en croissance avant les autres grâce à notre analyse avancée des signaux faibles du marché.
              </p>
              <div className="space-y-6 mb-8">
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-yellow-500/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <i className="ri-search-line text-yellow-400"></i>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-white mb-2">Scraper d'Appels d'Offres</h4>
                    <p className="text-gray-200">Analyse en temps réel des marchés publics pour détecter les tendances sectorielles émergentes.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-yellow-500/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <i className="ri-lightbulb-line text-yellow-400"></i>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-white mb-2">Veille Brevets</h4>
                    <p className="text-gray-200">Suivi des innovations et dépôts de brevets pour anticiper les révolutions technologiques.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-yellow-500/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <i className="ri-user-star-line text-yellow-400"></i>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-white mb-2">Mouvements de Dirigeants</h4>
                    <p className="text-gray-200">Analyse des changements de direction pour identifier les secteurs stratégiques.</p>
                  </div>
                </div>
              </div>
              <Link href="/opportunities">
                <button className="bg-yellow-500 text-black px-8 py-4 rounded-lg font-semibold text-lg hover:bg-yellow-400 transition-colors cursor-pointer whitespace-nowrap">
                  Explorer les Opportunités
                </button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-6 text-center">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-gray-800">
              Open <span className="text-yellow-500">Banking</span>
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              Connectez tous vos comptes bancaires en toute sécurité pour une vision complète de votre patrimoine financier.
            </p>
            <div className="bg-white rounded-xl p-8 shadow-lg border border-yellow-200">
              <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-bank-line text-yellow-500 text-2xl"></i>
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">Fonctionnalité en Développement</h3>
              <p className="text-gray-600 mb-6">
                Notre solution Open Banking arrive bientôt ! Vous pourrez connecter tous vos comptes bancaires pour une gestion centralisée et sécurisée de votre patrimoine.
              </p>
              <div className="flex justify-center space-x-8 text-sm text-gray-500">
                <div className="flex items-center space-x-2">
                  <i className="ri-shield-check-line text-green-500"></i>
                  <span>Sécurité bancaire</span>
                </div>
                <div className="flex items-center space-x-2">
                  <i className="ri-link-line text-blue-500"></i>
                  <span>Agrégation de comptes</span>
                </div>
                <div className="flex items-center space-x-2">
                  <i className="ri-eye-line text-purple-500"></i>
                  <span>Vision globale</span>
                </div>
              </div>
              <div className="mt-6">
                <span className="inline-block bg-yellow-100 text-yellow-800 px-4 py-2 rounded-full text-sm font-semibold">
                  Bientôt disponible
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-black">
        <div className="container mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-white">
                Marketplace de <span className="text-yellow-400">Services</span> Intégrée
              </h2>
              <p className="text-xl text-gray-400 mb-8">
                Comparez et orientez vers notaires, avocats, banques, courtiers FX, assurances… avec prise de rendez-vous instantanée et commission reverse.
              </p>
              <div className="space-y-6 mb-8">
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-yellow-500/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <i className="ri-search-line text-yellow-400"></i>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-white mb-2">Comparaison de Services</h4>
                    <p className="text-gray-400">Trouvez rapidement les meilleurs professionnels selon vos critères : tarifs, spécialités, localisation.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-yellow-500/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <i className="ri-calendar-line text-yellow-400"></i>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-white mb-2">Prise de Rendez-vous Instantanée</h4>
                    <p className="text-gray-400">Réservez directement en ligne avec les professionnels sélectionnés en quelques clics.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-yellow-500/20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <i className="ri-money-dollar-circle-line text-yellow-400"></i>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-white mb-2">Commission Reverse</h4>
                    <p className="text-gray-400">Bénéficiez d'une rémunération sur les services utilisés via notre plateforme.</p>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 mb-8">
                <div className="bg-gray-900 p-4 rounded-lg border border-yellow-500/20">
                  <div className="flex items-center space-x-3 mb-2">
                    <i className="ri-scales-line text-yellow-400"></i>
                    <span className="text-white font-semibold">Notaires</span>
                  </div>
                  <p className="text-gray-400 text-sm">Transactions immobilières, successions</p>
                </div>
                <div className="bg-gray-900 p-4 rounded-lg border border-yellow-500/20">
                  <div className="flex items-center space-x-3 mb-2">
                    <i className="ri-briefcase-line text-yellow-400"></i>
                    <span className="text-white font-semibold">Avocats</span>
                  </div>
                  <p className="text-gray-400 text-sm">Droit fiscal, patrimonial</p>
                </div>
                <div className="bg-gray-900 p-4 rounded-lg border border-yellow-500/20">
                  <div className="flex items-center space-x-3 mb-2">
                    <i className="ri-bank-line text-yellow-400"></i>
                    <span className="text-white font-semibold">Banques</span>
                  </div>
                  <p className="text-gray-400 text-sm">Prêts, investissements</p>
                </div>
                <div className="bg-gray-900 p-4 rounded-lg border border-yellow-500/20">
                  <div className="flex items-center space-x-3 mb-2">
                    <i className="ri-shield-check-line text-yellow-400"></i>
                    <span className="text-white font-semibold">Assurances</span>
                  </div>
                  <p className="text-gray-400 text-sm">Vie, habitation, auto</p>
                </div>
              </div>
              <Link href="/marketplace">
                <button className="bg-yellow-500 text-black px-8 py-4 rounded-lg font-semibold text-lg hover:bg-yellow-400 transition-colors cursor-pointer whitespace-nowrap">
                  Découvrir le Marketplace
                </button>
              </Link>
            </div>
            <div className="relative">
              <div 
                className="w-full h-96 bg-cover bg-center rounded-xl"
                style={{
                  backgroundImage: `url('https://readdy.ai/api/search-image?query=professional%20business%20services%20marketplace%20platform%20showing%20lawyers%20notaries%20banks%20and%20insurance%20professionals%2C%20modern%20digital%20interface%20with%20service%20comparison%20tools%2C%20appointment%20booking%20system%2C%20clean%20corporate%20design%20with%20yellow%20and%20black%20color%20scheme%2C%20financial%20services%20directory%20concept&width=600&height=400&seq=marketplace-services-001&orientation=landscape')`
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent rounded-xl" />
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
