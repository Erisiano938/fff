
'use client';

import { useState } from 'react';
import Link from 'next/link';
import ShinyText from './ShinyText';

export default function Hero() {
  const [isHovered, setIsHovered] = useState(false);

  const heroContent = {
    title: "Votre partenaire en investissement intelligent",
    subtitle: "Plateforme financière de nouvelle génération",
    description: "Optimisez vos investissements grâce à l'intelligence artificielle, nos outils d'analyse avancés et notre académie de trading. Rejoignez des milliers d'investisseurs qui font confiance à notre expertise.",
    buttonPrimary: "Nous contacter",
    buttonSecondary: "Accéder au Dashboard"
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden" suppressHydrationWarning={true}>
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url('https://static.readdy.ai/image/2fd303749c7ebdaed28729a47deb56cb/f22e497c07adb039610ea79f9e17ac98.png')`
        }}
      />
      
      <div className="absolute inset-0 bg-black/50" />
      
      <div className="relative z-10 text-center text-white px-4 max-w-6xl mx-auto">
        <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
          <span className="bg-gradient-to-r from-yellow-400 via-yellow-500 to-yellow-600 bg-clip-text text-transparent animate-pulse">
            {heroContent.title}
          </span>
        </h1>
        
        <div className="text-xl md:text-2xl mb-4 font-medium">
          <ShinyText 
            text={heroContent.subtitle}
            className="bg-gradient-to-r from-yellow-300 via-yellow-400 to-yellow-500 bg-clip-text text-transparent"
            speed={3}
          />
        </div>
        
        <div className="text-lg md:text-xl mb-12 max-w-4xl mx-auto leading-relaxed">
          <span className="bg-gradient-to-r from-yellow-200 via-yellow-300 to-yellow-400 bg-clip-text text-transparent">
            {heroContent.description}
          </span>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
          <Link 
            href="/contact"
            className="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-black px-8 py-4 rounded-lg font-semibold text-lg transition-all duration-300 transform hover:scale-105 hover:shadow-xl whitespace-nowrap cursor-pointer"
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
          >
            {heroContent.buttonPrimary}
          </Link>
          
          <Link 
            href="/dashboard"
            className="bg-transparent border-2 border-yellow-400 text-yellow-400 hover:bg-yellow-400 hover:text-black px-8 py-4 rounded-lg font-semibold text-lg transition-all duration-300 transform hover:scale-105 hover:shadow-xl whitespace-nowrap cursor-pointer"
          >
            {heroContent.buttonSecondary}
          </Link>
        </div>
      </div>
    </div>
  );
}
