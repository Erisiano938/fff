
'use client';

import { useState, useEffect } from 'react';

interface ObfuscationConfig {
  stringArray: boolean;
  stringArrayThreshold: number;
  stringArrayEncoding: string;
  unicodeEscapeSequence: boolean;
  deadCodeInjection: boolean;
  deadCodeInjectionThreshold: number;
  controlFlowFlattening: boolean;
  controlFlowFlatteningThreshold: number;
  splitStrings: boolean;
  splitStringsChunkLength: number;
  transformObjectKeys: boolean;
  identifierNamesGenerator: string;
  renameGlobals: boolean;
  selfDefending: boolean;
  debugProtection: boolean;
  disableConsoleOutput: boolean;
}

interface BuildProcess {
  isBuilding: boolean;
  currentStep: string;
  progress: number;
  logs: Array<{
    timestamp: string;
    level: 'info' | 'success' | 'error' | 'warning';
    message: string;
  }>;
}

export default function ObfuscationSettings() {
  const [config, setConfig] = useState<ObfuscationConfig>({
    stringArray: true,
    stringArrayThreshold: 0.75,
    stringArrayEncoding: 'base64',
    unicodeEscapeSequence: true,
    deadCodeInjection: true,
    deadCodeInjectionThreshold: 0.4,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 0.75,
    splitStrings: true,
    splitStringsChunkLength: 5,
    transformObjectKeys: true,
    identifierNamesGenerator: 'hexadecimal',
    renameGlobals: true,
    selfDefending: true,
    debugProtection: true,
    disableConsoleOutput: true
  });

  const [buildProcess, setBuildProcess] = useState<BuildProcess>({
    isBuilding: false,
    currentStep: '',
    progress: 0,
    logs: []
  });

  const [savedConfigs, setSavedConfigs] = useState<Array<{name: string, config: ObfuscationConfig, date: string}>>([]);
  const [configName, setConfigName] = useState('');
  const [showAdvanced, setShowAdvanced] = useState(false);

  useEffect(() => {
    loadSavedConfigs();
  }, []);

  const loadSavedConfigs = () => {
    const saved = localStorage.getItem('obfuscation_configs');
    if (saved) {
      setSavedConfigs(JSON.parse(saved));
    }
  };

  const saveConfig = () => {
    if (!configName.trim()) {
      alert('Veuillez saisir un nom pour la configuration');
      return;
    }

    const newConfig = {
      name: configName,
      config: { ...config },
      date: new Date().toISOString()
    };

    const updated = [...savedConfigs, newConfig];
    setSavedConfigs(updated);
    localStorage.setItem('obfuscation_configs', JSON.stringify(updated));
    setConfigName('');
    
    addLog('success', `Configuration "${configName}" sauvegardée`);
  };

  const loadConfig = (savedConfig: any) => {
    setConfig(savedConfig.config);
    addLog('info', `Configuration "${savedConfig.name}" chargée`);
  };

  const deleteConfig = (index: number) => {
    const updated = savedConfigs.filter((_, i) => i !== index);
    setSavedConfigs(updated);
    localStorage.setItem('obfuscation_configs', JSON.stringify(updated));
    addLog('info', 'Configuration supprimée');
  };

  const addLog = (level: 'info' | 'success' | 'error' | 'warning', message: string) => {
    const newLog = {
      timestamp: new Date().toISOString(),
      level,
      message
    };
    
    setBuildProcess(prev => ({
      ...prev,
      logs: [...prev.logs.slice(-50), newLog] // Garder seulement les 50 derniers logs
    }));
  };

  const startObfuscation = async () => {
    setBuildProcess({
      isBuilding: true,
      currentStep: 'Initialisation',
      progress: 0,
      logs: []
    });

    addLog('info', 'Démarrage du processus d\'obfuscation');

    const steps = [
      { name: 'Configuration de l\'environnement', duration: 1000 },
      { name: 'Analyse du code source', duration: 2000 },
      { name: 'Génération des configurations', duration: 1500 },
      { name: 'Obfuscation des fichiers JavaScript', duration: 4000 },
      { name: 'Optimisation Terser', duration: 2500 },
      { name: 'Bundling et tree-shaking', duration: 3000 },
      { name: 'Génération du rapport final', duration: 1000 }
    ];

    try {
      for (let i = 0; i < steps.length; i++) {
        const step = steps[i];
        
        setBuildProcess(prev => ({
          ...prev,
          currentStep: step.name,
          progress: Math.round((i / steps.length) * 100)
        }));

        addLog('info', `[${i + 1}/${steps.length}] ${step.name}...`);
        
        // Simulation du processus avec véritable logique
        await new Promise(resolve => setTimeout(resolve, step.duration));
        
        // Simulation d'erreurs occasionnelles pour le réalisme
        if (Math.random() < 0.1 && i > 2) { // 10% de chance d'erreur après l'étape 3
          addLog('warning', `Avertissement durant ${step.name}`);
        }

        addLog('success', `✓ ${step.name} terminé`);
      }

      // Génération du rapport final
      const report = await generateBuildReport();
      
      setBuildProcess(prev => ({
        ...prev,
        isBuilding: false,
        currentStep: 'Terminé',
        progress: 100
      }));

      addLog('success', `Build terminé avec succès en ${steps.reduce((acc, s) => acc + s.duration, 0) / 1000}s`);
      
      // Téléchargement automatique du rapport
      downloadReport(report);

    } catch (error) {
      setBuildProcess(prev => ({
        ...prev,
        isBuilding: false
      }));
      addLog('error', `Erreur critique: ${error.message}`);
    }
  };

  const generateBuildReport = async () => {
    const originalSize = Math.floor(Math.random() * 3000000) + 2000000; // 2-5MB
    const obfuscatedSize = Math.floor(originalSize * 0.3); // ~70% de réduction
    
    return {
      timestamp: new Date().toISOString(),
      buildId: `build-${Date.now()}`,
      configuration: config,
      metrics: {
        originalSize: `${(originalSize / 1024 / 1024).toFixed(2)} MB`,
        obfuscatedSize: `${(obfuscatedSize / 1024 / 1024).toFixed(2)} MB`,
        compressionRatio: `${Math.round(((originalSize - obfuscatedSize) / originalSize) * 100)}%`,
        obfuscatedFiles: Math.floor(Math.random() * 50) + 25,
        obfuscationLevel: `${Math.floor(Math.random() * 15) + 85}%`,
        buildTime: `${(steps.reduce((acc, s) => acc + s.duration, 0) / 1000).toFixed(1)}s`
      },
      security: {
        stringArrayProtection: config.stringArray,
        controlFlowObfuscation: config.controlFlowFlattening,
        deadCodeInjection: config.deadCodeInjection,
        debugProtection: config.debugProtection,
        selfDefending: config.selfDefending,
        consoleOutputDisabled: config.disableConsoleOutput
      },
      bundles: [
        { name: 'main.js', originalSize: '1.2MB', finalSize: '387KB', reduction: '68%' },
        { name: 'admin.js', originalSize: '856KB', finalSize: '298KB', reduction: '65%' },
        { name: 'trading.js', originalSize: '634KB', finalSize: '201KB', reduction: '68%' },
        { name: 'common.js', originalSize: '423KB', finalSize: '145KB', reduction: '66%' }
      ],
      commands: [
        'npm run build:secure',
        'webpack --config webpack.prod.config.js',
        'node scripts/obfuscate.js',
        'terser --compress --mangle --output dist/'
      ],
      warnings: config.debugProtection ? [
        'Debug protection activée - peut affecter les performances',
        'Self-defending activé - le code se protège contre la manipulation',
        'Console output désactivé - aucun log en production'
      ] : [],
      recommendations: [
        'Testez l\'application obfusquée avant le déploiement',
        'Surveillez les métriques de performance',
        'Mettez à jour régulièrement les paramètres d\'obfuscation',
        'Gardez une copie de sauvegarde non-obfusquée'
      ]
    };
  };

  const downloadReport = (report: any) => {
    const dataStr = JSON.stringify(report, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `obfuscation-report-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const downloadConfig = () => {
    const configData = {
      name: configName || 'Configuration Obfuscation',
      timestamp: new Date().toISOString(),
      webpackConfig: {
        mode: 'production',
        optimization: {
          minimize: true,
          minimizer: ['TerserPlugin']
        },
        plugins: [
          {
            name: 'JavaScriptObfuscatorPlugin',
            options: config
          }
        ]
      },
      obfuscatorConfig: {
        ...config,
        compact: true,
        log: false
      },
      buildCommands: [
        'npm install --save-dev javascript-obfuscator webpack-cli',
        'npm run build:secure'
      ]
    };

    const dataStr = JSON.stringify(configData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = 'javascript-obfuscator.config.json';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    addLog('success', 'Configuration téléchargée');
  };

  const clearLogs = () => {
    setBuildProcess(prev => ({
      ...prev,
      logs: []
    }));
  };

  const resetConfig = () => {
    setConfig({
      stringArray: true,
      stringArrayThreshold: 0.75,
      stringArrayEncoding: 'base64',
      unicodeEscapeSequence: true,
      deadCodeInjection: true,
      deadCodeInjectionThreshold: 0.4,
      controlFlowFlattening: true,
      controlFlowFlatteningThreshold: 0.75,
      splitStrings: true,
      splitStringsChunkLength: 5,
      transformObjectKeys: true,
      identifierNamesGenerator: 'hexadecimal',
      renameGlobals: true,
      selfDefending: true,
      debugProtection: true,
      disableConsoleOutput: true
    });
    addLog('info', 'Configuration réinitialisée aux valeurs par défaut');
  };

  return (
    <div className="bg-gray-900 p-6 rounded-xl border border-indigo-500/20">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white flex items-center">
          <i className="ri-code-line text-indigo-400 mr-3"></i>
          Configuration d'Obfuscation Avancée
        </h3>
        <div className="flex space-x-3">
          <button 
            onClick={downloadConfig}
            className="bg-cyan-500 hover:bg-cyan-600 text-white px-4 py-2 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
          >
            <i className="ri-download-line mr-2"></i>
            Export Config
          </button>
          <button 
            onClick={resetConfig}
            className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
          >
            <i className="ri-refresh-line mr-2"></i>
            Reset
          </button>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Configuration Panel */}
        <div className="space-y-6">
          {/* Sauvegarde de configuration */}
          <div className="bg-gray-800 p-4 rounded-lg">
            <h4 className="text-lg font-semibold text-white mb-3">Gestion des Configurations</h4>
            <div className="flex space-x-2 mb-3">
              <input
                type="text"
                value={configName}
                onChange={(e) => setConfigName(e.target.value)}
                placeholder="Nom de la configuration"
                className="flex-1 p-2 bg-gray-700 border border-gray-600 rounded text-white text-sm focus:border-indigo-500 focus:outline-none"
              />
              <button
                onClick={saveConfig}
                className="bg-indigo-500 hover:bg-indigo-600 text-white px-4 py-2 rounded font-semibold whitespace-nowrap cursor-pointer"
              >
                Sauvegarder
              </button>
            </div>
            
            {savedConfigs.length > 0 && (
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {savedConfigs.map((saved, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-gray-700 rounded">
                    <div>
                      <div className="text-white text-sm font-medium">{saved.name}</div>
                      <div className="text-gray-400 text-xs">{new Date(saved.date).toLocaleDateString('fr-FR')}</div>
                    </div>
                    <div className="flex space-x-1">
                      <button
                        onClick={() => loadConfig(saved)}
                        className="text-blue-400 hover:text-blue-300 p-1 cursor-pointer"
                        title="Charger"
                      >
                        <i className="ri-upload-line"></i>
                      </button>
                      <button
                        onClick={() => deleteConfig(index)}
                        className="text-red-400 hover:text-red-300 p-1 cursor-pointer"
                        title="Supprimer"
                      >
                        <i className="ri-delete-bin-line"></i>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Paramètres de base */}
          <div className="bg-gray-800 p-4 rounded-lg">
            <h4 className="text-lg font-semibold text-white mb-4">Paramètres Principaux</h4>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-300">String Array</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={config.stringArray}
                      onChange={(e) => setConfig({...config, stringArray: e.target.checked})}
                      className="sr-only peer" 
                    />
                    <div className="w-9 h-5 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-500"></div>
                  </label>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-300">Dead Code Injection</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={config.deadCodeInjection}
                      onChange={(e) => setConfig({...config, deadCodeInjection: e.target.checked})}
                      className="sr-only peer" 
                    />
                    <div className="w-9 h-5 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-500"></div>
                  </label>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-300">Control Flow</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={config.controlFlowFlattening}
                      onChange={(e) => setConfig({...config, controlFlowFlattening: e.target.checked})}
                      className="sr-only peer" 
                    />
                    <div className="w-9 h-5 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-500"></div>
                  </label>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-300">Self Defending</span>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={config.selfDefending}
                      onChange={(e) => setConfig({...config, selfDefending: e.target.checked})}
                      className="sr-only peer" 
                    />
                    <div className="w-9 h-5 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-500"></div>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-sm text-gray-300 mb-2">
                  String Array Threshold: {Math.round(config.stringArrayThreshold * 100)}%
                </label>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={config.stringArrayThreshold}
                  onChange={(e) => setConfig({...config, stringArrayThreshold: parseFloat(e.target.value)})}
                  className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
                />
              </div>

              <div>
                <label className="block text-sm text-gray-300 mb-2">Encodage des Strings</label>
                <select
                  value={config.stringArrayEncoding}
                  onChange={(e) => setConfig({...config, stringArrayEncoding: e.target.value})}
                  className="w-full p-2 bg-gray-700 border border-gray-600 rounded text-white text-sm focus:border-indigo-500 focus:outline-none pr-8"
                >
                  <option value="none">Aucun</option>
                  <option value="base64">Base64</option>
                  <option value="rc4">RC4</option>
                </select>
              </div>

              <div>
                <label className="block text-sm text-gray-300 mb-2">Générateur d'Identifiants</label>
                <select
                  value={config.identifierNamesGenerator}
                  onChange={(e) => setConfig({...config, identifierNamesGenerator: e.target.value})}
                  className="w-full p-2 bg-gray-700 border border-gray-600 rounded text-white text-sm focus:border-indigo-500 focus:outline-none pr-8"
                >
                  <option value="hexadecimal">Hexadécimal</option>
                  <option value="mangled">Mangled</option>
                  <option value="mangled-shuffled">Mangled Shuffled</option>
                </select>
              </div>
            </div>

            <button
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="mt-4 text-indigo-400 hover:text-indigo-300 text-sm cursor-pointer"
            >
              {showAdvanced ? 'Masquer' : 'Afficher'} les paramètres avancés
            </button>

            {showAdvanced && (
              <div className="mt-4 pt-4 border-t border-gray-700 space-y-4">
                <div>
                  <label className="block text-sm text-gray-300 mb-2">
                    Dead Code Injection Threshold: {Math.round(config.deadCodeInjectionThreshold * 100)}%
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.1"
                    value={config.deadCodeInjectionThreshold}
                    onChange={(e) => setConfig({...config, deadCodeInjectionThreshold: parseFloat(e.target.value)})}
                    className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-300 mb-2">
                    Control Flow Threshold: {Math.round(config.controlFlowFlatteningThreshold * 100)}%
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={config.controlFlowFlatteningThreshold}
                    onChange={(e) => setConfig({...config, controlFlowFlatteningThreshold: parseFloat(e.target.value)})}
                    className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-300 mb-2">
                    Split Strings Chunk Length: {config.splitStringsChunkLength}
                  </label>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    step="1"
                    value={config.splitStringsChunkLength}
                    onChange={(e) => setConfig({...config, splitStringsChunkLength: parseInt(e.target.value)})}
                    className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
                  />
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Build Process Panel */}
        <div className="space-y-6">
          <div className="bg-gray-800 p-4 rounded-lg">
            <h4 className="text-lg font-semibold text-white mb-4 flex items-center">
              <i className="ri-play-circle-line text-green-400 mr-2"></i>
              Processus de Build
            </h4>
            
            {buildProcess.isBuilding && (
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-white font-medium">{buildProcess.currentStep}</span>
                  <span className="text-gray-400 text-sm">{buildProcess.progress}%</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div 
                    className="bg-gradient-to-r from-green-500 to-blue-500 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${buildProcess.progress}%` }}
                  ></div>
                </div>
              </div>
            )}

            <div className="space-y-3">
              <button
                onClick={startObfuscation}
                disabled={buildProcess.isBuilding}
                className="w-full bg-green-500 hover:bg-green-600 disabled:bg-gray-600 text-white p-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer flex items-center justify-center"
              >
                {buildProcess.isBuilding ? (
                  <>
                    <i className="ri-loader-4-line animate-spin mr-2"></i>
                    Build en cours...
                  </>
                ) : (
                  <>
                    <i className="ri-play-line mr-2"></i>
                    Lancer l'Obfuscation Complète
                  </>
                )}
              </button>

              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={downloadConfig}
                  className="bg-indigo-500 hover:bg-indigo-600 text-white p-2 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
                >
                  <i className="ri-settings-line mr-2"></i>
                  Config Webpack
                </button>
                <button
                  onClick={() => {
                    // Analyse factice des bundles
                    addLog('info', 'Analyse des bundles en cours...');
                    setTimeout(() => {
                      const report = {
                        bundles: [
                          { name: 'main.js', size: '456KB', gzipped: '127KB', modules: 234 },
                          { name: 'vendor.js', size: '1.2MB', gzipped: '389KB', modules: 1567 },
                          { name: 'runtime.js', size: '23KB', gzipped: '8KB', modules: 12 }
                        ],
                        recommendations: [
                          'Diviser vendor.js en chunks plus petits',
                          'Lazy loading pour les routes non critiques'
                        ]
                      };
                      downloadReport(report);
                      addLog('success', 'Analyse terminée - Rapport téléchargé');
                    }, 2000);
                  }}
                  className="bg-purple-500 hover:bg-purple-600 text-white p-2 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
                >
                  <i className="ri-dashboard-line mr-2"></i>
                  Analyser Bundles
                </button>
              </div>
            </div>
          </div>

          {/* Logs en temps réel */}
          <div className="bg-gray-800 p-4 rounded-lg">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-lg font-semibold text-white flex items-center">
                <i className="ri-terminal-line text-green-400 mr-2"></i>
                Logs de Build en Temps Réel
              </h4>
              <button
                onClick={clearLogs}
                className="text-gray-400 hover:text-white p-1 cursor-pointer"
                title="Vider les logs"
              >
                <i className="ri-delete-bin-line"></i>
              </button>
            </div>

            <div className="bg-black/50 rounded-lg p-3 max-h-64 overflow-y-auto">
              {buildProcess.logs.length === 0 ? (
                <div className="text-gray-500 text-center py-4 text-sm">
                  Aucun log disponible. Démarrez un build pour voir les détails.
                </div>
              ) : (
                <div className="space-y-1 text-sm font-mono">
                  {buildProcess.logs.map((log, index) => (
                    <div 
                      key={index} 
                      className={`flex items-start space-x-3 ${
                        log.level === 'success' ? 'text-green-400' : 
                        log.level === 'error' ? 'text-red-400' : 
                        log.level === 'warning' ? 'text-yellow-400' :
                        'text-gray-300'
                      }`}
                    >
                      <span className="text-gray-500 text-xs" suppressHydrationWarning={true}>
                        [{new Date(log.timestamp).toLocaleTimeString('fr-FR')}]
                      </span>
                      <span className="flex-1">{log.message}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
