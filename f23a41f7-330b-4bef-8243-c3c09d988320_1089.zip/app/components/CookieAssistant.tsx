
'use client';

import { useState, useRef, useEffect } from 'react';

interface Message {
  id: string;
  content: string;
  isUser: boolean;
  timestamp: Date;
}

interface KnowledgeBase {
  cookies: {
    types: { [key: string]: string };
    security: string[];
    durations: { [key: string]: string };
    thirdParty: { [key: string]: string };
  };
  legal: {
    gdpr: string;
    userRights: string[];
    contact: string;
  };
  technical: {
    management: string[];
    browsers: { [key: string]: string };
  };
  trading: {
    platform: string[];
    security: string[];
    features: string[];
  };
  finance: {
    services: string[];
    regulations: string[];
    protection: string[];
  };
  general: {
    company: string;
    mission: string;
    values: string[];
  };
}

export default function CookieAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Base de connaissances étendue et intelligente
  const knowledgeBase: KnowledgeBase = {
    cookies: {
      types: {
        'strictement nécessaires': 'Cookies obligatoires pour la sécurité, l\'authentification et le fonctionnement de base de la plateforme. Ils ne peuvent pas être désactivés.',
        'fonctionnels': 'Cookies recommandés qui mémorisent vos préférences (langue, paramètres trading, thème). Améliorent votre expérience utilisateur.',
        'analytiques': 'Cookies optionnels (Google Analytics, Hotjar) qui nous aident à comprendre comment vous utilisez notre plateforme pour l\'améliorer.',
        'marketing': 'Cookies optionnels pour la publicité ciblée et le retargeting (LinkedIn Insight, Facebook Pixel). Vous pouvez les refuser.'
      },
      security: [
        'Aucun mot de passe ou code d\'accès stocké',
        'Aucun numéro de compte bancaire enregistré',
        'Aucune donnée de carte de crédit conservée',
        'Seuls des identifiants de session sécurisés sont utilisés',
        'Chiffrement SSL/TLS pour toutes les transmissions'
      ],
      durations: {
        'session': 'Supprimés automatiquement à la fermeture du navigateur',
        'fonctionnels': 'Conservés jusqu\'à 12 mois maximum',
        'analytiques': 'Conservés jusqu\'à 24 mois maximum',
        'marketing': 'Conservés de 6 à 12 mois selon le service'
      },
      thirdParty: {
        'Google Analytics': 'Analyse du trafic et comportement utilisateur (24 mois)',
        'Hotjar': 'Cartes de chaleur et enregistrements de session (12 mois)',
        'LinkedIn Insight': 'Publicité B2B ciblée (6 mois)',
        'Facebook Pixel': 'Retargeting publicitaire (12 mois)'
      }
    },
    legal: {
      gdpr: 'CMV Finance respecte intégralement le RGPD. Vous disposez d\'un contrôle total sur vos données personnelles.',
      userRights: [
        'Droit d\'accès à vos données',
        'Droit de rectification',
        'Droit à l\'effacement',
        'Droit à la portabilité',
        'Droit d\'opposition au traitement',
        'Droit de limitation du traitement'
      ],
      contact: 'privacy@cmvfinance.com pour toute question sur vos données'
    },
    technical: {
      management: [
        'Centre de préférences intégré sur notre site',
        'Paramètres de navigateur (Chrome, Firefox, Safari, Edge)',
        'Désactivation par catégorie (sauf cookies essentiels)',
        'Suppression manuelle via l\'historique du navigateur'
      ],
      browsers: {
        'Chrome': 'Paramètres > Confidentialité et sécurité > Cookies',
        'Firefox': 'Paramètres > Vie privée et sécurité > Cookies',
        'Safari': 'Préférences > Confidentialité > Cookies',
        'Edge': 'Paramètres > Cookies et autorisations de site'
      }
    },
    trading: {
      platform: [
        'Plateforme de trading professionnelle',
        'Analyses techniques avancées',
        'Outils de gestion des risques',
        'Formation interactive',
        'Indicateurs personnalisés'
      ],
      security: [
        'Authentification à deux facteurs',
        'Chiffrement de bout en bout',
        'Surveillance des transactions',
        'Isolation des données sensibles',
        'Audits de sécurité réguliers'
      ],
      features: [
        'Trading en temps réel',
        'Analyses de marché',
        'Portefeuille diversifié',
        'Alertes personnalisées',
        'Rapports détaillés'
      ]
    },
    finance: {
      services: [
        'Conseil en investissement',
        'Gestion de patrimoine',
        'Analyse fiscale',
        'Simulation de retraite',
        'Optimisation d\'allocation'
      ],
      regulations: [
        'Agrément AMF (Autorité des Marchés Financiers)',
        'Conformité MiFID II',
        'Respect des directives européennes',
        'Contrôles ACPR réguliers'
      ],
      protection: [
        'Fonds de garantie des dépôts',
        'Ségrégation des comptes clients',
        'Assurance responsabilité civile professionnelle',
        'Audit externe annuel'
      ]
    },
    general: {
      company: 'CMV Finance est une plateforme française de trading et services financiers fondée sur l\'innovation et la transparence.',
      mission: 'Démocratiser l\'accès aux marchés financiers avec des outils professionnels et une formation de qualité.',
      values: [
        'Transparence totale',
        'Sécurité maximale',
        'Innovation continue',
        'Formation accessible',
        'Service client premium'
      ]
    }
  };

  // Intelligence artificielle avancée pour interpréter et répondre
  const aiRespond = (userInput: string): string => {
    const input = userInput.toLowerCase();
    
    // Détection des intentions et contexte
    const intentions = {
      greeting: ['bonjour', 'bonsoir', 'salut', 'hello', 'hey'],
      cookies: ['cookie', 'traceur', 'données', 'vie privée', 'confidentialité'],
      security: ['sécurit', 'protec', 'danger', 'risque', 'safe', 'sûr'],
      management: ['gérer', 'désactiv', 'supprimer', 'paramètr', 'contrôl'],
      trading: ['trading', 'investis', 'bourse', 'marché', 'action'],
      technical: ['comment', 'navigateur', 'chrome', 'firefox', 'safari'],
      legal: ['droit', 'rgpd', 'gdpr', 'légal', 'juridique'],
      duration: ['durée', 'combien', 'temps', 'conservation'],
      thirdparty: ['tiers', 'google', 'facebook', 'linkedin', 'hotjar'],
      help: ['aide', 'help', 'assistant', 'problème', 'question']
    };

    // Analyse contextuelle intelligente
    let detectedIntentions: string[] = [];
    Object.entries(intentions).forEach(([intent, keywords]) => {
      if (keywords.some(keyword => input.includes(keyword))) {
        detectedIntentions.push(intent);
      }
    });

    // Réponses adaptatives basées sur l'intelligence contextuelle
    if (detectedIntentions.includes('greeting')) {
      return `Bonjour ! Je suis l'assistant virtuel de CMV Finance. Je suis là pour répondre à toutes vos questions sur notre politique des cookies, la sécurité de vos données, et bien plus encore. Comment puis-je vous aider aujourd'hui ?`;
    }

    if (detectedIntentions.includes('cookies') && detectedIntentions.includes('security')) {
      return `🔒 **Sécurité des cookies chez CMV Finance :**\n\nRassurez-vous, nos cookies ne stockent JAMAIS :\n${knowledgeBase.cookies.security.map(item => `• ${item}`).join('\n')}\n\nNous utilisons uniquement des identifiants de session chiffrés et respectons les plus hauts standards de sécurité bancaire. Vos données financières sensibles sont protégées par des systèmes séparés et hautement sécurisés.`;
    }

    if (detectedIntentions.includes('cookies') && detectedIntentions.includes('management')) {
      return `⚙️ **Gestion de vos cookies :**\n\nVous avez un contrôle total :\n${knowledgeBase.technical.management.map(item => `• ${item}`).join('\n')}\n\n**Dans votre navigateur :**\n${Object.entries(knowledgeBase.technical.browsers).map(([browser, path]) => `• **${browser}** : ${path}`).join('\n')}\n\nBesoin d'aide ? Contactez-nous : ${knowledgeBase.legal.contact}`;
    }

    if (detectedIntentions.includes('cookies') && detectedIntentions.includes('duration')) {
      return `⏱️ **Durées de conservation :**\n\n${Object.entries(knowledgeBase.cookies.durations).map(([type, duration]) => `• **${type.charAt(0).toUpperCase() + type.slice(1)}** : ${duration}`).join('\n')}\n\nCes durées respectent strictement les recommandations CNIL et RGPD pour votre protection.`;
    }

    if (detectedIntentions.includes('thirdparty')) {
      return `🤝 **Services tiers partenaires :**\n\n${Object.entries(knowledgeBase.cookies.thirdParty).map(([service, description]) => `• **${service}** : ${description}`).join('\n')}\n\nTous nos partenaires sont certifiés RGPD et respectent nos standards de sécurité élevés.`;
    }

    if (detectedIntentions.includes('trading')) {
      return `📈 **Plateforme de trading CMV Finance :**\n\n**Nos services :**\n${knowledgeBase.trading.platform.map(item => `• ${item}`).join('\n')}\n\n**Sécurité trading :**\n${knowledgeBase.trading.security.map(item => `• ${item}`).join('\n')}\n\nNos cookies optimisent votre expérience de trading sans compromettre la sécurité de vos investissements.`;
    }

    if (detectedIntentions.includes('legal')) {
      return `⚖️ **Vos droits légaux :**\n\n${knowledgeBase.legal.gdpr}\n\n**Vos droits RGPD :**\n${knowledgeBase.legal.userRights.map(right => `• ${right}`).join('\n')}\n\nPour exercer vos droits : ${knowledgeBase.legal.contact}`;
    }

    // Réponse générale intelligente sur les cookies
    if (detectedIntentions.includes('cookies')) {
      return `🍪 **Types de cookies utilisés :**\n\n${Object.entries(knowledgeBase.cookies.types).map(([type, description]) => `• **${type.charAt(0).toUpperCase() + type.slice(1)}** : ${description}`).join('\n')}\n\nVous gardez le contrôle total sur vos préférences !`;
    }

    // Intelligence adaptative - extraction de mots-clés pour réponses personnalisées
    const keywords = input.split(' ').filter(word => word.length > 3);
    let contextualResponse = '';

    if (keywords.some(word => ['pourquoi', 'raison', 'but'].includes(word))) {
      contextualResponse = `Chez CMV Finance, nous utilisons les cookies pour améliorer votre expérience de trading et respecter les réglementations financières. Chaque cookie a un objectif précis et vous restez maître de vos choix.`;
    } else if (keywords.some(word => ['supprimer', 'effacer', 'nettoyer'].includes(word))) {
      contextualResponse = `Pour supprimer vos cookies : accédez aux paramètres de votre navigateur > Confidentialité > Cookies, puis sélectionnez CMV Finance. Ou utilisez notre centre de préférences intégré sur le site.`;
    } else if (keywords.some(word => ['obligatoire', 'forcé', 'imposé'].includes(word))) {
      contextualResponse = `Seuls les cookies strictement nécessaires sont obligatoires (sécurité, authentification). Tous les autres sont optionnels et vous pouvez les refuser sans affecter les fonctionnalités essentielles de trading.`;
    } else if (keywords.some(word => ['partage', 'vente', 'transmission'].includes(word))) {
      contextualResponse = `CMV Finance ne vend JAMAIS vos données. Nous ne les partageons qu'avec nos partenaires techniques certifiés (Google Analytics, etc.) et uniquement pour améliorer nos services. Vous gardez le contrôle total.`;
    }

    if (contextualResponse) return contextualResponse;

    // Réponse d'assistance générale adaptative
    return `Je suis là pour vous aider ! En tant qu'assistant CMV Finance, je peux répondre à toutes vos questions sur :\n\n• 🍪 Notre politique des cookies\n• 🔒 La sécurité de vos données\n• ⚙️ La gestion de vos préférences\n• 📈 Nos services de trading\n• ⚖️ Vos droits légaux\n• 🤝 Nos partenaires tiers\n\nPosez-moi votre question spécifique, je m'adapterai pour vous donner la meilleure réponse possible !`;
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      const welcomeMessage: Message = {
        id: '1',
        content: `Bonjour ! Je suis l'assistant virtuel de CMV Finance. 🤖\n\nJe peux vous aider avec toutes vos questions sur les cookies, la sécurité, et bien plus encore. Je m'adapte à vos besoins spécifiques !\n\n**Questions populaires :**\n• Mes données sont-elles sécurisées ?\n• Comment gérer mes cookies ?\n• Quels sont mes droits ?\n• Pourquoi utilisez-vous des cookies ?`,
        isUser: false,
        timestamp: new Date()
      };
      setMessages([welcomeMessage]);
    }
  }, [isOpen]);

  const handleSend = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      isUser: true,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulation d'intelligence artificielle avec délai réaliste
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: aiRespond(inputValue),
        isUser: false,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1500 + Math.random() * 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const quickQuestions = [
    "Mes données sont-elles sécurisées ?",
    "Comment désactiver les cookies ?",
    "Quels cookies utilisez-vous ?",
    "Puis-je trader sans cookies ?",
    "Mes droits sur mes données ?"
  ];

  return (
    <>
      {/* Bouton flottant */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 w-16 h-16 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-full shadow-2xl hover:shadow-3xl transition-all z-50 flex items-center justify-center cursor-pointer group"
      >
        <div className="relative">
          <i className="ri-customer-service-2-line text-2xl group-hover:scale-110 transition-transform"></i>
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
        </div>
      </button>

      {/* Interface de chat */}
      {isOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end justify-end p-6">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md h-[600px] flex flex-col">
            {/* En-tête */}
            <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-4 rounded-t-2xl flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                  <i className="ri-robot-line text-lg"></i>
                </div>
                <div>
                  <h3 className="font-semibold">Assistant CMV Finance</h3>
                  <div className="text-xs opacity-90 flex items-center">
                    <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></div>
                    En ligne - IA adaptative
                  </div>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-white/20 transition-colors"
              >
                <i className="ri-close-line text-lg"></i>
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] p-3 rounded-2xl whitespace-pre-line ${
                      message.isUser
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-800'
                    }`}
                  >
                    {message.content}
                    <div className={`text-xs mt-2 opacity-70 ${
                      message.isUser ? 'text-blue-100' : 'text-gray-500'
                    }`}>
                      {message.timestamp.toLocaleTimeString('fr-FR', { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })}
                    </div>
                  </div>
                </div>
              ))}

              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-gray-100 text-gray-800 p-3 rounded-2xl">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Questions rapides */}
            {messages.length <= 1 && (
              <div className="px-4 pb-2">
                <div className="text-xs text-gray-500 mb-2">Questions populaires :</div>
                <div className="flex flex-wrap gap-2">
                  {quickQuestions.slice(0, 3).map((question, index) => (
                    <button
                      key={index}
                      onClick={() => setInputValue(question)}
                      className="text-xs bg-blue-50 text-blue-600 px-3 py-1 rounded-full hover:bg-blue-100 transition-colors cursor-pointer"
                    >
                      {question}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Zone de saisie */}
            <div className="p-4 border-t border-gray-100">
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Posez votre question..."
                  className="flex-1 border border-gray-200 rounded-full px-4 py-2 focus:outline-none focus:border-blue-500 text-sm"
                />
                <button
                  onClick={handleSend}
                  disabled={!inputValue.trim()}
                  className="w-10 h-10 bg-blue-600 text-white rounded-full flex items-center justify-center hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <i className="ri-send-plane-line text-sm"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
