
'use client';

import { useEffect, useState } from 'react';

interface ShinyTextProps {
  text: string;
  disabled?: boolean;
  speed?: number;
  className?: string;
}

const ShinyText = ({ text, disabled = false, speed = 5, className = '' }: ShinyTextProps) => {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return (
      <span className={className}>
        {text}
      </span>
    );
  }

  const animationDuration = `${speed}s`;

  return (
    <span
      className={`inline-block ${disabled ? '' : 'animate-shine'} ${className}`}
      style={{
        background: disabled ? 'inherit' : 'linear-gradient(90deg, currentColor 30%, rgba(255, 255, 255, 0.9) 50%, currentColor 70%)',
        backgroundSize: '200% 100%',
        WebkitBackgroundClip: disabled ? 'initial' : 'text',
        backgroundClip: disabled ? 'initial' : 'text',
        color: disabled ? 'inherit' : 'transparent',
        animation: disabled ? 'none' : `shine ${animationDuration} ease-in-out infinite`,
      }}
    >
      {text}
      <style jsx>{`
        @keyframes shine {
          0% { background-position: -200% 0; }
          100% { background-position: 200% 0; }
        }
      `}</style>
    </span>
  );
};

export default ShinyText;
