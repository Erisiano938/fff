
'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';

export default function Features() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const features = [
    {
      icon: 'ri-dashboard-line',
      title: 'Gestion de Portefeuille',
      description: 'Optimisez vos investissements avec nos outils d\'analyse avancés',
      link: '/dashboard',
      image: 'https://readdy.ai/api/search-image?query=Modern%20financial%20dashboard%20with%20portfolio%20analytics%2C%20investment%20tracking%20charts%2C%20dark%20elegant%20interface%20with%20golden%20accents%2C%20professional%20financial%20management%20tools%2C%20clean%20minimalist%20design&width=400&height=300&seq=portfolio-dashboard&orientation=landscape'
    },
    {
      icon: 'ri-graduation-cap-line',
      title: 'Académie de Trading',
      description: 'Apprenez les stratégies des meilleurs traders professionnels',
      link: '/academy',
      image: 'https://readdy.ai/api/search-image?query=Educational%20finance%20academy%20with%20books%2C%20charts%2C%20learning%20materials%2C%20professional%20trading%20education%20setup%2C%20dark%20elegant%20background%20with%20golden%20lighting%2C%20modern%20learning%20environment&width=400&height=300&seq=trading-academy&orientation=landscape'
    },
    {
      icon: 'ri-store-line',
      title: 'Marketplace d\'Indicateurs',
      description: 'Accédez aux meilleurs indicateurs techniques du marché',
      link: '/indicators',
      image: 'https://readdy.ai/api/search-image?query=Digital%20marketplace%20interface%20with%20trading%20indicators%2C%20technical%20analysis%20tools%2C%20charts%20and%20graphs%2C%20dark%20professional%20theme%20with%20golden%20highlights%2C%20modern%20financial%20technology&width=400&height=300&seq=indicators-marketplace&orientation=landscape'
    },
    {
      icon: 'ri-gamepad-line',
      title: 'Formation Interactive',
      description: 'Maîtrisez le trading avec nos simulations gamifiées',
      link: '/formation-interactive',
      image: 'https://readdy.ai/api/search-image?query=Interactive%20gamified%20learning%20interface%20with%20financial%20education%20games%2C%20trading%20simulators%2C%20quiz%20challenges%2C%20cryptocurrency%20and%20real%20estate%20modules%2C%20dark%20modern%20design%20with%20golden%20highlights%2C%20engaging%20educational%20gaming%20environment&width=400&height=300&seq=gamified-learning&orientation=landscape'
    }
  ];

  if (!mounted) {
    return (
      <section className="py-20 bg-gray-900">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <div className="h-12 bg-gray-800 rounded animate-pulse mb-4"></div>
            <div className="h-6 bg-gray-800 rounded max-w-2xl mx-auto"></div>
          </div>
          <div className="grid md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-8">
            {[1, 2, 3, 4].map((_, index) => (
              <div key={index} className="bg-black/50 rounded-2xl h-96 animate-pulse"></div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 bg-gray-900" suppressHydrationWarning={true}>
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4" suppressHydrationWarning={true}>
            Nos <span className="text-yellow-400">Fonctionnalités</span>
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto" suppressHydrationWarning={true}>
            Découvrez notre plateforme complète pour optimiser vos investissements
          </p>
        </div>

        <div className="grid md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <Link 
              key={index} 
              href={feature.link}
              className="bg-black/50 rounded-2xl border border-yellow-500/20 hover:border-yellow-500/40 transition-all group cursor-pointer overflow-hidden"
            >
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={feature.image}
                  alt={feature.title}
                  className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
                <div className="absolute bottom-4 left-4">
                  <div className="w-12 h-12 bg-yellow-500/20 rounded-xl flex items-center justify-center group-hover:bg-yellow-500/30 transition-colors">
                    <i className={`${feature.icon} text-2xl text-yellow-400`}></i>
                  </div>
                </div>
              </div>
              
              <div className="p-8">
                <h3 className="text-xl font-bold text-white mb-4 group-hover:text-yellow-400 transition-colors" suppressHydrationWarning={true}>
                  {feature.title}
                </h3>
                <p className="text-gray-400 leading-relaxed group-hover:text-gray-300 transition-colors mb-6" suppressHydrationWarning={true}>
                  {feature.description}
                </p>
                <div className="flex items-center text-yellow-400 font-semibold group-hover:text-yellow-300 transition-colors" suppressHydrationWarning={true}>
                  Découvrir
                  <i className="ri-arrow-right-line ml-2 group-hover:translate-x-1 transition-transform"></i>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
