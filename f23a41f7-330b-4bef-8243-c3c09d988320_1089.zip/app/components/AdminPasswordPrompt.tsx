'use client';

import { useState } from 'react';

interface AdminPasswordPromptProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  adminEmail: string;
}

export default function AdminPasswordPrompt({ 
  isOpen, 
  onClose, 
  onSuccess, 
  adminEmail 
}: AdminPasswordPromptProps) {
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      // Simulation d'authentification - en production, ceci devrait être sécurisé
      if (password === 'admin123' || password === 'cmv2024') {
        onSuccess();
        setPassword('');
      } else {
        setError('Mot de passe administrateur incorrect');
      }
    } catch (err) {
      setError('Erreur lors de l\'authentification');
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setPassword('');
    setError('');
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-gray-900 rounded-lg p-6 w-full max-w-md mx-4 border border-gray-800">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center">
              <i className="ri-shield-keyhole-line text-white text-lg"></i>
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">Authentification Administrateur</h3>
              <p className="text-sm text-gray-400">Accès sécurisé requis</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="text-gray-400 hover:text-white cursor-pointer"
          >
            <i className="ri-close-line text-xl"></i>
          </button>
        </div>

        <div className="mb-6 p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
          <div className="flex items-center space-x-2 text-yellow-400">
            <i className="ri-warning-line"></i>
            <span className="text-sm font-medium">Zone d'administration sécurisée</span>
          </div>
          <p className="text-xs text-yellow-300 mt-1">
            Cette action nécessite une authentification administrateur
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2 text-gray-300">
              Email administrateur
            </label>
            <input
              type="email"
              value={adminEmail}
              disabled
              className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-gray-400 cursor-not-allowed"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2 text-gray-300">
              Mot de passe administrateur *
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-red-500 focus:outline-none"
              placeholder="Entrez votre mot de passe"
              required
              autoFocus
            />
          </div>

          {error && (
            <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
              <div className="flex items-center space-x-2 text-red-400">
                <i className="ri-error-warning-line"></i>
                <span className="text-sm">{error}</span>
              </div>
            </div>
          )}

          <div className="flex space-x-3 mt-6">
            <button
              type="button"
              onClick={handleClose}
              className="flex-1 px-4 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-lg font-medium transition-colors cursor-pointer"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={loading || !password}
              className="flex-1 px-4 py-3 bg-red-600 hover:bg-red-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors cursor-pointer flex items-center justify-center"
            >
              {loading ? (
                <>
                  <i className="ri-loader-4-line animate-spin mr-2"></i>
                  Vérification...
                </>
              ) : (
                <>
                  <i className="ri-shield-check-line mr-2"></i>
                  Authentifier
                </>
              )}
            </button>
          </div>
        </form>

        <div className="mt-4 p-3 bg-gray-800 rounded-lg">
          <div className="text-xs text-gray-400">
            <div className="flex items-center space-x-2 mb-1">
              <i className="ri-information-line"></i>
              <span className="font-medium">Mots de passe de test :</span>
            </div>
            <div className="ml-4 space-y-1">
              <div>• admin123 (développement)</div>
              <div>• cmv2024 (production)</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}