
'use client';

import { useState } from 'react';

interface MarkdownRendererProps {
  content: string;
  className?: string;
}

export default function MarkdownRenderer({ content, className = '' }: MarkdownRendererProps) {
  const [imageErrors, setImageErrors] = useState<Set<string>>(new Set());

  const handleImageError = (src: string) => {
    setImageErrors(prev => new Set([...prev, src]));
  };

  const parseMarkdown = (text: string) => {
    // Découper le contenu en blocs
    const blocks = text.split(/\n\s*\n/);
    
    return blocks.map((block, index) => {
      const trimmedBlock = block.trim();
      if (!trimmedBlock) return null;

      // Images ![alt](src)
      if (trimmedBlock.match(/^!\[.*?\]\(.*?\)$/)) {
        const match = trimmedBlock.match(/^!\[(.*?)\]\((.*?)\)$/);
        if (match) {
          const [, alt, src] = match;
          const fullSrc = src.startsWith('/') ? src : `/assets/posts/${src}`;
          
          if (imageErrors.has(fullSrc)) {
            return (
              <div key={index} className="my-8 text-center">
                <div className="bg-gray-800 border-2 border-dashed border-gray-600 rounded-xl p-8">
                  <i className="ri-image-line text-4xl text-gray-500 mb-4"></i>
                  <p className="text-gray-400">Image non disponible</p>
                  <p className="text-gray-500 text-sm mt-2">{alt || 'Image'}</p>
                </div>
              </div>
            );
          }

          return (
            <figure key={index} className="my-8">
              <div className="relative rounded-xl overflow-hidden shadow-2xl">
                <img
                  src={fullSrc}
                  alt={alt}
                  className="w-full h-auto object-cover"
                  onError={() => handleImageError(fullSrc)}
                  loading="lazy"
                />
              </div>
              {alt && (
                <figcaption className="text-center text-gray-400 text-sm mt-4 italic">
                  {alt}
                </figcaption>
              )}
            </figure>
          );
        }
      }

      // Titres
      if (trimmedBlock.startsWith('###')) {
        const title = trimmedBlock.replace(/^###\s*/, '');
        return (
          <h3 key={index} className="text-2xl font-bold text-yellow-400 mt-12 mb-6 first:mt-0">
            {title}
          </h3>
        );
      }

      if (trimmedBlock.startsWith('##')) {
        const title = trimmedBlock.replace(/^##\s*/, '');
        return (
          <h2 key={index} className="text-3xl font-bold text-yellow-400 mt-12 mb-6 first:mt-0">
            {title}
          </h2>
        );
      }

      if (trimmedBlock.startsWith('#')) {
        const title = trimmedBlock.replace(/^#\s*/, '');
        return (
          <h1 key={index} className="text-4xl font-bold text-yellow-400 mt-12 mb-6 first:mt-0">
            {title}
          </h1>
        );
      }

      // Listes
      if (trimmedBlock.match(/^[-*+]\s/m)) {
        const items = trimmedBlock.split('\n').filter(line => line.match(/^[-*+]\s/));
        return (
          <ul key={index} className="list-none space-y-3 my-6">
            {items.map((item, itemIndex) => (
              <li key={itemIndex} className="flex items-start text-gray-300">
                <span className="text-yellow-400 mr-3 mt-1 text-sm">▶</span>
                <span>{item.replace(/^[-*+]\s/, '')}</span>
              </li>
            ))}
          </ul>
        );
      }

      // Listes numérotées
      if (trimmedBlock.match(/^\d+\.\s/m)) {
        const items = trimmedBlock.split('\n').filter(line => line.match(/^\d+\.\s/));
        return (
          <ol key={index} className="list-none space-y-3 my-6">
            {items.map((item, itemIndex) => (
              <li key={itemIndex} className="flex items-start text-gray-300">
                <span className="bg-yellow-400 text-black rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-1 flex-shrink-0">
                  {itemIndex + 1}
                </span>
                <span>{item.replace(/^\d+\.\s/, '')}</span>
              </li>
            ))}
          </ol>
        );
      }

      // Citations (commencent par >)
      if (trimmedBlock.startsWith('>')) {
        const quote = trimmedBlock.replace(/^>\s*/, '').replace(/\n>/g, '\n');
        return (
          <blockquote key={index} className="border-l-4 border-yellow-400 pl-6 py-4 my-6 bg-gray-900/50 rounded-r-lg">
            <p className="text-gray-300 italic text-lg leading-relaxed">"{quote}"</p>
          </blockquote>
        );
      }

      // Code blocks (```code```)
      if (trimmedBlock.startsWith('```') && trimmedBlock.endsWith('```')) {
        const code = trimmedBlock.slice(3, -3).trim();
        return (
          <pre key={index} className="bg-gray-900 rounded-xl p-6 overflow-x-auto my-6 border border-gray-700">
            <code className="text-green-400 text-sm font-mono">{code}</code>
          </pre>
        );
      }

      // Texte en gras **text**
      const boldText = trimmedBlock.replace(/\*\*(.*?)\*\*/g, '<strong class="text-yellow-400 font-semibold">$1</strong>');
      
      // Texte en italique *text*
      const italicText = boldText.replace(/\*(.*?)\*/g, '<em class="italic text-gray-300">$1</em>');
      
      // Liens [text](url)
      const linkedText = italicText.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" class="text-yellow-400 hover:text-yellow-300 underline transition-colors" target="_blank" rel="noopener noreferrer">$1</a>');

      // Paragraphe normal
      return (
        <p 
          key={index} 
          className="text-gray-300 leading-relaxed mb-6 text-lg"
          dangerouslySetInnerHTML={{ __html: linkedText }}
        />
      );
    }).filter(Boolean);
  };

  return (
    <div className={`prose prose-lg prose-invert max-w-none ${className}`}>
      {parseMarkdown(content)}
    </div>
  );
}
