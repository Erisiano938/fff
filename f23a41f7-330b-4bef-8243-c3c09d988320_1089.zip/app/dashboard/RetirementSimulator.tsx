
'use client';

import { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, BarChart, Bar } from 'recharts';

export default function RetirementSimulator() {
  const [currentAge, setCurrentAge] = useState(30);
  const [retirementAge, setRetirementAge] = useState(65);
  const [currentSalary, setCurrentSalary] = useState(45000);
  const [monthlyContribution, setMonthlyContribution] = useState(300);
  const [currentSavings, setCurrentSavings] = useState(10000);
  const [expectedReturn, setExpectedReturn] = useState(6);
  const [showAssuranceVieModal, setShowAssuranceVieModal] = useState(false);
  const [showRegimeModal, setShowRegimeModal] = useState(false);

  // Nouveaux états pour les régimes de retraite
  const [regime, setRegime] = useState('prive');
  const [trimestresActuels, setTrimestresActuels] = useState(40);
  const [salaireAnnuelMoyen, setSalaireAnnuelMoyen] = useState(42000);
  const [regimeComplementaire, setRegimeComplementaire] = useState('arrco');
  const [pointsArrco, setPointsArrco] = useState(1250);
  const [pointsAgirc, setPointsAgirc] = useState(800);
  const [regimeEtranger, setRegimeEtranger] = useState(false);
  const [dureeEtrangere, setDureeEtrangere] = useState(0);
  const [pensionEtrangere, setPensionEtrangere] = useState(0);

  const yearsToRetirement = retirementAge - currentAge;
  const totalContributions = monthlyContribution * 12 * yearsToRetirement + currentSavings;
  const futureValue = currentSavings * Math.pow(1 + expectedReturn/100, yearsToRetirement) + 
                     monthlyContribution * 12 * ((Math.pow(1 + expectedReturn/100, yearsToRetirement) - 1) / (expectedReturn/100));
  const monthlyPension = (futureValue * 0.04) / 12;

  // Calculs des retraites par régime
  const trimestresManquants = Math.max(0, 172 - (trimestresActuels + (retirementAge - currentAge) * 4));
  const tauxPlein = trimestresManquants === 0 ? 50 : Math.max(37.5, 50 - (trimestresManquants * 0.625));

  const pensionRetraiteBase = (salaireAnnuelMoyen * tauxPlein) / 100 / 12;

  const pointsArrcoFinaux = pointsArrco + ((currentSalary * 0.06) / 1.3498) * yearsToRetirement;
  const pointsAgircFinaux = regime === 'cadre' ? pointsAgirc + ((Math.max(0, currentSalary - 43992) * 0.17) / 1.3498) * yearsToRetirement : pointsAgirc;

  const pensionArrco = (pointsArrcoFinaux * 1.3498) / 12;
  const pensionAgirc = regime === 'cadre' ? (pointsAgircFinaux * 1.3498) / 12 : 0;

  const pensionTotaleRegimes = pensionRetraiteBase + pensionArrco + pensionAgirc + (regimeEtranger ? pensionEtrangere : 0);
  const pensionTotale = pensionTotaleRegimes + monthlyPension;

  const replacementRatio = (pensionTotale * 12) / currentSalary * 100;

  const generateProjectionData = () => {
    const data = [];
    let accumulated = currentSavings;

    for (let year = 0; year <= yearsToRetirement; year++) {
      if (year > 0) {
        accumulated = accumulated * (1 + expectedReturn/100) + monthlyContribution * 12;
      }
      data.push({
        age: currentAge + year,
        accumulated: Math.round(accumulated),
        contributions: currentSavings + (monthlyContribution * 12 * year),
        regimeBase: Math.round(pensionRetraiteBase * 12 * (year / yearsToRetirement)),
        regimeComplementaire: Math.round((pensionArrco + pensionAgirc) * 12 * (year / yearsToRetirement))
      });
    }
    return data;
  };

  const projectionData = generateProjectionData();

  const pieDataRegimes = [
    { name: 'Retraite de Base', value: pensionRetraiteBase * 12, color: '#3B82F6' },
    { name: 'Retraite Complémentaire', value: (pensionArrco + pensionAgirc) * 12, color: '#10B981' },
    { name: 'Épargne Privée', value: monthlyPension * 12, color: '#F59E0B' },
    ...(regimeEtranger ? [{ name: 'Régime Étranger', value: pensionEtrangere * 12, color: '#8B5CF6' }] : [])
  ];

  const optimisationData = [
    { age: 62, pension: pensionTotaleRegimes * 0.85, decote: '-15%' },
    { age: 64, pension: pensionTotaleRegimes * 0.95, decote: '-5%' },
    { age: 65, pension: pensionTotaleRegimes, decote: '0%' },
    { age: 67, pension: pensionTotaleRegimes * 1.10, decote: '+10%' },
    { age: 70, pension: pensionTotaleRegimes * 1.25, decote: '+25%' }
  ];

  const calculRachatTrimestres = () => {
    const coutTrimestre = Math.min(currentSalary * 0.15, 4500);
    const gainAnnuel = (salaireAnnuelMoyen * 0.625) / 100;
    const rentabilite = (gainAnnuel * 20) / coutTrimestre;
    return { cout: coutTrimestre, gain: gainAnnuel, rentabilite };
  };

  const rachatInfo = calculRachatTrimestres();

  const handleProductClick = (productName) => {
    if (productName === 'Assurance Vie') {
      setShowAssuranceVieModal(true);
    }
  };

  return (
    <div className="space-y-8">
      <div className="bg-gradient-to-r from-blue-500/20 to-purple-600/20 p-6 rounded-xl border border-blue-500/30">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl font-bold text-white">Simulateur Retraite Complet</h2>
            <p className="text-gray-300">Projection détaillée tous régimes confondus</p>
          </div>
          <button 
            onClick={() => setShowRegimeModal(true)}
            className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-400 transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-settings-3-line mr-2"></i>
            Configurer Régimes
          </button>
        </div>

        <div className="grid md:grid-cols-4 gap-4">
          <div className="bg-blue-500/20 p-4 rounded-xl border border-blue-500/30">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-blue-400 font-semibold">Retraite de Base</h3>
              <i className="ri-government-line text-2xl text-blue-400"></i>
            </div>
            <p className="text-2xl font-bold text-white">{pensionRetraiteBase.toLocaleString('fr-FR', { maximumFractionDigits: 0 })} €</p>
            <p className="text-xs text-gray-400">Taux: {tauxPlein.toFixed(1)}%</p>
          </div>

          <div className="bg-green-500/20 p-4 rounded-xl border border-green-500/30">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-green-400 font-semibold">Complémentaire</h3>
              <i className="ri-team-line text-2xl text-green-400"></i>
            </div>
            <p className="text-2xl font-bold text-white">{(pensionArrco + pensionAgirc).toLocaleString('fr-FR', { maximumFractionDigits: 0 })} €</p>
            <p className="text-xs text-gray-400">{Math.round(pointsArrcoFinaux + pointsAgircFinaux)} points</p>
          </div>

          <div className="bg-yellow-500/20 p-4 rounded-xl border border-yellow-500/30">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-yellow-400 font-semibold">Épargne Privée</h3>
              <i className="ri-safe-line text-2xl text-yellow-400"></i>
            </div>
            <p className="text-2xl font-bold text-white">{monthlyPension.toLocaleString('fr-FR', { maximumFractionDigits: 0 })} €</p>
            <p className="text-xs text-gray-400">Capital: {(futureValue/1000).toFixed(0)}K €</p>
          </div>

          <div className="bg-purple-500/20 p-4 rounded-xl border border-purple-500/30">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-purple-400 font-semibold">Total Mensuel</h3>
              <i className="ri-calculator-line text-2xl text-purple-400"></i>
            </div>
            <p className="text-3xl font-bold text-white">{pensionTotale.toLocaleString('fr-FR', { maximumFractionDigits: 0 })} €</p>
            <p className="text-xs text-gray-400">Taux remplacement: {replacementRatio.toFixed(0)}%</p>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="space-y-6">
          <div className="bg-gray-900/50 p-6 rounded-xl border border-blue-500/20">
            <h3 className="text-xl font-bold text-white mb-6">Paramètres Généraux</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-gray-400 text-sm mb-2">Âge Actuel</label>
                <input
                  type="range"
                  min="20"
                  max="60"
                  value={currentAge}
                  onChange={(e) => setCurrentAge(Number(e.target.value))}
                  className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-sm text-gray-400 mt-1">
                  <span>20 ans</span>
                  <span className="text-blue-400 font-semibold">{currentAge} ans</span>
                  <span>60 ans</span>
                </div>
              </div>

              <div>
                <label className="block text-gray-400 text-sm mb-2">Âge de Retraite</label>
                <input
                  type="range"
                  min="60"
                  max="70"
                  value={retirementAge}
                  onChange={(e) => setRetirementAge(Number(e.target.value))}
                  className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-sm text-gray-400 mt-1">
                  <span>60 ans</span>
                  <span className="text-blue-400 font-semibold">{retirementAge} ans</span>
                  <span>70 ans</span>
                </div>
              </div>

              <div>
                <label className="block text-gray-400 text-sm mb-2">Salaire Annuel (€)</label>
                <input
                  type="range"
                  min="20000"
                  max="100000"
                  step="1000"
                  value={currentSalary}
                  onChange={(e) => setCurrentSalary(Number(e.target.value))}
                  className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-sm text-gray-400 mt-1">
                  <span>20K €</span>
                  <span className="text-blue-400 font-semibold">{currentSalary.toLocaleString()} €</span>
                  <span>100K €</span>
                </div>
              </div>

              <div>
                <label className="block text-gray-400 text-sm mb-2">Épargne Mensuelle (€)</label>
                <input
                  type="range"
                  min="50"
                  max="1000"
                  step="10"
                  value={monthlyContribution}
                  onChange={(e) => setMonthlyContribution(Number(e.target.value))}
                  className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-sm text-gray-400 mt-1">
                  <span>50 €</span>
                  <span className="text-blue-400 font-semibold">{monthlyContribution} €</span>
                  <span>1000 €</span>
                </div>
              </div>

              <div>
                <label className="block text-gray-400 text-sm mb-2">Épargne Actuelle (€)</label>
                <input
                  type="range"
                  min="0"
                  max="100000"
                  step="1000"
                  value={currentSavings}
                  onChange={(e) => setCurrentSavings(Number(e.target.value))}
                  className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-sm text-gray-400 mt-1">
                  <span>0 €</span>
                  <span className="text-blue-400 font-semibold">{currentSavings.toLocaleString()} €</span>
                  <span>100K €</span>
                </div>
              </div>
            </div>
          </div>

          {trimestresManquants > 0 && (
            <div className="bg-orange-500/20 p-6 rounded-xl border border-orange-500/30">
              <h3 className="text-xl font-bold text-white mb-4 flex items-center">
                <i className="ri-alert-line text-orange-400 mr-2"></i>
                Rachat de Trimestres
              </h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-400">Trimestres manquants:</span>
                  <span className="text-orange-400 font-semibold">{trimestresManquants}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Coût unitaire:</span>
                  <span className="text-white">{rachatInfo.cout.toLocaleString()} €</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Gain annuel:</span>
                  <span className="text-green-400 font-semibold">+{rachatInfo.gain.toLocaleString()} €</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Rentabilité:</span>
                  <span className={`font-semibold ${rachatInfo.rentabilite > 1.2 ? 'text-green-400' : rachatInfo.rentabilite > 1 ? 'text-yellow-400' : 'text-red-400'}`}>
                    {rachatInfo.rentabilite.toFixed(1)}x
                  </span>
                </div>
                <div className="bg-black/30 p-3 rounded">
                  <p className="text-sm text-gray-300">
                    <strong className="text-orange-400">Recommandation:</strong> 
                    {rachatInfo.rentabilite > 1.2 ? ' Rachat très rentable' : 
                     rachatInfo.rentabilite > 1 ? ' Rachat à étudier' : 
                     ' Rachat peu rentable'}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="lg:col-span-2 space-y-6">
          <div className="bg-gray-900/50 p-6 rounded-xl border border-blue-500/20">
            <h3 className="text-xl font-bold text-white mb-6">Répartition des Revenus Retraite</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieDataRegimes}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={120}
                    dataKey="value"
                  >
                    {pieDataRegimes.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value) => `${Number(value).toLocaleString()} €/an`}
                    contentStyle={{ 
                      backgroundColor: '#1F2937', 
                      border: '1px solid #3B82F6',
                      borderRadius: '8px'
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-4 mt-4">
              {pieDataRegimes.map((entry, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }}></div>
                  <div>
                    <span className="text-sm text-white font-medium">{entry.name}</span>
                    <div className="text-xs text-gray-400">{(entry.value/12).toLocaleString()} €/mois</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gray-900/50 p-6 rounded-xl border border-blue-500/20">
            <h3 className="text-xl font-bold text-white mb-6">Optimisation Âge de Départ</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={optimisationData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis 
                    dataKey="age" 
                    stroke="#9CA3AF"
                    tick={{ fontSize: 12 }}
                  />
                  <YAxis 
                    stroke="#9CA3AF"
                    tick={{ fontSize: 12 }}
                    tickFormatter={(value) => `${Math.round(value)} €`}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1F2937', 
                      border: '1px solid #3B82F6',
                      borderRadius: '8px'
                    }}
                    formatter={(value, name) => [
                      `${Number(value).toLocaleString()} €/mois`,
                      'Pension mensuelle'
                    ]}
                    labelFormatter={(age) => `Départ à ${age} ans`}
                  />
                  <Bar 
                    dataKey="pension" 
                    fill="#3B82F6"
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-5 gap-2 mt-4">
              {optimisationData.map((item, index) => (
                <div key={index} className="text-center bg-black/30 p-3 rounded-lg">
                  <div className="text-sm font-semibold text-white">{item.age} ans</div>
                  <div className={`text-xs font-semibold ${item.decote.includes('+') ? 'text-green-400' : item.decote.includes('-') ? 'text-red-400' : 'text-gray-400'}`}>
                    {item.decote}
                  </div>
                  <div className="text-xs text-gray-400">{Math.round(item.pension)} €</div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gray-900/50 p-6 rounded-xl border border-blue-500/20">
            <h3 className="text-xl font-bold text-white mb-6">Évolution Patrimoine Retraite</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={projectionData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis 
                    dataKey="age" 
                    stroke="#9CA3AF"
                    tick={{ fontSize: 12 }}
                  />
                  <YAxis 
                    stroke="#9CA3AF"
                    tick={{ fontSize: 12 }}
                    tickFormatter={(value) => `${(value/1000).toFixed(0)}K €`}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1F2937', 
                      border: '1px solid #3B82F6',
                      borderRadius: '8px'
                    }}
                    formatter={(value, name) => [
                      `${Number(value).toLocaleString()} €`,
                      name === 'accumulated' ? 'Épargne Privée' : 
                      name === 'regimeBase' ? 'Droits Base' :
                      name === 'regimeComplementaire' ? 'Droits Complémentaire' : 'Contributions'
                    ]}
                    labelFormatter={(age) => `À ${age} ans`}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="regimeBase" 
                    stroke="#3B82F6" 
                    strokeWidth={2}
                    dot={false}
                    name="regimeBase"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="regimeComplementaire" 
                    stroke="#10B981" 
                    strokeWidth={2}
                    dot={false}
                    name="regimeComplementaire"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="accumulated" 
                    stroke="#F59E0B" 
                    strokeWidth={3}
                    dot={false}
                    name="accumulated"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>

      {/* Modal Configuration Régimes */}
      {showRegimeModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 rounded-xl border border-blue-500/30 max-w-4xl w-full max-h-[95vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-700">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-bold text-white">Configuration des Régimes</h2>
                  <p className="text-gray-400">Paramétrez tous vos régimes de retraite</p>
                </div>
                <button 
                  onClick={() => setShowRegimeModal(false)}
                  className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-gray-700 transition-colors cursor-pointer"
                >
                  <i className="ri-close-line text-xl text-gray-400"></i>
                </button>
              </div>
            </div>

            <div className="p-6 space-y-8">
              <div>
                <h3 className="text-xl font-bold text-white mb-4">Régime de Base</h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <label className="block text-gray-400 text-sm mb-2">Statut Professionnel</label>
                      <select 
                        value={regime}
                        onChange={(e) => setRegime(e.target.value)}
                        className="w-full bg-gray-800 text-white p-3 rounded-lg border border-gray-600 focus:border-blue-500 pr-8"
                      >
                        <option value="prive">Salarié Privé (CNAV)</option>
                        <option value="cadre">Cadre Supérieur</option>
                        <option value="public">Fonction Publique</option>
                        <option value="independant">Travailleur Indépendant</option>
                        <option value="liberal">Profession Libérale</option>
                        <option value="agricole">Régime Agricole (MSA)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-gray-400 text-sm mb-2">Trimestres Acquis</label>
                      <input
                        type="range"
                        min="0"
                        max="172"
                        value={trimestresActuels}
                        onChange={(e) => setTrimestresActuels(Number(e.target.value))}
                        className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                      />
                      <div className="flex justify-between text-sm text-gray-400 mt-1">
                        <span>0</span>
                        <span className="text-blue-400 font-semibold">{trimestresActuels} trimestres</span>
                        <span>172 (carrière complète)</span>
                      </div>
                    </div>

                    <div>
                      <label className="block text-gray-400 text-sm mb-2">Salaire Annuel Moyen (€)</label>
                      <input
                        type="range"
                        min="15000"
                        max="100000"
                        step="1000"
                        value={salaireAnnuelMoyen}
                        onChange={(e) => setSalaireAnnuelMoyen(Number(e.target.value))}
                        className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                      />
                      <div className="flex justify-between text-sm text-gray-400 mt-1">
                        <span>15K €</span>
                        <span className="text-blue-400 font-semibold">{salaireAnnuelMoyen.toLocaleString()} €</span>
                        <span>100K €</span>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">Moyenne des 25 meilleures années</p>
                    </div>
                  </div>

                  <div className="bg-blue-500/10 p-4 rounded-xl border border-blue-500/20">
                    <h4 className="font-semibold text-white mb-3">Calcul Retraite de Base</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Salaire de référence:</span>
                        <span className="text-white">{salaireAnnuelMoyen.toLocaleString()} €</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Taux de liquidation:</span>
                        <span className={`font-semibold ${tauxPlein === 50 ? 'text-green-400' : 'text-orange-400'}`}>
                          {tauxPlein.toFixed(1)}%
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Trimestres manquants:</span>
                        <span className={`font-semibold ${trimestresManquants === 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {trimestresManquants}
                        </span>
                      </div>
                      <div className="border-t border-blue-500/20 pt-2 mt-3">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Pension mensuelle:</span>
                          <span className="text-blue-400 font-bold">{pensionRetraiteBase.toLocaleString()} €</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold text-white mb-4">Régimes Complémentaires</h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <label className="block text-gray-400 text-sm mb-2">Régime Complémentaire</label>
                      <select 
                        value={regimeComplementaire}
                        onChange={(e) => setRegimeComplementaire(e.target.value)}
                        className="w-full bg-gray-800 text-white p-3 rounded-lg border border-gray-600 focus:border-blue-500 pr-8"
                      >
                        <option value="arrco">ARRCO (Non-cadres)</option>
                        <option value="arrco-agirc">ARRCO + AGIRC (Cadres)</option>
                        <option value="ircantec">IRCANTEC (Public)</option>
                        <option value="rafp">RAFP (Fonction Publique)</option>
                        <option value="cipav">CIPAV (Libéraux)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-gray-400 text-sm mb-2">Points ARRCO Acquis</label>
                      <input
                        type="range"
                        min="0"
                        max="5000"
                        step="50"
                        value={pointsArrco}
                        onChange={(e) => setPointsArrco(Number(e.target.value))}
                        className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                      />
                      <div className="flex justify-between text-sm text-gray-400 mt-1">
                        <span>0</span>
                        <span className="text-green-400 font-semibold">{pointsArrco} points</span>
                        <span>5000</span>
                      </div>
                    </div>

                    {regime === 'cadre' && (
                      <div>
                        <label className="block text-gray-400 text-sm mb-2">Points AGIRC Acquis</label>
                        <input
                          type="range"
                          min="0"
                          max="3000"
                          step="25"
                          value={pointsAgirc}
                          onChange={(e) => setPointsAgirc(Number(e.target.value))}
                          className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                        />
                        <div className="flex justify-between text-sm text-gray-400 mt-1">
                          <span>0</span>
                          <span className="text-green-400 font-semibold">{pointsAgirc} points</span>
                          <span>3000</span>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="bg-green-500/10 p-4 rounded-xl border border-green-500/20">
                    <h4 className="font-semibold text-white mb-3">Calcul Complémentaire</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Points ARRCO finaux:</span>
                        <span className="text-white">{Math.round(pointsArrcoFinaux)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Valeur du point:</span>
                        <span className="text-white">1,3498 €</span>
                      </div>
                      {regime === 'cadre' && (
                        <div className="flex justify-between">
                          <span className="text-gray-400">Points AGIRC finaux:</span>
                          <span className="text-white">{Math.round(pointsAgircFinaux)}</span>
                        </div>
                      )}
                      <div className="border-t border-green-500/20 pt-2 mt-3">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Pension mensuelle:</span>
                          <span className="text-green-400 font-bold">{(pensionArrco + pensionAgirc).toLocaleString()} €</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold text-white mb-4">Régimes Étrangers</h3>
                <div className="flex items-center space-x-3 mb-4">
                  <input
                    type="checkbox"
                    checked={regimeEtranger}
                    onChange={(e) => setRegimeEtranger(e.target.checked)}
                    className="w-4 h-4"
                  />
                  <label className="text-gray-300">J'ai cotisé dans des régimes étrangers</label>
                </div>

                {regimeEtranger && (
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <label className="block text-gray-400 text-sm mb-2">Durée de Cotisation (années)</label>
                        <input
                          type="range"
                          min="1"
                          max="40"
                          value={dureeEtrangere}
                          onChange={(e) => setDureeEtrangere(Number(e.target.value))}
                          className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                        />
                        <div className="flex justify-between text-sm text-gray-400 mt-1">
                          <span>1 an</span>
                          <span className="text-purple-400 font-semibold">{dureeEtrangere} années</span>
                          <span>40 ans</span>
                        </div>
                      </div>

                      <div>
                        <label className="block text-gray-400 text-sm mb-2">Pension Estimée (€/mois)</label>
                        <input
                          type="range"
                          min="50"
                          max="2000"
                          step="25"
                          value={pensionEtrangere}
                          onChange={(e) => setPensionEtrangere(Number(e.target.value))}
                          className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                        />
                        <div className="flex justify-between text-sm text-gray-400 mt-1">
                          <span>50 €</span>
                          <span className="text-purple-400 font-semibold">{pensionEtrangere} €</span>
                          <span>2000 €</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-purple-500/10 p-4 rounded-xl border border-purple-500/20">
                      <h4 className="font-semibold text-white mb-3">Coordination Européenne</h4>
                      <div className="space-y-2 text-sm text-gray-300">
                        <p><strong className="text-purple-400">Totalisation:</strong> Vos périodes sont additionnées pour l'ouverture des droits</p>
                        <p><strong className="text-purple-400">Proratisation:</strong> Chaque pays verse sa quote-part</p>
                        <p><strong className="text-purple-400">Âge légal:</strong> Respect des conditions de chaque régime</p>
                      </div>
                      <div className="mt-3 pt-3 border-t border-purple-500/20">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Pension étrangère:</span>
                          <span className="text-purple-400 font-bold">{pensionEtrangere} €/mois</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex space-x-4 pt-4 border-t border-gray-700">
                <button 
                  onClick={() => setShowRegimeModal(false)}
                  className="flex-1 bg-blue-500 text-white py-3 px-6 rounded-lg font-semibold hover:bg-blue-400 transition-colors cursor-pointer whitespace-nowrap"
                >
                  Appliquer Configuration
                </button>
                <button 
                  onClick={() => setShowRegimeModal(false)}
                  className="px-6 py-3 border border-gray-600 text-gray-300 rounded-lg hover:bg-gray-700 transition-colors cursor-pointer whitespace-nowrap"
                >
                  Annuler
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="bg-gray-900/50 p-6 rounded-xl border border-yellow-500/20">
        <h3 className="text-xl font-bold text-white mb-6">Produits Recommandés pour la Retraite</h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[ 
            {
              name: 'PER Individuel',
              description: 'Plan d\'épargne retraite avec déduction fiscale',
              rate: '3-7%',
              risk: 'Moyen',
              icon: 'ri-shield-line'
            },
            {
              name: 'Assurance Vie',
              description: 'LE placement retraite des Français - Fiscalité ultra-avantageuse',
              rate: '2,5-6%',
              risk: 'Modulable',
              icon: 'ri-umbrella-line'
            },
            {
              name: 'PEA',
              description: 'Actions européennes avec exonération fiscale',
              rate: '4-8%',
              risk: 'Élevé',
              icon: 'ri-line-chart-line'
            },
            {
              name: 'Immobilier Locatif',
              description: 'Revenus locatifs pour la retraite',
              rate: '3-5%',
              risk: 'Moyen',
              icon: 'ri-home-line'
            }
          ].map((product, index) => (
            <div key={index} className="bg-black/30 p-6 rounded-xl border border-gray-700 hover:border-yellow-500/40 transition-all cursor-pointer">
              <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center mb-4">
                <i className={`${product.icon} text-2xl text-yellow-400`}></i>
              </div>
              <h4 className="text-lg font-bold text-white mb-2">{product.name}</h4>
              <p className="text-gray-400 text-sm mb-4">{product.description}</p>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-400">Rendement:</span>
                  <span className="text-green-400 font-semibold text-sm">{product.rate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Risque:</span>
                  <span className={`font-semibold text-sm ${product.risk === 'Faible' ? 'text-green-400' : 
                                                  product.risk === 'Moyen' ? 'text-yellow-400' : 'text-red-400'}`}>{product.risk}</span>
                </div>
              </div>
              <button 
                onClick={() => handleProductClick(product.name)}
                className="w-full mt-4 bg-yellow-500/20 text-yellow-400 py-2 rounded-lg hover:bg-yellow-500/30 transition-colors cursor-pointer whitespace-nowrap"
              >
                En savoir plus
              </button>
            </div>
          ))}
        </div>
      </div>

      {showAssuranceVieModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 rounded-xl border border-blue-500/30 max-w-6xl w-full max-h-[95vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-700">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                    <i className="ri-shield-line text-2xl text-blue-400"></i>
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-white">Assurance Vie - Solution Retraite N°1</h2>
                    <p className="text-gray-400">L'outil privilégié pour préparer sa retraite avec 1 800 Mds€ d'encours</p>
                  </div>
                </div>
                <button 
                  onClick={() => setShowAssuranceVieModal(false)}
                  className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-gray-700 transition-colors cursor-pointer"
                >
                  <i className="ri-close-line text-xl text-gray-400"></i>
                </button>
              </div>

              <div className="p-6 space-y-8">
                <div>
                  <h3 className="text-xl font-bold text-white mb-4">Pourquoi l'Assurance Vie pour la Retraite ?</h3>
                  <div className="bg-blue-500/10 p-6 rounded-xl border border-blue-500/20">
                    <p className="text-gray-300 leading-relaxed mb-6">
                      L'assurance vie est <strong className="text-white">LE placement retraite par excellence</strong> des Français. 
                      Avec plus de 1 800 milliards d'euros d'encours, elle combine <strong className="text-blue-400">sécurité, performance et fiscalité ultra-avantageuse</strong>.
                      C'est l'outil idéal pour constituer un capital retraite ou générer des revenus complémentaires.
                    </p>
                    <div className="grid md:grid-cols-4 gap-4">
                      <div className="text-center bg-black/30 p-4 rounded-lg">
                        <div className="text-2xl font-bold text-blue-400">2,8%</div>
                        <div className="text-sm text-gray-400">Fonds euros 2023</div>
                        <div className="text-xs text-gray-500">Garanti à 100%</div>
                      </div>
                      <div className="text-center bg-black/30 p-4 rounded-lg">
                        <div className="text-2xl font-bold text-green-400">4-8%</div>
                        <div className="text-sm text-gray-400">Unités de compte</div>
                        <div className="text-xs text-gray-500">Potentiel long terme</div>
                      </div>
                      <div className="text-center bg-black/30 p-4 rounded-lg">
                        <div className="text-2xl font-bold text-yellow-400">8 ans</div>
                        <div className="text-sm text-gray-400">Optimisation fiscale</div>
                        <div className="text-xs text-gray-500">Seuil magique</div>
                      </div>
                      <div className="text-center bg-black/30 p-4 rounded-lg">
                        <div className="text-2xl font-bold text-purple-400">152,5K€</div>
                        <div className="text-sm text-gray-400">Abattement succession</div>
                        <div className="text-xs text-gray-500">Par bénéficiaire</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-bold text-white mb-4">Supports d'Investissement pour la Retraite</h3>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="bg-cyan-500/10 p-6 rounded-xl border border-cyan-500/20">
                      <div className="flex items-center mb-4">
                        <div className="w-12 h-12 bg-cyan-500/20 rounded-lg flex items-center justify-center mr-3">
                          <i className="ri-shield-check-line text-2xl text-cyan-400"></i>
                        </div>
                        <h4 className="font-semibold text-white text-lg">Fonds en Euros</h4>
                      </div>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Rendement 2023:</span>
                          <span className="text-white font-semibold">2,8%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Rendement moyen 10 ans:</span>
                          <span className="text-white font-semibold">2,1%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Garantie capital:</span>
                          <span className="text-green-400">100%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Risque:</span>
                          <span className="text-green-400">Nul</span>
                        </div>
                        <p className="text-gray-300 text-sm mt-3 bg-black/30 p-3 rounded">
                          <strong className="text-cyan-400">Idéal pour:</strong> Sécuriser le capital retraite, 
                          recevoir des intérêts garantis. Base solide du patrimoine retraite.
                        </p>
                      </div>
                    </div>

                    <div className="bg-purple-500/10 p-6 rounded-xl border border-purple-500/20">
                      <div className="flex items-center mb-4">
                        <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center mr-3">
                          <i className="ri-line-chart-line text-2xl text-purple-400"></i>
                        </div>
                        <h4 className="font-semibold text-white text-lg">Unités de Compte</h4>
                      </div>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Rendement potentiel:</span>
                          <span className="text-white font-semibold">4-8%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Actions moyens 20 ans:</span>
                          <span className="text-green-400 font-semibold">6,2%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Garantie capital:</span>
                          <span className="text-red-400">Non</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Risque:</span>
                          <span className="text-yellow-400">Modéré à élevé</span>
                        </div>
                        <p className="text-gray-300 text-sm mt-3 bg-black/30 p-3 rounded">
                          <strong className="text-purple-400">Idéal pour:</strong> Faire fructifier le capital retraite,
                          contrer l'inflation sur le long terme. Croissance patrimoniale.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-bold text-white mb-4">Fiscalité : L'Avantage Décisif pour la Retraite</h3>
                  <div className="grid md:grid-cols-3 gap-6">
                    <div className="bg-red-500/10 p-6 rounded-xl border border-red-500/20">
                      <h4 className="font-semibold text-white mb-3">Avant 4 ans</h4>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Impôt sur plus-values:</span>
                          <span className="text-red-400 font-semibold">35%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Prélèvements sociaux:</span>
                          <span className="text-red-400 font-semibold">17,2%</span>
                        </div>
                        <div className="border-t border-red-500/20 pt-2 mt-3">
                          <div className="flex justify-between">
                            <span className="text-gray-400">Total fiscalité:</span>
                            <span className="text-red-400 font-bold">52,2%</span>
                          </div>
                        </div>
                        <div className="text-xs text-red-300">
                          Phase d'accumulation - éviter les retraits
                        </div>
                      </div>
                    </div>

                    <div className="bg-yellow-500/10 p-6 rounded-xl border border-yellow-500/20">
                      <h4 className="font-semibold text-white mb-3">4 à 8 ans</h4>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Impôt sur plus-values:</span>
                          <span className="text-yellow-400 font-semibold">15%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Prélèvements sociaux:</span>
                          <span className="text-yellow-400 font-semibold">17,2%</span>
                        </div>
                        <div className="border-t border-yellow-500/20 pt-2 mt-3">
                          <div className="flex justify-between">
                            <span className="text-gray-400">Total fiscalité:</span>
                            <span className="text-yellow-400 font-bold">32,2%</span>
                          </div>
                        </div>
                        <div className="text-xs text-yellow-300">
                          Période de transition
                        </div>
                      </div>
                    </div>

                    <div className="bg-green-500/10 p-6 rounded-xl border border-green-500/20">
                      <h4 className="font-semibold text-white mb-3">Après 8 ans - OPTIMAL</h4>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Impôt sur plus-values:</span>
                          <span className="text-green-400 font-semibold">7,5%</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Prélèvements sociaux:</span>
                          <span className="text-yellow-400 font-semibold">17,2%</span>
                        </div>
                        <div className="border-t border-green-500/20 pt-2 mt-3">
                          <div className="flex justify-between">
                            <span className="text-gray-400">Total fiscalité:</span>
                            <span className="text-green-400 font-bold">24,7%</span>
                          </div>
                        </div>
                        <div className="bg-green-500/20 p-2 rounded mt-3">
                          <div className="text-xs text-green-300 font-semibold">
                            Abattement annuel : 4 600€ (9 200€ couple)
                          </div>
                          <div className="text-xs text-green-300">
                            Sur gains nets - Parfait pour la retraite !
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-bold text-white mb-4">Stratégies d'Allocation selon l'Âge</h3>
                  <div className="space-y-4">
                    <div className="bg-green-500/10 p-4 rounded-xl border border-green-500/20">
                      <h4 className="font-semibold text-white mb-2 flex items-center">
                        <i className="ri-seedling-line text-green-400 mr-2"></i>
                        20-40 ans - Accumulation Dynamique
                      </h4>
                      <p className="text-sm text-gray-300 mb-3">Horizon long = prise de risque maximale pour la croissance</p>
                      <div className="grid md:grid-cols-3 gap-3 text-sm">
                        <div className="bg-black/30 p-3 rounded">
                          <div className="text-white font-semibold">20%</div>
                          <div className="text-gray-400">Fonds euros (sécurité)</div>
                        </div>
                        <div className="bg-black/30 p-3 rounded">
                          <div className="text-white font-semibold">70%</div>
                          <div className="text-gray-400">Actions diversifiées</div>
                        </div>
                        <div className="bg-black/30 p-3 rounded">
                          <div className="text-white font-semibold">10%</div>
                          <div className="text-gray-400">SCPI/Immobilier</div>
                        </div>
                      </div>
                      <p className="text-green-300 text-xs mt-2">Objectif : 6-8% de rendement annuel moyen</p>
                    </div>

                    <div className="bg-blue-500/10 p-4 rounded-xl border border-blue-500/20">
                      <h4 className="font-semibold text-white mb-2 flex items-center">
                        <i className="ri-scales-line text-blue-400 mr-2"></i>
                        40-55 ans - Équilibre et Consolidation
                      </h4>
                      <p className="text-sm text-gray-300 mb-3">Équilibrer croissance et sécurité pour la pré-retraite</p>
                      <div className="grid md:grid-cols-3 gap-3 text-sm">
                        <div className="bg-black/30 p-3 rounded">
                          <div className="text-white font-semibold">40%</div>
                          <div className="text-gray-400">Fonds euros</div>
                        </div>
                        <div className="bg-black/30 p-3 rounded">
                          <div className="text-white font-semibold">45%</div>
                          <div className="text-gray-400">Actions + ETF</div>
                        </div>
                        <div className="bg-black/30 p-3 rounded">
                          <div className="text-white font-semibold">15%</div>
                          <div className="text-gray-400">SCPI revenus</div>
                        </div>
                      </div>
                      <p className="text-blue-300 text-xs mt-2">Objectif : 4-6% avec moins de volatilité</p>
                    </div>

                    <div className="bg-purple-500/10 p-4 rounded-xl border border-purple-500/20">
                      <h4 className="font-semibold text-white mb-2 flex items-center">
                        <i className="ri-shield-line text-purple-400 mr-2"></i>
                        55+ ans - Préservation et Revenus
                      </h4>
                      <p className="text-sm text-gray-300 mb-3">Sécuriser le capital et optimiser les revenus retraite</p>
                      <div className="grid md:grid-cols-3 gap-3 text-sm">
                        <div className="bg-black/30 p-3 rounded">
                          <div className="text-white font-semibold">65%</div>
                          <div className="text-gray-400">Fonds euros</div>
                        </div>
                        <div className="bg-black/30 p-3 rounded">
                          <div className="text-white font-semibold">20%</div>
                          <div className="text-gray-400">Actions défensives</div>
                        </div>
                        <div className="bg-black/30 p-3 rounded">
                          <div className="text-white font-semibold">15%</div>
                          <div className="text-gray-400">SCPI rendement</div>
                        </div>
                      </div>
                      <p className="text-purple-300 text-xs mt-2">Objectif : 3-5% avec sécurité maximale</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-bold text-white mb-4">Comment Utiliser votre Assurance Vie à la Retraite</h3>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="bg-blue-500/10 p-6 rounded-xl border border-blue-500/20">
                      <h4 className="font-semibold text-white mb-4 flex items-center">
                        <i className="ri-money-euro-circle-line text-blue-400 mr-2"></i>
                        Retraits Programmés (Recommandé)
                      </h4>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Flexibilité:</span>
                          <span className="text-green-400 font-semibold">Maximale</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Montants:</span>
                          <span className="text-white">Variables selon besoins</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Fiscalité:</span>
                          <span className="text-green-400 font-semibold">Sur plus-values uniquement</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Capital restant:</span>
                          <span className="text-blue-400">Continue de fructifier</span>
                        </div>
                      </div>
                      <div className="bg-blue-500/20 p-3 rounded mt-4">
                        <p className="text-blue-300 text-sm font-semibold">Exemple pratique :</p>
                        <p className="text-gray-300 text-xs">
                          Capital 300K€ → Retrait 1 250€/mois (5%/an)
                          Fiscalité réelle : ~15€/mois seulement !
                        </p>
                      </div>
                    </div>

                    <div className="bg-purple-500/10 p-6 rounded-xl border border-purple-500/20">
                      <h4 className="font-semibold text-white mb-4 flex items-center">
                        <i className="ri-calendar-line text-purple-400 mr-2"></i>
                        Rente Viagère (Sécurité)
                      </h4>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Sécurité:</span>
                          <span className="text-green-400 font-semibold">Garantie à vie</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Montants:</span>
                          <span className="text-white">Fixes et réguliers</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Fiscalité:</span>
                          <span className="text-green-400 font-semibold">Fraction seulement</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Transmission:</span>
                          <span className="text-red-400">Capital consommé</span>
                        </div>
                      </div>
                      <div className="bg-purple-500/20 p-3 rounded mt-4">
                        <p className="text-purple-300 text-sm font-semibold">Exemple pratique :</p>
                        <p className="text-gray-300 text-xs">
                          Homme 65 ans, capital 300K€
                          → Rente 1 100€/mois à vie garantie
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-bold text-white mb-4">Pourquoi Choisir l'Assurance Vie vs Autres Placements ?</h3>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-gray-700">
                          <th className="text-left py-3 text-gray-400">Caractéristique</th>
                          <th className="text-center py-3 text-blue-400">Assurance Vie</th>
                          <th className="text-center py-3 text-green-400">PER</th>
                          <th className="text-center py-3 text-yellow-400">PEA</th>
                          <th className="text-center py-3 text-purple-400">CTO</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-700">
                        <tr>
                          <td className="py-3 text-gray-300">Plafond versements</td>
                          <td className="py-3 text-center text-green-400 font-semibold">Aucun</td>
                          <td className="py-3 text-center text-white">10% revenus</td>
                          <td className="py-3 text-center text-white">150K€</td>
                          <td className="py-3 text-center text-green-400">Aucun</td>
                        </tr>
                        <tr>
                          <td className="py-3 text-gray-300">Fiscalité optimale</td>
                          <td className="py-3 text-center text-green-400 font-semibold">24,7% (après 8 ans)</td>
                          <td className="py-3 text-center text-white">TMI à la sortie</td>
                          <td className="py-3 text-center text-white">17,2% (après 5 ans)</td>
                          <td className="py-3 text-center text-red-400">30%</td>
                        </tr>
                        <tr>
                          <td className="py-3 text-gray-300">Disponibilité</td>
                          <td className="py-3 text-center text-green-400 font-semibold">Immédiate</td>
                          <td className="py-3 text-center text-red-400">Bloqué jusqu'à retraite</td>
                          <td className="py-3 text-center text-yellow-400">5 ans minimum</td>
                          <td className="py-3 text-center text-green-400">Immédiate</td>
                        </tr>
                        <tr>
                          <td className="py-3 text-gray-300">Transmission</td>
                          <td className="py-3 text-center text-green-400 font-semibold">152,5K€ exonérés</td>
                          <td className="py-3 text-center text-white">Droits succession</td>
                          <td className="py-3 text-center text-white">Droits succession</td>
                          <td className="py-3 text-center text-white">Droits succession</td>
                        </tr>
                        <tr>
                          <td className="py-3 text-gray-300">Univers investissement</td>
                          <td className="py-3 text-center text-green-400 font-semibold">Très large</td>
                          <td className="py-3 text-center text-green-400">Très large</td>
                          <td className="py-3 text-center text-yellow-400">Actions UE</td>
                          <td className="py-3 text-center text-green-400">Mondial</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-bold text-white mb-4">Simulations Réalistes - Revenus Retraite</h3>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-gray-700">
                          <th className="text-left py-3 text-gray-400">Capital à 65 ans</th>
                          <th className="text-center py-3 text-blue-400">Retraits 4%/an</th>
                          <th className="text-center py-3 text-green-400">Revenus nets/mois</th>
                          <th className="text-center py-3 text-purple-400">Fiscalité réelle/an</th>
                          <th className="text-center py-3 text-yellow-400">Équivalent salaire brut</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-700">
                        <tr>
                          <td className="py-3 text-gray-300 font-semibold">200 000€</td>
                          <td className="py-3 text-center text-white font-semibold">8 000€</td>
                          <td className="py-3 text-center text-green-400 font-semibold">640€</td>
                          <td className="py-3 text-center text-yellow-400">180€</td>
                          <td className="py-3 text-center text-yellow-400">~970€</td>
                        </tr>
                        <tr>
                          <td className="py-3 text-gray-300 font-semibold">350 000€</td>
                          <td className="py-3 text-center text-white font-semibold">14 000€</td>
                          <td className="py-3 text-center text-green-400 font-semibold">1 120€</td>
                          <td className="py-3 text-center text-yellow-400">315€</td>
                          <td className="py-3 text-center text-yellow-400">~1 700€</td>
                        </tr>
                        <tr>
                          <td className="py-3 text-gray-300 font-semibold">500 000€</td>
                          <td className="py-3 text-center text-white font-semibold">20 000€</td>
                          <td className="py-3 text-center text-green-400 font-semibold">1 580€</td>
                          <td className="py-3 text-center text-yellow-400">450€</td>
                          <td className="py-3 text-center text-yellow-400">~2 400€</td>
                        </tr>
                        <tr className="bg-blue-500/10">
                          <td className="py-3 text-white font-bold">750 000€</td>
                          <td className="py-3 text-center text-white font-semibold">30 000€</td>
                          <td className="py-3 text-center text-green-400 font-bold">2 380€</td>
                          <td className="py-3 text-center text-yellow-400">675€</td>
                          <td className="py-3 text-center text-yellow-400 font-bold">~3 600€</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <p className="text-gray-400 text-xs mt-3">
                    * Calculs avec abattement 4 600€/an, fiscalité à 24,7% après 8 ans, retraits sur plus-values uniquement
                  </p>
                </div>

                <div className="bg-gradient-to-r from-blue-500/20 to-blue-600/20 p-6 rounded-xl border border-blue-500/30">
                  <h3 className="text-xl font-bold text-white mb-4 flex items-center">
                    <i className="ri-lightbulb-line text-blue-400 mr-3"></i>
                    Conseils d'Experts - Optimisation Retraite 2024
                  </h3>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold text-white mb-3">Stratégies Gagnantes</h4>
                      <ul className="space-y-2 text-sm text-gray-300">
                        <li className="flex items-start space-x-2">
                          <i className="ri-checkbox-circle-line text-green-400 mt-0.5"></i>
                          <span>Ouvrir avant 30 ans pour optimiser les 8 ans</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <i className="ri-checkbox-circle-line text-green-400 mt-0.5"></i>
                          <span>Privilégier contrats sans frais d'entrée</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <i className="ri-checkbox-circle-line text-green-400 mt-0.5"></i>
                          <span>Adapter allocation selon l'âge (règle 100-âge)</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <i className="ri-checkbox-circle-line text-green-400 mt-0.5"></i>
                          <span>Diversifier sur plusieurs contrats/assureurs</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <i className="ri-checkbox-circle-line text-green-400 mt-0.5"></i>
                          <span>Alimenter massivement avant 70 ans</span>
                        </li>
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-semibold text-white mb-3">Pièges à Éviter</h4>
                      <ul className="space-y-2 text-sm text-gray-300">
                        <li className="flex items-start space-x-2">
                          <i className="ri-close-circle-line text-red-400 mt-0.5"></i>
                          <span>Racheter avant 8 ans (sauf urgence vitale)</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <i className="ri-close-circle-line text-red-400 mt-0.5"></i>
                          <span>100% fonds euros (sous-performance vs inflation)</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <i className="ri-close-circle-line text-red-400 mt-0.5"></i>
                          <span>Choisir contrats avec frais d'entrée 4-5%</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <i className="ri-close-circle-line text-red-400 mt-0.5"></i>
                          <span>Négliger la qualité de l'assureur</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <i className="ri-close-circle-line text-red-400 mt-0.5"></i>
                          <span>Oublier de désigner les bénéficiaires</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="flex space-x-4 pt-4 border-t border-gray-700">
                  <button className="flex-1 bg-blue-500 text-white py-3 px-6 rounded-lg font-semibold hover:bg-blue-400 transition-colors cursor-pointer whitespace-nowrap">
                    Ouvrir Assurance Vie Retraite
                  </button>
                  <button className="flex-1 bg-green-500 text-white py-3 px-6 rounded-lg font-semibold hover:bg-green-400 transition-colors cursor-pointer whitespace-nowrap">
                    Simuler ma Retraite
                  </button>
                  <button 
                    onClick={() => setShowAssuranceVieModal(false)}
                    className="px-6 py-3 border border-gray-600 text-gray-300 rounded-lg hover:bg-gray-700 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    Fermer
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
