
'use client';

import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function PortfolioChart() {
  const data = [
    { month: 'Jan', value: 115000 },
    { month: 'Fév', value: 118500 },
    { month: 'Mar', value: 122000 },
    { month: 'Avr', value: 119800 },
    { month: 'Mai', value: 124300 },
    { month: 'Jun', value: 127544 }
  ];

  return (
    <div className="bg-gray-900 rounded-xl p-6 border border-yellow-500/20">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white">Évolution du Portefeuille</h3>
        <div className="flex space-x-2">
          <button className="px-3 py-1 text-sm bg-yellow-500 text-black rounded whitespace-nowrap cursor-pointer">6M</button>
          <button className="px-3 py-1 text-sm text-gray-400 hover:text-white transition-colors whitespace-nowrap cursor-pointer">1A</button>
          <button className="px-3 py-1 text-sm text-gray-400 hover:text-white transition-colors whitespace-nowrap cursor-pointer">5A</button>
        </div>
      </div>

      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <defs>
              <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#EAB308" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#EAB308" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
            <XAxis 
              dataKey="month" 
              stroke="#9CA3AF"
              fontSize={12}
            />
            <YAxis 
              stroke="#9CA3AF"
              fontSize={12}
              tickFormatter={(value) => `€${(value / 1000).toFixed(0)}k`}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: '#1F2937',
                border: '1px solid #EAB308',
                borderRadius: '8px',
                color: '#FFFFFF'
              }}
              formatter={(value) => [`€${value.toLocaleString()}`, 'Valeur']}
            />
            <Area 
              type="monotone" 
              dataKey="value" 
              stroke="#EAB308" 
              strokeWidth={2}
              fillOpacity={1} 
              fill="url(#colorValue)" 
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
