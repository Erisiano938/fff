
'use client';

import { useState, useEffect, useRef } from 'react';

export default function DigitalTwin() {
  const canvasRef = useRef(null);
  const animationRef = useRef(null);
  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState('galaxy');
  const [speed, setSpeed] = useState(1);
  const [zoom, setZoom] = useState(1);
  const [selectedAsset, setSelectedAsset] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [portfolioData, setPortfolioData] = useState({
    totalValue: 127544,
    assets: []
  });
  const [showAllocationSummary, setShowAllocationSummary] = useState(false);
  const [assetPositions, setAssetPositions] = useState([]);

  useEffect(() => {
    const syncPortfolioData = () => {
      try {
        // Priorité 1: Portfolio Config (éditeur de portefeuille)
        const savedConfig = localStorage.getItem('portfolio_config');
        
        if (savedConfig) {
          const config = JSON.parse(savedConfig);
          
          if (config.allocations && config.allocations.length > 0) {
            const totalValue = config.totalPortfolio || 127544;
            const assets = config.allocations.map(alloc => ({
              name: alloc.name || 'Actif',
              value: alloc.value || (totalValue * (alloc.percentage / 100)),
              percentage: alloc.percentage || ((alloc.value / totalValue) * 100),
              color: alloc.color || '#6B7280',
              description: getAssetDescription(alloc.name),
              riskLevel: getAssetRisk(alloc.name),
              allocation: ((alloc.value || (totalValue * (alloc.percentage / 100))) / totalValue * 100).toFixed(1),
              type: getAssetType(alloc.name),
              sector: getAssetSector(alloc.name)
            }));
            
            setPortfolioData({
              totalValue: totalValue,
              assets: assets
            });
            return;
          }
        }

        // Fallback: Portfolio Data
        const savedData = localStorage.getItem('portfolio_data');
        if (savedData) {
          const data = JSON.parse(savedData);
          
          if (data.allocations && data.allocations.length > 0) {
            const totalValue = data.totalValue || 127544;
            const assets = data.allocations.map(alloc => ({
              name: alloc.name || 'Actif',
              value: alloc.value || (totalValue * (alloc.percentage / 100)),
              percentage: alloc.percentage || ((alloc.value / totalValue) * 100),
              color: alloc.color || '#6B7280',
              description: getAssetDescription(alloc.name),
              riskLevel: getAssetRisk(alloc.name),
              allocation: ((alloc.value || (totalValue * (alloc.percentage / 100))) / totalValue * 100).toFixed(1),
              type: getAssetType(alloc.name),
              sector: getAssetSector(alloc.name)
            }));
            
            setPortfolioData({
              totalValue: totalValue,
              assets: assets
            });
            return;
          }
        }

        // Données par défaut si aucune configuration
        const defaultAssets = [
          { name: 'Actions', percentage: 45, color: '#EAB308' },
          { name: 'Obligations', percentage: 25, color: '#3B82F6' },
          { name: 'ETF', percentage: 20, color: '#10B981' },
          { name: 'Crypto', percentage: 7, color: '#8B5CF6' },
          { name: 'Cash', percentage: 3, color: '#6B7280' }
        ].map(asset => ({
          ...asset,
          value: (127544 * asset.percentage) / 100,
          description: getAssetDescription(asset.name),
          riskLevel: getAssetRisk(asset.name),
          allocation: asset.percentage.toFixed(1),
          type: getAssetType(asset.name),
          sector: getAssetSector(asset.name)
        }));

        setPortfolioData({
          totalValue: 127544,
          assets: defaultAssets
        });

      } catch (error) {
        console.error('Erreur lors de la synchronisation des données:', error);
      }
    };

    syncPortfolioData();

    // Écouter les changements
    const handleStorageChange = () => {
      syncPortfolioData();
    };

    const handlePortfolioUpdate = (event) => {
      console.log('Portfolio update event received:', event.detail);
      syncPortfolioData();
    };

    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('portfolioUpdated', handlePortfolioUpdate);

    // Vérification périodique
    const interval = setInterval(() => {
      const lastUpdate = localStorage.getItem('dashboard_portfolio_updated');
      if (lastUpdate) {
        syncPortfolioData();
        localStorage.removeItem('dashboard_portfolio_updated');
      }
    }, 5000);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('portfolioUpdated', handlePortfolioUpdate);
      clearInterval(interval);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);

  const getAssetDescription = (name) => {
    const descriptions = {
      'Actions': 'Titres de propriété d\'entreprises cotées en bourse',
      'Actions défensives': 'Actions de secteurs peu cycliques et stables',
      'Actions croissance': 'Actions d\'entreprises à fort potentiel de croissance',
      'Actions dividendes': 'Actions d\'entreprises versant des dividendes réguliers',
      'Actions diversifiées': 'Portefeuille diversifié d\'actions internationales',
      'Obligations': 'Titres de créance émis par des États ou entreprises',
      'Obligations d\'État': 'Dettes souveraines considérées comme sûres',
      'Obligations Entreprises': 'Dettes d\'entreprises avec rendement plus élevé',
      'ETF': 'Fonds indiciels cotés offrant une diversification instantanée',
      'ETF diversifiés': 'ETF couvrant plusieurs secteurs ou régions',
      'ETF internationaux': 'Exposition aux marchés mondiaux via ETF',
      'Crypto': 'Cryptomonnaies et actifs numériques décentralisés',
      'Crypto & Blockchain': 'Exposition à l\'écosystème blockchain et crypto',
      'Bitcoin': 'Première et principale cryptomonnaie décentralisée',
      'Ethereum': 'Plateforme blockchain pour les contrats intelligents',
      'Cash': 'Liquidités disponibles immédiatement',
      'Liquidités': 'Réserves monétaires et comptes à vue',
      'Immobilier': 'Investissements dans des biens immobiliers',
      'REIT': 'Fonds d\'investissement immobilier cotés',
      'Or': 'Métal précieux, valeur refuge traditionnelle',
      'Matières Premières': 'Commodités et ressources naturelles'
    };
    return descriptions[name] || 'Actif financier diversifié';
  };

  const getAssetRisk = (name) => {
    const riskLevels = {
      'Cash': 'Très Faible',
      'Liquidités': 'Très Faible',
      'Obligations d\'État': 'Faible',
      'Obligations': 'Faible',
      'Obligations Entreprises': 'Modéré',
      'Actions défensives': 'Modéré',
      'ETF diversifiés': 'Modéré',
      'Actions diversifiées': 'Modéré-Élevé',
      'Actions': 'Modéré-Élevé',
      'ETF': 'Modéré-Élevé',
      'Immobilier': 'Modéré-Élevé',
      'REIT': 'Élevé',
      'Actions croissance': 'Élevé',
      'Or': 'Élevé',
      'Matières Premières': 'Élevé',
      'Crypto': 'Très Élevé',
      'Bitcoin': 'Très Élevé',
      'Ethereum': 'Très Élevé',
      'Crypto & Blockchain': 'Très Élevé'
    };
    return riskLevels[name] || 'Modéré';
  };

  const getAssetType = (name) => {
    const types = {
      'Actions': 'Actions',
      'Actions défensives': 'Actions',
      'Actions croissance': 'Actions',
      'Actions dividendes': 'Actions',
      'Actions diversifiées': 'Actions',
      'Obligations': 'Obligations',
      'Obligations d\'État': 'Obligations',
      'Obligations Entreprises': 'Obligations',
      'ETF': 'Fonds',
      'ETF diversifiés': 'Fonds',
      'ETF internationaux': 'Fonds',
      'Crypto': 'Alternatif',
      'Bitcoin': 'Alternatif',
      'Ethereum': 'Alternatif', 
      'Crypto & Blockchain': 'Alternatif',
      'Cash': 'Monétaire',
      'Liquidités': 'Monétaire',
      'Immobilier': 'Immobilier',
      'REIT': 'Immobilier',
      'Or': 'Matières Premières',
      'Matières Premières': 'Matières Premières'
    };
    return types[name] || 'Mixte';
  };

  const getAssetSector = (name) => {
    const sectors = {
      'Actions défensives': 'Santé, Utilities, Consommation',
      'Actions croissance': 'Technologie, Innovation',
      'Actions dividendes': 'Energie, Télécom, Services',
      'Obligations d\'État': 'Gouvernemental',
      'Obligations Entreprises': 'Corporate',
      'ETF diversifiés': 'Multi-sectoriel',
      'ETF internationaux': 'International',
      'Crypto': 'Numérique',
      'Bitcoin': 'Store of Value',
      'Ethereum': 'Smart Contracts',
      'REIT': 'Immobilier Commercial',
      'Or': 'Métaux Précieux'
    };
    return sectors[name] || 'Diversifié';
  };

  useEffect(() => {
    if (!isActive) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * window.devicePixelRatio;
    canvas.height = rect.height * window.devicePixelRatio;
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio);

    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const baseRadius = Math.min(centerX, centerY) * 0.6 * zoom;

    let rotation = 0;
    const particles = [];

    // Générer les particules d'énergie
    for (let i = 0; i < 50; i++) {
      particles.push({
        x: Math.random() * rect.width,
        y: Math.random() * rect.height,
        vx: (Math.random() - 0.5) * 2,
        vy: (Math.random() - 0.5) * 2,
        size: Math.random() * 3 + 1,
        opacity: Math.random() * 0.5 + 0.3
      });
    }

    // Calculer les positions des actifs
    const assetCount = portfolioData.assets.length;
    const newAssetPositions = portfolioData.assets.map((asset, index) => {
      const angle = (index / assetCount) * Math.PI * 2;
      const distance = baseRadius * (0.6 + (asset.value / portfolioData.totalValue) * 0.4);
      
      return {
        ...asset,
        angle,
        distance,
        particles: Math.min(Math.max(Math.floor(asset.value / portfolioData.totalValue * 30), 8), 30)
      };
    });

    setAssetPositions(newAssetPositions);

    const animate = () => {
      ctx.clearRect(0, 0, rect.width, rect.height);

      // Arrière-plan selon le mode
      if (mode === 'galaxy') {
        const gradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, baseRadius);
        gradient.addColorStop(0, 'rgba(17, 24, 39, 0.9)');
        gradient.addColorStop(1, 'rgba(0, 0, 0, 0.95)');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, rect.width, rect.height);
      } else if (mode === 'neural') {
        ctx.fillStyle = 'rgba(0, 10, 20, 0.95)';
        ctx.fillRect(0, 0, rect.width, rect.height);
      } else if (mode === 'quantum') {
        const gradient = ctx.createLinearGradient(0, 0, rect.width, rect.height);
        gradient.addColorStop(0, 'rgba(20, 0, 40, 0.9)');
        gradient.addColorStop(1, 'rgba(0, 20, 40, 0.9)');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, rect.width, rect.height);
      } else if (mode === 'matrix') {
        ctx.fillStyle = 'rgba(0, 20, 0, 0.95)';
        ctx.fillRect(0, 0, rect.width, rect.height);
      }

      // Animer les particules d'énergie
      particles.forEach(particle => {
        particle.x += particle.vx * speed;
        particle.y += particle.vy * speed;

        if (particle.x < 0 || particle.x > rect.width) particle.vx *= -1;
        if (particle.y < 0 || particle.y > rect.height) particle.vy *= -1;

        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fillStyle = mode === 'galaxy' ? `rgba(255, 215, 0, ${particle.opacity})` :
                       mode === 'neural' ? `rgba(0, 255, 255, ${particle.opacity})` :
                       mode === 'quantum' ? `rgba(255, 0, 255, ${particle.opacity})` :
                       `rgba(0, 255, 0, ${particle.opacity})`;
        ctx.fill();
      });

      // Dessiner les actifs selon leur position finale
      newAssetPositions.forEach((asset, index) => {
        const finalAngle = asset.angle + rotation;
        const x = centerX + Math.cos(finalAngle) * asset.distance;
        const y = centerY + Math.sin(finalAngle) * asset.distance;

        // Taille proportionnelle à la valeur
        const size = Math.max(15, (asset.value / portfolioData.totalValue) * 80);

        // Halo pulsant
        const pulseSize = size + Math.sin(Date.now() * 0.003 + index) * 5;
        const gradient = ctx.createRadialGradient(x, y, 0, x, y, pulseSize);
        gradient.addColorStop(0, asset.color + '40');
        gradient.addColorStop(1, asset.color + '00');
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(x, y, pulseSize, 0, Math.PI * 2);
        ctx.fill();

        // Corps principal de l'actif
        ctx.beginPath();
        ctx.arc(x, y, size, 0, Math.PI * 2);
        ctx.fillStyle = asset.color;
        ctx.fill();
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Particules orbitales
        for (let i = 0; i < asset.particles; i++) {
          const particleAngle = (i / asset.particles) * Math.PI * 2 + rotation * 2;
          const particleDistance = size + 20 + Math.sin(Date.now() * 0.002 + i) * 10;
          const particleX = x + Math.cos(particleAngle) * particleDistance;
          const particleY = y + Math.sin(particleAngle) * particleDistance;

          ctx.beginPath();
          ctx.arc(particleX, particleY, 2, 0, Math.PI * 2);
          ctx.fillStyle = asset.color + '80';
          ctx.fill();
        }

        // Stocker les coordonnées finales pour la détection de clic
        asset.finalX = x;
        asset.finalY = y;
        asset.finalSize = size;
      });

      // Connexions entre actifs (mode neural)
      if (mode === 'neural') {
        newAssetPositions.forEach((asset1, i) => {
          newAssetPositions.forEach((asset2, j) => {
            if (i < j && Math.random() < 0.3) {
              ctx.beginPath();
              ctx.moveTo(asset1.finalX, asset1.finalY);
              ctx.lineTo(asset2.finalX, asset2.finalY);
              ctx.strokeStyle = 'rgba(0, 255, 255, 0.2)';
              ctx.lineWidth = 1;
              ctx.stroke();

              // Impulsion électrique
              const progress = (Date.now() * 0.005 + i + j) % 1;
              const impX = asset1.finalX + (asset2.finalX - asset1.finalX) * progress;
              const impY = asset1.finalY + (asset2.finalY - asset1.finalY) * progress;
              
              ctx.beginPath();
              ctx.arc(impX, impY, 3, 0, Math.PI * 2);
              ctx.fillStyle = 'rgba(0, 255, 255, 0.8)';
              ctx.fill();
            }
          });
        });
      }

      rotation += 0.005 * speed;
      animationRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isActive, mode, speed, zoom, portfolioData]);

  const handleCanvasClick = (event) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const clickX = event.clientX - rect.left;
    const clickY = event.clientY - rect.top;

    console.log('Clic détecté:', { clickX, clickY });

    // Vérifier chaque actif
    assetPositions.forEach((asset, index) => {
      if (asset.finalX && asset.finalY && asset.finalSize) {
        const distance = Math.sqrt(
          Math.pow(clickX - asset.finalX, 2) + Math.pow(clickY - asset.finalY, 2)
        );
        const hitRadius = Math.max(asset.finalSize + 10, 25); // Zone de clic élargie

        console.log(`Asset ${asset.name}: distance=${distance.toFixed(2)}, hitRadius=${hitRadius}`);

        if (distance <= hitRadius) {
          console.log(`Actif sélectionné: ${asset.name}`);
          setSelectedAsset(asset);
          setShowModal(true);
          return;
        }
      }
    });
  };

  const modes = [
    { id: 'galaxy', name: 'Galaxie Patrimoniale', icon: 'ri-planet-line', color: 'text-yellow-400' },
    { id: 'neural', name: 'Réseau Neural', icon: 'ri-brain-line', color: 'text-cyan-400' },
    { id: 'quantum', name: 'États Quantiques', icon: 'ri-atom-line', color: 'text-purple-400' },
    { id: 'matrix', name: 'Matrice Digitale', icon: 'ri-code-line', color: 'text-green-400' }
  ];

  const getRiskColor = (riskLevel) => {
    const colors = {
      'Très Faible': 'text-green-400',
      'Faible': 'text-green-300',
      'Modéré': 'text-yellow-400',
      'Modéré-Élevé': 'text-orange-400',
      'Élevé': 'text-red-400',
      'Très Élevé': 'text-red-500'
    };
    return colors[riskLevel] || 'text-gray-400';
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="bg-gray-900 rounded-xl border border-yellow-500/20 overflow-hidden">
      <div className="p-6">
        <div className="flex justify-between items-start mb-6">
          <div>
            <h3 className="text-2xl font-bold text-white mb-2 flex items-center">
              <i className="ri-stack-line text-yellow-400 mr-3"></i>
              Digital Twin 3D
            </h3>
            <p className="text-gray-400">
              Visualisation immersive de votre portefeuille patrimonial
            </p>
          </div>
          <div className="flex space-x-2">
            <button
              onClick={() => setShowAllocationSummary(!showAllocationSummary)}
              className="px-4 py-2 bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-pie-chart-line mr-2"></i>
              Récapitulatif
            </button>
            <button
              onClick={() => setIsActive(!isActive)}
              className={`px-4 py-2 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                isActive 
                  ? 'bg-red-500 hover:bg-red-600 text-white' 
                  : 'bg-yellow-500 hover:bg-yellow-600 text-black'
              }`}
            >
              {isActive ? (
                <>
                  <i className="ri-pause-line mr-2"></i>
                  Arrêter
                </>
              ) : (
                <>
                  <i className="ri-play-line mr-2"></i>
                  Démarrer
                </>
              )}
            </button>
          </div>
        </div>

        {/* Contrôles de mode */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
          {modes.map((modeOption) => (
            <button
              key={modeOption.id}
              onClick={() => setMode(modeOption.id)}
              className={`p-3 rounded-lg border transition-all cursor-pointer ${
                mode === modeOption.id
                  ? 'border-yellow-500 bg-yellow-500/10'
                  : 'border-gray-700 bg-gray-800/50 hover:border-gray-600'
              }`}
            >
              <div className="flex items-center space-x-2">
                <i className={`${modeOption.icon} ${modeOption.color}`}></i>
                <span className="text-white font-medium text-sm">{modeOption.name}</span>
              </div>
            </button>
          ))}
        </div>

        {/* Contrôles de vitesse et zoom */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Vitesse de rotation
            </label>
            <input
              type="range"
              min="0.1"
              max="3"
              step="0.1"
              value={speed}
              onChange={(e) => setSpeed(parseFloat(e.target.value))}
              className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
            />
            <div className="text-sm text-gray-500 mt-1">{speed.toFixed(1)}x</div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Niveau de zoom
            </label>
            <input
              type="range"
              min="0.5"
              max="2"
              step="0.1"
              value={zoom}
              onChange={(e) => setZoom(parseFloat(e.target.value))}
              className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
            />
            <div className="text-sm text-gray-500 mt-1">{zoom.toFixed(1)}x</div>
          </div>
        </div>

        {/* Canvas 3D */}
        <div className="relative bg-black rounded-lg overflow-hidden" style={{ height: '400px' }}>
          <canvas
            ref={canvasRef}
            onClick={handleCanvasClick}
            className="w-full h-full cursor-pointer"
            style={{ width: '100%', height: '100%' }}
          />
          
          {/* Instructions */}
          <div className="absolute bottom-4 right-4 bg-black/70 text-white p-3 rounded-lg text-sm">
            <div className="flex items-center space-x-2 mb-1">
              <i className="ri-mouse-line text-yellow-400"></i>
              <span>Cliquez sur un actif pour les détails</span>
            </div>
            <div className="flex items-center space-x-2">
              <i className="ri-eye-line text-blue-400"></i>
              <span>Taille = proportion dans le portefeuille</span>
            </div>
          </div>

          {/* Informations du portefeuille */}
          <div className="absolute top-4 left-4 bg-black/70 text-white p-3 rounded-lg">
            <div className="text-sm text-gray-400">Valeur totale</div>
            <div className="text-xl font-bold text-yellow-400">
              {formatCurrency(portfolioData.totalValue)}
            </div>
            <div className="text-sm text-gray-400 mt-1">
              {portfolioData.assets.length} positions
            </div>
          </div>
        </div>
      </div>

      {/* Modal de détails d'actif */}
      {showModal && selectedAsset && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-900 rounded-xl border border-yellow-500/30 max-w-md w-full max-h-[80vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center space-x-3">
                  <div
                    className="w-8 h-8 rounded-full"
                    style={{ backgroundColor: selectedAsset.color }}
                  ></div>
                  <div>
                    <h3 className="text-xl font-bold text-white">{selectedAsset.name}</h3>
                    <p className="text-sm text-gray-400">{selectedAsset.type}</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowModal(false)}
                  className="text-gray-400 hover:text-white cursor-pointer"
                >
                  <i className="ri-close-line text-xl"></i>
                </button>
              </div>

              <div className="space-y-4">
                <div className="bg-black/30 p-4 rounded-lg">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-sm text-gray-400">Valeur</div>
                      <div className="text-lg font-bold text-white">
                        {formatCurrency(selectedAsset.value)}
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-400">Allocation</div>
                      <div className="text-lg font-bold text-yellow-400">
                        {selectedAsset.allocation}%
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <div className="text-sm text-gray-400 mb-2">Description</div>
                  <p className="text-gray-300 text-sm leading-relaxed">
                    {selectedAsset.description}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm text-gray-400">Niveau de risque</div>
                    <div className={`font-semibold ${getRiskColor(selectedAsset.riskLevel)}`}>
                      {selectedAsset.riskLevel}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-400">Secteur</div>
                    <div className="text-white font-medium">
                      {selectedAsset.sector}
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-gray-700">
                  <button
                    onClick={() => setShowModal(false)}
                    className="w-full bg-yellow-500 hover:bg-yellow-600 text-black py-3 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap"
                  >
                    Analyser cet actif
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Récapitulatif des allocations */}
      {showAllocationSummary && (
        <div className="border-t border-gray-700 p-6">
          <h4 className="text-lg font-bold text-white mb-4 flex items-center">
            <i className="ri-pie-chart-line text-blue-400 mr-2"></i>
            Récapitulatif des Allocations
          </h4>
          
          <div className="grid gap-4">
            {portfolioData.assets.map((asset, index) => (
              <div key={index} className="bg-black/20 p-4 rounded-lg border border-gray-700">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div
                      className="w-4 h-4 rounded-full"
                      style={{ backgroundColor: asset.color }}
                    ></div>
                    <div>
                      <h5 className="font-semibold text-white">{asset.name}</h5>
                      <p className="text-xs text-gray-400">{asset.type}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-white">
                      {formatCurrency(asset.value)}
                    </div>
                    <div className="text-sm text-yellow-400">
                      {asset.allocation}%
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-400">Risque:</span>
                    <span className={`ml-2 font-medium ${getRiskColor(asset.riskLevel)}`}>
                      {asset.riskLevel}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-400">Secteur:</span>
                    <span className="text-white ml-2">{asset.sector}</span>
                  </div>
                </div>
                
                <div className="mt-3">
                  <p className="text-xs text-gray-300 leading-relaxed">
                    {asset.description}
                  </p>
                </div>

                {/* Barre de progression */}
                <div className="mt-3">
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div
                      className="h-2 rounded-full transition-all duration-300"
                      style={{
                        width: `${asset.allocation}%`,
                        backgroundColor: asset.color
                      }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-6 pt-4 border-t border-gray-700">
            <div className="flex justify-between items-center text-sm">
              <span className="text-gray-400">Total vérifié:</span>
              <span className="font-bold text-white">
                {formatCurrency(portfolioData.totalValue)}
              </span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span className="text-gray-400">Nombre d'actifs:</span>
              <span className="font-bold text-white">
                {portfolioData.assets.length} positions
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
