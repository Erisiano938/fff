
'use client';

export default function RecentTransactions() {
  const transactions = [
    {
      type: 'buy',
      asset: 'APPLE INC',
      symbol: 'AAPL',
      amount: '+12 actions',
      value: '-€2,184.50',
      date: '2024-01-15',
      time: '14:32'
    },
    {
      type: 'dividend',
      asset: 'MICROSOFT CORP',
      symbol: 'MSFT',
      amount: 'Dividende',
      value: '+€47.80',
      date: '2024-01-14',
      time: '09:15'
    },
    {
      type: 'sell',
      asset: 'TESLA INC',
      symbol: 'TSLA',
      amount: '-5 actions',
      value: '+€1,247.25',
      date: '2024-01-13',
      time: '16:45'
    },
    {
      type: 'buy',
      asset: 'BITCOIN ETF',
      symbol: 'BTC',
      amount: '+0.5 parts',
      value: '-€1,856.30',
      date: '2024-01-12',
      time: '11:20'
    },
    {
      type: 'dividend',
      asset: 'VANGUARD S&P 500',
      symbol: 'VOO',
      amount: 'Dividende',
      value: '+€23.45',
      date: '2024-01-11',
      time: '08:30'
    }
  ];

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'buy': return 'ri-arrow-down-line';
      case 'sell': return 'ri-arrow-up-line';
      case 'dividend': return 'ri-money-dollar-circle-line';
      default: return 'ri-exchange-line';
    }
  };

  const getTransactionColor = (type: string) => {
    switch (type) {
      case 'buy': return 'text-blue-400 bg-blue-500/20';
      case 'sell': return 'text-green-400 bg-green-500/20';
      case 'dividend': return 'text-yellow-400 bg-yellow-500/20';
      default: return 'text-gray-400 bg-gray-500/20';
    }
  };

  return (
    <div className="bg-gray-900 rounded-xl p-6 border border-yellow-500/20">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-white">Transactions Récentes</h3>
        <button className="text-yellow-400 hover:text-yellow-300 text-sm cursor-pointer whitespace-nowrap">
          Voir tout
        </button>
      </div>

      <div className="space-y-4">
        {transactions.map((transaction, index) => (
          <div key={index} className="flex items-center justify-between p-4 bg-black/30 rounded-lg hover:bg-black/50 transition-colors">
            <div className="flex items-center space-x-4">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${getTransactionColor(transaction.type)}`}>
                <i className={`${getTransactionIcon(transaction.type)} text-lg`}></i>
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-white font-medium">{transaction.asset}</span>
                  <span className="text-gray-400 text-sm">({transaction.symbol})</span>
                </div>
                <div className="flex items-center space-x-2 text-sm text-gray-400">
                  <span>{transaction.amount}</span>
                  <span>•</span>
                  <span>{transaction.date} à {transaction.time}</span>
                </div>
              </div>
            </div>
            <div className={`font-semibold ${transaction.value.startsWith('+') ? 'text-green-400' : 'text-red-400'}`}>
              {transaction.value}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
