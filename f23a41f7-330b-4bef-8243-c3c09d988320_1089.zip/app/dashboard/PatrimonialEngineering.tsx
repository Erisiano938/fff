
'use client';

import React, { useState } from 'react';
import OfficialFATCACRSReporting from './OfficialFATCACRSReporting';

export default function PatrimonialEngineering() {
  const [activeTab, setActiveTab] = useState('succession');
  const [showStressTest, setShowStressTest] = useState(false);
  const [selectedTopic, setSelectedTopic] = useState(null);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [showConsolidatedDashboard, setShowConsolidatedDashboard] = useState(false);
  const [selectedCurrency, setSelectedCurrency] = useState('EUR');
  const [selectedJurisdiction, setSelectedJurisdiction] = useState('FR');
  const [showConsolidationDetails, setShowConsolidationDetails] = useState(false);
  const [selectedConsolidationItem, setSelectedConsolidationItem] = useState(null);
  const [showFATCAModal, setShowFATCAModal] = useState(false);
  const [generatingReport, setGeneratingReport] = useState(false);
  const [selectedReportType, setSelectedReportType] = useState('');

  const getConsolidationContent = (itemTitle) => {
    const contentMap = {
      'Valorisation temps réel': {
        title: 'Valorisation Temps Réel',
        subtitle: 'Conversion automatique et valorisation instantanée multi-devises',
        description: 'Système de valorisation en temps réel utilisant les taux de change actualisés toutes les minutes avec prise en compte des spreads et impacts fiscaux.',
        color: 'from-blue-500 to-cyan-600',
        icon: 'ri-refresh-line',
        stats: {
          'Devises supportées': '25+',
          'Fréquence MAJ': '1 min',
          'Précision': '99.9%',
          'Latence': '<100ms'
        },
        features: [
          {
            title: 'Conversion temps réel',
            description: 'Taux de change mis à jour en continu',
            details: 'Intégration avec les principales plateformes de change pour des taux actualisés en temps réel avec gestion des spreads bid/ask.',
            examples: ['EUR/USD: 1.0892 (spread: 0.0003)', 'GBP/EUR: 1.1456 (spread: 0.0005)', 'CHF/EUR: 1.0234 (spread: 0.0002)']
          },
          {
            title: 'Alertes automatiques',
            description: 'Notifications en cas de variations importantes',
            details: 'Système d\'alertes personnalisables avec seuils configurables et notifications push pour les mouvements significatifs.',
            examples: ['Alerte si variation >2%', 'Notification seuil psychologique', 'Rappel rééquilibrage mensuel']
          }
        ],
        benefits: [
          'Valorisation instantanée du patrimoine',
          'Détection rapide des opportunités',
          'Gestion proactive des risques de change',
          'Optimisation des moments de transfert'
        ]
      },
      'Gestion fiscale multi-juridictions': {
        title: 'Gestion Fiscale Multi-Juridictions',
        subtitle: 'Application automatique des règles fiscales par pays',
        description: 'Base de données fiscale exhaustive avec calcul automatique des impôts locaux et optimisation des structures selon la résidence.',
        color: 'from-green-500 to-emerald-600',
        icon: 'ri-government-line',
        stats: {
          'Juridictions': '45+',
          'Conventions': '2,800+',
          'Règles fiscales': '15,000+',
          'MAJ réglementaire': 'Quotidienne'
        },
        features: [
          {
            title: 'Règles fiscales automatiques',
            description: 'Application des conventions fiscales',
            details: 'Système expert appliquant automatiquement les règles fiscales locales et les conventions bilatérales pour optimiser la fiscalité.',
            examples: ['Convention France-Suisse', 'Crédit d\'impôt étranger US', 'Optimisation holding luxembourgeoise']
          },
          {
            title: 'Simulation d\'impact',
            description: 'Calcul prévisionnel avant opérations',
            details: 'Outil de simulation permettant d\'évaluer l\'impact fiscal avant toute opération transfrontalière.',
            examples: ['Impact transfert de résidence', 'Optimisation donation internationale', 'Restructuration patrimoniale']
          }
        ],
        benefits: [
          'Conformité fiscale automatique',
          'Optimisation des structures',
          'Réduction des risques de redressement',
          'Maximisation de l\'efficacité fiscale'
        ]
      },
      'Optimisation fiscale internationale': {
        title: 'Optimisation Fiscale Internationale',
        subtitle: 'Stratégies d\'optimisation patrimoniale globale',
        description: 'Analyse approfondie des opportunités d\'optimisation fiscale avec recommandations personnalisées selon votre situation.',
        color: 'from-purple-500 to-pink-600',
        icon: 'ri-lightbulb-line',
        stats: {
          'Économies moyennes': '25%',
          'Stratégies': '150+',
          'Pays optimisés': '35+',
          'Succès client': '94%'
        },
        features: [
          {
            title: 'Analyse des opportunités',
            description: 'Identification des leviers d\'optimisation',
            details: 'Analyse complète de votre situation pour identifier les meilleures opportunités d\'optimisation fiscale internationale.',
            examples: ['Holding de participation', 'Optimisation résidence fiscale', 'Structures de family office']
          },
          {
            title: 'Recommandations personnalisées',
            description: 'Stratégies adaptées à votre profil',
            details: 'Recommandations sur mesure tenant compte de votre situation personnelle, familiale et patrimoniale.',
            examples: ['Plan de transmission optimisé', 'Restructuration internationale', 'Optimisation revenus passifs']
          }
        ],
        benefits: [
          'Réduction significative de la fiscalité',
          'Structures pérennes et sécurisées',
          'Conformité réglementaire garantie',
          'Accompagnement personnalisé'
        ]
      }
    };

    return contentMap[itemTitle] || null;
  };

  const handleTopicClick = (topic) => {
    setSelectedTopic(topic);
    setShowDetailModal(true);
  };

  const stressTestParams = {
    urgentNeed: 50000,
    timeframe: 30,
    deathCapital: 100000,
    creditLine: 20000,
    cash: 15000,
    lifeInsurance: 80000,
    realestate: 200000,
    stocks: 60000,
    bonds: 40000,
    crypto: 10000
  };

  const stressScenarios = [
    { name: 'Optimiste', cashDiscount: 0, lifeDiscount: 5, realestateDiscount: 15, stocksDiscount: 10, bondsDiscount: 2, cryptoDiscount: 30 },
    { name: 'Réliste', cashDiscount: 0, lifeDiscount: 15, realestateDiscount: 30, stocksDiscount: 25, bondsDiscount: 5, cryptoDiscount: 50 },
    { name: 'Pessimiste', cashDiscount: 0, lifeDiscount: 30, realestateDiscount: 50, stocksDiscount: 40, bondsDiscount: 10, cryptoDiscount: 70 }
  ];

  const calculateStressTest = () => {
    return stressScenarios.map(scenario => {
      const availableCash = stressTestParams.cash;
      const availableCredit = stressTestParams.creditLine;
      const availableDeathCapital = stressTestParams.timeframe <= 90 ? stressTestParams.deathCapital : 0;

      const lifeInsuranceValue = stressTestParams.lifeInsurance * (1 - scenario.lifeDiscount / 100);
      const realestateValue = stressTestParams.realestate * (1 - scenario.realestateDiscount / 100);
      const stocksValue = stressTestParams.stocks * (1 - scenario.stocksDiscount / 100);
      const bondsValue = stressTestParams.bonds * (1 - scenario.bondsDiscount / 100);
      const cryptoValue = stressTestParams.crypto * (1 - scenario.cryptoDiscount / 100);

      const totalAvailable = availableCash + availableCredit + availableDeathCapital + lifeInsuranceValue + realestateValue + stocksValue + bondsValue + cryptoValue;

      const coverage = (totalAvailable / stressTestParams.urgentNeed) * 100;

      return {
        scenario: scenario.name,
        totalAvailable,
        coverage,
        breakdown: {
          cash: availableCash,
          credit: availableCredit,
          deathCapital: availableDeathCapital,
          lifeInsurance: lifeInsuranceValue,
          realestate: realestateValue,
          stocks: stocksValue,
          bonds: bondsValue,
          crypto: cryptoValue
        }
      };
    });
  };

  const consolidatedData = {
    totalPatrimony: {
      EUR: 2450000,
      USD: 2695000,
      GBP: 2156000,
      CHF: 2403000,
      JPY: 332500000
    },
    assets: [
      {
        type: 'Immobilier',
        jurisdiction: 'France',
        currency: 'EUR',
        value: 850000,
        percentage: 34.7,
        taxRate: 30,
        reportingRequired: false,
        lastUpdate: '2024-01-15'
      },
      {
        type: 'Actions',
        jurisdiction: 'États-Unis',
        currency: 'USD',
        value: 456000,
        percentage: 18.6,
        taxRate: 28,
        reportingRequired: true,
        lastUpdate: '2024-01-15'
      },
      {
        type: 'Obligations',
        jurisdiction: 'Suisse',
        currency: 'CHF',
        value: 320000,
        percentage: 13.1,
        taxRate: 15,
        reportingRequired: true,
        lastUpdate: '2024-01-15'
      },
      {
        type: 'Assurance-vie',
        jurisdiction: 'Luxembourg',
        currency: 'EUR',
        value: 280000,
        percentage: 11.4,
        taxRate: 12,
        reportingRequired: true,
        lastUpdate: '2024-01-15'
      },
      {
        type: 'Cryptomonnaies',
        jurisdiction: 'Singapour',
        currency: 'USD',
        value: 125000,
        percentage: 5.1,
        taxRate: 0,
        reportingRequired: true,
        lastUpdate: '2024-01-15'
      },
      {
        type: 'Fonds d\'investissement',
        jurisdiction: 'Royaume-Uni',
        currency: 'GBP',
        value: 189000,
        percentage: 7.7,
        taxRate: 20,
        reportingRequired: true,
        lastUpdate: '2024-01-15'
      }
    ],
    exchangeRates: {
      'USD/EUR': 0.91,
      'GBP/EUR': 1.14,
      'CHF/EUR': 1.02,
      'JPY/EUR': 0.0074
    },
    reportingObligations: [
      {
        type: 'FATCA',
        jurisdiction: 'États-Unis',
        deadline: '2024-03-15',
        status: 'En cours',
        amount: 456000,
        currency: 'USD'
      },
      {
        type: 'CRS',
        jurisdiction: 'Suisse',
        deadline: '2024-04-30',
        status: 'À faire',
        amount: 320000,
        currency: 'CHF'
      },
      {
        type: 'Déclaration 3916',
        jurisdiction: 'France',
        deadline: '2024-05-31',
        status: 'Planifié',
        amount: 1290000,
        currency: 'EUR'
      }
    ],
    taxOptimization: [
      {
        suggestion: 'Utiliser le crédit d\'impôt étranger pour les dividendes US',
        potentialSaving: 12800,
        currency: 'EUR',
        priority: 'Haute'
      },
      {
        suggestion: 'Restructurer via holding luxembourgeoise',
        potentialSaving: 28000,
        currency: 'EUR',
        priority: 'Moyenne'
      },
      {
        suggestion: 'Optimiser timing des plus-values crypto',
        potentialSaving: 5600,
        currency: 'EUR',
        priority: 'Basse'
      }
    ]
  };

  const currencies = ['EUR', 'USD', 'GBP', 'CHF', 'JPY'];
  const jurisdictions = [
    { code: 'FR', name: 'France', flag: '🇫🇷' },
    { code: 'US', name: 'États-Unis', flag: '🇺🇸' },
    { code: 'CH', name: 'Suisse', flag: '🇨🇭' },
    { code: 'LU', name: 'Luxembourg', flag: '🇱🇺' },
    { code: 'GB', name: 'Royaume-Uni', flag: '🇬🇧' },
    { code: 'SG', name: 'Singapour', flag: '🇸🇬' }
  ];

  const formatCurrency = (amount, currency) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const juridicalTopics = [
    {
      id: 'demembrement',
      title: 'Démembrement de Propriété',
      category: 'Stratégies Fiscales',
      color: 'from-blue-500 to-indigo-600',
      description: 'Optimisation fiscale par séparation usufruit/nue-propriété',
      icon: 'ri-git-branch-line',
      items: [
        {
          title: 'Usufruit Classique',
          description: 'Séparation temporaire entre usage et propriété pour optimiser transmissions',
          details: 'L\'usufruit permet de conserver l\'usage et les revenus d\'un bien tout en transmettant la nue-propriété. Barème fiscal dégressif selon l\'âge : 90% à 60 ans, 80% à 65 ans, 70% à 70 ans, 60% à 75 ans, 50% à 80 ans, 40% à 85 ans, 30% à 90 ans. Idéal pour optimiser les transmissions familiales tout en conservant des revenus. Durée libre ou viagère selon stratégie patrimoniale.',
          advantages: ['Transmission anticipée avec conservation revenus', 'Réduction droits mutation', 'Souplex dans durée engagement'],
          fiscality: 'Barème dégressif selon âge - Economie fiscale majeure',
          examples: 'Don usufruit résidence principale : économie 200k€ droits succession'
        },
        {
          title: 'Quasi-Usufruit',
          description: 'Usufruit sur biens consomptibles avec obligation restitution en valeur',
          details: 'Le quasi-usufruit s\'applique aux liquidités, valeurs mobilières et biens consomptibles. L\'usufruitier peut disposer librement des biens mais doit restituer l\'équivalent en valeur au terme. Fiscalité identique à l\'usufruit classique. Parfait pour transmettre des portefeuilles financiers en conservant la gestion et les revenus.',
          advantages: ['Gestion libre des capitaux', 'Conservation revenus', 'Transmission optimisée'],
          fiscality: 'Même barème que usufruit classique',
          examples: 'Portefeuille 500k€ : économie droits 150k€ + revenus conservés'
        },
        {
          title: 'Nue-Propriété Temporaire',
          description: 'Investissement avec reconstitution programmée pleine propriété',
          details: 'Stratégie d\'investissement consistant à acquérir la nue-propriété d\'un bien avec reconstitution automatique au décès usufruitier. Rendement attractif (4-7% net) et récupération garantie. Adapté investisseurs recherchant sécurité et rendement. Marché résidences seniors, immobilier commercial.',
          advantages: ['Rendement sécurisé 4-7%', 'Récupération garantie bien', 'Pas gestion locative'],
          fiscality: 'Plus-value exonérée si détention >15 ans',
          examples: 'Nue-propriété 300k€ → récupération 500k€ en 15 ans'
        },
        {
          title: 'Viager Occupé',
          description: 'Acquisition avec rente viagère et droit habitation vendeur',
          details: 'Achat d\'un bien immobilier moyennant bouquet initial et rente viagère au vendeur qui conserve droit d\'habitation. Décote 30-50% selon âge vendeur. Risque longévité compensé par prix acquisition réduit. Nécessite analyse actuarielle précise.',
          advantages: ['Prix acquisition réduit', 'Rendement potentiel élevé', 'Diversification patrimoniale'],
          fiscality: 'Rentes déductibles revenus fonciers si bien loué après libération',
          examples: 'Appartement 400k€ acquis 250k€ + rente 1000€/mois'
        }
      ]
    },
    {
      id: 'sci-familiale',
      title: 'SCI Familiale',
      category: 'Structures Patrimoniales',
      color: 'from-green-500 to-emerald-600',
      description: 'Optimisation détention immobilière et transmission familiale',
      icon: 'ri-building-2-line',
      items: [
        {
          title: 'SCI à l\'IR',
          description: 'Transparence fiscale avec imposition directe des associés',
          details: 'Régime fiscal transparent : revenus et charges imputés directement aux associés au prorata parts. Permet imputation déficits fonciers sur revenus globaux (limite 10 700€/an + report). Idéal optimisation fiscale revenus locatifs en famille et transmission progressive par donations parts.',
          advantages: ['Déficits fonciers déductibles', 'Transmission progressive', 'Souplesse gestion'],
          fiscality: 'Transparence fiscale - Déficits imputables revenus globaux',
          examples: 'SCI familiale 800k€ : donation 50k€ parts/an = transmission 15 ans'
        },
        {
          title: 'SCI à l\'IS',
          description: 'Société soumise impôt sociétés pour patrimoine important',
          details: 'Option pour IS avec taux réduit 15% premiers 38 120€ puis 25%. Constitution réserves et autofinancement possibles. Plus-values cession privilégiées. Adapté patrimoines immobiliers importants et stratégies développement. Attention régime distributions.',
          advantages: ['Constitution de réserves', 'Taux IS avantageux début', 'Plus-values privilégiées'],
          fiscality: 'IS 15% puis 25% - Plus-values société privilégiées',
          examples: 'SCI IS : réinvestissement bénéfices sans fiscalité immédiate'
        },
        {
          title: 'SCI de Jouissance',
          description: 'Organisation usage périodique bien immobilier familial',
          details: 'Chaque associé dispose droit usage périodique selon parts détenues. Évite conflits familiaux résidences secondaires. Facilite transmission tout organisant usage équitable. Aucun revenu locatif imposable car usage personnel. Statuts précis obligatoires.',
          advantages: ['Évite conflits familiaux', 'Usage organisé équitable', 'Pas revenus imposables'],
          fiscality: 'Aucune fiscalité usage personnel',
          examples: 'Résidence secondaire : 4 enfants = usage 3 mois chacun'
        },
        {
          title: 'SCI avec Démembrement',
          description: 'Combinaison SCI et démembrement pour optimisation maximale',
          details: 'Structure sophistiquée combinant SCI et démembrement parts sociales. Parents conservent usufruit parts (revenus) et transmettent nue-propriété enfants. Double optimisation : structure SCI + démembrement. Transmission progressive et gestion centralisée.',
          advantages: ['Double optimisation fiscale', 'Transmission progressive', 'Conservation revenus'],
          fiscality: 'Barème démembrement applicable aux parts sociales',
          examples: 'SCI 1M€ démembrée : économie 300-500k€ droits succession'
        }
      ]
    },
    {
      id: 'assurance-vie',
      title: 'Assurance-Vie & Capitalisation',
      category: 'Optimisation Fiscale',
      color: 'from-purple-500 to-violet-600',
      description: 'Enveloppes privilégiées pour épargne et transmission',
      icon: 'ri-shield-user-line',
      items: [
        {
          title: 'Contrats Luxembourgeois',
          description: 'Triangle sécurité et diversification internationale renforcée',
          details: 'Sécurité maximale : ségrégation actifs, garantie 100% et fonds garantie. Accès fonds institutionnels fermés grand public. Gestion privée personnalisée avec family office. Fiscalité française applicable mais protection renforcée capitaux. Minimum 125k€ généralement.',
          advantages: ['Sécurité juridique renforcée', 'Fonds institutionnels exclusifs', 'Gestion family office'],
          fiscality: 'Fiscalité française + protection patrimoniale Luxembourg',
          examples: 'Contrat 500k€ : accès fonds rendement 8-12% nets'
        },
        {
          title: 'Assurance-Vie Multi-Support Premium',
          description: 'Contrats haut de gamme avec gestion institutionnelle',
          details: 'Combinaison fonds euros garantis et UC performance. Gestion libre, mandat personnalisé ou pilotage algorithmique. Fiscalité dégressive : 35% <4ans, 15% 4-8ans, 7,5% >8ans. Abattement 4 600€/an (9 200€ couple) sur rachats. Contrats premium : fonds exclusifs, frais négociés.',
          advantages: ['Fiscalité dégressive avantageuse', 'Fonds exclusifs premium', 'Gestion professionnelle'],
          fiscality: 'Fiscalité dégressive + abattements annuels',
          examples: 'Rachat 50k€ après 8 ans : imposition 7,5% sur 40 400€'
        },
        {
          title: 'Contrat de Capitalisation',
          description: 'Alternative assurance-vie pour personnes morales et non-résidents',
          details: 'Accessible SCI, sociétés et non-résidents. Même fiscalité assurance-vie mais pas clause bénéficiaire. Idéal stratégies patrimoniales entreprise et optimisation trésorerie structures. Transmission par donation/succession classique.',
          advantages: ['Accessible personnes morales', 'Même fiscalité AV', 'Optimisation trésorerie'],
          fiscality: 'Identique assurance-vie sans clause bénéficiaire',
          examples: 'SCI : optimisation trésorerie + fiscalité privilégiée'
        },
        {
          title: 'PERP/PER - Retraite Supplémentaire',
          description: 'Épargne retraite avec déduction fiscale et transmission optimisée',
          details: 'Plans épargne retraite avec déduction fiscale versements (limite 10% revenus). Sortie rente ou capital (depuis PER). Fiscalité privilégiée transmission : exonération droits succession si décès avant 62 ans. Réversion conjoint possible.',
          advantages: ['Déduction fiscale versements', 'Transmission privilégiée', 'Réversion possible'],
          fiscality: 'Déduction versements + transmission exonérée <62 ans',
          examples: 'Versement 20k€/an : économie fiscale 6-9k€ selon TMI'
        }
      ]
    },
    {
      id: 'transmission',
      title: 'Stratégies de Transmission',
      category: 'Succession & Donation',
      color: 'from-orange-500 to-red-600',
      description: 'Techniques avancées optimisation transmissions patrimoniales',
      icon: 'ri-parent-line',
      items: [
        {
          title: 'Donation-Partage Complexe',
          description: 'Transmission et répartition définitive avec clause retour',
          details: 'Permet transmettre et répartir simultanément entre héritiers avec valeurs figées au jour donation. Possibilité clauses retour conventionnel, réserve usufruit, charge entretien. Évite rapports successoraux futurs. Abattements : 100k€/enfant, 31 865€/petit-enfant.',
          advantages: ['Valeurs figées donation', 'Évite conflits successoraux', 'Clauses protectrices'],
          fiscality: 'Abattements renouvelables tous 15 ans',
          examples: 'Donation 800k€ 4 enfants : économie 300k€ droits succession'
        },
        {
          title: 'Pacte Dutreil Renforcé',
          description: 'Transmission entreprise familiale avec exonération 75% optimisée',
          details: 'Engagement collectif conservation 2 ans puis individuel 4 ans. Exonération 75% droits transmission sur parts détenues. Conditions strictes : détention 25%, exercice activité, engagement maintien. Possibilité manager-package et clause préemption.',
          advantages: ['Exonération 75% droits', 'Transmission entreprise facilitée', 'Clauses protection'],
          fiscality: 'Économie fiscale majeure 75% droits mutation',
          examples: 'Entreprise 2M€ : économie 750k€ droits + optimisation structure'
        },
        {
          title: 'Fiducie-Libéralité',
          description: 'Trust français pour gestion et transmission sophistiquée',
          details: 'Constituant transfère biens fiduciaire durée déterminée (max 99 ans). Protection actifs, gestion professionnelle, transmission programmée. Fiscalité transparente ou IR selon cas. Outil sophistiqué gros patrimoines nécessitant gestion complexe multigénérationnelle.',
          advantages: ['Protection actifs optimale', 'Gestion professionnelle', 'Transmission programmée'],
          fiscality: 'Transparence fiscale selon modalités',
          examples: 'Patrimoine 5M€ : protection + gestion + transmission 3 générations'
        },
        {
          title: 'Libéralités Graduelles',
          description: 'Transmission avec substitution fidéicommissaire pour protection',
          details: 'Donation/legs avec obligation conservation et transmission génération suivante. Protection contre dilapidation héritiers, créanciers, divorces. Durée limitée une génération. Technique sophistiquée nécessitant rédaction notariale précise.',
          advantages: ['Protection multi-générationnelle', 'Évite dilapidation', 'Transmission sécurisée'],
          fiscality: 'Droits perçus chaque transmission selon barème',
          examples: 'Patrimoine familial : protection 2 générations garantie'
        }
      ]
    },
    {
      id: 'defiscalisation',
      title: 'Défiscalisation & Réductions',
      category: 'Optimisation Fiscale',
      color: 'from-pink-500 to-rose-600',
      description: 'Dispositifs investissement avec avantages fiscaux',
      icon: 'ri-money-dollar-circle-line',
      items: [
        {
          title: 'Loi Pinel+ Optimisée',
          description: 'Investissement locatif réduction impôt renforcée avec stratégie sortie',
          details: 'Réduction 12% à 21% selon durée engagement (6-12 ans). Plafond 300k€/an, 5 500€/m². Conditions : zones éligibles, plafonds ressources/loyers, BBC. Stratégie sortie : revente ou conservation selon évolution fiscale. Attention plus-values futures.',
          advantages: ['Réduction impôt immédiate', 'Constitution patrimoine', 'Revenus locatifs'],
          fiscality: 'Réduction 12-21% + revenus locatifs imposables',
          examples: 'Investissement 300k€ : réduction 36-63k€ + loyers'
        },
        {
          title: 'LMNP Censi-Bouvard Premium',
          description: 'Meublé professionnel avec amortissement et réduction optimisés',
          details: 'Statut LMNP avec récupération TVA et amortissement bien/mobilier. Réduction Censi-Bouvard 11% sur 9 ans. Revenus défiscalisés par amortissements. Résidences services haut de gamme, étudiantes premium, seniors. Rentabilité nette optimisée.',
          advantages: ['Amortissements défiscalisants', 'Réduction 11%', 'Revenus nets élevés'],
          fiscality: 'Réduction + amortissements + récupération TVA',
          examples: 'LMNP 400k€ : réduction 44k€ + revenus défiscalisés 15 ans'
        },
        {
          title: 'Monuments Historiques & Malraux',
          description: 'Investissement patrimonial culturel avec déductions exceptionnelles',
          details: 'MH : déduction 100% travaux revenus globaux sans plafond. Malraux : 22-30% réduction selon secteur. Conservation 15 ans minimum. Investissement patrimonial et culturel exigeant. Expertise technique juridique indispensable.',
          advantages: ['Dédutions/réductions importantes', 'Patrimoine exceptionnel', 'Plus-values potentielles'],
          fiscality: 'MH: déduction 100% - Malraux: réduction 22-30%',
          examples: 'MH 500k€ travaux : déduction totale si revenus suffisants'
        },
        {
          title: 'Outre-Mer & Girardin',
          description: 'Investissements DOM-TOM avec défiscalisation renforcée',
          details: 'Réductions IR jusqu\'à 120% montant investi (plafond). Girardin industriel/logement social. Investissements productifs outre-mer. Montages sophistiqués avec garanties bancaires. Risques spécifiques nécessitant due diligence approfondie.',
          advantages: ['Réductions exceptionnelles >100%', 'Diversification géographique', 'Garanties possibles'],
          fiscality: 'Réductions 110-120% selon dispositifs',
          examples: 'Girardin 100k€ : réduction 110-120k€ selon montage'
        }
      ]
    },
    {
      id: 'holding-patrimoniale',
      title: 'Holding & Structures Avancées',
      category: 'Ingénierie Patrimoniale',
      color: 'from-indigo-500 to-blue-600',
      description: 'Structures sophistiquées pour gros patrimoines',
      icon: 'ri-organization-chart',
      items: [
        {
          title: 'Holding Animatrice Familiale',
          description: 'Structure active contrôle participations avec services centralisés',
          details: 'Exercice contrôle effectif filiales avec prestations services (admin, compta, juridique). Régime mère-fille : exonération dividendes reçus. Éligibilité pacte Dutreil. Optimisation fiscale plus-values cessions. Structuration grandes fortunes familiales.',
          advantages: ['Régime mère-fille', 'Pacte Dutreil éligible', 'Services centralisés'],
          fiscality: 'Exonération dividendes + plus-values privilégiées',
          examples: 'Holding 3 filiales : dividendes exonérés + services facturés'
        },
        {
          title: 'Holding Passive Patrimoniale',
          description: 'Véhicule détention participations et patrimoine diversifié',
          details: 'Structure détention passive participations/immobilier. Régime moins favorable mais simplicité. Facilite transmissions donations parts. Mutualisation risques. Gestion centralisée revenus capitaux mobiliers. Optimisation selon composition portefeuille.',
          advantages: ['Transmission facilitée', 'Mutualisation risques', 'Gestion centralisée'],
          fiscality: 'Régime sociétés classique',
          examples: 'Holding patrimoniale : immobilier + participations + liquidités'
        },
        {
          title: 'Structure LBO Familial',
          description: 'Acquisition entreprise familiale avec effet levier optimisé',
          details: 'Montage acquisition entreprise par holding avec financement bancaire. Effet levier optimisant rentabilité fonds propres. Déduction intérêts emprunt. Transmission progressive par donations parts holding. Montage complexe nécessitant expertise.',
          advantages: ['Effet levier financier', 'Optimisation transmission', 'Déduction intérêts'],
          fiscality: 'Déduction intérêts + transmission optimisée',
          examples: 'Acquisition 2M€ : apport 500k€ + emprunt 1,5M€'
        },
        {
          title: 'Trust Français Complexe',
          description: 'Fiducie multigénérationnelle avec gestion institutionnelle',
          details: 'Structure fiduciaire française pour gestion patrimoine complexe. Durée maximale 99 ans. Gestion professionnelle institutionnelle. Transmission programmée plusieurs générations. Protection optimale actifs. Fiscalité selon modalités constitution.',
          advantages: ['Gestion institutionnelle', 'Protection maximale', 'Transmission multigénérationnelle'],
          fiscality: 'Selon modalités - transparence ou imposition trust',
          examples: 'Patrimoine 10M€ : gestion 3 générations avec protection'
        }
      ]
    },
    {
      id: 'consolidation-multidevises',
      title: 'Consolidation Multi-Devises',
      category: 'Gestion Internationale',
      color: 'from-cyan-500 to-blue-600',
      description: 'Tableau de bord consolidé multi-devises et multi-juridictions',
      icon: 'ri-global-line',
      items: [
        {
          title: 'Valorisation Temps Réel',
          description: 'Conversion automatique et valorisation instantanée multi-devises',
          details: 'Système de valorisation en temps réel utilisant les taux de change actualisés toutes les minutes. Prise en compte des spreads bid/ask, des frais de change et des impacts fiscaux. Calcul automatique des plus ou moins-values latentes de change. Alertes automatiques en cas de variations significatives.',
          advantages: ['Valorisation instantanée', 'Alertes automatiques', 'Prise en compte spreads'],
          fiscality: 'Calcul automatique plus-values change + impact fiscal',
          examples: 'Portefeuille 1M USD : suivi temps réel + alerte -2%'
        },
        {
          title: 'Gestion Fiscale Multi-Juridictions',
          description: 'Application automatique des règles fiscales par juridiction',
          details: 'Base de données fiscale mise à jour automatiquement pour chaque juridiction. Calcul des impôts locaux, des crédits d\'impôt étrangers, des conventions fiscales. Optimisation automatique des structures selon résidence fiscale. Simulation d\'impact avant opérations.',
          advantages: ['Règles fiscales automatiques', 'Optimisation structures', 'Simulation d\'impact'],
          fiscality: 'Application automatique conventions fiscales + optimisation',
          examples: 'Dividende US → Crédit d\'impôt 15% + optimisation 15%'
        },
        {
          title: 'Reporting FATCA/CRS Automatisé',
          description: 'Génération automatique des déclarations internationales',
          details: 'Système de reporting automatique conforme FATCA (États-Unis) et CRS (OCDE). Identification automatique des comptes déclarables, calcul des seuils, génération des formulaires. Calendrier des échéances, alertes préventives, archivage sécurisé. Intégration avec conseillers fiscaux.',
          advantages: ['Reporting automatique', 'Identification comptes', 'Alertes échéances'],
          fiscality: 'Conformité FATCA/CRS + archivage sécurisé',
          examples: 'Compte US 100k$ : déclaration FATCA automatique + formulaire 3520'
        },
        {
          title: 'Consolidation Patrimoniale Globale',
          description: 'Vue d\'ensemble unifiée du patrimoine international',
          details: 'Agrégation automatique de tous les actifs internationaux en devise de référence. Analyse des corrélations inter-devises, stress-tests géopolitiques, optimisation allocation géographique. Tableaux de bord personnalisés par famille d\'actifs et juridiction.',
          advantages: ['Vue globale unifiée', 'Stress-tests géopolitiques', 'Optimisation allocation'],
          fiscality: 'Analyse impact fiscal global + optimisation juridictionnelle',
          examples: 'Patrimoine 5M€ : 12 juridictions consolidées + optimisation fiscale'
        }
      ]
    }
  ];

  const categories = [
    {
      id: 'succession',
      title: 'Transmission & Succession',
      icon: 'ri-parent-line',
      color: 'from-blue-500 to-indigo-600',
      items: [
        {
          title: 'Calcul des droits de succession',
          description: 'Simulation précise selon le lien de parenté et les abattements',
          details: 'Prise en compte de tous les abattements légaux, calcul des droits selon le barème progressif, optimisation par donations antérieures.'
        },
        {
          title: 'Optimisation de transmission',
          description: 'Donation, démembrement, assurance-vie : quelle approche adopter ?',
          details: 'Comparaison des différentes approches de transmission avec calcul des économies fiscales potentielles et impact sur votre train de vie.'
        },
        {
          title: 'Pacte Dutreil entreprise',
          description: 'Transmission d\'entreprise avec réduction de 75% des droits',
          details: 'Conditions d\'éligibilité, engagements requis, et optimisation de la transmission d\'entreprise familiale avec le dispositif Dutreil.'
        }
      ]
    },
    {
      id: 'immobilier',
      title: 'Immobilier & SCI',
      icon: 'ri-building-line',
      color: 'from-orange-500 to-red-600',
      items: [
        {
          title: 'SCI : création et optimisation',
          description: 'Structure patrimoniale pour l\'immobilier familial',
          details: 'Avantages fiscaux, modalités de transmission, gestion des parts sociales, et optimisation de la détention immobilière en famille.'
        },
        {
          title: 'Démembrement immobilier',
          description: 'Usufruit/nue-propriété : approche patrimoniale avancée',
          details: 'Calcul des valeurs d\'usufruit selon l\'âge, optimisation fiscale, et méthodes de reconstitution de la pleine propriété.'
        },
        {
          title: 'Défiscalisation immobilière',
          description: 'Loi Pinel, LMNP, déficit foncier : comparatif complet',
          details: 'Analyse comparative des dispositifs de défiscalisation avec calcul de rentabilité nette et adaptation à votre situation fiscale.'
        }
      ]
    },
    {
      id: 'juridique',
      title: 'Cartographie Juridique',
      icon: 'ri-map-2-line',
      color: 'from-purple-500 to-violet-600',
      items: [
        {
          title: 'Cartographie patrimoniale interactive',
          description: 'Vue d\'ensemble complète des structures et stratégies disponibles',
          details: 'Exploration interactive des solutions juridiques et fiscales adaptées à votre situation patrimoniale avec explications détaillées, exemples concrets et chiffrages.'
        },
        {
          title: 'Calculateurs spécialisés',
          description: 'Outils de calcul avancés pour chaque stratégie patrimoniale',
          details: 'Calculateurs spécialisés : droits de succession, plus-values, IFI, donations, flat tax vs barème progressif, revenus fonciers, démembrement, pacte Dutreil.'
        },
        {
          title: 'Comparateur de stratégies',
          description: 'Analyse comparative des différentes approches patrimoniales',
          details: 'Outil comparatif sophistiqué pour évaluer l\'efficacité fiscale et patrimoniale de différentes stratégies selon votre situation personnelle.'
        }
      ]
    },
    {
      id: 'consolidation',
      title: 'Consolidation Multi-Devises',
      icon: 'ri-global-line',
      color: 'from-cyan-500 to-blue-600',
      items: [
        {
          title: 'Tableau de bord consolidé',
          description: 'Vue d\'ensemble unifiée du patrimoine international',
          details: 'Valorisation en temps réel, conversion automatique, gestion des règles fiscales locales et des obligations de reporting (FATCA, CRS). Dépasse les limites de la monnaie locale avec options manuelles.'
        },
        {
          title: 'Optimisation fiscale internationale',
          description: 'Application automatique des conventions fiscales',
          details: 'Calcul automatique des crédits d\'impôt étrangers, optimisation des structures selon résidence fiscale, simulation d\'impact avant opérations transfrontalières.'
        },
        {
          title: 'Reporting automatisé',
          description: 'Génération automatique des déclarations FATCA/CRS',
          details: 'Identification automatique des comptes déclarables, calcul des seuils, génération des formulaires avec calendrier des échéances et alertes préventives.'
        }
      ]
    }
  ];

  const handleConsolidationAccess = (itemTitle) => {
    console.log('Accessing consolidation item:', itemTitle); 
    if (itemTitle === 'Reporting automatisé') {
      setShowFATCAModal(true);
    } else {
      setSelectedConsolidationItem(itemTitle);
      setShowConsolidationDetails(true);
    }
  };

  const closeConsolidationDetails = () => {
    setShowConsolidationDetails(false);
    setSelectedConsolidationItem(null);
  };

  const closeFATCAModal = () => {
    setShowFATCAModal(false);
  };

  const generateFATCAReport = async (reportType) => {
    setGeneratingReport(true);

    try {
      // Simulation de génération de rapport
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Génération du contenu HTML pour le rapport
      const reportContent = generateReportHTML(reportType);

      // Création du fichier et téléchargement
      const blob = new Blob([reportContent], { type: 'text/html;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${reportType}_${new Date().toISOString().split('T')[0]}.html`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      alert(`Rapport ${reportType} généré et téléchargé avec succès !`);
    } catch (error) {
      console.error('Erreur lors de la génération du rapport:', error);
      alert('Erreur lors de la génération du rapport');
    } finally {
      setGeneratingReport(false);
    }
  };

  const generateReportHTML = (reportType) => {
    const reportConfigs = {
      'Form 8938': {
        title: 'Form 8938 - Statement of Specified Foreign Financial Assets',
        description: 'Déclaration des actifs financiers étrangers spécifiés',
        fields: [
          { label: 'Part I - Filer Information', type: 'section' },
          { label: 'Name', type: 'text', value: 'Client CMV Finance' },
          { label: 'Social Security Number', type: 'text', value: 'XXX-XX-XXXX' },
          { label: 'Address', type: 'text', value: '123 Main Street, Paris, France' },
          { label: 'Part II - Summary of Specified Foreign Financial Assets', type: 'section' },
          { label: 'Maximum value of specified foreign financial assets', type: 'currency', value: '$456,000' },
          { label: 'Part III - Detailed Information for Each Asset', type: 'section' },
          { label: 'Asset 1: US Brokerage Account', type: 'subsection' },
          { label: 'Financial institution name', type: 'text', value: 'Morgan Stanley' },
          { label: 'Account number', type: 'text', value: 'XXXX-XXXX-1234' },
          { label: 'Maximum value during tax year', type: 'currency', value: '$456,000' },
          { label: 'Asset 2: Swiss Bank Account', type: 'subsection' },
          { label: 'Financial institution name', type: 'text', value: 'UBS Switzerland AG' },
          { label: 'Account number', type: 'text', value: 'CH-XXXX-XXXX-5678' },
          { label: 'Maximum value during tax year', type: 'currency', value: 'CHF 320,000' }
        ],
        instructions: [
          'Remplir ce formulaire si vous êtes un contribuable américain avec des actifs financiers étrangers dépassant les seuils',
          'Seuils: $50,000 en fin d\'année ou $75,000 à tout moment (célibataire résidant aux États-Unis)',
          'Seuils doublés pour les couples mariés',
          'Déposer avec votre déclaration de revenus avant le 15 avril'
        ]
      },
      'Form 3520': {
        title: 'Form 3520 - Annual Return to Report Transactions with Foreign Trusts',
        description: 'Déclaration annuelle des transactions avec trusts étrangers',
        fields: [
          { label: 'Part I - General Information', type: 'section' },
          { label: 'Name of filer', type: 'text', value: 'Client CMV Finance' },
          { label: 'Social Security Number', type: 'text', value: 'XXX-XX-XXXX' },
          { label: 'Part II - Transactions with Foreign Trusts', type: 'section' },
          { label: 'Did you receive a distribution from a foreign trust?', type: 'checkbox', value: 'Yes' },
          { label: 'Amount of distribution', type: 'currency', value: '$125,000' },
          { label: 'Part III - Ownership of Foreign Trust', type: 'section' },
          { label: 'Are you treated as the owner of any portion of a foreign trust?', type: 'checkbox', value: 'No' },
          { label: 'Part IV - Transfers to Foreign Trust', type: 'section' },
          { label: 'Did you transfer property to a foreign trust?', type: 'checkbox', value: 'Yes' },
          { label: 'Fair market value of property transferred', type: 'currency', value: '$280,000' }
        ],
        instructions: [
          'Obligatoire pour les contribuables américains ayant des transactions avec des trusts étrangers',
          'Incluant les distributions reçues, les transferts effectués, ou la propriété de trusts',
          'Pénalités sévères en cas de non-déclaration: jusqu\'à 35% de la valeur',
          'Déposer avant le 15 avril avec prorogation automatique au 15 octobre'
        ]
      },
      'Form 3520-A': {
        title: 'Form 3520-A - Annual Information Return of Foreign Trust with a U.S. Owner',
        description: 'Déclaration annuelle d\'information d\'un trust étranger avec propriétaire américain',
        fields: [
          { label: 'Part I - General Information', type: 'section' },
          { label: 'Name of trust', type: 'text', value: 'Luxembourg Family Trust' },
          { label: 'Employer identification number', type: 'text', value: 'XX-XXXXXXX' },
          { label: 'Country of trust', type: 'text', value: 'Luxembourg' },
          { label: 'Part II - Income Statement', type: 'section' },
          { label: 'Ordinary income', type: 'currency', value: '$45,000' },
          { label: 'Capital gains', type: 'currency', value: '$23,000' },
          { label: 'Total income', type: 'currency', value: '$68,000' },
          { label: 'Part III - Balance Sheet', type: 'section' },
          { label: 'Cash and cash equivalents', type: 'currency', value: '$150,000' },
          { label: 'Securities', type: 'currency', value: '$850,000' },
          { label: 'Real estate', type: 'currency', value: '$500,000' },
          { label: 'Total assets', type: 'currency', value: '$1,500,000' }
        ],
        instructions: [
          'Requis pour les trusts étrangers ayant un propriétaire américain',
          'Doit être déposé par le trust lui-même ou son représentant',
          'Inclut les états financiers complets du trust',
          'Date limite: 15 mars de l\'année suivante'
        ]
      },
      'CRS Common Reporting Standard': {
        title: 'CRS - Common Reporting Standard Information',
        description: 'Standard commun de déclaration pour l\'échange automatique d\'informations',
        fields: [
          { label: 'Section A - Account Holder Information', type: 'section' },
          { label: 'Individual/Entity Name', type: 'text', value: 'Client CMV Finance' },
          { label: 'Address', type: 'text', value: '123 Main Street, Paris, France' },
          { label: 'Tax Identification Number', type: 'text', value: 'FR-TIN-123456789' },
          { label: 'Date of Birth', type: 'date', value: '1975-05-15' },
          { label: 'Section B - Financial Institution Information', type: 'section' },
          { label: 'Name of Financial Institution', type: 'text', value: 'UBS Switzerland AG' },
          { label: 'Address', type: 'text', value: 'Zurich, Switzerland' },
          { label: 'Section C - Account Information', type: 'section' },
          { label: 'Account Number', type: 'text', value: 'CH-XXXX-XXXX-5678' },
          { label: 'Account Balance', type: 'currency', value: 'CHF 320,000' },
          { label: 'Income/Proceeds', type: 'currency', value: 'CHF 15,000' }
        ],
        instructions: [
          'Échange automatique d\'informations entre administrations fiscales',
          'Concerne les résidents fiscaux d\'autres pays participants',
          'Transmission automatique par les institutions financières',
          'Couvre comptes bancaires, assurances-vie, fonds d\'investissement'
        ]
      },
      'FBAR FinCEN Form 114': {
        title: 'FBAR - Report of Foreign Bank and Financial Accounts',
        description: 'Déclaration des comptes bancaires et financiers étrangers',
        fields: [
          { label: 'Part I - Filer Information', type: 'section' },
          { label: 'Last Name', type: 'text', value: 'Client' },
          { label: 'First Name', type: 'text', value: 'CMV Finance' },
          { label: 'Social Security Number', type: 'text', value: 'XXX-XX-XXXX' },
          { label: 'Address', type: 'text', value: '123 Main Street, Paris, France' },
          { label: 'Part II - Financial Account Information', type: 'section' },
          { label: 'Account 1: Swiss Bank Account', type: 'subsection' },
          { label: 'Financial Institution Name', type: 'text', value: 'UBS Switzerland' },
          { label: 'Account Number', type: 'text', value: 'CH-XXXX-XXXX-5678' },
          { label: 'Maximum Account Value', type: 'currency', value: '$347,000' },
          { label: 'Account 2: Luxembourg Insurance', type: 'subsection' },
          { label: 'Financial Institution Name', type: 'text', value: 'Luxembourg Life Insurance' },
          { label: 'Account Number', type: 'text', value: 'LU-XXXX-XXXX-9012' },
          { label: 'Maximum Account Value', type: 'currency', value: '$280,000' }
        ],
        instructions: [
          'Obligatoire si total des comptes étrangers > $10,000 à tout moment',
          'Dépôt électronique uniquement sur BSA E-Filing System',
          'Date limite: 15 avril avec prorogation automatique au 15 octobre',
          'Pénalité: jusqu\'à $12,921 par compte non déclaré'
        ]
      },
      'Déclaration 3916': {
        title: 'Déclaration 3916 - Ouverture, détention ou clôture de comptes à l\'étranger',
        description: 'Déclaration française des comptes détenus à l\'étranger',
        fields: [
          { label: 'Section 1 - Identification du déclarant', type: 'section' },
          { label: 'Nom', type: 'text', value: 'Client CMV Finance' },
          { label: 'Prénom', type: 'text', value: 'Client' },
          { label: 'Numéro fiscal', type: 'text', value: '1234567890123' },
          { label: 'Adresse', type: 'text', value: '123 Main Street, Paris, France' },
          { label: 'Section 2 - Informations sur les comptes', type: 'section' },
          { label: 'Compte 1: Suisse', type: 'subsection' },
          { label: 'Établissement', type: 'text', value: 'UBS Switzerland' },
          { label: 'Pays', type: 'text', value: 'Suisse' },
          { label: 'Numéro de compte', type: 'text', value: 'CH-XXXX-XXXX-5678' },
          { label: 'Date d\'ouverture', type: 'date', value: '2020-03-15' },
          { label: 'Compte 2: Luxembourg', type: 'subsection' },
          { label: 'Établissement', type: 'text', value: 'Banque de Luxembourg' },
          { label: 'Pays', type: 'text', value: 'Luxembourg' },
          { label: 'Numéro de compte', type: 'text', value: 'LU-XXXX-XXXX-9012' },
          { label: 'Date d\'ouverture', type: 'date', value: '2019-11-20' }
        ],
        instructions: [
          'Obligatoire pour tous les comptes détenus à l\'étranger',
          'Déclaration avec la déclaration de revenus (2042)',
          'Inclut comptes bancaires, assurances-vie, comptes-titres',
          'Pénalité: 1,500€ par compte non déclaré'
        ]
      }
    };

    const config = reportConfigs[reportType];
    if (!config) return '';

    return `
      <!DOCTYPE html>
      <html lang="fr">
      <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>${config.title}</title>
          <style>
              * { margin: 0; padding: 0; box-sizing: border-box; }
              body { 
                  font-family: Arial, sans-serif;
                  line-height: 1.6;
                  color: #333;
                  background: #f5f5f5;
                  padding: 20px;
              }
              .container {
                  max-width: 800px;
                  margin: 0 auto;
                  background: white;
                  padding: 30px;
                  border-radius: 10px;
                  box-shadow: 0 0 20px rgba(0,0,0,0.1);
              }
              .header {
                  text-align: center;
                  border-bottom: 3px solid #1f2937;
                  padding-bottom: 20px;
                  margin-bottom: 30px;
              }
              .logo {
                  font-size: 24px;
                  font-weight: bold;
                  color: #1f2937;
                  margin-bottom: 10px;
                  font-family: 'Pacifico', serif;
              }
              .form-title {
                  font-size: 20px;
                  font-weight: bold;
                  color: #1f2937;
                  margin-bottom: 10px;
              }
              .form-subtitle {
                  color: #6b7280;
                  margin-bottom: 20px;
              }
              .section {
                  margin-bottom: 30px;
              }
              .section-header {
                  background: #1f2937;
                  color: white;
                  padding: 10px 15px;
                  font-weight: bold;
                  margin-bottom: 15px;
                  border-radius: 5px;
              }
              .subsection-header {
                  background: #374151;
                  color: white;
                  padding: 8px 12px;
                  font-weight: bold;
                  margin: 15px 0 10px 0;
                  border-radius: 3px;
                  font-size: 14px;
              }
              .form-group {
                  margin-bottom: 15px;
                  display: flex;
                  align-items: center;
              }
              .form-label {
                  width: 40%;
                  font-weight: medium;
                  color: #374151;
                  padding-right: 15px;
              }
              .form-value {
                  width: 60%;
                  padding: 8px 12px;
                  border: 2px solid #e5e7eb;
                  border-radius: 5px;
                  background: #f9fafb;
                  font-family: monospace;
              }
              .instructions {
                  background: #dbeafe;
                  border: 1px solid #3b82f6;
                  border-radius: 8px;
                  padding: 20px;
                  margin-top: 30px;
              }
              .instructions h3 {
                  color: #1e40af;
                  margin-bottom: 15px;
              }
              .instructions ul {
                  color: #1e40af;
                  padding-left: 20px;
              }
              .instructions li {
                  margin-bottom: 8px;
              }
              .footer {
                  text-align: center;
                  margin-top: 40px;
                  padding-top: 20px;
                  border-top: 1px solid #e5e7eb;
                  color: #6b7280;
                  font-size: 14px;
              }
              .status-badge {
                  display: inline-block;
                  padding: 4px 12px;
                  background: #10b981;
                  color: white;
                  border-radius: 20px;
                  font-size: 12px;
                  font-weight: bold;
                  margin-left: 10px;
              }
              .warning {
                  background: #fef3c7;
                  border: 1px solid #f59e0b;
                  border-radius: 8px;
                  padding: 15px;
                  margin: 20px 0;
                  color: #92400e;
              }
              .checkbox-field {
                  width: 20px;
                  height: 20px;
                  margin-right: 10px;
              }
              @media print {
                  body { background: white; padding: 0; }
                  .container { box-shadow: none; }
              }
          </style>
      </head>
      <body>
          <div class="container">
              <div class="header">
                  <div class="logo">CMV FINANCE</div>
                  <div class="form-title">${config.title}</div>
                  <div class="form-subtitle">${config.description}</div>
                  <div style="margin-top: 15px;">
                      <span>Date de génération: ${new Date().toLocaleDateString('fr-FR')}</span>
                      <span class="status-badge">GÉNÉRÉ AUTOMATIQUEMENT</span>
                  </div>
              </div>

              <div class="warning">
                  <strong>⚠️ ATTENTION:</strong> Ce document est généré automatiquement à partir de vos données. 
                  Veuillez vérifier toutes les informations avant soumission aux autorités fiscales.
              </div>

              ${config.fields.map(field => {
                if (field.type === 'section') {
                  return `<div class="section-header">${field.label}</div>`;
                } else if (field.type === 'subsection') {
                  return `<div class="subsection-header">${field.label}</div>`;
                } else if (field.type === 'checkbox') {
                  return `
                    <div class="form-group">
                        <div class="form-label">${field.label}</div>
                        <div class="form-value">
                            <input type="checkbox" class="checkbox-field" ${field.value === 'Yes' ? 'checked' : ''} disabled>
                            ${field.value}
                        </div>
                    </div>
                  `;
                } else {
                  return `
                    <div class="form-group">
                        <div class="form-label">${field.label}:</div>
                        <div class="form-value">${field.value || 'À compléter'}</div>
                    </div>
                  `;
                }
              }).join('')}

              <div class="instructions">
                  <h3>Instructions Importantes</h3>
                  <ul>
                      ${config.instructions.map(instruction => `<li>${instruction}</li>`).join('')}
                  </ul>
              </div>

              <div class="footer">
                  <p><strong>CMV Finance - Conseil en Gestion de Patrimoine</strong></p>
                  <p>123 Avenue des Champs-Élysées, 75008 Paris</p>
                  <p>Tél: +33 1 23 45 67 89 | Email: reporting@cmvfinance.com</p>
                  <p style="margin-top: 15px; font-size: 12px;">
                      Document généré automatiquement le ${new Date().toLocaleDateString('fr-FR')} à ${new Date().toLocaleTimeString('fr-FR')}
                  </p>
                  <p style="font-size: 12px; color: #ef4444;">
                      Ce document est confidentiel et destiné exclusivement au client mentionné ci-dessus.
                  </p>
              </div>
          </div>
      </body>
      </html>
    `;
  };

  React.useEffect(() => {
    const handleEscapeKey = (event) => {
      if (event.key === 'Escape') {
        closeConsolidationDetails();
        closeFATCAModal();
      }
    };

    if (showConsolidationDetails || showFATCAModal) {
      document.addEventListener('keydown', handleEscapeKey);
      return () => document.removeEventListener('keydown', handleEscapeKey);
    }
  }, [showConsolidationDetails, showFATCAModal]);

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
          <i className="ri-settings-3-line text-white text-xl"></i>
        </div>
        <div>
          <h3 className="text-xl font-bold text-gray-900">Ingénierie Patrimoniale</h3>
          <p className="text-gray-600 text-sm">Solutions avancées de gestion de patrimoine</p>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-6 border-b border-gray-200">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => setActiveTab(category.id)}
            className={`flex items-center space-x-2 px-4 py-2 rounded-t-lg transition-all whitespace-nowrap ${activeTab === category.id ? 'bg-blue-50 border-b-2 border-blue-500 text-blue-700' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'}`}
          >
            <i className={`${category.icon} text-lg`}></i>
            <span className="font-medium">{category.title}</span>
          </button>
        ))}
      </div>

      <div className="space-y-4">
        {activeTab === 'consolidation' && (
          <>
            <div className="bg-gradient-to-r from-cyan-50 to-blue-50 rounded-lg p-6 border border-cyan-200 mb-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h4 className="font-semibold text-cyan-900 mb-3 text-xl">Tableau de Bord Consolidé Multi-Devises</h4>
                  <p className="text-cyan-700 text-sm">
                    Gérez votre patrimoine international avec valorisation temps réel, conversion automatique et gestion des règles fiscales locales.
                  </p>
                </div>
                <button
                  onClick={() => setShowConsolidatedDashboard(!showConsolidatedDashboard)}
                  className="px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700 transition-colors whitespace-nowrap"
                >
                  {showConsolidatedDashboard ? 'Masquer' : 'Afficher'} le Dashboard
                </button>
              </div>

              {showConsolidatedDashboard && (
                <div className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Devise de référence</label>
                      <select
                        value={selectedCurrency}
                        onChange={(e) => setSelectedCurrency(e.target.value)}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:border-cyan-500 focus:outline-none"
                      >
                        {currencies.map((currency) => (
                          <option key={currency} value={currency}>
                            {currency}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Juridiction principale</label>
                      <select
                        value={selectedJurisdiction}
                        onChange={(e) => setSelectedJurisdiction(e.target.value)}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:border-cyan-500 focus:outline-none"
                      >
                        {jurisdictions.map((jurisdiction) => (
                          <option key={jurisdiction.code} value={jurisdiction.code}>
                            {jurisdiction.flag} {jurisdiction.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-lg border border-gray-200">
                    <h5 className="font-semibold text-gray-900 mb-4">Patrimoine Total Consolidé</h5>
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                      {currencies.map((currency) => (
                        <div key={currency} className="text-center">
                          <div className="text-2xl font-bold text-gray-900">
                            {formatCurrency(consolidatedData.totalPatrimony[currency], currency)}
                          </div>
                          <div className="text-sm text-gray-600">{currency}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-lg border border-gray-200">
                    <h5 className="font-semibold text-gray-900 mb-4">Répartition par Juridiction</h5>
                    <div className="space-y-4">
                      {consolidatedData.assets.map((asset, index) => (
                        <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                          <div className="flex items-center space-x-4">
                            <div className="w-12 h-12 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-lg flex items-center justify-center">
                              <i className="ri-building-line text-white text-xl"></i>
                            </div>
                            <div>
                              <div className="font-semibold text-gray-900">{asset.type}</div>
                              <div className="text-sm text-gray-600">
                                {jurisdictions.find((j) => j.code === asset.jurisdiction.substring(0, 2))?.flag}
                                {` `} {asset.jurisdiction} • {asset.currency}
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-bold text-gray-900">
                              {formatCurrency(asset.value, asset.currency)}
                            </div>
                            <div className="text-sm text-gray-600">{asset.percentage}% du total</div>
                            <div className="text-xs text-gray-500">
                              Fiscal: {asset.taxRate}% • {asset.reportingRequired ? 'Déclarable' : 'Non déclarable'}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-lg border border-gray-200">
                    <h5 className="font-semibold text-gray-900 mb-4">Obligations de Reporting</h5>
                    <div className="space-y-3">
                      {consolidatedData.reportingObligations.map((obligation, index) => (
                        <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                          <div className="flex items-center space-x-3">
                            <div
                              className={`w-3 h-3 rounded-full ${obligation.status === 'En cours' ? 'bg-blue-500' : obligation.status === 'À faire' ? 'bg-red-500' : 'bg-yellow-500'
                                }`}
                            ></div>
                            <div>
                              <div className="font-semibold text-gray-900">{obligation.type}</div>
                              <div className="text-sm text-gray-600">{obligation.jurisdiction}</div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-bold text-gray-900">
                              {formatCurrency(obligation.amount, obligation.currency)}
                            </div>
                            <div className="text-sm text-gray-600">Échéance: {obligation.deadline}</div>
                            <div
                              className={`text-xs px-2 py-1 rounded-full ${obligation.status === 'En cours' ? 'bg-blue-100 text-blue-800' : obligation.status === 'À faire' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'
                                }`}
                            >
                              {obligation.status}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-lg border border-gray-200">
                    <h5 className="font-semibold text-gray-900 mb-4">Optimisations Fiscales Détectées</h5>
                    <div className="space-y-3">
                      {consolidatedData.taxOptimization.map((optimization, index) => (
                        <div key={index} className="flex items-center justify-between p-4 bg-green-50 rounded-lg border border-green-200">
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                              <i className="ri-lightbulb-line text-white text-sm"></i>
                            </div>
                            <div>
                              <div className="font-semibold text-gray-900">{optimization.suggestion}</div>
                              <div className="text-sm text-gray-600">Priorité: {optimization.priority}</div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-bold text-green-600">
                              +{formatCurrency(optimization.potentialSaving, optimization.currency)}
                            </div>
                            <div className="text-sm text-gray-600">Économie potentielle</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white p-6 rounded-lg border border-gray-200">
                    <h5 className="font-semibold text-gray-900 mb-4">Taux de Change (Temps Réel)</h5>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {Object.entries(consolidatedData.exchangeRates).map(([pair, rate]) => (
                        <div key={pair} className="text-center p-3 bg-gray-50 rounded-lg">
                          <div className="font-semibold text-gray-900">{pair}</div>
                          <div className="text-lg font-bold text-blue-600">{rate}</div>
                          <div className="text-xs text-gray-500">Mis à jour: {new Date().toLocaleTimeString()}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {juridicalTopics.filter((topic) => topic.id === 'consolidation-multidevises').map((topic) => (
                <div
                  key={topic.id}
                  className={`bg-gradient-to-br ${topic.color} rounded-xl p-6 text-white cursor-pointer hover:shadow-xl transition-all transform hover:-translate-y-2 hover:scale-105`}
                  onClick={() => handleTopicClick(topic)}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                      <i className={`${topic.icon} text-2xl text-white`}></i>
                    </div>
                    <i className="ri-arrow-right-line text-2xl opacity-75"></i>
                  </div>

                  <h5 className="font-bold text-xl mb-2">{topic.title}</h5>
                  <p className="text-white/90 text-sm mb-4 line-clamp-2">{topic.description}</p>

                  <div className="flex items-center justify-between mb-4">
                    <span className="bg-white/20 px-3 py-1 rounded-full text-xs font-semibold">
                      {topic.category}
                    </span>
                    <span className="text-white/80 text-sm font-medium">
                      {topic.items.length} solutions
                    </span>
                  </div>

                  <div className="border-t border-white/20 pt-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-white/90">Multi-juridictions</span>
                      <span className="bg-white/30 px-2 py-1 rounded text-xs font-bold">Avancé</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {categories
              .find((cat) => cat.id === activeTab)
              ?.items.slice(1)
              .map((item, index) => (
                <div key={index} className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-lg p-4 border border-gray-200">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900 mb-2">{item.title}</h4>
                      <p className="text-gray-600 text-sm mb-3">{item.description}</p>
                      <p className="text-gray-700 text-xs leading-relaxed">{item.details}</p>
                    </div>
                    <div className="ml-4">
                      <button
                        onClick={() => handleConsolidationAccess(item.title)}
                        className="bg-cyan-600 text-white px-4 py-2 rounded-lg hover:bg-cyan-700 transition-colors cursor-pointer whitespace-nowrap"
                      >
                        Accéder
                      </button>
                    </div>
                  </div>
                </div>
              ))}
          </>)
        }

        {activeTab === 'juridique' && (
          <>
            <div className="bg-gradient-to-r from-purple-50 to-violet-50 rounded-lg p-6 border border-purple-200 mb-6">
              <h4 className="font-semibold text-purple-900 mb-3 text-xl">Cartographie Juridique & Patrimoniale Interactive</h4>
              <p className="text-purple-700 text-sm mb-6">
                Explorez les stratégies patrimoniales sophistiquées avec analyses détaillées, exemples concrets et chiffrages précis.
                Chaque domaine contient des techniques avancées rarement disponibles sur les plateformes grand public.
              </p>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {juridicalTopics.filter((topic) => topic.id !== 'consolidation-multidevises').map((topic) => (
                  <div
                    key={topic.id}
                    className={`bg-gradient-to-br ${topic.color} rounded-xl p-6 text-white cursor-pointer hover:shadow-xl transition-all transform hover:-translate-y-2 hover:scale-105`}
                    onClick={() => handleTopicClick(topic)}
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                        <i className={`${topic.icon} text-2xl text-white`}></i>
                      </div>
                      <i className="ri-arrow-right-line text-2xl opacity-75"></i>
                    </div>

                    <h5 className="font-bold text-xl mb-2">{topic.title}</h5>
                    <p className="text-white/90 text-sm mb-4 line-clamp-2">{topic.description}</p>

                    <div className="flex items-center justify-between mb-4">
                      <span className="bg-white/20 px-3 py-1 rounded-full text-xs font-semibold">
                        {topic.category}
                      </span>
                      <span className="text-white/80 text-sm font-medium">
                        {topic.items.length} stratégies
                      </span>
                    </div>

                    <div className="border-t border-white/20 pt-3">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-white/90">Techniques avancées</span>
                        <span className="bg-white/30 px-2 py-1 rounded text-xs font-bold">Détails</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {categories
                .find((cat) => cat.id === activeTab)
                ?.items.slice(1)
                .map((item, index) => (
                  <div key={index} className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-lg p-4 border border-gray-200">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="font-semibold text-gray-900 mb-2">{item.title}</h4>
                        <p className="text-gray-600 text-sm mb-3">{item.description}</p>
                        <p className="text-gray-700 text-xs leading-relaxed">{item.details}</p>
                      </div>
                      <div className="ml-4">
                        <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap">
                          Accéder
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
            </div>

            {categories
              .find((cat) => cat.id === activeTab)
              ?.items.slice(1)
              .map((item, index) => (
                <div key={index} className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-lg p-4 border border-gray-200">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900 mb-2">{item.title}</h4>
                      <p className="text-gray-600 text-sm mb-3">{item.description}</p>
                      <p className="text-gray-700 text-xs leading-relaxed">{item.details}</p>
                    </div>
                    <div className="ml-4">
                      <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap">
                        Accéder
                      </button>
                    </div>
                  </div>
                </div>
              ))}
          </>
        )}

        {activeTab !== 'juridique' && activeTab !== 'consolidation' && (
          <>
            {categories
              .find((cat) => cat.id === activeTab)
              ?.items.map((item, index) => (
                <div key={index} className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-lg p-4 border border-gray-200">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900 mb-2">{item.title}</h4>
                      <p className="text-gray-600 text-sm mb-3">{item.description}</p>
                      <p className="text-gray-700 text-xs leading-relaxed">{item.details}</p>
                    </div>
                    <div className="ml-4">
                      <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap">
                        Accéder
                      </button>
                    </div>
                  </div>
                </div>
              ))}
          </>
        )}
      </div>

      {showDetailModal && selectedTopic && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-6xl w-full max-h-[95vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 bg-gradient-to-r from-gray-50 to-gray-100">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div
                    className={`w-16 h-16 bg-gradient-to-br ${selectedTopic.color} rounded-2xl flex items-center justify-center flex-shrink-0`}
                  >
                    <i className={`${selectedTopic.icon} text-3xl text-white`}></i>
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">{selectedTopic.title}</h2>
                    <p className="text-gray-600 text-lg">{selectedTopic.description}</p>
                    <span className="inline-block mt-1 px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm font-medium">
                      {selectedTopic.category}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setShowDetailModal(false)}
                  className="w-10 h-10 flex items-center justify-center rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
                >
                  <i className="ri-close-line text-2xl text-gray-600"></i>
                </button>
              </div>
            </div>

            <div className="p-6 space-y-8">
              {selectedTopic.items.map((item, index) => (
                <div key={index} className="bg-gradient-to-r from-gray-50 to-white rounded-xl p-6 border-l-4 border-blue-500 shadow-sm">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="font-bold text-gray-900 text-xl mb-2">{item.title}</h3>
                      <p className="text-gray-700 text-sm mb-4 font-medium">{item.description}</p>
                    </div>
                    <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-xs font-bold">
                      Stratégie #{index + 1}
                    </span>
                  </div>

                  <div className="bg-white p-5 rounded-lg border border-gray-200 mb-4">
                    <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                      <i className="ri-information-line text-blue-600 mr-2"></i>
                      Analyse Détaillée
                    </h4>
                    <p className="text-gray-800 text-sm leading-relaxed">{item.details}</p>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4 mb-4">
                    <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                      <h4 className="font-semibold text-green-900 mb-2 flex items-center">
                        <i className="ri-checkbox-circle-line text-green-600 mr-2"></i>
                        Avantages Clés
                      </h4>
                      <ul className="space-y-1 text-sm">
                        {item.advantages?.map((advantage, idx) => (
                          <li key={idx} className="text-green-800 flex items-start">
                            <i className="ri-arrow-right-s-line text-green-600 mt-0.5 mr-1"></i>
                            {advantage}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                      <h4 className="font-semibold text-blue-900 mb-2 flex items-center">
                        <i className="ri-calculator-line text-blue-600 mr-2"></i>
                        Fiscalité & Rendement
                      </h4>
                      <p className="text-blue-800 text-sm">{item.fiscality}</p>
                    </div>
                  </div>

                  <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                    <h4 className="font-semibold text-yellow-900 mb-2 flex items-center">
                      <i className="ri-lightbulb-line text-yellow-600 mr-2"></i>
                      Exemple Concret
                    </h4>
                    <p className="text-yellow-800 text-sm font-medium">{item.examples}</p>
                  </div>

                  <div className="flex space-x-3 mt-6 pt-4 border-t border-gray-200">
                    <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-semibold whitespace-nowrap">
                      <i className="ri-calculator-line mr-1"></i>
                      Calculer
                    </button>
                    <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors text-sm font-semibold whitespace-nowrap">
                      <i className="ri-download-line mr-1"></i>
                      Guide PDF
                    </button>
                    <button className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors text-sm font-semibold whitespace-nowrap">
                      <i className="ri-user-line mr-1"></i>
                      Conseil Expert
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-6 bg-gray-50 border-t border-gray-200">
              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-600">
                  <i className="ri-shield-check-line text-green-500 mr-1"></i>
                  Informations validées par experts patrimoniaux
                </div>
                <button
                  onClick={() => setShowDetailModal(false)}
                  className="bg-gray-800 text-white px-6 py-3 rounded-lg hover:bg-gray-700 transition-colors font-semibold cursor-pointer whitespace-nowrap"
                >
                  Fermer
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showConsolidationDetails && selectedConsolidationItem && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-6xl w-full max-h-[95vh] overflow-y-auto">
            {(() => {
              const content = getConsolidationContent(selectedConsolidationItem);
              if (!content) return null;

              return (
                <>
                  <div className={`p-6 border-b border-gray-200 bg-gradient-to-r ${content.color}`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center flex-shrink-0">
                          <i className={`${content.icon} text-3xl text-white`}></i>
                        </div>
                        <div>
                          <h2 className="text-2xl font-bold text-white">{content.title}</h2>
                          <p className="text-white/90 text-lg">{content.subtitle}</p>
                        </div>
                      </div>
                      <button
                        onClick={closeConsolidationDetails}
                        className="w-10 h-10 flex items-center justify-center rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
                      >
                        <i className="ri-close-line text-2xl text-white"></i>
                      </button>
                    </div>
                  </div>

                  <div className="p-6 bg-gray-50 border-b border-gray-200">
                    <p className="text-gray-700 text-lg">{content.description}</p>
                  </div>

                  <div className="p-6 bg-white border-b border-gray-200">
                    <h3 className="text-xl font-bold text-gray-900 mb-4">Statistiques Clés</h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {Object.entries(content.stats).map(([key, value]) => (
                        <div key={key} className="text-center bg-gray-50 p-4 rounded-lg">
                          <div className="text-2xl font-bold text-blue-600">{value}</div>
                          <div className="text-sm text-gray-600">{key}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="p-6 space-y-6">
                    <h3 className="text-xl font-bold text-gray-900 mb-4">Fonctionnalités Principales</h3>
                    {content.features.map((feature, index) => (
                      <div key={index} className="bg-gray-50 rounded-xl p-6 border border-gray-200">
                        <div className="flex items-start space-x-4">
                          <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                            <i className="ri-star-line text-blue-600 text-xl"></i>
                          </div>
                          <div className="flex-1">
                            <h4 className="font-bold text-gray-900 text-lg mb-2">{feature.title}</h4>
                            <p className="text-gray-700 mb-3">{feature.description}</p>
                            <div className="bg-white p-4 rounded-lg border border-gray-200 mb-3">
                              <p className="text-gray-800 text-sm">{feature.details}</p>
                            </div>
                            <div className="space-y-2">
                              <h5 className="font-semibold text-gray-900">Exemples concrets :</h5>
                              <ul className="space-y-1">
                                {feature.examples.map((example, idx) => (
                                  <li key={idx} className="text-sm text-gray-700 flex items-start">
                                    <i className="ri-arrow-right-s-line text-blue-600 mt-0.5 mr-1"></i>
                                    {example}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="p-6 bg-green-50 border-t border-gray-200">
                    <h3 className="text-xl font-bold text-gray-900 mb-4">Bénéfices Clés</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      {content.benefits.map((benefit, index) => (
                        <div key={index} className="flex items-start space-x-3">
                          <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0">
                            <i className="ri-check-line text-white text-sm"></i>
                          </div>
                          <span className="text-gray-800">{benefit}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="p-6 bg-gray-50 border-t border-gray-200">
                    <div className="flex items-center justify-between">
                      <div className="text-sm text-gray-600">
                        <i className="ri-shield-check-line text-green-500 mr-1"></i>
                        Système certifié et conforme aux réglementations internationales
                      </div>
                      <div className="flex space-x-3">
                        <button className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors font-semibold cursor-pointer whitespace-nowrap">
                          <i className="ri-settings-3-line mr-2"></i>
                          Configurer
                        </button>
                        <button className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors font-semibold cursor-pointer whitespace-nowrap">
                          <i className="ri-book-open-line mr-2"></i>
                          Guide
                        </button>
                        <button className="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 transition-colors font-semibold cursor-pointer whitespace-nowrap">
                          <i className="ri-customer-service-2-line mr-2"></i>
                          Support
                        </button>
                        <button
                          onClick={closeConsolidationDetails}
                          className="bg-gray-600 text-white px-6 py-3 rounded-lg hover:bg-gray-700 transition-colors font-semibold cursor-pointer whitespace-nowrap"
                        >
                          Fermer
                        </button>
                      </div>
                    </div>
                  </div>
                </ >
              );
            })()}
          </div>
        </div>
      )}

      {showFATCAModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 rounded-xl max-w-7xl w-full max-h-[95vh] overflow-y-auto border border-yellow-500/20">
            <div className="flex items-center justify-between p-6 border-b border-gray-800">
              <h3 className="text-2xl font-bold text-white">Formulaires Officiels FATCA/CRS</h3>
              <button
                onClick={closeFATCAModal}
                className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-800 transition-colors cursor-pointer"
              >
                <i className="ri-close-line text-xl text-gray-400 hover:text-white"></i>
              </button>
            </div>

            <div className="p-6">
              <OfficialFATCACRSReporting />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
