
'use client';

import { useState } from 'react';

export default function LegalAssistant() {
  const [activeCalculator, setActiveCalculator] = useState<string | null>(null);

  const calculators = [
    {
      id: 'succession',
      title: 'Droits de Succession',
      description: 'Calcul précis selon barème progressif 2024 et abattements familiaux',
      icon: 'ri-scales-line',
      color: 'bg-blue-50 border-blue-200 text-blue-700'
    },
    {
      id: 'plusvalues',
      title: 'Plus-values Immobilières',
      description: 'Abattements durée détention, exonérations et fiscalité spécifique',
      icon: 'ri-home-line',
      color: 'bg-green-50 border-green-200 text-green-700'
    },
    {
      id: 'ifi',
      title: 'IFI - Impôt Fortune Immobilière',
      description: 'Assiette, décote, exonérations biens professionnels et nue-propriété',
      icon: 'ri-building-line',
      color: 'bg-purple-50 border-purple-200 text-purple-700'
    },
    {
      id: 'donation',
      title: 'Donation Optimale',
      description: 'Comparaison donation simple, démembrement, assurance-vie',
      icon: 'ri-gift-line',
      color: 'bg-orange-50 border-orange-200 text-orange-700'
    },
    {
      id: 'flattax',
      title: 'Flat Tax vs Barème',
      description: 'Optimisation fiscale revenus financiers - Calcul net/net',
      icon: 'ri-percent-line',
      color: 'bg-red-50 border-red-200 text-red-700'
    },
    {
      id: 'foncier',
      title: 'Revenus Fonciers',
      description: 'Micro-foncier vs réel, charges déductibles et optimisation',
      icon: 'ri-key-line',
      color: 'bg-indigo-50 border-indigo-200 text-indigo-700'
    }
  ];

  const SuccessionCalculator = () => {
    const [patrimoine, setPatrimoine] = useState('');
    const [lienParente, setLienParente] = useState('');
    const [nombreBeneficiaires, setNombreBeneficiaires] = useState('1');
    const [donationsAnterieures, setDonationsAnterieures] = useState('');
    const [result, setResult] = useState<any>(null);

    const abattements = {
      'conjoint': 80724,
      'enfant': 100000,
      'petitenfant': 31865,
      'parent': 100000,
      'freresoeur': 15932,
      'neveuniece': 7967,
      'autre': 1594
    };

    const bareme = [
      { min: 0, max: 8072, taux: 0.05 },
      { min: 8072, max: 12109, taux: 0.10 },
      { min: 12109, max: 15932, taux: 0.15 },
      { min: 15932, max: 552324, taux: 0.20 },
      { min: 552324, max: 902838, taux: 0.30 },
      { min: 902838, max: 1805677, taux: 0.40 },
      { min: 1805677, max: Infinity, taux: 0.45 }
    ];

    const baremeAutres = [
      { min: 0, max: 24430, taux: 0.35 },
      { min: 24430, max: Infinity, taux: 0.45 }
    ];

    const calculateSuccession = () => {
      const patrimoineValue = parseFloat(patrimoine);
      const donations = parseFloat(donationsAnterieures) || 0;
      const nbBenef = parseInt(nombreBeneficiaires);
      
      if (!patrimoineValue || !lienParente) return;

      const partParBeneficiaire = patrimoineValue / nbBenef;
      const abattement = abattements[lienParente as keyof typeof abattements];
      const assietteTaxable = Math.max(0, partParBeneficiaire + donations - abattement);
      
      let droits = 0;
      const currentBareme = ['freresoeur', 'neveuniece', 'autre'].includes(lienParente) ? baremeAutres : bareme;
      
      for (const tranche of currentBareme) {
        if (assietteTaxable > tranche.min) {
          const taxable = Math.min(assietteTaxable, tranche.max) - tranche.min;
          droits += taxable * tranche.taux;
        }
      }

      // Réduction pour charges de famille
      let reduction = 0;
      if (lienParParente === 'conjoint' && nbBenef > 1) {
        reduction = Math.min(droits * 0.20, 305);
      }

      const droitsFinaux = Math.max(0, droits - reduction);
      const tauxEffectif = patrimoineValue > 0 ? (droitsFinaux / patrimoineValue) * 100 : 0;

      setResult({
        partParBeneficiaire,
        abattement,
        assietteTaxable,
        droitsBruts: droits,
        reduction,
        droitsFinaux,
        tauxEffectif,
        patrimoineNet: patrimoineValue - (droitsFinaux * nbBenef)
      });
    };

    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Patrimoine total à transmettre (€)
            </label>
            <input
              type="number"
              value={patrimoine}
              onChange={(e) => setPatrimoine(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="500000"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Lien de parenté avec le défunt
            </label>
            <select
              value={lienParente}
              onChange={(e) => setLienParente(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent pr-8"
            >
              <option value="">Sélectionner</option>
              <option value="conjoint">Conjoint/Partenaire PACS</option>
              <option value="enfant">Enfant</option>
              <option value="petitenfant">Petit-enfant</option>
              <option value="parent">Parent</option>
              <option value="freresoeur">Frère/Sœur</option>
              <option value="neveuniece">Neveu/Nièce</option>
              <option value="autre">Autre</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nombre de bénéficiaires
            </label>
            <input
              type="number"
              value={nombreBeneficiaires}
              onChange={(e) => setNombreBeneficiaires(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              min="1"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Donations antérieures (15 dernières années) (€)
            </label>
            <input
              type="number"
              value={donationsAnterieures}
              onChange={(e) => setDonationsAnterieures(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="0"
            />
          </div>
        </div>

        <button
          onClick={calculateSuccession}
          className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors font-medium"
        >
          Calculer les droits de succession
        </button>

        {result && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-blue-900 mb-4">Résultat du calcul</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <p><span className="font-medium">Part par bénéficiaire:</span> {result.partParBeneficiaire.toLocaleString('fr-FR')} €</p>
                <p><span className="font-medium">Abattement applicable:</span> {result.abattement.toLocaleString('fr-FR')} €</p>
                <p><span className="font-medium">Assiette taxable:</span> {result.assietteTaxable.toLocaleString('fr-FR')} €</p>
                <p><span className="font-medium">Droits bruts:</span> {result.droitsBruts.toLocaleString('fr-FR')} €</p>
              </div>
              <div>
                <p><span className="font-medium">Réduction:</span> {result.reduction.toLocaleString('fr-FR')} €</p>
                <p><span className="font-medium text-blue-700">Droits finaux:</span> {result.droitsFinaux.toLocaleString('fr-FR')} €</p>
                <p><span className="font-medium">Taux effectif:</span> {result.tauxEffectif.toFixed(2)} %</p>
                <p><span className="font-medium text-green-700">Patrimoine net transmis:</span> {result.patrimoineNet.toLocaleString('fr-FR')} €</p>
              </div>
            </div>
            
            <div className="mt-4 p-3 bg-blue-100 rounded-lg">
              <p className="text-sm text-blue-800">
                <i className="ri-information-line mr-1"></i>
                <strong>Conseil d'expert:</strong> {result.tauxEffectif > 20 ? 
                  'Taux élevé - Envisagez une donation anticipée ou un démembrement de propriété pour optimiser la transmission.' :
                  'Transmission optimisée dans le cadre fiscal actuel.'}
              </p>
            </div>
          </div>
        )}
      </div>
    );
  };

  const PlusValuesCalculator = () => {
    const [prixAchat, setPrixAchat] = useState('');
    const [fraisAchat, setFraisAchat] = useState('');
    const [travauxDeductibles, setTravauxDeductibles] = useState('');
    const [prixVente, setPrixVente] = useState('');
    const [fraisVente, setFraisVente] = useState('');
    const [dureeDetention, setDureeDetention] = useState('');
    const [typeLogement, setTypeLogement] = useState('');
    const [zoneTendue, setZoneTendue] = useState(false);
    const [result, setResult] = useState<any>(null);

    const calculatePlusValues = () => {
      const achat = parseFloat(prixAchat);
      const fraisA = parseFloat(fraisAchat) || 0;
      const travaux = parseFloat(travauxDeductibles) || 0;
      const vente = parseFloat(prixVente);
      const fraisV = parseFloat(fraisVente) || 0;
      const duree = parseFloat(dureeDetention);

      if (!achat || !vente || !duree) return;

      // Prix de revient
      const prixRevient = achat + fraisA + travaux;
      const prixVenteNet = vente - fraisV;
      const plusValueBrute = prixVenteNet - prixRevient;

      if (plusValueBrute <= 0) {
        setResult({ plusValueBrute, message: 'Aucune plus-value à déclarer (moins-value)' });
        return;
      }

      // Exonération résidence principale
      if (typeLogement === 'principale') {
        setResult({ 
          plusValueBrute, 
          exoneration: 'totale',
          message: 'Exonération totale - Résidence principale' 
        });
        return;
      }

      // Exonération durée détention (22 ans pour IR, 30 ans pour PS)
      if (duree >= 30) {
        setResult({ 
          plusValueBrute, 
          exoneration: 'totale',
          message: 'Exonération totale - Détention > 30 ans' 
        });
        return;
      }

      // Abattements pour durée de détention
      let abattementIR = 0;
      let abattementPS = 0;

      if (duree >= 6) {
        const anneesAuDela6 = Math.min(duree - 6, 15);
        const anneesAuDela21 = Math.max(0, duree - 21);
        abattementIR = (anneesAuDela6 * 6) + (anneesAuDela21 * 4);
      }

      if (duree >= 6) {
        const anneesAuDela6 = Math.min(duree - 6, 16);
        const anneesAuDela22 = Math.max(0, duree - 22);
        abattementPS = (anneesAuDela6 * 1.65) + (anneesAuDela22 * 1.60);
      }

      // Exonération première cession (zone tendue)
      let exonerationPremiereCession = false;
      if (zoneTendue && typeLogement === 'autre' && vente <= 200000) {
        exonerationPremiereCession = true;
      }

      const plusValueIR = plusValueBrute * (1 - abattementIR / 100);
      const plusValuePS = plusValueBrute * (1 - abattementPS / 100);

      const impotIR = exonerationPremiereCession ? 0 : plusValueIR * 0.19;
      const prelevementsSociaux = exonerationPremiereCession ? 0 : plusValuePS * 0.172;

      const totalImpots = impotIR + prelevementsSociaux;
      const plusValueNette = plusValueBrute - totalImpots;

      setResult({
        plusValueBrute,
        prixRevient,
        prixVenteNet,
        abattementIR,
        abattementPS,
        plusValueIR,
        plusValuePS,
        impotIR,
        prelevementsSociaux,
        totalImpots,
        plusValueNette,
        exonerationPremiereCession,
        tauxImposition: (totalImpots / plusValueBrute) * 100
      });
    };

    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Prix d'achat (€)
            </label>
            <input
              type="number"
              value={prixAchat}
              onChange={(e) => setPrixAchat(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              placeholder="300000"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Frais d'acquisition (€)
            </label>
            <input
              type="number"
              value={fraisAchat}
              onChange={(e) => setFraisAchat(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              placeholder="21000"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Travaux déductibles (€)
            </label>
            <input
              type="number"
              value={travauxDeductibles}
              onChange={(e) => setTravauxDeductibles(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              placeholder="15000"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Prix de vente (€)
            </label>
            <input
              type="number"
              value={prixVente}
              onChange={(e) => setPrixVente(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              placeholder="450000"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Frais de vente (€)
            </label>
            <input
              type="number"
              value={fraisVente}
              onChange={(e) => setFraisVente(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              placeholder="31500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Durée de détention (années)
            </label>
            <input
              type="number"
              value={dureeDetention}
              onChange={(e) => setDureeDetention(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              placeholder="8.5"
              step="0.1"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Type de logement
            </label>
            <select
              value={typeLogement}
              onChange={(e) => setTypeLogement(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent pr-8"
            >
              <option value="">Sélectionner</option>
              <option value="principale">Résidence principale</option>
              <option value="secondaire">Résidence secondaire</option>
              <option value="locatif">Bien locatif</option>
              <option value="autre">Autre bien</option>
            </select>
          </div>

          <div className="flex items-center">
            <input
              type="checkbox"
              id="zoneTendue"
              checked={zoneTendue}
              onChange={(e) => setZoneTendue(e.target.checked)}
              className="mr-2"
            />
            <label htmlFor="zoneTendue" className="text-sm text-gray-700">
              Zone tendue (A, A bis, B1)
            </label>
          </div>
        </div>

        <button
          onClick={calculatePlusValues}
          className="w-full bg-green-600 text-white py-3 px-6 rounded-lg hover:bg-green-700 transition-colors font-medium"
        >
          Calculer la plus-value immobilière
        </button>

        {result && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-green-900 mb-4">Résultat du calcul</h3>
            
            {result.message ? (
              <div className="p-3 bg-green-100 rounded-lg">
                <p className="text-green-800 font-medium">{result.message}</p>
                <p className="text-sm text-green-700 mt-1">Plus-value brute: {result.plusValueBrute.toLocaleString('fr-FR')} €</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <p><span className="font-medium">Plus-value brute:</span> {result.plusValueBrute.toLocaleString('fr-FR')} €</p>
                    <p><span className="font-medium">Prix de revient:</span> {result.prixRevient.toLocaleString('fr-FR')} €</p>
                    <p><span className="font-medium">Prix de vente net:</span> {result.prixVenteNet.toLocaleString('fr-FR')} €</p>
                    <p><span className="font-medium">Abattement IR:</span> {result.abattementIR.toFixed(1)} %</p>
                  </div>
                  <div>
                    <p><span className="font-medium">Abattement PS:</span> {result.abattementPS.toFixed(1)} %</p>
                    <p><span className="font-medium">Impôt sur le revenu:</span> {result.impotIR.toLocaleString('fr-FR')} €</p>
                    <p><span className="font-medium">Prélèvements sociaux:</span> {result.prelevementsSociaux.toLocaleString('fr-FR')} €</p>
                    <p><span className="font-medium text-green-700">Plus-value nette:</span> {result.plusValueNette.toLocaleString('fr-FR')} €</p>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <p className="font-medium text-lg">Total impôts: {result.totalImpots.toLocaleString('fr-FR')} € ({result.tauxImposition.toFixed(1)}%)</p>
                </div>

                {result.exonerationPremiereCession && (
                  <div className="p-3 bg-blue-100 rounded-lg">
                    <p className="text-blue-800 text-sm">
                      <i className="ri-information-line mr-1"></i>
                      Exonération première cession appliquée (zone tendue, prix ≤ 200k€)
                    </p>
                  </div>
                )}

                <div className="p-3 bg-green-100 rounded-lg">
                  <p className="text-sm text-green-800">
                    <i className="ri-lightbulb-line mr-1"></i>
                    <strong>Conseil d'expert:</strong> {result.tauxImposition > 25 ? 
                      'Taux élevé - Considérez attendre pour bénéficier d\'abattements supplémentaires.' :
                      'Fiscalité optimisée pour cette durée de détention.'}
                  </p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    );
  };

  const IFICalculator = () => {
    const [patrimoineImmobilier, setPatrimoineImmobilier] = useState('');
    const [dettesDeductibles, setDettesDeductibles] = useState('');
    const [biensProfessionnels, setBiensProfessionnels] = useState('');
    const [nuePropriete, setNuePropriete] = useState('');
    const [oeuvresArt, setOeuvresArt] = useState('');
    const [partsPME, setPartsPME] = useState('');
    const [situationFamiliale, setSituationFamiliale] = useState('');
    const [revenus, setRevenus] = useState('');
    const [result, setResult] = useState<any>(null);

    const calculateIFI = () => {
      const patrimoine = parseFloat(patrimoineImmobilier);
      const dettes = parseFloat(dettesDeductibles) || 0;
      const biensPro = parseFloat(biensProfessionnels) || 0;
      const nue = parseFloat(nuePropriete) || 0;
      const oeuvres = parseFloat(oeuvresArt) || 0;
      const pme = parseFloat(partsPME) || 0;
      const revenusFiscaux = parseFloat(revenus) || 0;

      if (!patrimoine) return;

      // Calcul de l'assiette nette
      const exonerations = biensPro + (nue * 0.77) + oeuvres + pme; // Nue-propriété abattue de 23%
      const assietteBrute = patrimoine - exonerations;
      const assietteNette = Math.max(0, assietteBrute - dettes);

      // Seuil d'assujettissement
      if (assietteNette < 1300000) {
        setResult({
          assietteNette,
          message: 'Patrimoine en dessous du seuil d\'assujettissement (1,3M€)',
          ifi: 0
        });
        return;
      }

      // Calcul de la décote
      let assietteApresDecote = assietteNette;
      if (assietteNette < 1800000) {
        const decote = 17500 - (assietteNette - 1300000) * 0.035;
        assietteApresDecote = Math.max(0, assietteNette - decote);
      }

      // Barème IFI 2024
      const bareme = [
        { min: 0, max: 800000, taux: 0 },
        { min: 800000, max: 1300000, taux: 0 },
        { min: 1300000, max: 2570000, taux: 0.005 },
        { min: 2570000, max: 5000000, taux: 0.007 },
        { min: 5000000, max: 10000000, taux: 0.01 },
        { min: 10000000, max: Infinity, taux: 0.0125 }
      ];

      let ifi = 0;
      for (const tranche of bareme) {
        if (assietteApresDecote > tranche.min) {
          const taxable = Math.min(assietteApresDecote, tranche.max) - tranche.min;
          ifi += taxable * tranche.taux;
        }
      }

      // Plafonnement à 75% des revenus
      const plafond = revenusFiscaux * 0.75;
      const ifiAvantPlafonnement = ifi;
      if (plafond > 0 && ifi > plafond) {
        ifi = plafond;
      }

      const tauxEffectif = assietteNette > 0 ? (ifi / assietteNette) * 100 : 0;

      setResult({
        patrimoine,
        exonerations,
        assietteBrute,
        dettes,
        assietteNette,
        assietteApresDecote,
        ifiAvantPlafonnement,
        plafonnement: ifiAvantPlafonnement - ifi,
        ifi,
        tauxEffectif,
        decoteAppliquee: assietteNette < 1800000
      });
    };

    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Patrimoine immobilier brut (€)
            </label>
            <input
              type="number"
              value={patrimoineImmobilier}
              onChange={(e) => setPatrimoineImmobilier(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              placeholder="2000000"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Dettes déductibles (€)
            </label>
            <input
              type="number"
              value={dettesDeductibles}
              onChange={(e) => setDettesDeductibles(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              placeholder="300000"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Biens professionnels exonérés (€)
            </label>
            <input
              type="number"
              value={biensProfessionnels}
              onChange={(e) => setBiensProfessionnels(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              placeholder="0"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nue-propriété (€)
            </label>
            <input
              type="number"
              value={nuePropriete}
              onChange={(e) => setNuePropriete(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              placeholder="0"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Œuvres d'art exonérées (€)
            </label>
            <input
              type="number"
              value={oeuvresArt}
              onChange={(e) => setOeuvresArt(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              placeholder="0"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Parts PME exonérées (€)
            </label>
            <input
              type="number"
              value={partsPME}
              onChange={(e) => setPartsPME(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              placeholder="0"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Revenus fiscaux N-1 (€)
            </label>
            <input
              type="number"
              value={revenus}
              onChange={(e) => setRevenus(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              placeholder="150000"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Situation familiale
            </label>
            <select
              value={situationFamiliale}
              onChange={(e) => setSituationFamiliale(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent pr-8"
            >
              <option value="">Sélectionner</option>
              <option value="celibataire">Célibataire</option>
              <option value="marie">Marié/PACS</option>
              <option value="divorce">Divorcé</option>
              <option value="veuf">Veuf/Veuve</option>
            </select>
          </div>
        </div>

        <button
          onClick={calculateIFI}
          className="w-full bg-purple-600 text-white py-3 px-6 rounded-lg hover:bg-purple-700 transition-colors font-medium"
        >
          Calculer l'IFI
        </button>

        {result && (
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-purple-900 mb-4">Résultat du calcul IFI</h3>
            
            {result.message ? (
              <div className="p-3 bg-purple-100 rounded-lg">
                <p className="text-purple-800 font-medium">{result.message}</p>
                <p className="text-sm text-purple-700 mt-1">Assiette nette: {result.assietteNette.toLocaleString('fr-FR')} €</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <p><span className="font-medium">Patrimoine brut:</span> {result.patrimoine.toLocaleString('fr-FR')} €</p>
                    <p><span className="font-medium">Exonérations:</span> {result.exonerations.toLocaleString('fr-FR')} €</p>
                    <p><span className="font-medium">Assiette brute:</span> {result.assietteBrute.toLocaleString('fr-FR')} €</p>
                    <p><span className="font-medium">Dettes déductibles:</span> {result.dettes.toLocaleString('fr-FR')} €</p>
                  </div>
                  <div>
                    <p><span className="font-medium">Assiette nette:</span> {result.assietteNette.toLocaleString('fr-FR')} €</p>
                    <p><span className="font-medium">IFI avant plafonnement:</span> {result.ifiAvantPlafonnement.toLocaleString('fr-FR')} €</p>
                    <p><span className="font-medium">Plafonnement:</span> {result.plafonnement.toLocaleString('fr-FR')} €</p>
                    <p><span className="font-medium text-purple-700">IFI final:</span> {result.ifi.toLocaleString('fr-FR')} €</p>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <p className="font-medium text-lg">Taux effectif: {result.tauxEffectif.toFixed(3)}%</p>
                  {result.decoteAppliquee && (
                    <p className="text-sm text-purple-700 mt-1">Décote appliquée (patrimoine &lt; 1,8M€)</p>
                  )}
                </div>

                <div className="p-3 bg-purple-100 rounded-lg">
                  <p className="text-sm text-purple-800">
                    <i className="ri-lightbulb-line mr-1"></i>
                    <strong>Conseil d'expert:</strong> {result.ifi > 50000 ? 
                      'IFI élevé - Envisagez un démembrement de propriété ou des investissements exonérés (PME, œuvres d\'art).' :
                      'IFI maîtrisé dans le cadre fiscal actuel.'}
                  </p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    );
  };

  const DonationCalculator = () => {
    const [montantDonation, setMontantDonation] = useState('');
    const [ageDonateur, setAgeDonateur] = useState('');
    const [lienParente, setLienParente] = useState('');
    const [typeDonation, setTypeDonation] = useState('');
    const [valeurBien, setValeurBien] = useState('');
    const [tauxUsufruit, setTauxUsufruit] = useState('');
    const [result, setResult] = useState<any>(null);

    const abattements = {
      'conjoint': 80724,
      'enfant': 100000,
      'petitenfant': 31865,
      'parent': 100000,
      'freresoeur': 15932,
      'neveuniece': 7967,
      'autre': 1594
    };

    const calculateDonation = () => {
      const montant = parseFloat(montantDonation);
      const age = parseInt(ageDonateur);
      const valeur = parseFloat(valeurBien) || montant;

      if (!montant || !age || !lienParente) return;

      const abattement = abattements[lienParente as keyof typeof abattements];
      
      // Calcul donation simple
      const donationSimple = {
        montant,
        abattement,
        assietteTaxable: Math.max(0, montant - abattement),
        droits: 0
      };

      // Barème donation
      const bareme = [
        { min: 0, max: 8072, taux: 0.05 },
        { min: 8072, max: 12109, taux: 0.10 },
        { min: 12109, max: 15932, taux: 0.15 },
        { min: 15932, max: 552324, taux: 0.20 },
        { min: 552324, max: 902838, taux: 0.30 },
        { min: 902838, max: 1805677, taux: 0.40 },
        { min: 1805677, max: Infinity, taux: 0.45 }
      ];

      for (const tranche of bareme) {
        if (donationSimple.assietteTaxable > tranche.min) {
          const taxable = Math.min(donationSimple.assietteTaxable, tranche.max) - tranche.min;
          donationSimple.droits += taxable * tranche.taux;
        }
      }

      // Réduction pour âge du donateur
      let reductionAge = 0;
      if (age < 70) reductionAge = 0.50;
      else if (age < 80) reductionAge = 0.30;

      donationSimple.droits *= (1 - reductionAge);

      // Calcul démembrement
      const demembrement = {
        valeurTotale: valeur,
        valeurUsufruit: 0,
        valeurNuePropriete: 0,
        droitsDemembrement: 0,
        economie: 0
      };

      if (typeDonation === 'demembrement') {
        // Barème usufruit selon l'âge
        let tauxUsufruitAge = 0;
        if (age < 21) tauxUsufruitAge = 0.90;
        else if (age < 31) tauxUsufruitAge = 0.80;
        else if (age < 41) tauxUsufruitAge = 0.70;
        else if (age < 51) tauxUsufruitAge = 0.60;
        else if (age < 61) tauxUsufruitAge = 0.50;
        else if (age < 71) tauxUsufruitAge = 0.40;
        else if (age < 81) tauxUsufruitAge = 0.30;
        else if (age < 91) tauxUsufruitAge = 0.20;
        else tauxUsufruitAge = 0.10;

        demembrement.valeurUsufruit = valeur * tauxUsufruitAge;
        demembrement.valeurNuePropriete = valeur - demembrement.valeurUsufruit;

        const assietteDemembrement = Math.max(0, demembrement.valeurNuePropriete - abattement);
        
        for (const tranche of bareme) {
          if (assietteDemembrement > tranche.min) {
            const taxable = Math.min(assietteDemembrement, tranche.max) - tranche.min;
            demembrement.droitsDemembrement += taxable * tranche.taux;
          }
        }

        demembrement.droitsDemembrement *= (1 - reductionAge);
        demembrement.economie = donationSimple.droits - demembrement.droitsDemembrement;
      }

      // Calcul assurance-vie
      const assuranceVie = {
        versements: montant,
        abattementAV: lienParente === 'enfant' ? 152500 : 0,
        droitsAV: 0,
        economie: 0
      };

      if (typeDonation === 'assurance-vie') {
        const assetteAV = Math.max(0, montant - assuranceVie.abattementAV);
        assuranceVie.droitsAV = assetteAV * 0.20; // Taux forfaitaire 20%
        assuranceVie.economie = donationSimple.droits - assuranceVie.droitsAV;
      }

      setResult({
        donationSimple,
        demembrement,
        assuranceVie,
        reductionAge,
        age,
        recommandation: demembrement.economie > assuranceVie.economie ? 'demembrement' : 'assurance-vie'
      });
    };

    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Montant à donner (€)
            </label>
            <input
              type="number"
              value={montantDonation}
              onChange={(e) => setMontantDonation(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              placeholder="200000"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Âge du donateur
            </label>
            <input
              type="number"
              value={ageDonateur}
              onChange={(e) => setAgeDonateur(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              placeholder="65"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Lien de parenté
            </label>
            <select
              value={lienParente}
              onChange={(e) => setLienParente(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent pr-8"
            >
              <option value="">Sélectionner</option>
              <option value="conjoint">Conjoint/Partenaire PACS</option>
              <option value="enfant">Enfant</option>
              <option value="petitenfant">Petit-enfant</option>
              <option value="parent">Parent</option>
              <option value="freresoeur">Frère/Sœur</option>
              <option value="neveuniece">Neveu/Nièce</option>
              <option value="autre">Autre</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Type de donation à comparer
            </label>
            <select
              value={typeDonation}
              onChange={(e) => setTypeDonation(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent pr-8"
            >
              <option value="">Donation simple uniquement</option>
              <option value="demembrement">Comparer avec démembrement</option>
              <option value="assurance-vie">Comparer avec assurance-vie</option>
              <option value="tous">Comparer toutes les options</option>
            </select>
          </div>

          {typeDonation === 'demembrement' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Valeur du bien à démembrer (€)
              </label>
              <input
                type="number"
                value={valeurBien}
                onChange={(e) => setValeurBien(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                placeholder="300000"
              />
            </div>
          )}
        </div>

        <button
          onClick={calculateDonation}
          className="w-full bg-orange-600 text-white py-3 px-6 rounded-lg hover:bg-orange-700 transition-colors font-medium"
        >
          Comparer les stratégies de donation
        </button>

        {result && (
          <div className="bg-orange-50 border border-orange-200 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-orange-900 mb-4">Comparaison des stratégies</h3>
            
            <div className="space-y-6">
              {/* Donation simple */}
              <div className="bg-white border border-orange-200 rounded-lg p-4">
                <h4 className="font-semibold text-orange-800 mb-3">1. Donation Simple</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p><span className="font-medium">Montant donné:</span> {result.donationSimple.montant.toLocaleString('fr-FR')} €</p>
                    <p><span className="font-medium">Abattement:</span> {result.donationSimple.abattement.toLocaleString('fr-FR')} €</p>
                  </div>
                  <div>
                    <p><span className="font-medium">Assiette taxable:</span> {result.donationSimple.assietteTaxable.toLocaleString('fr-FR')} €</p>
                    <p><span className="font-medium text-orange-700">Droits:</span> {result.donationSimple.droits.toLocaleString('fr-FR')} €</p>
                  </div>
                </div>
                {result.reductionAge > 0 && (
                  <p className="text-sm text-orange-600 mt-2">
                    Réduction d'âge appliquée: {(result.reductionAge * 100).toFixed(0)}% (donateur {result.age} ans)
                  </p>
                )}
              </div>

              {/* Démembrement */}
              {(typeDonation === 'demembrement' || typeDonation === 'tous') && (
                <div className="bg-white border border-green-200 rounded-lg p-4">
                  <h4 className="font-semibold text-green-800 mb-3">2. Donation avec Démembrement</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p><span className="font-medium">Valeur totale:</span> {result.demembrement.valeurTotale.toLocaleString('fr-FR')} €</p>
                      <p><span className="font-medium">Valeur usufruit:</span> {result.demembrement.valeurUsufruit.toLocaleString('fr-FR')} €</p>
                    </div>
                    <div>
                      <p><span className="font-medium">Valeur nue-propriété:</span> {result.demembrement.valeurNuePropriete.toLocaleString('fr-FR')} €</p>
                      <p><span className="font-medium text-green-700">Droits:</span> {result.demembrement.droitsDemembrement.toLocaleString('fr-FR')} €</p>
                    </div>
                  </div>
                  <div className="mt-3 p-2 bg-green-100 rounded">
                    <p className="text-sm text-green-800 font-medium">
                      Économie vs donation simple: {result.demembrement.economie.toLocaleString('fr-FR')} €
                    </p>
                  </div>
                </div>
              )}

              {/* Assurance-vie */}
              {(typeDonation === 'assurance-vie' || typeDonation === 'tous') && (
                <div className="bg-white border border-blue-200 rounded-lg p-4">
                  <h4 className="font-semibold text-blue-800 mb-3">3. Assurance-Vie</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p><span className="font-medium">Versements:</span> {result.assuranceVie.versements.toLocaleString('fr-FR')} €</p>
                      <p><span className="font-medium">Abattement AV:</span> {result.assuranceVie.abattementAV.toLocaleString('fr-FR')} €</p>
                    </div>
                    <div>
                      <p><span className="font-medium text-blue-700">Droits (20%):</span> {result.assuranceVie.droitsAV.toLocaleString('fr-FR')} €</p>
                    </div>
                  </div>
                  <div className="mt-3 p-2 bg-blue-100 rounded">
                    <p className="text-sm text-blue-800 font-medium">
                      Économie vs donation simple: {result.assuranceVie.economie.toLocaleString('fr-FR')} €
                    </p>
                  </div>
                </div>
              )}

              {/* Recommandation */}
              <div className="p-4 bg-orange-100 rounded-lg">
                <p className="text-sm text-orange-800">
                  <i className="ri-lightbulb-line mr-1"></i>
                  <strong>Stratégie recommandée:</strong> {
                    result.recommandation === 'demembrement' ? 
                    'Donation avec démembrement - Économie fiscale maximale' :
                    result.recommandation === 'assurance-vie' ?
                    'Assurance-vie - Fiscalité avantageuse et souplesse' :
                    'Donation simple - Solution la plus adaptée à votre situation'
                  }
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  const FlatTaxCalculator = () => {
    const [dividendes, setDividendes] = useState('');
    const [interets, setInterets] = useState('');
    const [plusValuesValeurs, setPlusValuesValeurs] = useState('');
    const [fraisGestion, setFraisGestion] = useState('');
    const [situationFamiliale, setSituationFamiliale] = useState('');
    const [nbParts, setNbParts] = useState('');
    const [revenuImposable, setRevenuImposable] = useState('');
    const [result, setResult] = useState<any>(null);

    const calculateFlatTax = () => {
      const div = parseFloat(dividendes) || 0;
      const int = parseFloat(interets) || 0;
      const pv = parseFloat(plusValuesValeurs) || 0;
      const frais = parseFloat(fraisGestion) || 0;
      const parts = parseFloat(nbParts) || 1;
      const revenu = parseFloat(revenuImposable) || 0;

      if (div === 0 && int === 0 && pv === 0) return;

      const revenus = div + int + pv;
      const revenusNets = Math.max(0, revenus - frais);

      // Calcul Flat Tax (PFU)
      const flatTax = {
        revenus: revenusNets,
        impotRevenu: revenusNets * 0.128, // 12.8%
        prelevementsSociaux: revenusNets * 0.172, // 17.2%
        total: revenusNets * 0.30,
        netApresImpot: revenusNets * 0.70
      };

      // Calcul barème progressif
      const quotientFamilial = revenu / parts;
      let tauxMarginal = 0;
      
      // Barème 2024
      if (quotientFamilial <= 11294) tauxMarginal = 0;
      else if (quotientFamilial <= 28797) tauxMarginal = 0.11;
      else if (quotientFamilial <= 82341) tauxMarginal = 0.30;
      else if (quotientFamilial <= 177106) tauxMarginal = 0.41;
      else tauxMarginal = 0.45;

      // Abattement dividendes (40%)
      const dividendesAbattus = div * 0.60;
      const revenusBareme = dividendesAbattus + int + pv - frais;

      const bareme = {
        revenus: revenusBareme,
        impotRevenu: Math.max(0, revenusBareme * tauxMarginal),
        prelevementsSociaux: revenusNets * 0.172,
        total: Math.max(0, revenusBareme * tauxMarginal) + (revenusNets * 0.172),
        netApresImpot: revenusNets - (Math.max(0, revenusBareme * tauxMarginal) + (revenusNets * 0.172)),
        tauxMarginal
      };

      const economie = bareme.total - flatTax.total;
      const meilleurChoix = flatTax.total < bareme.total ? 'flatTax' : 'bareme';

      setResult({
        revenus,
        revenusNets,
        flatTax,
        bareme,
        economie,
        meilleurChoix,
        pourcentageEconomie: revenus > 0 ? Math.abs(economie / revenus) * 100 : 0
      });
    };

    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Dividendes perçus (€)
            </label>
            <input
              type="number"
              value={dividendes}
              onChange={(e) => setDividendes(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              placeholder="15000"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Intérêts et revenus obligataires (€)
            </label>
            <input
              type="number"
              value={interets}
              onChange={(e) => setInterets(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              placeholder="5000"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Plus-values valeurs mobilières (€)
            </label>
            <input
              type="number"
              value={plusValuesValeurs}
              onChange={(e) => setPlusValuesValeurs(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              placeholder="8000"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Frais de gestion déductibles (€)
            </label>
            <input
              type="number"
              value={fraisGestion}
              onChange={(e) => setFraisGestion(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              placeholder="500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Revenu imposable total (€)
            </label>
            <input
              type="number"
              value={revenuImposable}
              onChange={(e) => setRevenuImposable(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              placeholder="80000"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nombre de parts fiscales
            </label>
            <input
              type="number"
              value={nbParts}
              onChange={(e) => setNbParts(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              placeholder="2"
              step="0.5"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Situation familiale
            </label>
            <select
              value={situationFamiliale}
              onChange={(e) => setSituationFamiliale(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent pr-8"
            >
              <option value="">Sélectionner</option>
              <option value="celibataire">Célibataire</option>
              <option value="marie">Marié/PACS</option>
              <option value="divorce">Divorcé</option>
              <option value="veuf">Veuf/Veuve</option>
            </select>
          </div>
        </div>

        <button
          onClick={calculateFlatTax}
          className="w-full bg-red-600 text-white py-3 px-6 rounded-lg hover:bg-red-700 transition-colors font-medium"
        >
          Comparer Flat Tax vs Barème Progressif
        </button>

        {result && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-red-900 mb-4">Comparaison fiscale</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Flat Tax */}
              <div className="bg-white border border-red-200 rounded-lg p-4">
                <h4 className="font-semibold text-red-800 mb-3 flex items-center">
                  <i className="ri-percent-line mr-2"></i>
                  Prélèvement Forfaitaire Unique (30%)
                </h4>
                <div className="space-y-2 text-sm">
                  <p><span className="font-medium">Revenus nets:</span> {result.flatTax.revenus.toLocaleString('fr-FR')} €</p>
                  <p><span className="font-medium">Impôt sur le revenu (12.8%):</span> {result.flatTax.impotRevenu.toLocaleString('fr-FR')} €</p>
                  <p><span className="font-medium">Prélèvements sociaux (17.2%):</span> {result.flatTax.prelevementsSociaux.toLocaleString('fr-FR')} €</p>
                  <div className="border-t pt-2">
                    <p><span className="font-medium text-red-700">Total impôts:</span> {result.flatTax.total.toLocaleString('fr-FR')} €</p>
                    <p><span className="font-medium text-green-700">Net après impôt:</span> {result.flatTax.netApresImpot.toLocaleString('fr-FR')} €</p>
                  </div>
                </div>
              </div>

              {/* Barème progressif */}
              <div className="bg-white border border-blue-200 rounded-lg p-4">
                <h4 className="font-semibold text-blue-800 mb-3 flex items-center">
                  <i className="ri-bar-chart-line mr-2"></i>
                  Barème Progressif
                </h4>
                <div className="space-y-2 text-sm">
                  <p><span className="font-medium">Revenus nets:</span> {result.bareme.revenus.toLocaleString('fr-FR')} €</p>
                  <p><span className="font-medium">Impôt sur le revenu ({(result.bareme.tauxMarginal * 100).toFixed(0)}%):</span> {result.bareme.impotRevenu.toLocaleString('fr-FR')} €</p>
                  <p><span className="font-medium">Prélèvements sociaux (17.2%):</span> {result.bareme.prelevementsSociaux.toLocaleString('fr-FR')} €</p>
                  <div className="border-t pt-2">
                    <p><span className="font-medium text-blue-700">Total impôts:</span> {result.bareme.total.toLocaleString('fr-FR')} €</p>
                    <p><span className="font-medium text-green-700">Net après impôt:</span> {result.bareme.netApresImpot.toLocaleString('fr-FR')} €</p>
                  </div>
                </div>
                <p className="text-xs text-blue-600 mt-2">
                  Abattement 40% appliqué sur les dividendes
                </p>
              </div>
            </div>

            {/* Recommandation */}
            <div className={`mt-6 p-4 rounded-lg ${result.meilleurChoix === 'flatTax' ? 'bg-red-100' : 'bg-blue-100'}`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className={`font-semibold ${result.meilleurChoix === 'flatTax' ? 'text-red-800' : 'text-blue-800'}`}>
                    <i className="ri-trophy-line mr-1"></i>
                    Meilleur choix: {result.meilleurChoix === 'flatTax' ? 'Prélèvement Forfaitaire Unique' : 'Barème Progressif'}
                  </p>
                  <p className={`text-sm ${result.meilleurChoix === 'flatTax' ? 'text-red-700' : 'text-blue-700'}`}>
                    Économie: {Math.abs(result.economie).toLocaleString('fr-FR')} € ({result.pourcentageEconomie.toFixed(1)}%)
                  </p>
                </div>
                <div className={`text-2xl ${result.meilleurChoix === 'flatTax' ? 'text-red-600' : 'text-blue-600'}`}>
                  {result.meilleurChoix === 'flatTax' ? '30%' : `${(result.bareme.tauxMarginal * 100).toFixed(0)}%`}
                </div>
              </div>
            </div>

            <div className="mt-4 p-3 bg-gray-100 rounded-lg">
              <p className="text-sm text-gray-800">
                <i className="ri-information-line mr-1"></i>
                <strong>Note:</strong> Le choix peut être fait opération par opération. L'option pour le barème progressif est irrévocable pour l'année entière.
              </p>
            </div>
          </div>
        )}
      </div>
    );
  };

  const FoncierCalculator = () => {
    const [loyers, setLoyers] = useState('');
    const [chargesDeductibles, setChargesDeductibles] = useState('');
    const [interetsEmprunt, setInteretsEmprunt] = useState('');
    const [travaux, setTravaux] = useState('');
    const [assurances, setAssurances] = useState('');
    const [fraisGestion, setFraisGestion] = useState('');
    const [taxeFonciere, setTaxeFonciere] = useState('');
    const [amortissements, setAmortissements] = useState('');
    const [situationFamiliale, setSituationFamiliale] = useState('');
    const [tauxMarginal, setTauxMarginal] = useState('');
    const [result, setResult] = useState<any>(null);

    const calculateFoncier = () => {
      const loyersAnnuels = parseFloat(loyers);
      const charges = parseFloat(chargesDeductibles) || 0;
      const interets = parseFloat(interetsEmprunt) || 0;
      const travauxAnnuels = parseFloat(travaux) || 0;
      const assurance = parseFloat(assurances) || 0;
      const gestion = parseFloat(fraisGestion) || 0;
      const taxe = parseFloat(taxeFonciere) || 0;
      const amort = parseFloat(amortissements) || 0;
      const taux = parseFloat(tauxMarginal) || 0;

      if (!loyersAnnuels) return;

      // Régime micro-foncier
      const microFoncier = {
        applicable: loyersAnnuels <= 15000,
        loyers: loyersAnnuels,
        abattement: loyersAnnuels * 0.30,
        revenuImposable: loyersAnnuels * 0.70,
        impot: (loyersAnnuels * 0.70) * (taux / 100),
        prelevementsSociaux: (loyersAnnuels * 0.70) * 0.172,
        totalImpots: ((loyersAnnuels * 0.70) * (taux / 100)) + ((loyersAnnuels * 0.70) * 0.172),
        revenuNet: loyersAnnuels - (((loyersAnnuels * 0.70) * (taux / 100)) + ((loyersAnnuels * 0.70) * 0.172))
      };

      // Régime réel
      const totalCharges = charges + interets + travauxAnnuels + assurance + gestion + taxe + amort;
      const regimeReel = {
        loyers: loyersAnnuels,
        charges: totalCharges,
        revenuImposable: Math.max(0, loyersAnnuels - totalCharges),
        impot: Math.max(0, loyersAnnuels - totalCharges) * (taux / 100),
        prelevementsSociaux: Math.max(0, loyersAnnuels - totalCharges) * 0.172,
        totalImpots: (Math.max(0, loyersAnnuels - totalCharges) * (taux / 100)) + (Math.max(0, loyersAnnuels - totalCharges) * 0.172),
        revenuNet: loyersAnnuels - totalCharges - ((Math.max(0, loyersAnnuels - totalCharges) * (taux / 100)) + (Math.max(0, loyersAnnuels - totalCharges) * 0.172)),
        deficitReportable: Math.max(0, totalCharges - loyersAnnuels)
      };

      const economie = microFoncier.totalImpots - regimeReel.totalImpots;
      const meilleurRegime = regimeReel.revenuNet > microFoncier.revenuNet ? 'reel' : 'micro';
      
      const rendementMicro = loyersAnnuels > 0 ? (microFoncier.revenuNet / loyersAnnuels) * 100 : 0;
      const rendementReel = loyersAnnuels > 0 ? (regimeReel.revenuNet / loyersAnnuels) * 100 : 0;

      setResult({
        microFoncier,
        regimeReel,
        economie,
        meilleurRegime,
        rendementMicro,
        rendementReel,
        pourcentageEconomie: loyersAnnuels > 0 ? Math.abs(economie / loyersAnnuels) * 100 : 0
      });
    };

    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Loyers annuels perçus (€)
            </label>
            <input
              type="number"
              value={loyers}
              onChange={(e) => setLoyers(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              placeholder="18000"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Taux marginal d'imposition (%)
            </label>
            <select
              value={tauxMarginal}
              onChange={(e) => setTauxMarginal(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent pr-8"
            >
              <option value="">Sélectionner</option>
              <option value="0">0% (non imposable)</option>
              <option value="11">11% (1ère tranche)</option>
              <option value="30">30% (2ème tranche)</option>
              <option value="41">41% (3ème tranche)</option>
              <option value="45">45% (4ème tranche)</option>
            </select>
          </div>

          <div className="md:col-span-2">
            <h4 className="font-medium text-gray-900 mb-3">Charges déductibles (régime réel)</h4>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Charges de copropriété (€)
            </label>
            <input
              type="number"
              value={chargesDeductibles}
              onChange={(e) => setChargesDeductibles(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              placeholder="2000"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Intérêts d'emprunt (€)
            </label>
            <input
              type="number"
              value={interetsEmprunt}
              onChange={(e) => setInteretsEmprunt(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              placeholder="4000"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Travaux et réparations (€)
            </label>
            <input
              type="number"
              value={travaux}
              onChange={(e) => setTravaux(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              placeholder="1500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Assurances (€)
            </label>
            <input
              type="number"
              value={assurances}
              onChange={(e) => setAssurances(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              placeholder="800"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Frais de gestion (€)
            </label>
            <input
              type="number"
              value={fraisGestion}
              onChange={(e) => setFraisGestion(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              placeholder="600"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Taxe foncière (€)
            </label>
            <input
              type="number"
              value={taxeFonciere}
              onChange={(e) => setTaxeFonciere(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              placeholder="1200"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Amortissements (€)
            </label>
            <input
              type="number"
              value={amortissements}
              onChange={(e) => setAmortissements(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              placeholder="2000"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Situation familiale
            </label>
            <select
              value={situationFamiliale}
              onChange={(e) => setSituationFamiliale(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent pr-8"
            >
              <option value="">Sélectionner</option>
              <option value="celibataire">Célibataire</option>
              <option value="marie">Marié/PACS</option>
              <option value="divorce">Divorcé</option>
              <option value="veuf">Veuf/Veuve</option>
            </select>
          </div>
        </div>

        <button
          onClick={calculateFoncier}
          className="w-full bg-indigo-600 text-white py-3 px-6 rounded-lg hover:bg-indigo-700 transition-colors font-medium"
        >
          Comparer Micro-foncier vs Régime Réel
        </button>

        {result && (
          <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-6">
            <h3 className="text-lg font-semibold text-indigo-900 mb-4">Comparaison des régimes fiscaux</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Micro-foncier */}
              <div className={`bg-white border rounded-lg p-4 ${!result.microFoncier.applicable ? 'opacity-50' : ''}`}>
                <h4 className="font-semibold text-indigo-800 mb-3 flex items-center">
                  <i className="ri-home-smile-line mr-2"></i>
                  Micro-foncier {!result.microFoncier.applicable && '(Non applicable)'}
                </h4>
                {!result.microFoncier.applicable && (
                  <p className="text-sm text-red-600 mb-3">Loyers &gt; 15 000 € - Régime non applicable</p>
                )}
                <div className="space-y-2 text-sm">
                  <p><span className="font-medium">Loyers:</span> {result.microFoncier.loyers.toLocaleString('fr-FR')} €</p>
                  <p><span className="font-medium">Abattement (30%):</span> {result.microFoncier.abattement.toLocaleString('fr-FR')} €</p>
                  <p><span className="font-medium">Revenu imposable:</span> {result.microFoncier.revenuImposable.toLocaleString('fr-FR')} €</p>
                  <p><span className="font-medium">Impôt sur le revenu:</span> {result.microFoncier.impot.toLocaleString('fr-FR')} €</p>
                  <p><span className="font-medium">Prélèvements sociaux:</span> {result.microFoncier.prelevementsSociaux.toLocaleString('fr-FR')} €</p>
                  <div className="border-t pt-2">
                    <p><span className="font-medium text-indigo-700">Total impôts:</span> {result.microFoncier.totalImpots.toLocaleString('fr-FR')} €</p>
                    <p><span className="font-medium text-green-700">Revenu net:</span> {result.microFoncier.revenuNet.toLocaleString('fr-FR')} €</p>
                    <p><span className="font-medium">Rendement net:</span> {result.rendementMicro.toFixed(1)}%</p>
                  </div>
                </div>
              </div>

              {/* Régime réel */}
              <div className="bg-white border border-indigo-200 rounded-lg p-4">
                <h4 className="font-semibold text-indigo-800 mb-3 flex items-center">
                  <i className="ri-calculator-line mr-2"></i>
                  Régime Réel
                </h4>
                <div className="space-y-2 text-sm">
                  <p><span className="font-medium">Loyers:</span> {result.regimeReel.loyers.toLocaleString('fr-FR')} €</p>
                  <p><span className="font-medium">Total charges:</span> {result.regimeReel.charges.toLocaleString('fr-FR')} €</p>
                  <p><span className="font-medium">Revenu imposable:</span> {result.regimeReel.revenuImposable.toLocaleString('fr-FR')} €</p>
                  <p><span className="font-medium">Impôt sur le revenu:</span> {result.regimeReel.impot.toLocaleString('fr-FR')} €</p>
                  <p><span className="font-medium">Prélèvements sociaux:</span> {result.regimeReel.prelevementsSociaux.toLocaleString('fr-FR')} €</p>
                  <div className="border-t pt-2">
                    <p><span className="font-medium text-indigo-700">Total impôts:</span> {result.regimeReel.totalImpots.toLocaleString('fr-FR')} €</p>
                    <p><span className="font-medium text-green-700">Revenu net:</span> {result.regimeReel.revenuNet.toLocaleString('fr-FR')} €</p>
                    <p><span className="font-medium">Rendement net:</span> {result.rendementReel.toFixed(1)}%</p>
                  </div>
                  {result.regimeReel.deficitReportable > 0 && (
                    <p className="text-sm text-blue-600 mt-1">Déficit reportable: {result.regimeReel.deficitReportable.toLocaleString('fr-FR')} €</p>
                  )}
                </div>
              </div>
            </div>

            {/* Recommandation */}
            <div className={`mt-6 p-4 rounded-lg ${result.meilleurRegime === 'micro' ? 'bg-green-100' : 'bg-blue-100'}`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className={`font-semibold ${result.meilleurRegime === 'micro' ? 'text-green-800' : 'text-blue-800'}`}>
                    <i className="ri-trophy-line mr-1"></i>
                    Régime optimal: {result.meilleurRegime === 'micro' ? 'Micro-foncier' : 'Régime Réel'}
                  </p>
                  <p className={`text-sm ${result.meilleurRegime === 'micro' ? 'text-green-700' : 'text-blue-700'}`}>
                    Gain annuel: {Math.abs(result.economie).toLocaleString('fr-FR')} € ({result.pourcentageEconomie.toFixed(1)}%)
                  </p>
                </div>
                <div className={`text-2xl ${result.meilleurRegime === 'micro' ? 'text-green-600' : 'text-blue-600'}`}>
                  {result.meilleurRegime === 'micro' ? result.rendementMicro.toFixed(1) : result.rendementReel.toFixed(1)}%
                </div>
              </div>
            </div>

            <div className="mt-4 p-3 bg-indigo-100 rounded-lg">
              <p className="text-sm text-indigo-800">
                <i className="ri-lightbulb-line mr-1"></i>
                <strong>Conseil d'expert:</strong> {result.meilleurRegime === 'reel' ? 
                  'Le régime réel permet de déduire toutes vos charges réelles. Conservez tous vos justificatifs.' :
                  'Le micro-foncier simplifie vos déclarations avec un abattement forfaitaire de 30%.'}
              </p>
            </div>
          </div>
        )}
      </div>
    );
  };

  const renderCalculator = () => {
    switch (activeCalculator) {
      case 'succession':
        return <SuccessionCalculator />;
      case 'plusvalues':
        return <PlusValuesCalculator />;
      case 'ifi':
        return <IFICalculator />;
      case 'donation':
        return <DonationCalculator />;
      case 'flattax':
        return <FlatTaxCalculator />;
      case 'foncier':
        return <FoncierCalculator />;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Assistant Juridique</h2>
        <p className="text-gray-600">Calculateurs spécialisés pour optimiser votre fiscalité</p>
      </div>

      {!activeCalculator ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {calculators.map((calc) => (
            <button
              key={calc.id}
              onClick={() => setActiveCalculator(calc.id)}
              className={`${calc.color} border-2 rounded-xl p-6 text-left hover:shadow-lg transition-all duration-200 hover:scale-105`}
            >
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 flex items-center justify-center">
                  <i className={`${calc.icon} text-2xl`}></i>
                </div>
                <h3 className="text-lg font-semibold ml-3">{calc.title}</h3>
              </div>
              <p className="text-sm opacity-80">{calc.description}</p>
            </button>
          ))}
        </div>
      ) : (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <button
              onClick={() => setActiveCalculator(null)}
              className="flex items-center text-gray-600 hover:text-gray-900 transition-colors"
            >
              <i className="ri-arrow-left-line mr-2"></i>
              Retour aux calculateurs
            </button>
            <h3 className="text-xl font-semibold text-gray-900">
              {calculators.find(c => c.id === activeCalculator)?.title}
            </h3>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-6">
            {renderCalculator()}
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <p className="text-sm text-yellow-800">
              <i className="ri-alert-line mr-1"></i>
              <strong>Avertissement:</strong> Ces calculateurs sont fournis à titre informatif. 
              Consultez un expert-comptable ou un conseiller fiscal pour une analyse personnalisée de votre situation.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
