'use client';

interface ImmobilierModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ImmobilierModal({ isOpen, onClose }: ImmobilierModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 rounded-xl border border-orange-500/30 max-w-5xl w-full max-h-[95vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-700">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-orange-500/20 rounded-lg flex items-center justify-center">
                <i className="ri-building-line text-2xl text-orange-400"></i>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">Immobilier Locatif & SCPI</h2>
                <p className="text-gray-400">Investissement immobilier avec revenus locatifs réguliers</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-gray-700 transition-colors cursor-pointer"
            >
              <i className="ri-close-line text-xl text-gray-400"></i>
            </button>
          </div>
        </div>

        <div className="p-6 space-y-8">
          {/* Vue d'ensemble */}
          <div>
            <h3 className="text-xl font-bold text-white mb-4">Vue d'ensemble</h3>
            <div className="bg-black/30 p-6 rounded-xl">
              <p className="text-gray-300 leading-relaxed mb-4">
                L'immobilier locatif permet de générer des revenus réguliers tout en constituant un patrimoine durable.
                Les SCPI offrent un accès simplifié à l'immobilier professionnel avec une gestion déléguée.
              </p>
              <div className="grid md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-400">4-6%</div>
                  <div className="text-sm text-gray-400">Rendement locatif</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-yellow-400">Modéré</div>
                  <div className="text-sm text-gray-400">Niveau de risque</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-400">Long terme</div>
                  <div className="text-sm text-gray-400">Horizon placement</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-400">Mensuel</div>
                  <div className="text-sm text-gray-400">Versement loyers</div>
                </div>
              </div>
            </div>
          </div>

          {/* Comparaison SCPI vs Immobilier Direct */}
          <div>
            <h3 className="text-xl font-bold text-white mb-4">SCPI vs Immobilier Direct</h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-green-500/10 p-6 rounded-xl border border-green-500/20">
                <h4 className="font-semibold text-white mb-4 flex items-center">
                  <i className="ri-building-2-line text-green-400 mr-2"></i>
                  SCPI (Sociétés Civiles de Placement Immobilier)
                </h4>
                <div className="space-y-3">
                  <div className="flex items-start space-x-2">
                    <i className="ri-check-line text-green-400 mt-0.5"></i>
                    <span className="text-sm text-gray-300">Gestion déléguée à des professionnels</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <i className="ri-check-line text-green-400 mt-0.5"></i>
                    <span className="text-sm text-gray-300">Diversification géographique et sectorielle</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <i className="ri-check-line text-green-400 mt-0.5"></i>
                    <span className="text-sm text-gray-300">Accessibilité dès 1 000€</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <i className="ri-close-line text-red-400 mt-0.5"></i>
                    <span className="text-sm text-gray-300">Frais de gestion (8-10%)</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <i className="ri-close-line text-red-400 mt-0.5"></i>
                    <span className="text-sm text-gray-300">Liquidité limitée</span>
                  </div>
                </div>
              </div>

              <div className="bg-blue-500/10 p-6 rounded-xl border border-blue-500/20">
                <h4 className="font-semibold text-white mb-4 flex items-center">
                  <i className="ri-home-line text-blue-400 mr-2"></i>
                  Immobilier Locatif Direct
                </h4>
                <div className="space-y-3">
                  <div className="flex items-start space-x-2">
                    <i className="ri-check-line text-green-400 mt-0.5"></i>
                    <span className="text-sm text-gray-300">Contrôle total de l'investissement</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <i className="ri-check-line text-green-400 mt-0.5"></i>
                    <span className="text-sm text-gray-300">Plus-values potentielles importantes</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <i className="ri-check-line text-green-400 mt-0.5"></i>
                    <span className="text-sm text-gray-300">Effet de levier avec emprunt</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <i className="ri-close-line text-red-400 mt-0.5"></i>
                    <span className="text-sm text-gray-300">Gestion locative chronophage</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <i className="ri-close-line text-red-400 mt-0.5"></i>
                    <span className="text-sm text-gray-300">Capital important requis</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Types de SCPI */}
          <div>
            <h3 className="text-xl font-bold text-white mb-4">Types de SCPI</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-blue-500/10 p-4 rounded-xl border border-blue-500/20">
                <h4 className="font-semibold text-white mb-3 flex items-center">
                  <i className="ri-building-4-line text-blue-400 mr-2"></i>
                  SCPI de Bureaux
                </h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Rendement moyen:</span>
                    <span className="text-white font-semibold">4,0 - 5,5%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Stabilité:</span>
                    <span className="text-green-400">Élevée</span>
                  </div>
                  <p className="text-gray-300 text-xs mt-2">
                    Focus sur les bureaux en centre-ville et quartiers d'affaires.
                  </p>
                </div>
              </div>

              <div className="bg-green-500/10 p-4 rounded-xl border border-green-500/20">
                <h4 className="font-semibold text-white mb-3 flex items-center">
                  <i className="ri-store-line text-green-400 mr-2"></i>
                  SCPI Commerciales
                </h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Rendement moyen:</span>
                    <span className="text-white font-semibold">4,5 - 6,0%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Stabilité:</span>
                    <span className="text-yellow-400">Moyenne</span>
                  </div>
                  <p className="text-gray-300 text-xs mt-2">
                    Centres commerciaux, magasins et surfaces spécialisées.
                  </p>
                </div>
              </div>

              <div className="bg-purple-500/10 p-4 rounded-xl border border-purple-500/20">
                <h4 className="font-semibold text-white mb-3 flex items-center">
                  <i className="ri-hospital-line text-purple-400 mr-2"></i>
                  SCPI Spécialisées
                </h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Rendement moyen:</span>
                    <span className="text-white font-semibold">5,0 - 7,0%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Stabilité:</span>
                    <span className="text-yellow-400">Variable</span>
                  </div>
                  <p className="text-gray-300 text-xs mt-2">
                    EHPAD, résidences étudiantes, cliniques et infrastructures.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Fiscalité immobilière */}
          <div>
            <h3 className="text-xl font-bold text-white mb-4">Fiscalité de l'Immobilier</h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-orange-500/10 p-6 rounded-xl border border-orange-500/20">
                <h4 className="font-semibold text-white mb-3">SCPI - Revenus Fonciers</h4>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Imposition:</span>
                    <span className="text-white font-semibold">Barème IR</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Prélèvements sociaux:</span>
                    <span className="text-yellow-400 font-semibold">17,2%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Abattement forfaitaire:</span>
                    <span className="text-green-400 font-semibold">30%</span>
                  </div>
                  <div className="border-t border-orange-500/20 pt-2">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Fiscalité totale moyenne:</span>
                      <span className="text-orange-400 font-bold">35-50%</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-blue-500/10 p-6 rounded-xl border border-blue-500/20">
                <h4 className="font-semibold text-white mb-3">Immobilier Direct</h4>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Revenus fonciers:</span>
                    <span className="text-white">Barème IR + 17,2%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Régime micro-foncier:</span>
                    <span className="text-green-400">Abattement 30%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Plus-values (>22 ans):</span>
                    <span className="text-green-400 font-semibold">Exonération</span>
                  </div>
                  <div className="text-xs text-blue-300 mt-2">
                    Possibilité déficit foncier
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Avantages et inconvénients */}
          <div>
            <h3 className="text-xl font-bold text-white mb-4">Avantages & Inconvénients</h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-green-500/10 p-6 rounded-xl border border-green-500/20">
                <h4 className="font-semibold text-white mb-4 flex items-center">
                  <i className="ri-thumb-up-line text-green-400 mr-2"></i>
                  Avantages
                </h4>
                <ul className="space-y-3">
                  <li className="flex items-start space-x-2">
                    <i className="ri-check-line text-green-400 mt-0.5"></i>
                    <div>
                      <span className="text-white font-medium">Revenus réguliers</span>
                      <p className="text-gray-300 text-xs">Loyers mensuels ou trimestriels</p>
                    </div>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-check-line text-green-400 mt-0.5"></i>
                    <div>
                      <span className="text-white font-medium">Protection inflation</span>
                      <p className="text-gray-300 text-xs">Indexation des loyers</p>
                    </div>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-check-line text-green-400 mt-0.5"></i>
                    <div>
                      <span className="text-white font-medium">Patrimoine tangible</span>
                      <p className="text-gray-300 text-xs">Actif réel et durable</p>
                    </div>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-check-line text-green-400 mt-0.5"></i>
                    <div>
                      <span className="text-white font-medium">Diversification</span>
                      <p className="text-gray-300 text-xs">Décorrélé des marchés financiers</p>
                    </div>
                  </li>
                </ul>
              </div>

              <div className="bg-red-500/10 p-6 rounded-xl border border-red-500/20">
                <h4 className="font-semibold text-white mb-4 flex items-center">
                  <i className="ri-thumb-down-line text-red-400 mr-2"></i>
                  Inconvénients
                </h4>
                <ul className="space-y-3">
                  <li className="flex items-start space-x-2">
                    <i className="ri-close-line text-red-400 mt-0.5"></i>
                    <div>
                      <span className="text-white font-medium">Faible liquidité</span>
                      <p className="text-gray-300 text-xs">Revente parfois difficile</p>
                    </div>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-close-line text-red-400 mt-0.5"></i>
                    <div>
                      <span className="text-white font-medium">Fiscalité lourde</span>
                      <p className="text-gray-300 text-xs">IR + prélèvements sociaux</p>
                    </div>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-close-line text-red-400 mt-0.5"></i>
                    <div>
                      <span className="text-white font-medium">Frais élevés</span>
                      <p className="text-gray-300 text-xs">Acquisition, gestion, revente</p>
                    </div>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-close-line text-red-400 mt-0.5"></i>
                    <div>
                      <span className="text-white font-medium">Risque vacance</span>
                      <p className="text-gray-300 text-xs">Perte de revenus locatifs</p>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* Performance historique */}
          <div>
            <h3 className="text-xl font-bold text-white mb-4">Performance Historique</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-700">
                    <th className="text-left py-3 text-gray-400">Type d'investissement</th>
                    <th className="text-center py-3 text-blue-400">Rendement 2023</th>
                    <th className="text-center py-3 text-green-400">Rendement 5 ans</th>
                    <th className="text-center py-3 text-purple-400">Taux de vacance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-700">
                  <tr>
                    <td className="py-3 text-gray-300">SCPI bureaux</td>
                    <td className="py-3 text-center text-white">4,2%</td>
                    <td className="py-3 text-center text-white">4,8%</td>
                    <td className="py-3 text-center text-green-400">3,2%</td>
                  </tr>
                  <tr>
                    <td className="py-3 text-gray-300">SCPI commerces</td>
                    <td className="py-3 text-center text-green-400">5,1%</td>
                    <td className="py-3 text-center text-green-400">5,3%</td>
                    <td className="py-3 text-center text-yellow-400">4,8%</td>
                  </tr>
                  <tr>
                    <td className="py-3 text-gray-300">SCPI santé</td>
                    <td className="py-3 text-center text-green-400">5,8%</td>
                    <td className="py-3 text-center text-green-400">6,1%</td>
                    <td className="py-3 text-center text-green-400">1,9%</td>
                  </tr>
                  <tr>
                    <td className="py-3 text-gray-300">Immobilier direct résidentiel</td>
                    <td className="py-3 text-center text-white">3,8%</td>
                    <td className="py-3 text-center text-white">4,2%</td>
                    <td className="py-3 text-center text-orange-400">6,5%</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Conseils et recommandations */}
          <div className="bg-gradient-to-r from-orange-500/20 to-orange-600/20 p-6 rounded-xl border border-orange-500/30">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center">
              <i className="ri-lightbulb-line text-orange-400 mr-3"></i>
              Conseils d'Experts
            </h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-white mb-3">Bonnes Pratiques</h4>
                <ul className="space-y-2 text-sm text-gray-300">
                  <li className="flex items-start space-x-2">
                    <i className="ri-checkbox-circle-line text-green-400 mt-0.5"></i>
                    <span>Diversifier géographiquement</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-checkbox-circle-line text-green-400 mt-0.5"></i>
                    <span>Analyser la qualité de gestion</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-checkbox-circle-line text-green-400 mt-0.5"></i>
                    <span>Vérifier taux d'occupation</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-checkbox-circle-line text-green-400 mt-0.5"></i>
                    <span>Privilégier secteurs porteurs</span>
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-white mb-3">Erreurs à Éviter</h4>
                <ul className="space-y-2 text-sm text-gray-300">
                  <li className="flex items-start space-x-2">
                    <i className="ri-close-circle-line text-red-400 mt-0.5"></i>
                    <span>Se concentrer sur une zone</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-close-circle-line text-red-400 mt-0.5"></i>
                    <span>Négliger les frais de gestion</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-close-circle-line text-red-400 mt-0.5"></i>
                    <span>Investir sans étude de marché</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-close-circle-line text-red-400 mt-0.5"></i>
                    <span>Surestimer la liquidité</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* Actions disponibles */}
          <div className="flex space-x-4 pt-4 border-t border-gray-700">
            <button className="flex-1 bg-orange-500 text-white py-3 px-6 rounded-lg font-semibold hover:bg-orange-400 transition-colors cursor-pointer whitespace-nowrap">
              Investir en SCPI
            </button>
            <button className="flex-1 bg-green-500 text-white py-3 px-6 rounded-lg font-semibold hover:bg-green-400 transition-colors cursor-pointer whitespace-nowrap">
              Calculer ma Rentabilité
            </button>
            <button
              onClick={onClose}
              className="px-6 py-3 border border-gray-600 text-gray-300 rounded-lg hover:bg-gray-700 transition-colors cursor-pointer whitespace-nowrap"
            >
              Fermer
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}