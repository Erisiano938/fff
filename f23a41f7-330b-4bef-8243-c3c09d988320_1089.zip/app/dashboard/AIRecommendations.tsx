'use client';

import { useState } from 'react';

export default function AIRecommendations() {
  const [currentStep, setCurrentStep] = useState(0);
  const [mifidProfile, setMifidProfile] = useState({
    // Connaissances et expérience
    investmentExperience: '',
    financialProducts: [],
    tradingFrequency: '',
    educationLevel: '',

    // Situation financière
    income: 50000,
    savings: 10000,
    monthlyInvestment: 500,
    existingInvestments: [],

    // Objectifs d'investissement
    investmentObjectives: [],
    timeHorizon: '',
    expectedReturn: '',

    // Tolérance au risque
    riskTolerance: '',
    maxLoss: '',
    volatilityComfort: '',

    // Informations personnelles
    age: 30,
    familySituation: '',
    professionalStatus: '',
    retirementPlanning: ''
  });

  const [profileCompleted, setProfileCompleted] = useState(false);
  const [recommendations, setRecommendations] = useState([]);
  const [isGenerating, setIsGenerating] = useState(false);

  const mifidSteps = [
    {
      title: 'Connaissances et Expérience',
      subtitle: 'Évaluation de votre expertise financière',
      icon: 'ri-graduation-cap-line'
    },
    {
      title: 'Situation Financière',
      subtitle: 'Analyse de votre capacité d\'investissement',
      icon: 'ri-money-euro-circle-line'
    },
    {
      title: 'Objectifs d\'Investissement',
      subtitle: 'Définition de vos buts financiers',
      icon: 'ri-target-line'
    },
    {
      title: 'Tolérance au Risque',
      subtitle: 'Mesure de votre appétit pour le risque',
      icon: 'ri-scales-line'
    }
  ];

  const generateMifidRecommendations = async () => {
    setIsGenerating(true);

    setTimeout(() => {
      // Calcul du score MiFID
      const experienceScore = calculateExperienceScore();
      const riskScore = calculateRiskScore();
      const capacityScore = calculateCapacityScore();

      const mockRecommendations = [
        {
          category: 'Profil MiFID',
          title: `Profil Investisseur : ${getInvestorProfile(experienceScore, riskScore)}`,
          content: `Selon l\'évaluation MiFID, vous êtes classé comme investisseur ${getInvestorProfile(experienceScore, riskScore).toLowerCase()}. Votre score d\'expérience est de ${experienceScore}/10, votre tolérance au risque de ${riskScore}/10, et votre capacité financière de ${capacityScore}/10.`,
          priority: 'high',
          icon: 'ri-user-star-line',
          mifidCompliant: true,
          actions: [
            'Produits recommandés selon MiFID',
            'Allocation adaptée à votre profil',
            'Suivi personnalisé requis'
          ]
        },
        {
          category: 'Allocation Recommandée',
          title: 'Répartition Conforme MiFID',
          content: generateAllocationAdvice(experienceScore, riskScore, capacityScore),
          priority: 'high',
          icon: 'ri-pie-chart-line',
          mifidCompliant: true,
          actions: getRecommendedActions(experienceScore, riskScore)
        },
        {
          category: 'Produits Éligibles',
          title: 'Instruments Financiers Autorisés',
          content: getEligibleProducts(experienceScore, riskScore),
          priority: 'medium',
          icon: 'ri-shield-check-line',
          mifidCompliant: true,
          actions: [ 'Vérification continue', 'Formation si nécessaire', 'Révision annuelle' ]
        },
        {
          category: 'Avertissements MiFID',
          title: 'Obligations Réglementaires',
          content: 'Conformément à MiFID II, cette évaluation doit être mise à jour régulièrement. Tout changement de situation doit être signalé. Les produits complexes nécessitent une expertise supplémentaire.',
          priority: 'medium',
          icon: 'ri-alert-line',
          mifidCompliant: true,
          actions: [ 'Mise à jour annuelle', 'Formation continue', 'Documentation obligatoire' ]
        }
      ];

      setRecommendations(mockRecommendations);
      setIsGenerating(false);
    }, 2000);
  };

  const calculateExperienceScore = () => {
    let score = 0;

    // Expérience d'investissement - scoring plus nuancé
    if (mifidProfile.investmentExperience === 'expert') score += 4;
    else if (mifidProfile.investmentExperience === 'experienced') score += 3.5;
    else if (mifidProfile.investmentExperience === 'practical') score += 2.5;
    else if (mifidProfile.investmentExperience === 'some') score += 1.5;
    else score += 0.5;

    // Opérations réalisées - scoring par complexité
    const operations = mifidProfile.financialProducts;
    const basicOps = operations.filter(op => [ 'savings', 'insurance' ].includes(op)).length;
    const intermediateOps = operations.filter(op => [ 'pea', 'stocks', 'etf', 'bonds' ].includes(op)).length;
    const advancedOps = operations.filter(op => [ 'rebalancing' ].includes(op)).length;
    const expertOps = operations.filter(op => [ 'derivatives', 'options', 'forex' ].includes(op)).length;

    score += basicOps * 0.3;
    score += intermediateOps * 0.7;
    score += advancedOps * 1.2;
    score += expertOps * 1.8;

    // Sources d'information
    if (mifidProfile.educationLevel === 'professional') score += 1.5;
    else if (mifidProfile.educationLevel === 'analysis') score += 1.2;
    else if (mifidProfile.educationLevel === 'specialized') score += 0.8;
    else if (mifidProfile.educationLevel === 'basic') score += 0.3;

    // Capacité d'analyse
    if (mifidProfile.tradingFrequency === 'expert') score += 1.5;
    else if (mifidProfile.tradingFrequency === 'advanced') score += 1.2;
    else if (mifidProfile.tradingFrequency === 'intermediate') score += 0.8;
    else if (mifidProfile.tradingFrequency === 'basic') score += 0.3;

    return Math.min(Math.round(score * 10) / 10, 10);
  };

  const calculateRiskScore = () => {
    let score = 5; // Base neutre

    if (mifidProfile.riskTolerance === 'high') score += 3;
    else if (mifidProfile.riskTolerance === 'medium') score += 1;
    else if (mifidProfile.riskTolerance === 'low') score -= 2;

    if (mifidProfile.maxLoss === 'high') score += 2;
    else if (mifidProfile.maxLoss === 'medium') score += 1;
    else score -= 1;

    return Math.max(1, Math.min(score, 10));
  };

  const calculateCapacityScore = () => {
    let score = 0;

    // Revenus
    if (mifidProfile.income > 100000) score += 4;
    else if (mifidProfile.income > 60000) score += 3;
    else if (mifidProfile.income > 40000) score += 2;
    else score += 1;

    // Épargne
    if (mifidProfile.savings > 50000) score += 3;
    else if (mifidProfile.savings > 20000) score += 2;
    else if (mifidProfile.savings > 5000) score += 1;

    // Capacité mensuelle
    if (mifidProfile.monthlyInvestment > 1000) score += 3;
    else if (mifidProfile.monthlyInvestment > 500) score += 2;
    else if (mifidProfile.monthlyInvestment > 200) score += 1;

    return Math.min(score, 10);
  };

  const getInvestorProfile = (exp, risk) => {
    const average = (exp + risk) / 2;
    if (average >= 8) return 'Expert';
    if (average >= 6) return 'Expérimenté';
    if (average >= 4) return 'Intermédiaire';
    return 'Débutant';
  };

  const generateAllocationAdvice = (exp, risk, capacity) => {
    if (exp <= 3 && risk <= 4) {
      return 'Profil conservateur : 70% fonds euros/obligations, 20% actions via ETF, 10% liquidités. Privilégiez la sécurité et la progression graduelle.';
    } else if (exp <= 6 && risk <= 6) {
      return 'Profil équilibré : 40% obligations/fonds euros, 50% actions diversifiées, 10% alternatifs. Balance entre sécurité et croissance.';
    } else {
      return 'Profil dynamique : 20% obligations, 60% actions, 15% sectoriels/géographiques, 5% alternatifs. Recherche de performance avec volatilité acceptée.';
    }
  };

  const getEligibleProducts = (exp, risk) => {
    if (exp <= 3) {
      return 'Profil débutant : Livrets réglementés, fonds euros d\'assurance vie, ETF World larges, OPCVM diversifiés simples. Les produits dérivés et structurés sont inadaptés à votre niveau d\'expérience.';
    } else if (exp <= 5) {
      return 'Profil intermédiaire : Actions individuelles de grandes entreprises, ETF sectoriels et géographiques, obligations d\'État et corporate, SCPI. Produits structurés simples avec accompagnement professionnel.';
    } else if (exp <= 7) {
      return 'Profil expérimenté : Small caps, ETF thématiques, obligations high yield, warrants, certificats, options vanilles sur indices. Accès aux marchés émergents et stratégies sectorielles.';
    } else {
      return 'Profil expert : Tous instruments autorisés incluant dérivés complexes, options exotiques, CFD, Forex, futures, produits structurés sophistiqués, investissements alternatifs. Expertise confirmée pour tous marchés.';
    }
  };

  const getRecommendedActions = (exp, risk) => {
    const actions = [ 'Diversification géographique', 'Rééquilibrage trimestriel' ];

    if (exp <= 3) {
      actions.push('Formation aux bases de l\'investissement');
      actions.push('Accompagnement conseiller');
    }

    if (risk >= 7) {
      actions.push('Surveillance quotidienne recommandée');
      actions.push('Stop-loss sur positions risquées');
    }

    return actions;
  };

  const nextStep = () => {
    if (currentStep < mifidSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      setProfileCompleted(true);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 0: // Connaissances et Expérience
        return (
          <div className="space-y-6">
            <div>
              <label className="block text-white font-medium mb-3">Quelle est votre expérience en investissement ?</label>
              <div className="space-y-2">
                {[ 
                  {
                    value: 'none',
                    label: 'Débutant complet',
                    desc: 'Aucune expérience pratique des marchés financiers'
                  },
                  {
                    value: 'some',
                    label: 'Connaissances théoriques',
                    desc: 'J\'ai lu, étudié mais peu investi en pratique'
                  },
                  {
                    value: 'practical',
                    label: 'Expérience pratique limitée',
                    desc: 'Quelques investissements simples (livrets, assurance vie)'
                  },
                  {
                    value: 'experienced',
                    label: 'Investisseur actif',
                    desc: 'Gestion régulière d\'un portefeuille diversifié'
                  },
                  {
                    value: 'expert',
                    label: 'Expert confirmé',
                    desc: 'Maîtrise des stratégies avancées et produits complexes'
                  }
                ].map((option) => (
                  <label key={option.value} className="flex items-center space-x-3 cursor-pointer p-3 rounded-lg hover:bg-gray-800/50">
                    <input
                      type="radio"
                      name="investmentExperience"
                      value={option.value}
                      checked={mifidProfile.investmentExperience === option.value}
                      onChange={(e) => setMifidProfile({ ...mifidProfile, investmentExperience: e.target.value })}
                      className="text-yellow-500"
                    />
                    <div>
                      <span className="text-white font-medium">{option.label}</span>
                      <p className="text-gray-400 text-sm">{option.desc}</p>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-white font-medium mb-3">Quelles opérations avez-vous déjà réalisées ? (Plusieurs choix possibles)</label>
              <div className="grid grid-cols-1 gap-3">
                {[ 
                  { value: 'savings', label: 'Ouverture de livrets réglementés', level: 'basic' },
                  { value: 'insurance', label: 'Souscription d\'assurance vie', level: 'basic' },
                  { value: 'pea', label: 'Ouverture et alimentation d\'un PEA', level: 'intermediate' },
                  { value: 'stocks', label: 'Achat/vente d\'actions individuelles', level: 'intermediate' },
                  { value: 'etf', label: 'Investissement dans des ETF', level: 'intermediate' },
                  { value: 'bonds', label: 'Achat d\'obligations', level: 'intermediate' },
                  { value: 'rebalancing', label: 'Rééquilibrage de portefeuille', level: 'advanced' },
                  { value: 'derivatives', label: 'Utilisation de produits dérivés', level: 'expert' },
                  { value: 'options', label: 'Trading d\'options', level: 'expert' },
                  { value: 'forex', label: 'Trading sur le Forex', level: 'expert' }
                ].map((operation) => (
                  <label key={operation.value} className="flex items-center space-x-3 cursor-pointer p-3 rounded-lg hover:bg-gray-800/50 border border-gray-700/50">
                    <input
                      type="checkbox"
                      checked={mifidProfile.financialProducts.includes(operation.value)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setMifidProfile({
                            ...mifidProfile,
                            financialProducts: [...mifidProfile.financialProducts, operation.value]
                          });
                        } else {
                          setMifidProfile({
                            ...mifidProfile,
                            financialProducts: mifidProfile.financialProducts.filter(p => p !== operation.value)
                          });
                        }
                      }}
                      className="text-yellow-500"
                    />
                    <div className="flex-1 flex items-center justify-between">
                      <span className="text-gray-300">{operation.label}</span>
                      <span className={`text-xs px-2 py-1 rounded-full ${operation.level === 'basic' ? 'bg-green-500/20 text-green-400' : operation.level === 'intermediate' ? 'bg-yellow-500/20 text-yellow-400' : operation.level === 'advanced' ? 'bg-orange-500/20 text-orange-400' : 'bg-red-500/20 text-red-400'}`}>
                        {operation.level === 'basic' ? 'Simple' : operation.level === 'intermediate' ? 'Intermédiaire' : operation.level === 'advanced' ? 'Avancé' : 'Expert'}
                      </span>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-white font-medium mb-3">Comment vous tenez-vous informé des marchés ?</label>
              <div className="space-y-2">
                {[ 
                  { value: 'none', label: 'Je ne suis pas les marchés', desc: 'Aucun suivi régulier' },
                  { value: 'basic', label: 'Actualités générales', desc: 'Journaux, sites d\'info généraliste' },
                  { value: 'specialized', label: 'Médias financiers', desc: 'Sites spécialisés, newsletters finance' },
                  { value: 'analysis', label: 'Analyses techniques', desc: 'Graphiques, indicateurs techniques' },
                  { value: 'professional', label: 'Sources professionnelles', desc: 'Bloomberg, Reuters, analyses d\'experts' }
                ].map((source) => (
                  <label key={source.value} className="flex items-center space-x-3 cursor-pointer p-3 rounded-lg hover:bg-gray-800/50">
                    <input
                      type="radio"
                      name="informationSource"
                      value={source.value}
                      checked={mifidProfile.educationLevel === source.value}
                      onChange={(e) => setMifidProfile({ ...mifidProfile, educationLevel: e.target.value })}
                      className="text-yellow-500"
                    />
                    <div>
                      <span className="text-white font-medium">{source.label}</span>
                      <p className="text-gray-400 text-sm">{source.desc}</p>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-white font-medium mb-3">Quelle est votre capacité d\'analyse ?</label>
              <div className="space-y-2">
                {[ 
                  { value: 'none', label: 'Je ne sais pas analyser', desc: 'J\'ai besoin de conseils pour tout' },
                  { value: 'basic', label: 'Notions de base', desc: 'Je comprends les concepts simples' },
                  { value: 'intermediate', label: 'Analyse autonome simple', desc: 'Je peux évaluer des investissements basiques' },
                  { value: 'advanced', label: 'Analyse approfondie', desc: 'Je maîtrise les ratios et valorisations' },
                  { value: 'expert', label: 'Expertise complète', desc: 'Analyse technique et fondamentale avancée' }
                ].map((analysis) => (
                  <label key={analysis.value} className="flex items-center space-x-3 cursor-pointer p-3 rounded-lg hover:bg-gray-800/50">
                    <input
                      type="radio"
                      name="analysisCapability"
                      value={analysis.value}
                      checked={mifidProfile.tradingFrequency === analysis.value}
                      onChange={(e) => setMifidProfile({ ...mifidProfile, tradingFrequency: e.target.value })}
                      className="text-yellow-500"
                    />
                    <div>
                      <span className="text-white font-medium">{analysis.label}</span>
                      <p className="text-gray-400 text-sm">{analysis.desc}</p>
                    </div>
                  </label>
                ))}
              </div>
            </div>
          </div>
        );

      case 1: // Situation Financière
        return (
          <div className="space-y-6">
            <div>
              <label className="block text-white font-medium mb-3">Revenus annuels nets (€)</label>
              <input
                type="range"
                min="20000"
                max="200000"
                step="5000"
                value={mifidProfile.income}
                onChange={(e) => setMifidProfile({ ...mifidProfile, income: Number(e.target.value) })}
                className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-sm text-gray-400 mt-1">
                <span>20K€</span>
                <span className="text-yellow-400 font-semibold">{mifidProfile.income.toLocaleString()} €</span>
                <span>200K€</span>
              </div>
            </div>

            <div>
              <label className="block text-white font-medium mb-3">Épargne disponible (€)</label>
              <input
                type="range"
                min="0"
                max="100000"
                step="1000"
                value={mifidProfile.savings}
                onChange={(e) => setMifidProfile({ ...mifidProfile, savings: Number(e.target.value) })}
                className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-sm text-gray-400 mt-1">
                <span>0€</span>
                <span className="text-yellow-400 font-semibold">{mifidProfile.savings.toLocaleString()} €</span>
                <span>100K€</span>
              </div>
            </div>

            <div>
              <label className="block text-white font-medium mb-3">Capacité d\'investissement mensuelle (€)</label>
              <input
                type="range"
                min="0"
                max="2000"
                step="50"
                value={mifidProfile.monthlyInvestment}
                onChange={(e) => setMifidProfile({ ...mifidProfile, monthlyInvestment: Number(e.target.value) })}
                className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-sm text-gray-400 mt-1">
                <span>0€</span>
                <span className="text-yellow-400 font-semibold">{mifidProfile.monthlyInvestment} €</span>
                <span>2000€</span>
              </div>
            </div>

            <div>
              <label className="block text-white font-medium mb-3">Investissements existants</label>
              <div className="grid grid-cols-2 gap-3">
                {[ 
                  'Livret A/LDD',
                  'Assurance Vie',
                  'PEA',
                  'Actions',
                  'SCPI',
                  'Immobilier locatif',
                  'Crypto',
                  'PER'
                ].map((investment) => (
                  <label key={investment} className="flex items-center space-x-2 cursor-pointer p-2 rounded hover:bg-gray-800/50">
                    <input
                      type="checkbox"
                      checked={mifidProfile.existingInvestments.includes(investment)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setMifidProfile({
                            ...mifidProfile,
                            existingInvestments: [...mifidProfile.existingInvestments, investment]
                          });
                        } else {
                          setMifidProfile({
                            ...mifidProfile,
                            existingInvestments: mifidProfile.existingInvestments.filter(i => i !== investment)
                          });
                        }
                      }}
                      className="text-yellow-500"
                    />
                    <span className="text-gray-300">{investment}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>
        );

      case 2: // Objectifs d'Investissement
        return (
          <div className="space-y-6">
            <div>
              <label className="block text-white font-medium mb-3">Vos objectifs d\'investissement (Plusieurs choix possibles)</label>
              <div className="space-y-3">
                {[ 
                  { value: 'retirement', label: 'Préparer ma retraite', icon: 'ri-time-line' },
                  { value: 'property', label: 'Acheter un bien immobilier', icon: 'ri-home-line' },
                  { value: 'children', label: 'Financer les études des enfants', icon: 'ri-graduation-cap-line' },
                  { value: 'travel', label: 'Financer des projets/voyages', icon: 'ri-plane-line' },
                  { value: 'income', label: 'Générer des revenus complémentaires', icon: 'ri-money-euro-circle-line' },
                  { value: 'wealth', label: 'Faire fructifier mon patrimoine', icon: 'ri-trophy-line' }
                ].map((objective) => (
                  <label key={objective.value} className="flex items-center space-x-3 cursor-pointer p-3 rounded-lg hover:bg-gray-800/50">
                    <input
                      type="checkbox"
                      checked={mifidProfile.investmentObjectives.includes(objective.value)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setMifidProfile({
                            ...mifidProfile,
                            investmentObjectives: [...mifidProfile.investmentObjectives, objective.value]
                          });
                        } else {
                          setMifidProfile({
                            ...mifidProfile,
                            investmentObjectives: mifidProfile.investmentObjectives.filter(o => o !== objective.value)
                          });
                        }
                      }}
                      className="text-yellow-500"
                    />
                    <i className={`${objective.icon} text-yellow-400`}></i>
                    <span className="text-white">{objective.label}</span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-white font-medium mb-3">Horizon d\'investissement principal</label>
              <div className="space-y-2">
                {[ 
                  { value: 'short', label: 'Court terme (moins de 3 ans)', desc: 'Objectifs à court terme' },
                  { value: 'medium', label: 'Moyen terme (3 à 10 ans)', desc: 'Projets à moyen terme' },
                  { value: 'long', label: 'Long terme (plus de 10 ans)', desc: 'Retraite, patrimoine' }
                ].map((horizon) => (
                  <label key={horizon.value} className="flex items-center space-x-3 cursor-pointer p-3 rounded-lg hover:bg-gray-800/50">
                    <input
                      type="radio"
                      name="timeHorizon"
                      value={horizon.value}
                      checked={mifidProfile.timeHorizon === horizon.value}
                      onChange={(e) => setMifidProfile({ ...mifidProfile, timeHorizon: e.target.value })}
                      className="text-yellow-500"
                    />
                    <div>
                      <span className="text-white font-medium">{horizon.label}</span>
                      <p className="text-gray-400 text-sm">{horizon.desc}</p>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-white font-medium mb-3">Rendement attendu annuel</label>
              <select
                value={mifidProfile.expectedReturn}
                onChange={(e) => setMifidProfile({ ...mifidProfile, expectedReturn: e.target.value })}
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-500 focus:outline-none pr-8"
              >
                <option value="">Sélectionnez...</option>
                <option value="conservative">1-3% (Très sécuritaire)</option>
                <option value="moderate">3-6% (Modéré)</option>
                <option value="growth">6-10% (Croissance)</option>
                <option value="aggressive">Plus de 10% (Très dynamique)</option>
              </select>
            </div>
          </div>
        );

      case 3: // Tolérance au Risque
        return (
          <div className="space-y-6">
            <div>
              <label className="block text-white font-medium mb-3">Comment décririez-vous votre tolérance au risque ?</label>
              <div className="space-y-2">
                {[ 
                  { value: 'low', label: 'Prudent', desc: 'Je préfère la sécurité, même pour des rendements faibles' },
                  { value: 'medium', label: 'Équilibré', desc: 'J\'accepte une volatilité modérée pour de meilleurs rendements' },
                  { value: 'high', label: 'Dynamique', desc: 'J\'accepte des risques élevés pour maximiser les gains' }
                ].map((tolerance) => (
                  <label key={tolerance.value} className="flex items-center space-x-3 cursor-pointer p-3 rounded-lg hover:bg-gray-800/50">
                    <input
                      type="radio"
                      name="riskTolerance"
                      value={tolerance.value}
                      checked={mifidProfile.riskTolerance === tolerance.value}
                      onChange={(e) => setMifidProfile({ ...mifidProfile, riskTolerance: e.target.value })}
                      className="text-yellow-500"
                    />
                    <div>
                      <span className="text-white font-medium">{tolerance.label}</span>
                      <p className="text-gray-400 text-sm">{tolerance.desc}</p>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-white font-medium mb-3">Quelle perte maximale accepteriez-vous sur 1 an ?</label>
              <div className="space-y-2">
                {[ 
                  { value: 'low', label: '0-5%', desc: 'Perte très limitée acceptable' },
                  { value: 'medium', label: '5-15%', desc: 'Perte modérée acceptable' },
                  { value: 'high', label: '15-30%', desc: 'Perte importante acceptable' },
                  { value: 'very-high', label: 'Plus de 30%', desc: 'Toute perte acceptable' }
                ].map((loss) => (
                  <label key={loss.value} className="flex items-center space-x-3 cursor-pointer p-3 rounded-lg hover:bg-gray-800/50">
                    <input
                      type="radio"
                      name="maxLoss"
                      value={loss.value}
                      checked={mifidProfile.maxLoss === loss.value}
                      onChange={(e) => setMifidProfile({ ...mifidProfile, maxLoss: e.target.value })}
                      className="text-yellow-500"
                    />
                    <div>
                      <span className="text-white font-medium">{loss.label}</span>
                      <p className="text-gray-400 text-sm">{loss.desc}</p>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-white font-medium mb-3">Comment réagissez-vous aux fluctuations de marché ?</label>
              <div className="space-y-2">
                {[ 
                  { value: 'panic', label: 'Je panique et vends rapidement', desc: 'Réaction émotionnelle forte' },
                  { value: 'worry', label: 'Je m\'inquiète mais j\'attends', desc: 'Stress mais patience' },
                  { value: 'calm', label: 'Je reste calme et analyse', desc: 'Approche rationnelle' },
                  { value: 'opportunity', label: 'Je vois des opportunités d\'achat', desc: 'Vision contrariante' }
                ].map((reaction) => (
                  <label key={reaction.value} className="flex items-center space-x-3 cursor-pointer p-3 rounded-lg hover:bg-gray-800/50">
                    <input
                      type="radio"
                      name="volatilityComfort"
                      value={reaction.value}
                      checked={mifidProfile.volatilityComfort === reaction.value}
                      onChange={(e) => setMifidProfile({ ...mifidProfile, volatilityComfort: e.target.value })}
                      className="text-yellow-500"
                    />
                    <div>
                      <span className="text-white font-medium">{reaction.label}</span>
                      <p className="text-gray-400 text-sm">{reaction.desc}</p>
                    </div>
                  </label>
                ))}
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  if (profileCompleted) {
    return (
      <div className="space-y-8">
        <div className="bg-gradient-to-r from-blue-500/20 to-yellow-500/20 p-6 rounded-xl border border-yellow-500/30">
          <h3 className="text-2xl font-bold text-white mb-2 flex items-center">
            <i className="ri-shield-check-line text-green-400 mr-3"></i>
            Profil MiFID Complété
          </h3>
          <p className="text-gray-300">
            Votre évaluation est conforme à la directive MiFID II.
            Les recommandations ci-dessous respectent les exigences réglementaires européennes.
          </p>
        </div>

        {recommendations.length === 0 ? (
          <div className="text-center">
            <button
              onClick={generateMifidRecommendations}
              disabled={isGenerating}
              className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-black py-4 px-8 rounded-lg font-semibold hover:from-yellow-400 hover:to-yellow-500 transition-all cursor-pointer whitespace-nowrap disabled:opacity-50"
            >
              {isGenerating ? (
                <span className="flex items-center justify-center">
                  <i className="ri-loader-4-line animate-spin mr-2"></i>
                  Génération des recommandations MiFID...
                </span>
              ) : (
                <span className="flex items-center justify-center">
                  <i className="ri-robot-line mr-2"></i>
                  Générer Recommandations Conformes MiFID
                </span>
              )}
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            {recommendations.map((rec, index) => (
              <div key={index} className="bg-gray-900/50 p-6 rounded-xl border border-yellow-500/20">
                <div className="flex items-start space-x-4">
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${rec.priority === 'high' ? 'bg-green-500/20' : 'bg-blue-500/20'}`}>
                    <i className={`${rec.icon} text-2xl ${rec.priority === 'high' ? 'text-green-400' : 'text-blue-400'}`}></i>
                  </div>

                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-3">
                      <span className="bg-gray-800 text-yellow-400 px-3 py-1 rounded-full text-sm font-medium">
                        {rec.category}
                      </span>
                      {rec.mifidCompliant && (
                        <span className="bg-green-500/20 text-green-400 px-2 py-1 rounded-full text-xs font-medium">
                          <i className="ri-shield-check-line mr-1"></i>
                          MiFID Conforme
                        </span>
                      )}
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${rec.priority === 'high' ? 'bg-green-500/20 text-green-400' : 'bg-blue-500/20 text-blue-400'}`}>
                        {rec.priority === 'high' ? 'Priorité élevée' : 'Recommandé'}
                      </span>
                    </div>

                    <h4 className="text-xl font-bold text-white mb-3">{rec.title}</h4>
                    <p className="text-gray-300 mb-4 leading-relaxed">{rec.content}</p>

                    <div>
                      <h5 className="text-white font-semibold mb-2 flex items-center">
                        <i className="ri-check-line text-green-400 mr-2"></i>
                        Actions recommandées
                      </h5>
                      <ul className="space-y-2">
                        {rec.actions.map((action, actionIndex) => (
                          <li key={actionIndex} className="flex items-center space-x-3">
                            <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>
                            <span className="text-gray-300">{action}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            ))}

            <div className="bg-blue-500/10 p-6 rounded-xl border border-blue-500/20">
              <div className="flex items-start space-x-4">
                <i className="ri-information-line text-2xl text-blue-400 mt-1"></i>
                <div>
                  <h4 className="text-blue-400 font-semibold mb-2">Conformité MiFID II</h4>
                  <p className="text-gray-300 text-sm mb-3">
                    Cette évaluation respecte les exigences de la directive MiFID II concernant
                    l\'évaluation du caractère approprié des instruments financiers.
                  </p>
                  <ul className="text-gray-300 text-sm space-y-1">
                    <li>• Évaluation des connaissances et de l\'expérience</li>
                    <li>• Analyse de la situation financière</li>
                    <li>• Identification des objectifs d\'investissement</li>
                    <li>• Mesure de la tolérance au risque</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="flex justify-center">
          <button
            onClick={() => {
              setCurrentStep(0);
              setProfileCompleted(false);
              setRecommendations([]);
            }}
            className="text-yellow-400 hover:text-yellow-300 transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-refresh-line mr-2"></i>
            Refaire l\'évaluation MiFID
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="bg-gradient-to-r from-blue-500/20 to-yellow-500/20 p-6 rounded-xl border border-yellow-500/30">
        <h3 className="text-2xl font-bold text-white mb-2 flex items-center">
          <i className="ri-shield-line text-blue-400 mr-3"></i>
          Évaluation MiFID II
        </h3>
        <p className="text-gray-300">
          Conformément à la directive européenne MiFID II, nous devons évaluer votre profil
          avant de vous proposer des conseils en investissement personnalisés.
        </p>
      </div>

      {/* Indicateur de progression */}
      <div className="flex items-center justify-between mb-8">
        {mifidSteps.map((step, index) => (
          <div key={index} className="flex items-center">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 ${index <= currentStep ? 'bg-yellow-500 border-yellow-500 text-black' : 'bg-gray-800 border-gray-600 text-gray-400'}`}>
              <i className={step.icon}></i>
            </div>
            {index < mifidSteps.length - 1 && (
              <div className={`w-20 h-1 mx-2 ${index < currentStep ? 'bg-yellow-500' : 'bg-gray-700'}`}></div>
            )}
          </div>
        ))}
      </div>

      <div className="bg-gray-900/50 p-8 rounded-xl border border-yellow-500/20">
        <div className="mb-6">
          <h4 className="text-2xl font-bold text-white mb-2">
            {mifidSteps[currentStep].title}
          </h4>
          <p className="text-gray-400">
            {mifidSteps[currentStep].subtitle}
          </p>
        </div>

        {renderStepContent()}

        <div className="flex justify-between mt-8">
          <button
            onClick={prevStep}
            disabled={currentStep === 0}
            className="px-6 py-3 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors cursor-pointer whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <i className="ri-arrow-left-line mr-2"></i>
            Précédent
          </button>

          <button
            onClick={nextStep}
            className="px-6 py-3 bg-gradient-to-r from-yellow-500 to-yellow-600 text-black rounded-lg font-semibold hover:from-yellow-400 hover:to-yellow-500 transition-all cursor-pointer whitespace-nowrap"
          >
            {currentStep === mifidSteps.length - 1 ? (
              <>
                <i className="ri-check-line mr-2"></i>
                Terminer l\'évaluation
              </>
            ) : (
              <>
                Suivant
                <i className="ri-arrow-right-line ml-2"></i>
              </>
            )}
          </button>
        </div>
      </div>

      <div className="bg-blue-500/10 p-4 rounded-xl border border-blue-500/20">
        <div className="flex items-start space-x-3">
          <i className="ri-information-line text-blue-400 text-lg mt-0.5"></i>
          <div>
            <h5 className="text-blue-400 font-semibold mb-1">Pourquoi cette évaluation ?</h5>
            <p className="text-gray-300 text-sm">
              La directive MiFID II nous oblige à évaluer votre adéquation avec les produits financiers
              pour vous protéger et vous proposer des investissements adaptés à votre profil.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
