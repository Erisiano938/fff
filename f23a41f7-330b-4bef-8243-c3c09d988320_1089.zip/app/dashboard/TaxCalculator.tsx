
'use client';

import { useState, useEffect } from 'react';

export default function TaxCalculator() {
  const [taxData, setTaxData] = useState({
    // Revenus du travail et pensions
    salaire: 0,
    primes: 0,
    avantages: 0,
    retraite: 0,
    chomage: 0,

    // Revenus professionnels
    bnc: 0,
    bic: 0,

    // Plus-values et autres revenus
    plusValues: 0,
    autresRevenus: 0,

    // Revenus du patrimoine
    revenus_fonciers: 0,
    revenus_mobiliers: 0,

    // Situation familiale
    situation: 'celibataire',
    enfants: 0,
    declarationCommune: false,

    // Charges déductibles
    pensionAlimentaire: 0,
    cotisationsRetraite: 0,
    deficitFoncier: 0,

    // Réductions d'impôt
    emploiDomicile: 0,
    dons: 0,
    investPinel: 0,
    fcpi: 0,
    sofica: 0,

    // Options
    bareme_progressif: false
  });

  const [results, setResults] = useState(null);
  const [showDetails, setShowDetails] = useState(false);

  // Calcul des parts fiscales avec déclaration commune
  const calculateParts = () => {
    let parts = 1;

    if (taxData.situation === 'marie' || taxData.declarationCommune) {
      parts = 2;
    } else if (taxData.situation === 'divorce') {
      parts = 1.5;
    }

    // Enfants
    if (taxData.enfants === 1) parts += 0.5;
    else if (taxData.enfants === 2) parts += 1;
    else if (taxData.enfants >= 3) parts += 1 + (taxData.enfants - 2);

    return parts;
  };

  // NOUVEAU CALCUL CORRIGÉ selon votre logique
  const calculateTax = (revenue: number, parts: number = 1): { totalTax: number; details: Array<{tranche: string; base: number; taux: number; impot: number}> } => {
    const quotientFamilial = revenue / parts;
    let taxTotal = 0;
    const details: Array<{tranche: string; base: number; taux: number; impot: number}> = [];

    const tranches = [
      { min: 0, max: 11497, rate: 0 },
      { min: 11498, max: 29315, rate: 0.11 },
      { min: 29316, max: 83823, rate: 0.30 },
      { min: 83824, max: 180294, rate: 0.41 },
      { min: 180295, max: Infinity, rate: 0.45 }
    ];

    for (const tranche of tranches) {
      if (quotientFamilial <= tranche.min) break;
      
      const trancheStart = tranche.min;
      const trancheEnd = Math.min(tranche.max, quotientFamilial);
      
      if (trancheEnd > trancheStart) {
        const taxableAmount = trancheEnd - trancheStart;
        const taxForTranche = taxableAmount * tranche.rate;
        
        details.push({
          tranche: tranche.max === Infinity ? 
            `Plus de ${tranche.min.toLocaleString('fr-FR')} €` :
            `${tranche.min.toLocaleString('fr-FR')} € à ${tranche.max.toLocaleString('fr-FR')} €`,
          base: taxableAmount,
          taux: tranche.rate * 100,
          impot: taxForTranche
        });
        
        taxTotal += taxForTranche;
      }
    }

    return {
      totalTax: taxTotal * parts,
      details
    };
  };

  // Fonction pour formater les montants
  const formatNumber = (num) => {
    return new Intl.NumberFormat('fr-FR').format(Math.round(num));
  };

  const formatCurrency = (num) => {
    return new Intl.NumberFormat('fr-FR').format(Math.round(num)) + ' €';
  };

  // Calculer les parts fiscales pour l'affichage
  const parts = calculateParts();

  useEffect(() => {
    // Calcul des revenus totaux
    const revenusBruts = 
      taxData.salaire + taxData.primes + taxData.avantages + taxData.retraite + taxData.chomage +
      taxData.bnc + taxData.bic +
      taxData.revenus_fonciers + taxData.revenus_mobiliers +
      taxData.plusValues + taxData.autresRevenus;

    // Calcul des parts fiscales
    const parts = calculateParts();

    // Abattement 10% sur salaires (minimum 468€, maximum 12 829€)
    const salaireBrut = taxData.salaire + taxData.primes + taxData.avantages + taxData.retraite + taxData.chomage;
    const abattement10 = Math.min(Math.max(salaireBrut * 0.1, 468), 12829);

    // Charges déductibles
    const chargesDeductibles = taxData.pensionAlimentaire + taxData.cotisationsRetraite + taxData.deficitFoncier;

    // Revenus imposables
    const revenusImposables = Math.max(0, revenusBruts - abattement10 - chargesDeductibles);

    // Calcul de l'impôt avec le barème progressif
    const { totalTax, details } = calculateTax(revenusImposables, parts);

    // Quotient familial pour l'affichage
    const quotientFamilial = revenusImposables / parts;

    // Réductions d'impôt
    const reductionEmploiDomicile = Math.min(taxData.emploiDomicile * 0.5, 12000);
    const reductionDons = Math.min(taxData.dons * 0.66, revenusImposables * 0.2);
    const reductionPinel = taxData.investPinel * 0.12;

    const totalReductions = reductionEmploiDomicile + reductionDons + reductionPinel;
    const impotBrut = Math.max(0, totalTax - totalReductions);

    // Prélèvements sociaux (17,2%) sur certains revenus
    const basePS = taxData.revenus_fonciers + taxData.plusValues + 
                   (taxData.bareme_progressif ? taxData.revenus_mobiliers : 0);
    const prelevementsSociaux = basePS * 0.172;

    // PFU sur revenus mobiliers si pas barème progressif
    const pfuTotal = !taxData.bareme_progressif ? taxData.revenus_mobiliers * 0.30 : 0;

    // Total final
    const totalFinal = impotBrut + prelevementsSociaux + pfuTotal;

    // Calcul des taux
    let tauxMarginal = 0;
    if (quotientFamilial > 180295) tauxMarginal = 45;
    else if (quotientFamilial > 83824) tauxMarginal = 41;
    else if (quotientFamilial > 29316) tauxMarginal = 30;
    else if (quotientFamilial > 11498) tauxMarginal = 11;
    else tauxMarginal = 0;

    const tauxMoyen = revenusImposables > 0 ? (impotBrut / revenusImposables) * 100 : 0;
    const tauxEffectif = revenusBruts > 0 ? (totalFinal / revenusBruts) * 100 : 0;

    const calculatedResults = {
      revenusBruts,
      revenusImposables,
      salaireBrut,
      revenus_pro: taxData.bnc + taxData.bic,
      revenus_patrimoine: taxData.revenus_fonciers + taxData.revenus_mobiliers,
      autres_revenus: taxData.plusValues + taxData.autresRevenus,
      abattement10,
      chargesDeductibles,
      parts,
      quotientFamilial,
      impotParTranche: details,
      impotUnitaire: totalTax / parts,
      impotBrut: totalTax,
      irDeBase: impotBrut,
      basePrelevementsSociaux: basePS,
      prelevementsSociauxTotal: prelevementsSociaux,
      pfuTotal,
      totalFinal,
      revenusNetsApresImpots: revenusBruts - totalFinal,
      tauxMarginal,
      tauxMoyen,
      tauxEffectif,
      reductions: {
        emploiDomicile: reductionEmploiDomicile,
        dons: reductionDons,
        pinel: reductionPinel,
        total: totalReductions
      }
    };

    setResults(calculatedResults);
  }, [taxData]);

  const handleRefresh = () => {
    const currentData = { ...taxData };
    setTaxData(currentData);
    
    const button = document.getElementById('refresh-button');
    if (button) {
      button.textContent = 'Actualisé !';
      setTimeout(() => {
        button.textContent = 'Actualiser';
      }, 1000);
    }
  };

  // Définir les tranches pour l'affichage détaillé
  const tranches = [
    { plafond: 11497, taux: 0 },
    { plafond: 29315, taux: 0.11 },
    { plafond: 83823, taux: 0.30 },
    { plafond: 180294, taux: 0.41 },
    { plafond: Infinity, taux: 0.45 }
  ];

  return (
    <div className="bg-black rounded-xl shadow-lg p-8">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-2xl font-bold text-white">
          Calculateur d'Impôts 2025
        </h2>
        <button
          id="refresh-button"
          onClick={handleRefresh}
          className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap"
        >
          <i className="ri-refresh-line w-4 h-4 flex items-center justify-center"></i>
          Actualiser
        </button>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Formulaire de saisie */}
        <div className="space-y-6">
          {/* Revenus du travail et pensions */}
          <div className="bg-gray-800/50 p-4 rounded-lg">
            <h4 className="font-semibold text-white mb-4 flex items-center">
              <i className="ri-briefcase-line text-green-400 mr-2"></i>
              Revenus du travail et pensions
            </h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-gray-300 text-sm font-medium mb-2">Salaires</label>
                <input
                  type="number"
                  value={taxData.salaire}
                  onChange={(e) => setTaxData({ ...taxData, salaire: parseFloat(e.target.value) || 0 })}
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
              </div>
              <div>
                <label className="block text-gray-300 text-sm font-medium mb-2">Primes</label>
                <input
                  type="number"
                  value={taxData.primes}
                  onChange={(e) => setTaxData({ ...taxData, primes: parseFloat(e.target.value) || 0 })}
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
              </div>
              <div>
                <label className="block text-gray-300 text-sm font-medium mb-2">Avantages en nature</label>
                <input
                  type="number"
                  value={taxData.avantages}
                  onChange={(e) => setTaxData({ ...taxData, avantages: parseFloat(e.target.value) || 0 })}
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
              </div>
              <div>
                <label className="block text-gray-300 text-sm font-medium mb-2">Pensions de retraite</label>
                <input
                  type="number"
                  value={taxData.retraite}
                  onChange={(e) => setTaxData({ ...taxData, retraite: parseFloat(e.target.value) || 0 })}
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
              </div>
            </div>
          </div>

          {/* Revenus professionnels */}
          <div className="bg-gray-800/50 p-4 rounded-lg">
            <h4 className="font-semibold text-white mb-4 flex items-center">
              <i className="ri-store-line text-blue-400 mr-2"></i>
              Revenus professionnels
            </h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-gray-300 text-sm font-medium mb-2">BNC (Bénéfices Non Commerciaux)</label>
                <input
                  type="number"
                  value={taxData.bnc}
                  onChange={(e) => setTaxData({ ...taxData, bnc: parseFloat(e.target.value) || 0 })}
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
              </div>
              <div>
                <label className="block text-gray-300 text-sm font-medium mb-2">BIC (Bénéfices Industriels et Commerciaux)</label>
                <input
                  type="number"
                  value={taxData.bic}
                  onChange={(e) => setTaxData({ ...taxData, bic: parseFloat(e.target.value) || 0 })}
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
              </div>
            </div>
          </div>

          {/* Revenus du patrimoine */}
          <div className="bg-gray-800/50 p-4 rounded-lg">
            <h4 className="font-semibold text-white mb-4 flex items-center">
              <i className="ri-home-line text-purple-400 mr-2"></i>
              Revenus du patrimoine
            </h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-gray-300 text-sm font-medium mb-2">Revenus fonciers</label>
                <input
                  type="number"
                  value={taxData.revenus_fonciers}
                  onChange={(e) => setTaxData({ ...taxData, revenus_fonciers: parseFloat(e.target.value) || 0 })}
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
              </div>
              <div>
                <label className="block text-gray-300 text-sm font-medium mb-2">Revenus mobiliers</label>
                <input
                  type="number"
                  value={taxData.revenus_mobiliers}
                  onChange={(e) => setTaxData({ ...taxData, revenus_mobiliers: parseFloat(e.target.value) || 0 })}
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
              </div>
            </div>
          </div>

          {/* Plus-values et autres revenus */}
          <div className="bg-gray-800/50 p-4 rounded-lg">
            <h4 className="font-semibold text-white mb-4 flex items-center">
              <i className="ri-line-chart-line text-yellow-400 mr-2"></i>
              Plus-values et autres revenus
            </h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-gray-300 text-sm font-medium mb-2">Plus-values</label>
                <input
                  type="number"
                  value={taxData.plusValues}
                  onChange={(e) => setTaxData({ ...taxData, plusValues: parseFloat(e.target.value) || 0 })}
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
              </div>
              <div>
                <label className="block text-gray-300 text-sm font-medium mb-2">Autres revenus</label>
                <input
                  type="number"
                  value={taxData.autresRevenus}
                  onChange={(e) => setTaxData({ ...taxData, autresRevenus: parseFloat(e.target.value) || 0 })}
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
              </div>
            </div>
          </div>

          {/* Situation familiale */}
          <div className="bg-gray-800/50 p-4 rounded-lg">
            <h4 className="font-semibold text-white mb-4 flex items-center">
              <i className="ri-group-line text-pink-400 mr-2"></i>
              Situation familiale
            </h4>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-gray-300 text-sm font-medium mb-2">Situation</label>
                  <select
                    value={taxData.situation}
                    onChange={(e) => setTaxData({ ...taxData, situation: e.target.value })}
                    className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none pr-8"
                  >
                    <option value="celibataire">Célibataire</option>
                    <option value="marie">Marié(e)</option>
                    <option value="divorce">Divorcé(e)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-gray-300 text-sm font-medium mb-2">Enfants à charge</label>
                  <input
                    type="number"
                    value={taxData.enfants}
                    onChange={(e) => setTaxData({ ...taxData, enfants: parseInt(e.target.value) || 0 })}
                    className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                    placeholder="0"
                    min="0"
                  />
                </div>
              </div>

              <div className="bg-blue-500/10 p-3 rounded-lg border border-blue-500/20">
                <label className="flex items-center space-x-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={taxData.declarationCommune}
                    onChange={(e) => setTaxData({ ...taxData, declarationCommune: e.target.checked })}
                    className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 rounded focus:ring-blue-500"
                  />
                  <div>
                    <span className="text-white font-medium">Déclaration commune</span>
                    <div className="text-xs text-blue-300">Même sans être marié (concubinage, PACS)</div>
                  </div>
                </label>
              </div>
            </div>
          </div>

          {/* Charges déductibles */}
          <div className="bg-gray-800/50 p-4 rounded-lg">
            <h4 className="font-semibold text-white mb-4 flex items-center">
              <i className="ri-subtract-line text-orange-400 mr-2"></i>
              Charges déductibles
            </h4>
            <div className="space-y-4">
              <div>
                <label className="block text-gray-300 text-sm font-medium mb-2">Pension alimentaire versée</label>
                <input
                  type="number"
                  value={taxData.pensionAlimentaire}
                  onChange={(e) => setTaxData({ ...taxData, pensionAlimentaire: parseFloat(e.target.value) || 0 })}
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
              </div>
              <div>
                <label className="block text-gray-300 text-sm font-medium mb-2">Cotisations retraite supplémentaire</label>
                <input
                  type="number"
                  value={taxData.cotisationsRetraite}
                  onChange={(e) => setTaxData({ ...taxData, cotisationsRetraite: parseFloat(e.target.value) || 0 })}
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
              </div>
              <div>
                <label className="block text-gray-300 text-sm font-medium mb-2">Déficit foncier</label>
                <input
                  type="number"
                  value={taxData.deficitFoncier}
                  onChange={(e) => setTaxData({ ...taxData, deficitFoncier: parseFloat(e.target.value) || 0 })}
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
              </div>
            </div>
          </div>

          {/* Réductions d'impôt */}
          <div className="bg-gray-800/50 p-4 rounded-lg">
            <h4 className="font-semibold text-white mb-4 flex items-center">
              <i className="ri-discount-percent-line text-green-400 mr-2"></i>
              Réductions d'impôt
            </h4>
            <div className="space-y-4">
              <div>
                <label className="block text-gray-300 text-sm font-medium mb-2">Emploi à domicile (50%)</label>
                <input
                  type="number"
                  value={taxData.emploiDomicile}
                  onChange={(e) => setTaxData({ ...taxData, emploiDomicile: parseFloat(e.target.value) || 0 })}
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
              </div>
              <div>
                <label className="block text-gray-300 text-sm font-medium mb-2">Dons (66%)</label>
                <input
                  type="number"
                  value={taxData.dons}
                  onChange={(e) => setTaxData({ ...taxData, dons: parseFloat(e.target.value) || 0 })}
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
              </div>
              <div>
                <label className="block text-gray-300 text-sm font-medium mb-2">Investissement Pinel (12%)</label>
                <input
                  type="number"
                  value={taxData.investPinel}
                  onChange={(e) => setTaxData({ ...taxData, investPinel: parseFloat(e.target.value) || 0 })}
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
              </div>
            </div>
          </div>

          {/* Options */}
          <div className="bg-gray-800/50 p-4 rounded-lg">
            <h4 className="font-semibold text-white mb-4 flex items-center">
              <i className="ri-settings-line text-cyan-400 mr-2"></i>
              Options
            </h4>
            <div>
              <label className="flex items-center space-x-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={taxData.bareme_progressif}
                  onChange={(e) => setTaxData({ ...taxData, bareme_progressif: e.target.checked })}
                  className="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 rounded focus:ring-blue-500"
                />
                <span className="text-gray-300">Barème progressif pour revenus financiers</span>
              </label>
            </div>
          </div>
        </div>

        {/* Résultats CORRIGÉS */}
        <div className="space-y-6">
          {results && (
            <>
              {/* Résumé principal CORRIGÉ */}
              <div className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 p-6 rounded-xl border border-blue-500/30">
                <h4 className="font-semibold text-white mb-4 flex items-center">
                  <i className="ri-calculator-line text-blue-400 mr-2"></i>
                  💡 Résultat Final - Formule Fiscale Française CORRIGÉE
                </h4>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Revenus bruts :</span>
                    <span className="text-white font-semibold">{formatNumber(results.revenusBruts)} €</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Revenus imposables :</span>
                    <span className="text-green-400 font-semibold">{formatNumber(results.revenusImposables)} €</span>
                  </div>
                  
                  {/* FORMULE CORRIGÉE */}
                  <div className="bg-gray-800/50 p-4 rounded-lg border border-yellow-500/30">
                    <div className="text-center text-yellow-400 font-bold mb-3">📊 FORMULE FISCALE FRANÇAISE CORRIGÉE</div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-blue-300 font-semibold">1️⃣ IR de base (barème progressif) :</span>
                        <span className="text-blue-400 font-bold text-lg">{formatNumber(results.irDeBase)} €</span>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <span className="text-orange-300 font-semibold">2️⃣ + Prélèvements sociaux (17,2%) :</span>
                        <span className="text-orange-400 font-bold text-lg">{formatNumber(results.prelevementsSociauxTotal)} €</span>
                      </div>

                      {results.pfuTotal > 0 && (
                        <div className="flex justify-between items-center">
                          <span className="text-cyan-300 font-semibold">3️⃣ + PFU sur revenus mobiliers (30%) :</span>
                          <span className="text-cyan-400 font-bold text-lg">{formatNumber(results.pfuTotal)} €</span>
                        </div>
                      )}
                      
                      <div className="border-t border-gray-600 pt-2 mt-3">
                        <div className="flex justify-between items-center">
                          <span className="text-white font-bold">= TOTAL À PAYER :</span>
                          <span className="text-green-400 font-bold text-lg">{formatNumber(results.totalFinal)} €</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="border-t border-gray-600 pt-3">
                    <div className="flex justify-between items-center text-2xl">
                      <span className="text-white font-bold">💰 TOTAL À PAYER :</span>
                      <span className="text-red-400 font-bold">{formatNumber(results.totalFinal)} €</span>
                    </div>
                    <div className="text-center text-sm text-gray-400 mt-1">
                      <span>IR: {formatNumber(results.irDeBase)} € + PS: {formatNumber(results.prelevementsSociauxTotal)} €{results.pfuTotal > 0 ? ` + PFU: ${formatNumber(results.pfuTotal)} €` : ''}</span>
                    </div>
                  </div>

                  <div className="border-t border-gray-600 pt-3">
                    <div className="flex justify-between items-center text-lg">
                      <span className="text-green-300 font-semibold">💵 Revenus nets :</span>
                      <span className="text-green-400 font-bold">{formatNumber(results.revenusNetsApresImpots)} €</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Détail du calcul CORRIGÉ */}
              <div className="bg-green-500/10 p-6 rounded-xl border border-green-500/20">
                <h4 className="font-semibold text-green-400 mb-4 flex items-center">
                  <i className="ri-check-circle-line mr-2"></i>
                  ✅ Calcul Détaillé - Logique Fiscale CORRIGÉE 2025
                </h4>

                <div className="space-y-4">
                  {/* Étape 1: Revenus bruts détaillés */}
                  <div className="bg-gray-800/50 p-4 rounded-lg">
                    <h5 className="font-medium text-white mb-3">1. Revenus bruts par catégorie</h5>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-300">• Salaires et pensions :</span>
                        <span className="text-white">{formatNumber(results.salaireBrut)} €</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">• Revenus professionnels (BNC/BIC) :</span>
                        <span className="text-white">{formatNumber(results.revenus_pro)} €</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">• Revenus du patrimoine :</span>
                        <span className="text-white">{formatNumber(results.revenus_patrimoine)} €</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">• Plus-values et autres :</span>
                        <span className="text-white">{formatNumber(results.autres_revenus)} €</span>
                      </div>
                      <div className="flex justify-between font-semibold border-t border-gray-600 pt-2">
                        <span className="text-green-400">Total revenus bruts :</span>
                        <span className="text-green-400">{formatNumber(results.revenusBruts)} €</span>
                      </div>
                    </div>
                  </div>

                  {/* Étape 2: Abattements et charges */}
                  <div className="bg-gray-800/50 p-4 rounded-lg">
                    <h5 className="font-medium text-white mb-3">2. Abattements et charges déductibles</h5>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-300">• Abattement 10% sur salaires :</span>
                        <span className="text-green-400">-{formatNumber(results.abattement10)} €</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">• Charges déductibles :</span>
                        <span className="text-green-400">-{formatNumber(results.chargesDeductibles)} €</span>
                      </div>
                      <div className="flex justify-between font-semibold border-t border-gray-600 pt-2">
                        <span className="text-blue-400">Revenus imposables :</span>
                        <span className="text-blue-400">{formatNumber(results.revenusImposables)} €</span>
                      </div>
                    </div>
                  </div>

                  {/* Étape 3: Application du barème progressif */}
                  <div className="bg-gray-800/50 p-4 rounded-lg">
                    <h5 className="font-medium text-white mb-3">3. Application du barème progressif 2025</h5>
                    
                    <div className="text-sm mb-3">
                      <div className="flex justify-between">
                        <span className="text-gray-300">Parts fiscales :</span>
                        <span className="text-white">{results.parts}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Quotient familial :</span>
                        <span className="text-white">{formatCurrency(results.quotientFamilial)}</span>
                      </div>
                    </div>

                    <div className="space-y-3 text-xs">
                      <div className="bg-blue-500/10 p-3 rounded text-xs text-blue-300 mb-3">
                        <div className="font-semibold mb-1">💡 Principe du barème progressif :</div>
                        <div className="space-y-1 text-blue-200">
                          <div>• Chaque tranche d'impôt s'applique seulement sur la partie qui la concerne</div>
                          <div>• Les tranches s'additionnent pour obtenir l'impôt total</div>
                          <div>• On calcule sur le quotient familial, puis on multiplie par le nombre de parts</div>
                        </div>
                      </div>

                      {tranches.map((tranche, index) => {
                        const quotientFamilial = results.quotientFamilial;
                        const montantTranche = Math.min(quotientFamilial, tranche.plafond) - (index === 0 ? 0 : tranches[index - 1].plafond);
                        const impotTranche = montantTranche > 0 ? montantTranche * tranche.taux : 0;
                        
                        if (quotientFamilial <= (index === 0 ? 0 : tranches[index - 1].plafond)) return null;

                        return (
                          <div key={index} className="bg-gray-700/30 p-3 rounded border-l-2 border-yellow-400">
                            <div className="space-y-2">
                              <div className="flex justify-between items-center">
                                <span className="text-gray-300 font-medium">
                                  Tranche {index + 1}: {formatCurrency(index === 0 ? 0 : tranches[index - 1].plafond + 1)} à {formatCurrency(tranche.plafond)} ({(tranche.taux * 100).toFixed(0)}%)
                                </span>
                                <span className="text-white font-semibold">{formatCurrency(impotTranche)}</span>
                              </div>
                              
                              <div className="text-xs space-y-1 pl-4 border-l border-gray-600">
                                <div className="text-gray-400">
                                  <span className="font-medium text-yellow-300">Calcul détaillé :</span>
                                </div>
                                <div className="text-gray-300">
                                  • Revenus concernés : {formatCurrency(Math.max(0, Math.min(quotientFamilial, tranche.plafond) - (index === 0 ? 0 : tranches[index - 1].plafond)))}
                                </div>
                                <div className="text-gray-300">
                                  • Formule : {formatCurrency(montantTranche)} × {(tranche.taux * 100).toFixed(0)}% = {formatCurrency(impotTranche)}
                                </div>
                                {index === 0 && (
                                  <div className="text-blue-300 italic">
                                    → Cette tranche est exonérée d'impôt (0%)
                                  </div>
                                )}
                                {index === 1 && montantTranche > 0 && (
                                  <div className="text-green-300 italic">
                                    → Première tranche imposable à 11%
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })}

                      <div className="bg-yellow-500/10 p-3 rounded border border-yellow-500/30">
                        <div className="flex justify-between font-medium">
                          <span className="text-yellow-400">📊 Impôt unitaire (somme de toutes les tranches) :</span>
                          <span className="text-yellow-400 font-bold">{formatCurrency(results.impotUnitaire)}</span>
                        </div>
                        <div className="text-xs text-yellow-300 mt-1">
                          Ceci est l'impôt calculé sur une seule part fiscale
                        </div>
                      </div>

                      <div className="bg-red-500/10 p-3 rounded border border-red-500/30">
                        <div className="flex justify-between font-semibold text-lg">
                          <span className="text-red-400">🎯 Impôt sur le revenu total :</span>
                          <span className="text-red-400 font-bold">{formatCurrency(results.impotBrut)}</span>
                        </div>
                        <div className="text-xs space-y-1 mt-2">
                          <div className="text-red-300">
                            <span className="font-medium">Calcul final :</span> {formatCurrency(results.impotUnitaire)} × {results.parts} parts = {formatCurrency(results.impotBrut)}
                          </div>
                          <div className="text-gray-400 italic">
                            Le système du quotient familial permet de répartir l'avantage fiscal sur toute la famille
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Étape 4: Prélèvements sociaux CORRIGÉE */}
                  <div className="bg-gray-800/50 p-4 rounded-lg">
                    <h5 className="font-medium text-white mb-3">4. Prélèvements sociaux (17,2%) - LOGIQUE CORRIGÉE</h5>
                    <div className="space-y-2 text-sm">
                      <div className="bg-yellow-500/10 p-2 rounded text-xs text-yellow-300 mb-2">
                        ⚠️ Les PS s'appliquent uniquement sur certains revenus du patrimoine
                      </div>
                      <div className="text-xs space-y-1 ml-4">
                        <div className="flex justify-between">
                          <span className="text-gray-400">• Revenus fonciers :</span>
                          <span className="text-gray-300">{formatNumber(taxData.revenus_fonciers)} €</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">• Revenus mobiliers (si barème progressif) :</span>
                          <span className="text-gray-300">{taxData.bareme_progressif ? formatNumber(taxData.revenus_mobiliers) : '0'} €</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">• Plus-values :</span>
                          <span className="text-gray-300">{formatNumber(taxData.plusValues)} €</span>
                        </div>
                        <div className="flex justify-between font-semibold border-t border-gray-600 pt-1">
                          <span className="text-blue-400">Base PS :</span>
                          <span className="text-blue-400">{formatNumber(results.basePrelevementsSociaux)} €</span>
                        </div>
                      </div>
                      <div className="flex justify-between font-semibold border-t border-gray-600 pt-2">
                        <span className="text-yellow-400">Total PS (17,2%) :</span>
                        <span className="text-yellow-400">{formatNumber(results.prelevementsSociauxTotal)} €</span>
                      </div>
                    </div>
                  </div>

                  {/* PFU si applicable */}
                  {results.pfuTotal > 0 && (
                    <div className="bg-gray-800/50 p-4 rounded-lg">
                      <h5 className="font-medium text-white mb-3">5. PFU sur revenus mobiliers (30%)</h5>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-300">Revenus mobiliers soumis au PFU :</span>
                          <span className="text-white">{formatNumber(taxData.revenus_mobiliers)} €</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-300">PFU (12,8% IR + 17,2% PS) :</span>
                          <span className="text-cyan-400">{formatNumber(results.pfuTotal)} €</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Formule finale CORRIGÉE */}
                  <div className="bg-gradient-to-r from-green-500/20 to-blue-500/20 p-4 rounded-lg border border-green-500/30">
                    <h5 className="font-medium text-green-400 mb-2">Formule fiscale française CORRIGÉE</h5>
                    <div className="font-mono text-xs text-green-300 space-y-1">
                      <div>• IR de base = Barème progressif sur revenus imposables</div>
                      <div>• PS = 17,2% × (Revenus fonciers + Plus-values + Revenus mobiliers si barème progressif)</div>
                      <div>• PFU = 30% × Revenus mobiliers (si pas barème progressif)</div>
                      <div>• Total = IR de base + PS + PFU</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Indicateurs de performance fiscale */}
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-gray-800/50 p-4 rounded-lg text-center">
                  <div className="text-sm text-gray-400 mb-2">Taux marginal</div>
                  <div className="text-2xl font-bold text-orange-400">{results.tauxMarginal}%</div>
                </div>
                <div className="bg-gray-800/50 p-4 rounded-lg text-center">
                  <div className="text-sm text-gray-400 mb-2">Taux moyen</div>
                  <div className="text-2xl font-bold text-blue-400">{results.tauxMoyen.toFixed(1)}%</div>
                </div>
                <div className="bg-gray-800/50 p-4 rounded-lg text-center">
                  <div className="text-sm text-gray-400 mb-2">Taux effectif</div>
                  <div className="text-2xl font-bold text-purple-400">{results.tauxEffectif.toFixed(1)}%</div>
                </div>
              </div>

              {/* Bouton détails complémentaires */}
              <button
                onClick={() => setShowDetails(!showDetails)}
                className="w-full bg-gray-700 hover:bg-gray-600 text-white py-3 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
              >
                {showDetails ? 'Masquer les détails' : 'Voir les détails complémentaires'}
              </button>

              {showDetails && (
                <div className="bg-gray-800/30 p-6 rounded-xl space-y-4">
                  <h4 className="font-semibold text-white">Détails complémentaires</h4>

                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <h5 className="font-medium text-gray-300 mb-3">Optimisations possibles</h5>
                      <div className="space-y-2 text-sm">
                        {results.reductions.total === 0 && (
                          <div className="text-yellow-400">• Envisagez des réductions d'impôt (emploi domicile, dons, etc.)</div>
                        )}
                        {results.tauxMarginal >= 30 && (
                          <div className="text-blue-400">• Investissements défiscalisés recommandés (Pinel, PER, etc.)</div>
                        )}
                        {results.pfuTotal === 0 && taxData.revenus_mobiliers > 0 && (
                          <div className="text-green-400">• PFU à 30% peut être plus avantageux que le barème</div>
                        )}
                      </div>
                    </div>

                    <div>
                      <h5 className="font-medium text-gray-300 mb-3">Réductions appliquées</h5>
                      <div className="space-y-2 text-sm">
                        {results.reductions.emploiDomicile > 0 && (
                          <div className="flex justify-between">
                            <span className="text-gray-400">Emploi domicile :</span>
                            <span className="text-green-400">-{formatNumber(results.reductions.emploiDomicile)} €</span>
                          </div>
                        )}
                        {results.reductions.dons > 0 && (
                          <div className="flex justify-between">
                            <span className="text-gray-400">Dons :</span>
                            <span className="text-green-400">-{formatNumber(results.reductions.dons)} €</span>
                          </div>
                        )}
                        {results.reductions.pinel > 0 && (
                          <div className="flex justify-between">
                            <span className="text-gray-400">Pinel :</span>
                            <span className="text-green-400">-{formatNumber(results.reductions.pinel)} €</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
