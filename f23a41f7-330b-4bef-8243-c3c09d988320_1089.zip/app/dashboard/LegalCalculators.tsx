
'use client';

import { useState } from 'react';

export default function LegalCalculators() {
  const [selectedCalculator, setSelectedCalculator] = useState('flatTax');
  const [results, setResults] = useState<any>(null);

  // États pour chaque calculateur
  const [successionData, setSuccessionData] = useState({
    patrimoine: 0,
    lienParente: 'enfant',
    donations: 0,
    abattements: true
  });

  const [immobilierData, setImmobilierData] = useState({
    prixAchat: 0,
    prixVente: 0,
    fraisAchat: 0,
    travaux: 0,
    dureeDetention: 0,
    residencePrincipale: false
  });

  const [ifiData, setIfiData] = useState({
    valeurBrute: 0,
    dettes: 0,
    exonerations: 0,
    reduction: 0
  });

  const [donationData, setDonationData] = useState({
    montant: 0,
    beneficiaire: 'enfant',
    ageDonateur: 0,
    donationsAnterieures: 0
  });

  const [flatTaxData, setFlatTaxData] = useState({
    revenusFinanciers: 0,
    plusValues: 0,
    autresRevenus: 0,
    parts: 1
  });

  const [fonciersData, setFonciersData] = useState({
    loyersAnnuels: 0,
    charges: 0,
    travaux: 0,
    interetsEmprunt: 0,
    regime: 'reel'
  });

  const calculators = [
    { id: 'succession', name: 'Droits de Succession', icon: 'ri-pie-chart-line', color: 'green' },
    { id: 'immobilier', name: 'Plus-values Immobilières', icon: 'ri-home-line', color: 'blue' },
    { id: 'ifi', name: 'IFI - Impôt Fortune', icon: 'ri-building-line', color: 'purple' },
    { id: 'donation', name: 'Donation Optimale', icon: 'ri-gift-line', color: 'orange' },
    { id: 'flatTax', name: 'Flat Tax vs Barème', icon: 'ri-scales-line', color: 'indigo' },
    { id: 'fonciers', name: 'Revenus Fonciers', icon: 'ri-key-line', color: 'pink' }
  ];

  const calculateSuccession = () => {
    const { patrimoine, lienParente, donations, abattements } = successionData;
    
    const abattementsByRelation: { [key: string]: number } = {
      'enfant': 100000,
      'conjoint': 80724,
      'petitEnfant': 31865,
      'frere': 15932,
      'neveu': 7967,
      'autre': 0
    };

    const tauxByRelation: { [key: string]: { tranches: number[], taux: number[] } } = {
      'enfant': { tranches: [8072, 12109, 15932, 552324], taux: [5, 10, 15, 20, 30, 40, 45] },
      'conjoint': { tranches: [], taux: [0] },
      'petitEnfant': { tranches: [8072, 12109, 15932, 552324], taux: [5, 10, 15, 20, 30, 40, 45] },
      'frere': { tranches: [24430], taux: [35, 45] },
      'neveu': { tranches: [8072], taux: [55, 60] },
      'autre': { tranches: [8072], taux: [60, 60] }
    };

    const abattement = abattements ? abattementsByRelation[lienParente] : 0;
    const assietteTaxable = Math.max(0, patrimoine - donations - abattement);
    
    let droits = 0;
    const tranches = tauxByRelation[lienParente].tranches;
    const taux = tauxByRelation[lienParente].taux;
    
    let reste = assietteTaxable;
    for (let i = 0; i < tranches.length && reste > 0; i++) {
      const tranche = Math.min(reste, tranches[i]);
      droits += tranche * (taux[i] / 100);
      reste -= tranche;
    }
    if (reste > 0) {
      droits += reste * (taux[taux.length - 1] / 100);
    }

    setResults({
      type: 'succession',
      patrimoine,
      abattement,
      assietteTaxable,
      droits: Math.round(droits),
      tauxEffectif: ((droits / patrimoine) * 100).toFixed(2)
    });
  };

  const calculateImmobilier = () => {
    const { prixAchat, prixVente, fraisAchat, travaux, dureeDetention, residencePrincipale } = immobilierData;
    
    if (residencePrincipale) {
      setResults({
        type: 'immobilier',
        plusValue: 0,
        impot: 0,
        exoneration: 'Résidence principale exonérée'
      });
      return;
    }

    const plusValueBrute = prixVente - prixAchat - fraisAchat - travaux;
    
    // Abattements pour durée de détention
    let abattementIR = 0;
    let abattementPS = 0;
    
    if (dureeDetention > 2) {
      abattementIR = Math.min(100, (dureeDetention - 2) * 6);
    }
    if (dureeDetention > 5) {
      abattementPS = Math.min(100, (dureeDetention - 5) * 1.65 + (dureeDetention > 22 ? (dureeDetention - 22) * 7.35 : 0));
    }

    const plusValueIR = plusValueBrute * (1 - abattementIR / 100);
    const plusValuePS = plusValueBrute * (1 - abattementPS / 100);
    
    const impotRevenu = Math.max(0, plusValueIR * 0.19);
    const prelevementsSociaux = Math.max(0, plusValuePS * 0.172);
    
    setResults({
      type: 'immobilier',
      plusValueBrute: Math.round(plusValueBrute),
      abattementIR,
      abattementPS,
      impotRevenu: Math.round(impotRevenu),
      prelevementsSociaux: Math.round(prelevementsSociaux),
      total: Math.round(impotRevenu + prelevementsSociaux)
    });
  };

  const calculateIFI = () => {
    const { valeurBrute, dettes, exonerations, reduction } = ifiData;
    
    const assietteTaxable = Math.max(0, valeurBrute - dettes - exonerations);
    
    if (assietteTaxable < 1300000) {
      setResults({
        type: 'ifi',
        assietteTaxable,
        impot: 0,
        message: 'Patrimoine en dessous du seuil IFI (1,3M€)'
      });
      return;
    }

    let impot = 0;
    if (assietteTaxable <= 5000000) {
      impot = (assietteTaxable - 1300000) * 0.005;
    } else if (assietteTaxable <= 10000000) {
      impot = 18500 + (assietteTaxable - 5000000) * 0.007;
    } else {
      impot = 53500 + (assietteTaxable - 10000000) * 0.01;
    }

    const impotFinal = Math.max(0, impot - reduction);

    setResults({
      type: 'ifi',
      assietteTaxable,
      impotBrut: Math.round(impot),
      reduction,
      impotFinal: Math.round(impotFinal)
    });
  };

  const calculateDonation = () => {
    const { montant, beneficiaire, ageDonateur, donationsAnterieures } = donationData;
    
    const abattementsByBeneficiaire: { [key: string]: number } = {
      'enfant': 100000,
      'petitEnfant': 31865,
      'conjoint': 80724,
      'frere': 15932,
      'autre': 0
    };

    let abattement = abattementsByBeneficiaire[beneficiaire];
    
    // Abattement supplémentaire si donateur > 80 ans
    if (ageDonateur >= 80 && ['enfant', 'petitEnfant'].includes(beneficiaire)) {
      abattement += 31865;
    }

    const assietteTaxable = Math.max(0, montant + donationsAnterieures - abattement);
    
    // Calcul des droits (même barème que succession)
    let droits = 0;
    if (beneficiaire === 'enfant' || beneficiaire === 'petitEnfant') {
      if (assietteTaxable <= 8072) droits = assietteTaxable * 0.05;
      else if (assietteTaxable <= 12109) droits = 404 + (assietteTaxable - 8072) * 0.10;
      else if (assietteTaxable <= 15932) droits = 808 + (assietteTaxable - 12109) * 0.15;
      else if (assietteTaxable <= 552324) droits = 1381 + (assietteTaxable - 15932) * 0.20;
      else droits = 108659 + (assietteTaxable - 552324) * 0.30;
    }

    setResults({
      type: 'donation',
      montant,
      abattement,
      assietteTaxable,
      droits: Math.round(droits),
      economie: Math.round((montant * 0.45) - droits) // Économie vs succession
    });
  };

  const calculateFlatTax = () => {
    const { revenusFinanciers, plusValues, autresRevenus, parts } = flatTaxData;
    
    // Flat Tax (30%)
    const flatTaxAmount = (revenusFinanciers + plusValues) * 0.30;
    
    // Barème progressif
    const revenusTotal = revenusFinanciers + plusValues + autresRevenus;
    const quotientFamilial = revenusTotal / parts;
    
    let impotBareme = 0;
    if (quotientFamilial <= 10777) impotBareme = 0;
    else if (quotientFamilial <= 27478) impotBareme = (quotientFamilial - 10777) * 0.11;
    else if (quotientFamilial <= 78570) impotBareme = 1837 + (quotientFamilial - 27478) * 0.30;
    else if (quotientFamilial <= 168994) impotBareme = 17165 + (quotientFamilial - 78570) * 0.41;
    else impotBareme = 54232 + (quotientFamilial - 168994) * 0.45;
    
    impotBareme *= parts;
    
    // Prélèvements sociaux (17.2%)
    const prelevementsSociaux = (revenusFinanciers + plusValues) * 0.172;
    const baremeTotal = impotBareme + prelevementsSociaux;

    setResults({
      type: 'flatTax',
      flatTax: Math.round(flatTaxAmount),
      bareme: Math.round(baremeTotal),
      economie: Math.round(Math.abs(flatTaxAmount - baremeTotal)),
      meilleurChoix: flatTaxAmount < baremeTotal ? 'Flat Tax' : 'Barème progressif'
    });
  };

  const calculateFonciers = () => {
    const { loyersAnnuels, charges, travaux, interetsEmprunt, regime } = fonciersData;
    
    if (regime === 'micro') {
      const abattement = loyersAnnuels * 0.30;
      const revenuImposable = loyersAnnuels - abattement;
      const prelevementsSociaux = revenuImposable * 0.172;
      
      setResults({
        type: 'fonciers',
        regime: 'Micro-foncier',
        loyersBruts: loyersAnnuels,
        abattement,
        revenuImposable: Math.round(revenuImposable),
        prelevementsSociaux: Math.round(prelevementsSociaux)
      });
    } else {
      const chargesDeductibles = charges + travaux + interetsEmprunt;
      const revenuImposable = loyersAnnuels - chargesDeductibles;
      const prelevementsSociaux = revenuImposable * 0.172;
      
      setResults({
        type: 'fonciers',
        regime: 'Régime réel',
        loyersBruts: loyersAnnuels,
        charges: chargesDeductibles,
        revenuImposable: Math.round(revenuImposable),
        prelevementsSociaux: Math.round(prelevementsSociaux)
      });
    }
  };

  const handleCalculate = () => {
    switch (selectedCalculator) {
      case 'succession': calculateSuccession(); break;
      case 'immobilier': calculateImmobilier(); break;
      case 'ifi': calculateIFI(); break;
      case 'donation': calculateDonation(); break;
      case 'flatTax': calculateFlatTax(); break;
      case 'fonciers': calculateFonciers(); break;
    }
  };

  const renderCalculatorForm = () => {
    switch (selectedCalculator) {
      case 'succession':
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-white font-medium mb-2">Patrimoine total (€)</label>
              <input
                type="number"
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-green-500 focus:outline-none"
                placeholder="Ex: 500000"
                value={successionData.patrimoine || ''}
                onChange={(e) => setSuccessionData({...successionData, patrimoine: Number(e.target.value)})}
              />
            </div>
            <div>
              <label className="block text-white font-medium mb-2">Lien de parenté</label>
              <select
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-green-500 focus:outline-none"
                value={successionData.lienParente}
                onChange={(e) => setSuccessionData({...successionData, lienParente: e.target.value})}
              >
                <option value="enfant">Enfant</option>
                <option value="conjoint">Conjoint/Partenaire PACS</option>
                <option value="petitEnfant">Petit-enfant</option>
                <option value="frere">Frère/Sœur</option>
                <option value="neveu">Neveu/Nièce</option>
                <option value="autre">Autre</option>
              </select>
            </div>
            <div>
              <label className="block text-white font-medium mb-2">Donations antérieures (€)</label>
              <input
                type="number"
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-green-500 focus:outline-none"
                placeholder="Ex: 50000"
                value={successionData.donations || ''}
                onChange={(e) => setSuccessionData({...successionData, donations: Number(e.target.value)})}
              />
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="abattements"
                checked={successionData.abattements}
                onChange={(e) => setSuccessionData({...successionData, abattements: e.target.checked})}
                className="rounded"
              />
              <label htmlFor="abattements" className="text-white">Appliquer les abattements légaux</label>
            </div>
          </div>
        );

      case 'immobilier':
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-white font-medium mb-2">Prix d'achat (€)</label>
              <input
                type="number"
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                placeholder="Ex: 300000"
                value={immobilierData.prixAchat || ''}
                onChange={(e) => setImmobilierData({...immobilierData, prixAchat: Number(e.target.value)})}
              />
            </div>
            <div>
              <label className="block text-white font-medium mb-2">Prix de vente (€)</label>
              <input
                type="number"
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                placeholder="Ex: 400000"
                value={immobilierData.prixVente || ''}
                onChange={(e) => setImmobilierData({...immobilierData, prixVente: Number(e.target.value)})}
              />
            </div>
            <div>
              <label className="block text-white font-medium mb-2">Frais d'acquisition (€)</label>
              <input
                type="number"
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                placeholder="Ex: 25000"
                value={immobilierData.fraisAchat || ''}
                onChange={(e) => setImmobilierData({...immobilierData, fraisAchat: Number(e.target.value)})}
              />
            </div>
            <div>
              <label className="block text-white font-medium mb-2">Travaux déductibles (€)</label>
              <input
                type="number"
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                placeholder="Ex: 15000"
                value={immobilierData.travaux || ''}
                onChange={(e) => setImmobilierData({...immobilierData, travaux: Number(e.target.value)})}
              />
            </div>
            <div>
              <label className="block text-white font-medium mb-2">Durée de détention (années)</label>
              <input
                type="number"
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                placeholder="Ex: 8"
                value={immobilierData.dureeDetention || ''}
                onChange={(e) => setImmobilierData({...immobilierData, dureeDetention: Number(e.target.value)})}
              />
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="residencePrincipale"
                checked={immobilierData.residencePrincipale}
                onChange={(e) => setImmobilierData({...immobilierData, residencePrincipale: e.target.checked})}
                className="rounded"
              />
              <label htmlFor="residencePrincipale" className="text-white">Résidence principale</label>
            </div>
          </div>
        );

      case 'ifi':
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-white font-medium mb-2">Valeur brute du patrimoine (€)</label>
              <input
                type="number"
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-purple-500 focus:outline-none"
                placeholder="Ex: 2000000"
                value={ifiData.valeurBrute || ''}
                onChange={(e) => setIfiData({...ifiData, valeurBrute: Number(e.target.value)})}
              />
            </div>
            <div>
              <label className="block text-white font-medium mb-2">Dettes déductibles (€)</label>
              <input
                type="number"
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-purple-500 focus:outline-none"
                placeholder="Ex: 200000"
                value={ifiData.dettes || ''}
                onChange={(e) => setIfiData({...ifiData, dettes: Number(e.target.value)})}
              />
            </div>
            <div>
              <label className="block text-white font-medium mb-2">Exonérations (€)</label>
              <input
                type="number"
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-purple-500 focus:outline-none"
                placeholder="Ex: 100000"
                value={ifiData.exonerations || ''}
                onChange={(e) => setIfiData({...ifiData, exonerations: Number(e.target.value)})}
              />
              <p className="text-xs text-gray-400 mt-1">Résidence principale (30%), biens professionnels, etc.</p>
            </div>
            <div>
              <label className="block text-white font-medium mb-2">Réductions d'impôt (€)</label>
              <input
                type="number"
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-purple-500 focus:outline-none"
                placeholder="Ex: 5000"
                value={ifiData.reduction || ''}
                onChange={(e) => setIfiData({...ifiData, reduction: Number(e.target.value)})}
              />
              <p className="text-xs text-gray-400 mt-1">Dons, investissements PME, etc.</p>
            </div>
          </div>
        );

      case 'donation':
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-white font-medium mb-2">Montant de la donation (€)</label>
              <input
                type="number"
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-orange-500 focus:outline-none"
                placeholder="Ex: 150000"
                value={donationData.montant || ''}
                onChange={(e) => setDonationData({...donationData, montant: Number(e.target.value)})}
              />
            </div>
            <div>
              <label className="block text-white font-medium mb-2">Bénéficiaire</label>
              <select
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-orange-500 focus:outline-none"
                value={donationData.beneficiaire}
                onChange={(e) => setDonationData({...donationData, beneficiaire: e.target.value})}
              >
                <option value="enfant">Enfant</option>
                <option value="petitEnfant">Petit-enfant</option>
                <option value="conjoint">Conjoint</option>
                <option value="frere">Frère/Sœur</option>
                <option value="autre">Autre</option>
              </select>
            </div>
            <div>
              <label className="block text-white font-medium mb-2">Âge du donateur</label>
              <input
                type="number"
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-orange-500 focus:outline-none"
                placeholder="Ex: 75"
                value={donationData.ageDonateur || ''}
                onChange={(e) => setDonationData({...donationData, ageDonateur: Number(e.target.value)})}
              />
              <p className="text-xs text-gray-400 mt-1">Abattement supplémentaire si plus de 80 ans</p>
            </div>
            <div>
              <label className="block text-white font-medium mb-2">Donations antérieures (€)</label>
              <input
                type="number"
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-orange-500 focus:outline-none"
                placeholder="Ex: 20000"
                value={donationData.donationsAnterieures || ''}
                onChange={(e) => setDonationData({...donationData, donationsAnterieures: Number(e.target.value)})}
              />
              <p className="text-xs text-gray-400 mt-1">Dans les 15 dernières années</p>
            </div>
          </div>
        );

      case 'flatTax':
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-white font-medium mb-2">Revenus financiers (€)</label>
              <input
                type="number"
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-indigo-500 focus:outline-none"
                placeholder="Ex: 15000"
                value={flatTaxData.revenusFinanciers || ''}
                onChange={(e) => setFlatTaxData({...flatTaxData, revenusFinanciers: Number(e.target.value)})}
              />
              <p className="text-xs text-gray-400 mt-1">Dividendes, intérêts, etc.</p>
            </div>
            <div>
              <label className="block text-white font-medium mb-2">Plus-values mobilières (€)</label>
              <input
                type="number"
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-indigo-500 focus:outline-none"
                placeholder="Ex: 8000"
                value={flatTaxData.plusValues || ''}
                onChange={(e) => setFlatTaxData({...flatTaxData, plusValues: Number(e.target.value)})}
              />
            </div>
            <div>
              <label className="block text-white font-medium mb-2">Autres revenus (€)</label>
              <input
                type="number"
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-indigo-500 focus:outline-none"
                placeholder="Ex: 50000"
                value={flatTaxData.autresRevenus || ''}
                onChange={(e) => setFlatTaxData({...flatTaxData, autresRevenus: Number(e.target.value)})}
              />
              <p className="text-xs text-gray-400 mt-1">Salaires, pensions, etc.</p>
            </div>
            <div>
              <label className="block text-white font-medium mb-2">Nombre de parts fiscales</label>
              <input
                type="number"
                step="0.5"
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-indigo-500 focus:outline-none"
                placeholder="Ex: 2.5"
                value={flatTaxData.parts || ''}
                onChange={(e) => setFlatTaxData({...flatTaxData, parts: Number(e.target.value)})}
              />
            </div>
          </div>
        );

      case 'fonciers':
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-white font-medium mb-2">Loyers annuels (€)</label>
              <input
                type="number"
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-pink-500 focus:outline-none"
                placeholder="Ex: 24000"
                value={fonciersData.loyersAnnuels || ''}
                onChange={(e) => setFonciersData({...fonciersData, loyersAnnuels: Number(e.target.value)})}
              />
            </div>
            <div>
              <label className="block text-white font-medium mb-2">Régime fiscal</label>
              <select
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-pink-500 focus:outline-none"
                value={fonciersData.regime}
                onChange={(e) => setFonciersData({...fonciersData, regime: e.target.value})}
              >
                <option value="micro">Micro-foncier (abattement 30%)</option>
                <option value="reel">Régime réel</option>
              </select>
            </div>
            {fonciersData.regime === 'reel' && (
              <>
                <div>
                  <label className="block text-white font-medium mb-2">Charges déductibles (€)</label>
                  <input
                    type="number"
                    className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-pink-500 focus:outline-none"
                    placeholder="Ex: 3000"
                    value={fonciersData.charges || ''}
                    onChange={(e) => setFonciersData({...fonciersData, charges: Number(e.target.value)})}
                  />
                  <p className="text-xs text-gray-400 mt-1">Syndic, assurance, taxe foncière, etc.</p>
                </div>
                <div>
                  <label className="block text-white font-medium mb-2">Travaux déductibles (€)</label>
                  <input
                    type="number"
                    className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-pink-500 focus:outline-none"
                    placeholder="Ex: 5000"
                    value={fonciersData.travaux || ''}
                    onChange={(e) => setFonciersData({...fonciersData, travaux: Number(e.target.value)})}
                  />
                </div>
                <div>
                  <label className="block text-white font-medium mb-2">Intérêts d'emprunt (€)</label>
                  <input
                    type="number"
                    className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-pink-500 focus:outline-none"
                    placeholder="Ex: 8000"
                    value={fonciersData.interetsEmprunt || ''}
                    onChange={(e) => setFonciersData({...fonciersData, interetsEmprunt: Number(e.target.value)})}
                  />
                </div>
              </>
            )}
          </div>
        );

      default:
        return null;
    }
  };

  const renderResults = () => {
    if (!results) {
      return (
        <div className="bg-gray-900 rounded-xl p-6 border border-gray-700/50 text-center">
          <div className="w-20 h-20 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
            <i className="ri-calculator-line text-3xl text-gray-400"></i>
          </div>
          <h3 className="text-lg font-bold text-white mb-2">Prêt à Calculer</h3>
          <p className="text-gray-400 mb-4">Remplissez le formulaire et cliquez sur "Calculer" pour obtenir vos résultats</p>
          <div className="text-sm text-gray-500">
            <i className="ri-shield-check-line mr-1"></i>
            Calculs conformes à la réglementation 2024
          </div>
        </div>
      );
    }

    switch (results.type) {
      case 'succession':
        return (
          <div className="space-y-4">
            <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-6">
              <h3 className="text-xl font-bold text-white mb-4 flex items-center">
                <i className="ri-pie-chart-line text-xl mr-3"></i>
                Droits de Succession
              </h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-300">Patrimoine total:</span>
                  <span className="text-white font-semibold">{results.patrimoine.toLocaleString()} €</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Abattement appliqué:</span>
                  <span className="text-green-400 font-semibold">-{results.abattement.toLocaleString()} €</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Assiette taxable:</span>
                  <span className="text-white font-semibold">{results.assietteTaxable.toLocaleString()} €</span>
                </div>
                <hr className="border-gray-700" />
                <div className="flex justify-between text-lg">
                  <span className="text-white font-bold">Droits à payer:</span>
                  <span className="text-red-400 font-bold">{results.droits.toLocaleString()} €</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Taux effectif:</span>
                  <span className="text-orange-400 font-semibold">{results.tauxEffectif}%</span>
                </div>
              </div>
            </div>
          </div>
        );

      case 'immobilier':
        return (
          <div className="space-y-4">
            <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-6">
              <h3 className="text-xl font-bold text-white mb-4 flex items-center">
                <i className="ri-home-line text-xl mr-3"></i>
                Plus-values Immobilières
              </h3>
              {results.exoneration ? (
                <div className="text-center">
                  <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className="ri-check-line text-2xl text-white"></i>
                  </div>
                  <p className="text-green-400 font-semibold text-lg">{results.exoneration}</p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-300">Plus-value brute:</span>
                    <span className="text-white font-semibold">{results.plusValueBrute.toLocaleString()} €</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Abattement IR:</span>
                    <span className="text-green-400 font-semibold">{results.abattementIR}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Abattement PS:</span>
                    <span className="text-green-400 font-semibold">{results.abattementPS}%</span>
                  </div>
                  <hr className="border-gray-700" />
                  <div className="flex justify-between">
                    <span className="text-gray-300">Impôt sur le revenu (19%):</span>
                    <span className="text-red-400 font-semibold">{results.impotRevenu.toLocaleString()} €</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Prélèvements sociaux (17.2%):</span>
                    <span className="text-red-400 font-semibold">{results.prelevementsSociaux.toLocaleString()} €</span>
                  </div>
                  <hr className="border-gray-700" />
                  <div className="flex justify-between text-lg">
                    <span className="text-white font-bold">Total à payer:</span>
                    <span className="text-red-400 font-bold">{results.total.toLocaleString()} €</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        );

      case 'ifi':
        return (
          <div className="space-y-4">
            <div className="bg-purple-500/10 border border-purple-500/20 rounded-xl p-6">
              <h3 className="text-xl font-bold text-white mb-4 flex items-center">
                <i className="ri-building-line text-xl mr-3"></i>
                Impôt sur la Fortune Immobilière
              </h3>
              {results.message ? (
                <div className="text-center">
                  <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className="ri-check-line text-2xl text-white"></i>
                  </div>
                  <p className="text-green-400 font-semibold text-lg">{results.message}</p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-300">Assiette taxable:</span>
                    <span className="text-white font-semibold">{results.assietteTaxable.toLocaleString()} €</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Impôt brut:</span>
                    <span className="text-red-400 font-semibold">{results.impotBrut.toLocaleString()} €</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Réductions:</span>
                    <span className="text-green-400 font-semibold">-{results.reduction.toLocaleString()} €</span>
                  </div>
                  <hr className="border-gray-700" />
                  <div className="flex justify-between text-lg">
                    <span className="text-white font-bold">IFI à payer:</span>
                    <span className="text-red-400 font-bold">{results.impotFinal.toLocaleString()} €</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        );

      case 'donation':
        return (
          <div className="space-y-4">
            <div className="bg-orange-500/10 border border-orange-500/20 rounded-xl p-6">
              <h3 className="text-xl font-bold text-white mb-4 flex items-center">
                <i className="ri-gift-line text-xl mr-3"></i>
                Donation Optimale
              </h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-300">Montant donné:</span>
                  <span className="text-white font-semibold">{results.montant.toLocaleString()} €</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Abattement appliqué:</span>
                  <span className="text-green-400 font-semibold">-{results.abattement.toLocaleString()} €</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Assiette taxable:</span>
                  <span className="text-white font-semibold">{results.assietteTaxable.toLocaleString()} €</span>
                </div>
                <hr className="border-gray-700" />
                <div className="flex justify-between">
                  <span className="text-gray-300">Droits de donation:</span>
                  <span className="text-red-400 font-semibold">{results.droits.toLocaleString()} €</span>
                </div>
                <div className="flex justify-between text-lg">
                  <span className="text-white font-bold">Économie vs succession:</span>
                  <span className="text-green-400 font-bold">+{results.economie.toLocaleString()} €</span>
                </div>
              </div>
            </div>
          </div>
        );

      case 'flatTax':
        return (
          <div className="space-y-4">
            <div className="bg-indigo-500/10 border border-indigo-500/20 rounded-xl p-6">
              <h3 className="text-xl font-bold text-white mb-4 flex items-center">
                <i className="ri-scales-line text-xl mr-3"></i>
                Flat Tax vs Barème Progressif
              </h3>
              <div className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="bg-gray-800 rounded-lg p-4">
                    <h4 className="text-white font-semibold mb-2">Flat Tax (30%)</h4>
                    <div className="text-2xl font-bold text-blue-400">{results.flatTax.toLocaleString()} €</div>
                  </div>
                  <div className="bg-gray-800 rounded-lg p-4">
                    <h4 className="text-white font-semibold mb-2">Barème Progressif</h4>
                    <div className="text-2xl font-bold text-purple-400">{results.bareme.toLocaleString()} €</div>
                  </div>
                </div>
                <hr className="border-gray-700" />
                <div className="text-center">
                  <div className="text-lg font-bold text-white mb-2">Meilleur choix:</div>
                  <div className="text-2xl font-bold text-green-400">{results.meilleurChoix}</div>
                  <div className="text-gray-300 mt-2">Économie: {results.economie.toLocaleString()} €</div>
                </div>
              </div>
            </div>
          </div>
        );

      case 'fonciers':
        return (
          <div className="space-y-4">
            <div className="bg-pink-500/10 border border-pink-500/20 rounded-xl p-6">
              <h3 className="text-xl font-bold text-white mb-4 flex items-center">
                <i className="ri-key-line text-xl mr-3"></i>
                Revenus Fonciers - {results.regime}
              </h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-300">Loyers bruts:</span>
                  <span className="text-white font-semibold">{results.loyersBruts.toLocaleString()} €</span>
                </div>
                {results.regime === 'Micro-foncier' ? (
                  <div className="flex justify-between">
                    <span className="text-gray-300">Abattement (30%):</span>
                    <span className="text-green-400 font-semibold">-{results.abattement.toLocaleString()} €</span>
                  </div>
                ) : (
                  <div className="flex justify-between">
                    <span className="text-gray-300">Charges déductibles:</span>
                    <span className="text-green-400 font-semibold">-{results.charges.toLocaleString()} €</span>
                  </div>
                )}
                <hr className="border-gray-700" />
                <div className="flex justify-between text-lg">
                  <span className="text-white font-bold">Revenu imposable:</span>
                  <span className="text-blue-400 font-bold">{results.revenuImposable.toLocaleString()} €</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Prélèvements sociaux (17.2%):</span>
                  <span className="text-red-400 font-semibold">{results.prelevementsSociaux.toLocaleString()} €</span>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-white mb-2">
          Calculateurs <span className="text-blue-400">Juridiques</span> et Fiscaux
        </h2>
        <p className="text-gray-400">Estimez l'impact fiscal de vos décisions patrimoniales</p>
      </div>

      <div className="bg-gray-900 rounded-xl p-6 border border-blue-500/20">
        <h3 className="text-xl font-bold text-white mb-4">Choisir un Calculateur</h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {calculators.map((calc) => (
            <button
              key={calc.id}
              onClick={() => {
                setSelectedCalculator(calc.id);
                setResults(null);
              }}
              className={`p-4 rounded-lg border-2 transition-all cursor-pointer text-left ${
                selectedCalculator === calc.id
                  ? `border-${calc.color}-500 bg-${calc.color}-500/10`
                  : 'border-gray-700 hover:border-gray-600 bg-black/30'
              }`}
            >
              <div className="flex items-center space-x-3 mb-2">
                <div className={`w-10 h-10 bg-${calc.color}-500 rounded-lg flex items-center justify-center`}>
                  <i className={`${calc.icon} text-lg text-white`}></i>
                </div>
                <span className="font-semibold text-white">{calc.name}</span>
              </div>
              {selectedCalculator === calc.id && (
                <div className={`text-${calc.color}-400 text-xs`}>✓ Sélectionné</div>
              )}
            </button>
          ))}
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        <div className="bg-gray-900 rounded-xl p-6 border border-blue-500/20">
          <h3 className="text-xl font-bold text-white mb-4 flex items-center">
            <i className={`${calculators.find(c => c.id === selectedCalculator)?.icon || ''} text-xl mr-3`}></i>
            {calculators.find(c => c.id === selectedCalculator)?.name}
          </h3>
          
          {renderCalculatorForm()}

          <button
            onClick={handleCalculate}
            className="w-full mt-6 bg-blue-500 hover:bg-blue-400 text-white py-3 px-6 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-calculator-line mr-2"></i>
            Calculer
          </button>

          <div className="mt-4 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
            <div className="flex items-start space-x-2">
              <i className="ri-information-line text-yellow-400 mt-0.5"></i>
              <div className="text-xs text-yellow-300">
                <strong>Avertissement:</strong> Ces calculs sont fournis à titre indicatif. Pour une analyse précise de votre situation, consultez un expert-comptable ou conseiller fiscal.
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          {renderResults()}
          
          {results && (
            <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-4">
              <h4 className="text-white font-semibold mb-2 flex items-center">
                <i className="ri-lightbulb-line text-green-400 mr-2"></i>
                Conseil Expert
              </h4>
              <p className="text-green-300 text-sm">
                {selectedCalculator === 'succession' && 'Pensez aux donations de votre vivant pour optimiser la transmission.'}
                {selectedCalculator === 'immobilier' && 'Plus vous gardez longtemps, plus les abattements sont importants.'}
                {selectedCalculator === 'ifi' && 'Investissez dans des biens exonérés pour réduire votre IFI.'}
                {selectedCalculator === 'donation' && 'Les donations permettent de transmettre en payant moins de droits.'}
                {selectedCalculator === 'flatTax' && 'La flat tax n\'est pas toujours plus avantageuse. Vérifiez selonvos revenus globaux.'}
                {selectedCalculator === 'fonciers' && 'Le régime réel peut être plus avantageux si vos charges dépassent 30%.'}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
