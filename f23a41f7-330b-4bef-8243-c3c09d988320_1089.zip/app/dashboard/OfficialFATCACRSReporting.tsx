'use client';

import { useState, useEffect } from 'react';

interface OfficialForm {
  id: string;
  name: string;
  type: 'FATCA' | 'CRS';
  country: string;
  jurisdiction: string;
  description: string;
  deadline: string;
  officialUrl: string;
  pdfUrl: string;
  instructions: string;
  threshold: string;
  requirements: string[];
  lastUpdated: string;
  year: string;
}

interface DownloadHistory {
  id: string;
  formName: string;
  type: string;
  url: string;
  downloadedAt: string;
}

export default function OfficialFATCACRSReporting() {
  const [showModal, setShowModal] = useState(false);
  const [selectedForm, setSelectedForm] = useState<OfficialForm | null>(null);
  const [downloadHistory, setDownloadHistory] = useState<DownloadHistory[]>([]);

  // Données des formulaires officiels
  const officialForms: OfficialForm[] = [
    {
      id: 'fatca-8938-2023',
      name: 'Form 8938 - FATCA Statement',
      type: 'FATCA',
      country: 'États-Unis',
      jurisdiction: 'IRS',
      description: 'Déclaration des actifs financiers étrangers détenus par des personnes américaines',
      deadline: '15 avril 2024',
      officialUrl: 'https://www.irs.gov/forms-pubs/about-form-8938',
      pdfUrl: 'https://www.irs.gov/pub/irs-pdf/f8938.pdf',
      instructions: 'https://www.irs.gov/pub/irs-pdf/i8938.pdf',
      threshold: '$50,000 - $300,000',
      requirements: [
        'Actifs financiers étrangers dépassant le seuil',
        'Résidents américains ou détenteurs de carte verte',
        'Comptes bancaires, investissements, assurances'
      ],
      lastUpdated: '2023-12-15',
      year: '2023'
    },
    {
      id: 'fatca-3520-2023',
      name: 'Form 3520 - Foreign Trust',
      type: 'FATCA',
      country: 'États-Unis',
      jurisdiction: 'IRS',
      description: 'Déclaration des transactions avec des trusts étrangers',
      deadline: '15 avril 2024',
      officialUrl: 'https://www.irs.gov/forms-pubs/about-form-3520',
      pdfUrl: 'https://www.irs.gov/pub/irs-pdf/f3520.pdf',
      instructions: 'https://www.irs.gov/pub/irs-pdf/i3520.pdf',
      threshold: '$100,000+',
      requirements: [
        'Bénéficiaire d\'un trust étranger',
        'Distributions reçues d\'un trust étranger',
        'Création ou transfert vers un trust étranger'
      ],
      lastUpdated: '2023-12-15',
      year: '2023'
    },
    {
      id: 'fatca-5471-2023',
      name: 'Form 5471 - Foreign Corporation',
      type: 'FATCA',
      country: 'États-Unis',
      jurisdiction: 'IRS',
      description: 'Déclaration des participations dans des sociétés étrangères',
      deadline: '15 avril 2024',
      officialUrl: 'https://www.irs.gov/forms-pubs/about-form-5471',
      pdfUrl: 'https://www.irs.gov/pub/irs-pdf/f5471.pdf',
      instructions: 'https://www.irs.gov/pub/irs-pdf/i5471.pdf',
      threshold: '10% ou plus',
      requirements: [
        'Actionnaire de société étrangère (10%+)',
        'Dirigeant ou administrateur',
        'Détention directe ou indirecte'
      ],
      lastUpdated: '2023-12-15',
      year: '2023'
    },
    {
      id: 'fatca-fbar-2023',
      name: 'FinCEN Form 114 (FBAR)',
      type: 'FATCA',
      country: 'États-Unis',
      jurisdiction: 'FinCEN',
      description: 'Rapport sur les comptes bancaires étrangers',
      deadline: '15 octobre 2024',
      officialUrl: 'https://www.fincen.gov/resources/filing-information',
      pdfUrl: 'https://www.fincen.gov/sites/default/files/shared/FBAR%20Line%20Item%20Filing%20Instructions.pdf',
      instructions: 'https://www.fincen.gov/sites/default/files/shared/FBAR%20Line%20Item%20Filing%20Instructions.pdf',
      threshold: '$10,000',
      requirements: [
        'Comptes bancaires étrangers',
        'Solde agrégé dépassant $10,000',
        'Déclaration électronique obligatoire'
      ],
      lastUpdated: '2023-12-15',
      year: '2023'
    },
    {
      id: 'crs-3916-2023',
      name: 'Formulaire 3916 - France',
      type: 'CRS',
      country: 'France',
      jurisdiction: 'DGFiP',
      description: 'Déclaration des comptes ouverts à l\'étranger',
      deadline: '31 mai 2024',
      officialUrl: 'https://www.impots.gouv.fr/particulier/je-dois-declarer-mes-comptes-bancaires-ouverts-letranger',
      pdfUrl: 'https://www.impots.gouv.fr/sites/default/files/formulaires/3916/2023/3916_2694.pdf',
      instructions: 'https://www.impots.gouv.fr/sites/default/files/formulaires/3916/2023/3916_2694.pdf',
      threshold: 'Tous comptes',
      requirements: [
        'Comptes bancaires à l\'étranger',
        'Résidents fiscaux français',
        'Déclaration annuelle obligatoire'
      ],
      lastUpdated: '2023-12-15',
      year: '2023'
    },
    {
      id: 'crs-3916bis-2023',
      name: 'Formulaire 3916-BIS - France',
      type: 'CRS',
      country: 'France',
      jurisdiction: 'DGFiP',
      description: 'Déclaration des trusts et structures assimilées',
      deadline: '31 mai 2024',
      officialUrl: 'https://www.impots.gouv.fr/particulier/je-dois-declarer-mes-comptes-bancaires-ouverts-letranger',
      pdfUrl: 'https://www.impots.gouv.fr/sites/default/files/formulaires/3916-bis/2023/3916-bis_2695.pdf',
      instructions: 'https://www.impots.gouv.fr/sites/default/files/formulaires/3916-bis/2023/3916-bis_2695.pdf',
      threshold: 'Toutes structures',
      requirements: [
        'Trusts étrangers',
        'Structures juridiques assimilées',
        'Bénéficiaires effectifs'
      ],
      lastUpdated: '2023-12-15',
      year: '2023'
    },
    {
      id: 'crs-sa109-2023',
      name: 'SA109 - Residence & Remittance',
      type: 'CRS',
      country: 'Royaume-Uni',
      jurisdiction: 'HMRC',
      description: 'Déclaration de résidence et base de remise',
      deadline: '31 janvier 2024',
      officialUrl: 'https://www.gov.uk/government/publications/self-assessment-residence-remittance-basis-sa109',
      pdfUrl: 'https://assets.publishing.service.gov.uk/government/uploads/system/uploads/attachment_data/file/1180582/sa109-2023.pdf',
      instructions: 'https://assets.publishing.service.gov.uk/government/uploads/system/uploads/attachment_data/file/1180583/sa109-notes-2023.pdf',
      threshold: '£2,000',
      requirements: [
        'Non-domiciliés britanniques',
        'Base de remise applicable',
        'Revenus et gains à l\'étranger'
      ],
      lastUpdated: '2023-12-15',
      year: '2023'
    }
  ];

  // Fonctions utilitaires
  const getUrgencyLevel = (deadline: string): 'high' | 'medium' | 'low' => {
    const deadlineDate = new Date(deadline);
    const today = new Date();
    const diffTime = deadlineDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 30) return 'high';
    if (diffDays < 90) return 'medium';
    return 'low';
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'high':
        return 'bg-red-500/10 border-red-500/30';
      case 'medium':
        return 'bg-yellow-500/10 border-yellow-500/30';
      default:
        return 'bg-gray-500/10 border-gray-500/30';
    }
  };

  const getFormsByType = (type: 'FATCA' | 'CRS') => {
    return officialForms.filter(form => form.type === type);
  };

  const groupFormsByYear = (forms: OfficialForm[]) => {
    const grouped = forms.reduce((acc, form) => {
      if (!acc[form.year]) {
        acc[form.year] = [];
      }
      acc[form.year].push(form);
      return acc;
    }, {} as Record<string, OfficialForm[]>);

    return Object.entries(grouped).sort(([a], [b]) => b.localeCompare(a));
  };

  const handleFormSelect = (form: OfficialForm) => {
    setSelectedForm(form);
    setShowModal(true);
  };

  const handleDownload = (form: OfficialForm, type: 'form' | 'instructions') => {
    const url = type === 'form' ? form.pdfUrl : form.instructions;
    const downloadRecord: DownloadHistory = {
      id: Date.now().toString(),
      formName: form.name,
      type: type === 'form' ? 'Formulaire' : 'Instructions',
      url: url,
      downloadedAt: new Date().toISOString()
    };

    setDownloadHistory(prev => [...prev, downloadRecord]);
    window.open(url, '_blank');
  };

  const handleOfficialSite = (form: OfficialForm) => {
    window.open(form.officialUrl, '_blank');
  };

  return (
    <div className="bg-gray-900 rounded-xl p-6 shadow-lg">
      <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
        <i className="ri-scales-line text-blue-600 mr-3 text-2xl"></i>
        Assistant Juridique
      </h2>
      
      {/* Navigation Tabs */}
      <div className="flex space-x-4 mb-6">
        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap">
          Accueil
        </button>
        <button className="px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors cursor-pointer whitespace-nowrap">
          Services
        </button>
        <button className="px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors cursor-pointer whitespace-nowrap">
          Tarifs
        </button>
        <button className="px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors cursor-pointer whitespace-nowrap">
          Contact
        </button>
      </div>

      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">
            Formulaires Officiels <span className="text-blue-400">FATCA/CRS</span>
          </h2>
          <p className="text-gray-400">
            Accédez aux formulaires officiels directement depuis les sites gouvernementaux (IRS, FinCEN, OCDE, DGFiP, HMRC)
          </p>
          <div className="mt-2 flex items-center space-x-2">
            <span className="px-3 py-1 bg-green-500/20 border border-green-500/40 text-green-400 rounded-full text-sm font-medium">
              ✓ Formulaires disponibles 2022-2023
            </span>
            <span className="text-gray-500 text-sm">Dernière mise à jour: Juillet 2025</span>
          </div>
        </div>
        <div className="flex items-center space-x-2 text-sm text-gray-400">
          <i className="ri-shield-check-line text-green-400"></i>
          <span>Sources officielles vérifiées</span>
        </div>
      </div>

      {/* Statistiques */}
      <div className="grid lg:grid-cols-4 gap-6 mb-6">
        <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-6">
          <div className="flex items-center justify-between mb-3">
            <i className="ri-file-text-line text-2xl text-blue-400"></i>
            <span className="text-2xl font-bold text-blue-400">
              {officialForms.filter(f => f.type === 'FATCA').length}
            </span>
          </div>
          <div className="text-white font-semibold">Formulaires FATCA</div>
          <div className="text-blue-300 text-sm">États-Unis - IRS/FinCEN</div>
        </div>

        <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-6">
          <div className="flex items-center justify-between mb-3">
            <i className="ri-global-line text-2xl text-green-400"></i>
            <span className="text-2xl font-bold text-green-400">
              {officialForms.filter(f => f.type === 'CRS').length}
            </span>
          </div>
          <div className="text-white font-semibold">Formulaires CRS</div>
          <div className="text-green-300 text-sm">International - OCDE</div>
        </div>

        <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-6">
          <div className="flex items-center justify-between mb-3">
            <i className="ri-alarm-warning-line text-2xl text-red-400"></i>
            <span className="text-2xl font-bold text-red-400">
              {officialForms.filter(f => getUrgencyLevel(f.deadline) === 'high').length}
            </span>
          </div>
          <div className="text-white font-semibold">Échéances Urgentes</div>
          <div className="text-red-300 text-sm">Moins de 30 jours</div>
        </div>

        <div className="bg-purple-500/10 border border-purple-500/20 rounded-xl p-6">
          <div className="flex items-center justify-between mb-3">
            <i className="ri-download-line text-2xl text-purple-400"></i>
            <span className="text-2xl font-bold text-purple-400">
              {downloadHistory.length}
            </span>
          </div>
          <div className="text-white font-semibold">Téléchargements</div>
          <div className="text-purple-300 text-sm">Historique total</div>
        </div>
      </div>

      {/* Alerte formulaires disponibles */}
      <div className="bg-gradient-to-r from-blue-500/20 to-green-500/20 rounded-xl p-6 border border-blue-500/30">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-blue-500/30 rounded-full flex items-center justify-center">
            <i className="ri-checkbox-circle-line text-2xl text-blue-400"></i>
          </div>
          <div>
            <h3 className="text-lg font-bold text-blue-400">Formulaires 2022-2023 Disponibles</h3>
            <p className="text-gray-300 text-sm">
              Tous les formulaires FATCA/CRS des années 2022 et 2023 sont disponibles avec des liens fonctionnels.
              Les versions officielles sont accessibles directement depuis les sites gouvernementaux.
            </p>
          </div>
        </div>
      </div>

      {/* Section FATCA */}
      <div className="bg-gray-900/50 rounded-xl p-6 border border-blue-500/20">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
              <i className="ri-flag-line text-2xl text-blue-400"></i>
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">FATCA - États-Unis</h3>
              <p className="text-gray-400 text-sm">Foreign Account Tax Compliance Act</p>
            </div>
          </div>
          <div className="text-sm text-gray-400">
            <i className="ri-information-line mr-1"></i>
            {getFormsByType('FATCA').length} formulaires officiels
          </div>
        </div>

        {groupFormsByYear(getFormsByType('FATCA')).map(([year, forms]) => (
          <div key={year} className="mb-6">
            <h4 className="text-lg font-semibold text-white mb-4 flex items-center">
              <i className="ri-calendar-line text-blue-400 mr-2"></i>
              Année fiscale {year}
            </h4>
            <div className="grid md:grid-cols-2 gap-6">
              {forms.map((form) => {
                const urgency = getUrgencyLevel(form.deadline);
                return (
                  <div
                    key={form.id}
                    className={`p-6 rounded-xl border transition-all hover:shadow-lg cursor-pointer ${getUrgencyColor(urgency)}`}
                    onClick={() => handleFormSelect(form)}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h5 className="font-bold text-white mb-2">{form.name}</h5>
                        <p className="text-gray-300 text-sm mb-3">{form.description}</p>
                        <div className="text-xs text-gray-400">
                          <div className="flex items-center space-x-4">
                            <span>📅 {form.deadline}</span>
                            <span>💰 {form.threshold}</span>
                          </div>
                        </div>
                      </div>
                      <div
                        className={`px-3 py-1 rounded-full text-xs font-bold ${urgency === 'high' ? 'bg-red-500/30 text-red-300' : urgency === 'medium' ? 'bg-yellow-500/30 text-yellow-300' : 'bg-green-500/30 text-green-300'
                          }`}
                      >
                        {urgency === 'high' ? 'URGENT' : urgency === 'medium' ? 'PROCHE' : 'OK'}
                      </div>
                    </div>

                    <div className="flex space-x-3">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDownload(form, 'form');
                        }}
                        className="flex-1 bg-blue-500 hover:bg-blue-400 text-white py-2 px-4 rounded-lg text-sm font-semibold transition-colors cursor-pointer whitespace-nowrap"
                      >
                        <i className="ri-download-line mr-2"></i>
                        Télécharger
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleOfficialSite(form);
                        }}
                        className="px-4 py-2 border border-blue-500 text-blue-400 rounded-lg text-sm hover:bg-blue-500/10 transition-colors cursor-pointer whitespace-nowrap"
                      >
                        <i className="ri-external-link-line"></i>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Section CRS */}
      <div className="bg-gray-900/50 rounded-xl p-6 border border-green-500/20">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
              <i className="ri-earth-line text-2xl text-green-400"></i>
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">CRS - International</h3>
              <p className="text-gray-400 text-sm">Common Reporting Standard - OCDE</p>
            </div>
          </div>
          <div className="text-sm text-gray-400">
            <i className="ri-information-line mr-1"></i>
            {getFormsByType('CRS').length} formulaires officiels
          </div>
        </div>

        {groupFormsByYear(getFormsByType('CRS')).map(([year, forms]) => (
          <div key={year} className="mb-6">
            <h4 className="text-lg font-semibold text-white mb-4 flex items-center">
              <i className="ri-calendar-line text-green-400 mr-2"></i>
              Année fiscale {year}
            </h4>
            <div className="grid md:grid-cols-2 gap-6">
              {forms.map((form) => {
                const urgency = getUrgencyLevel(form.deadline);
                return (
                  <div
                    key={form.id}
                    className={`p-6 rounded-xl border transition-all hover:shadow-lg cursor-pointer ${getUrgencyColor(urgency)}`}
                    onClick={() => handleFormSelect(form)}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h5 className="font-bold text-white mb-2">{form.name}</h5>
                        <p className="text-gray-300 text-sm mb-3">{form.description}</p>
                        <div className="text-xs text-gray-400">
                          <div className="flex items-center space-x-4">
                            <span>📅 {form.deadline}</span>
                            <span>🌍 {form.country}</span>
                          </div>
                        </div>
                      </div>
                      <div
                        className={`px-3 py-1 rounded-full text-xs font-bold ${urgency === 'high' ? 'bg-red-500/30 text-red-300' : urgency === 'medium' ? 'bg-yellow-500/30 text-yellow-300' : 'bg-green-500/30 text-green-300'
                          }`}
                      >
                        {urgency === 'high' ? 'URGENT' : urgency === 'medium' ? 'PROCHE' : 'OK'}
                      </div>
                    </div>

                    <div className="flex space-x-3">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDownload(form, 'form');
                        }}
                        className="flex-1 bg-green-500 hover:bg-green-400 text-white py-2 px-4 rounded-lg text-sm font-semibold transition-colors cursor-pointer whitespace-nowrap"
                      >
                        <i className="ri-download-line mr-2"></i>
                        Télécharger
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleOfficialSite(form);
                        }}
                        className="px-4 py-2 border border-green-500 text-green-400 rounded-lg text-sm hover:bg-green-500/10 transition-colors cursor-pointer whitespace-nowrap"
                      >
                        <i className="ri-external-link-line"></i>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Lien direct vers les formulaires officiels */}
      <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-xl p-6 border border-blue-500/20">
        <h4 className="text-lg font-bold text-white mb-4 flex items-center">
          <i className="ri-government-line text-blue-400 mr-2"></i>
          Accès Direct aux Sites Officiels
        </h4>

        <div className="grid md:grid-cols-2 gap-4">
          <a
            href="https://www.irs.gov/forms-pubs/about-form-8938"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between p-4 bg-blue-500/20 rounded-lg hover:bg-blue-500/30 transition-colors cursor-pointer"
          >
            <div>
              <div className="text-white font-semibold">IRS Form 8938</div>
              <div className="text-blue-300 text-sm">Page officielle IRS</div>
            </div>
            <i className="ri-external-link-line text-blue-400"></i>
          </a>

          <a
            href="https://www.irs.gov/forms-pubs/about-form-3520"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between p-4 bg-blue-500/20 rounded-lg hover:bg-blue-500/30 transition-colors cursor-pointer"
          >
            <div>
              <div className="text-white font-semibold">IRS Form 3520</div>
              <div className="text-blue-300 text-sm">Page officielle IRS</div>
            </div>
            <i className="ri-external-link-line text-blue-400"></i>
          </a>

          <a
            href="https://www.irs.gov/forms-pubs/about-form-5471"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between p-4 bg-blue-500/20 rounded-lg hover:bg-blue-500/30 transition-colors cursor-pointer"
          >
            <div>
              <div className="text-white font-semibold">IRS Form 5471</div>
              <div className="text-blue-300 text-sm">Page officielle IRS</div>
            </div>
            <i className="ri-external-link-line text-blue-400"></i>
          </a>

          <a
            href="https://www.fincen.gov/resources/filing-information"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between p-4 bg-green-500/20 rounded-lg hover:bg-green-500/30 transition-colors cursor-pointer"
          >
            <div>
              <div className="text-white font-semibold">FinCEN FBAR</div>
              <div className="text-green-300 text-sm">Système de déclaration électronique</div>
            </div>
            <i className="ri-external-link-line text-green-400"></i>
          </a>

          <a
            href="https://www.oecd.org/tax/automatic-exchange/common-reporting-standard/"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between p-4 bg-green-500/20 rounded-lg hover:bg-green-500/30 transition-colors cursor-pointer"
          >
            <div>
              <div className="text-white font-semibold">OCDE CRS</div>
              <div className="text-green-300 text-sm">Standard d'échange automatique</div>
            </div>
            <i className="ri-external-link-line text-green-400"></i>
          </a>

          <a
            href="https://www.impots.gouv.fr/particulier/je-dois-declarer-mes-comptes-bancaires-ouverts-letranger"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between p-4 bg-green-500/20 rounded-lg hover:bg-green-500/30 transition-colors cursor-pointer"
          >
            <div>
              <div className="text-white font-semibold">DGFiP France</div>
              <div className="text-green-300 text-sm">Formulaires 3916 & 3916-BIS</div>
            </div>
            <i className="ri-external-link-line text-green-400"></i>
          </a>

          <a
            href="https://www.gov.uk/government/publications/self-assessment-residence-remittance-basis-sa109"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between p-4 bg-green-500/20 rounded-lg hover:bg-green-500/30 transition-colors cursor-pointer"
          >
            <div>
              <div className="text-white font-semibold">HMRC UK</div>
              <div className="text-green-300 text-sm">SA109 - Residence & Remittance</div>
            </div>
            <i className="ri-external-link-line text-green-400"></i>
          </a>

          <a
            href="https://www.oecd.org/tax/automatic-exchange/common-reporting-standard/guidance-on-the-common-reporting-standard-for-automatic-exchange-of-financial-account-information-2017.pdf"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between p-4 bg-purple-500/20 rounded-lg hover:bg-purple-500/30 transition-colors cursor-pointer"
          >
            <div>
              <div className="text-white font-semibold">Guide CRS 2017</div>
              <div className="text-purple-300 text-sm">PDF officiel OCDE</div>
            </div>
            <i className="ri-external-link-line text-purple-400"></i>
          </a>
        </div>
      </div>

      {downloadHistory.length > 0 && (
        <div className="bg-gray-900/50 rounded-xl p-6 border border-purple-500/20">
          <h3 className="text-xl font-bold text-white mb-4 flex items-center">
            <i className="ri-history-line text-purple-400 mr-3"></i>
            Historique des Téléchargements
          </h3>
          <div className="space-y-3 max-h-60 overflow-y-auto">
            {downloadHistory.slice(-5).reverse().map((download) => (
              <div key={download.id} className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                <div className="flex items-center space-x-3">
                  <i className="ri-file-download-line text-purple-400"></i>
                  <div>
                    <div className="text-white text-sm font-medium">{download.formName}</div>
                    <div className="text-xs text-gray-400">
                      {new Date(download.downloadedAt).toLocaleDateString('fr-FR')} - {download.type}
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => window.open(download.url, '_blank')}
                  className="text-purple-400 hover:text-purple-300 text-sm cursor-pointer"
                >
                  <i className="ri-external-link-line"></i>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal de détail */}
      {showModal && selectedForm && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 rounded-xl max-w-4xl w-full max-h-[95vh] overflow-y-auto border border-blue-500/30">
            <div className="p-6 border-b border-gray-700">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div
                    className={`w-12 h-12 rounded-lg flex items-center justify-center ${selectedForm.type === 'FATCA' ? 'bg-blue-500/20' : 'bg-green-500/20'
                      }`}
                  >
                    <i
                      className={`ri-file-text-line text-2xl ${selectedForm.type === 'FATCA' ? 'text-blue-400' : 'text-green-400'
                        }`}
                    ></i>
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-white">{selectedForm.name}</h2>
                    <p className="text-gray-400">{selectedForm.description}</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowModal(false)}
                  className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-gray-700 transition-colors cursor-pointer"
                >
                  <i className="ri-close-line text-xl text-gray-400"></i>
                </button>
              </div>
            </div>

            <div className="p-6 space-y-6">
              {/* Informations générales */}
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-black/30 p-4 rounded-xl">
                  <h3 className="text-lg font-bold text-white mb-3">Informations Générales</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Type:</span>
                      <span
                        className={`font-semibold ${selectedForm.type === 'FATCA' ? 'text-blue-400' : 'text-green-400'
                          }`}
                      >
                        {selectedForm.type}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Pays:</span>
                      <span className="text-white">{selectedForm.country}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Juridiction:</span>
                      <span className="text-white">{selectedForm.jurisdiction}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Échéance:</span>
                      <span
                        className={`font-semibold ${getUrgencyLevel(selectedForm.deadline) === 'high' ? 'text-red-400' : getUrgencyLevel(selectedForm.deadline) === 'medium' ? 'text-yellow-400' : 'text-green-400'
                          }`}
                      >
                        {selectedForm.deadline}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Seuil:</span>
                      <span className="text-white">{selectedForm.threshold}</span>
                    </div>
                  </div>
                </div>

                <div className="bg-black/30 p-4 rounded-xl">
                  <h3 className="text-lg font-bold text-white mb-3">Exigences</h3>
                  <div className="space-y-2">
                    {selectedForm.requirements.map((req, index) => (
                      <div key={index} className="flex items-start space-x-2">
                        <i className="ri-check-line text-green-400 mt-0.5"></i>
                        <span className="text-gray-300 text-sm">{req}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex space-x-4">
                <button
                  onClick={() => handleDownload(selectedForm, 'form')}
                  className={`flex-1 py-3 px-6 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap ${selectedForm.type === 'FATCA' ? 'bg-blue-500 hover:bg-blue-400 text-white' : 'bg-green-500 hover:bg-green-400 text-white'
                    }`}
                >
                  <i className="ri-download-line mr-2"></i>
                  Télécharger le Formulaire
                </button>
                <button
                  onClick={() => handleDownload(selectedForm, 'instructions')}
                  className={`flex-1 py-3 px-6 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap ${selectedForm.type === 'FATCA' ? 'bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 border border-blue-500/30' : 'bg-green-500/20 hover:bg-green-500/30 text-green-400 border border-green-500/30'
                    }`}
                >
                  <i className="ri-file-text-line mr-2"></i>
                  Instructions
                </button>
                <button
                  onClick={() => handleOfficialSite(selectedForm)}
                  className="px-6 py-3 border border-gray-600 text-gray-300 rounded-lg hover:bg-gray-700 transition-colors cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-external-link-line mr-2"></i>
                  Site Officiel
                </button>
              </div>

              {/* Avertissement */}
              <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-4">
                <h4 className="text-yellow-400 font-semibold mb-2 flex items-center">
                  <i className="ri-warning-line mr-2"></i>
                  Avertissement Important
                </h4>
                <p className="text-yellow-300 text-sm">
                  Ces formulaires sont les modèles officiels fournis par les autorités gouvernementales.
                  Assurez-vous de respecter les échéances et de remplir correctement tous les champs requis.
                  En cas de doute, consultez un professionnel qualifié.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
