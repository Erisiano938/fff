
'use client';

import { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, PieChart, Pie, Cell, BarChart, Bar } from 'recharts';
import LiquidityStressTest from './LiquidityStressTest';

export default function SavingsSimulator() {
  const [activeTab, setActiveTab] = useState('simulator');
  const [formData, setFormData] = useState({
    montantInitial: 10000,
    versementMensuel: 500,
    duree: 10,
    tauxRendement: 4.5,
    fiscalite: 'PEA'
  });
  
  const [simulation, setSimulation] = useState({
    capitalFinal: 0,
    interetsGeneres: 0,
    versementsTotal: 0,
    gainFiscal: 0
  });

  const [projectionData, setProjectionData] = useState([]);

  const fiscaliteOptions = [
    { value: 'PEA', label: 'PEA', taux: 0 },
    { value: 'AV', label: 'Assurance Vie', taux: 7.5 },
    { value: 'CTO', label: 'Compte Titres Ordinaire', taux: 30 },
    { value: 'PEL', label: 'Plan Épargne Logement', taux: 12.8 }
  ];

  const calculateSimulation = () => {
    const { montantInitial, versementMensuel, duree, tauxRendement, fiscalite } = formData;
    const tauxMensuel = tauxRendement / 100 / 12;
    const nbMois = duree * 12;
    
    // Calcul avec versements mensuels
    let capital = montantInitial;
    const projectionYearly = [];
    
    // Données pour le graphique année par année
    for (let annee = 0; annee <= duree; annee++) {
      const moisEcoules = annee * 12;
      let capitalAnnee = montantInitial;
      
      for (let i = 0; i < moisEcoules && i < nbMois; i++) {
        capitalAnnee = capitalAnnee * (1 + tauxMensuel) + versementMensuel;
      }
      
      const versementsAnnee = montantInitial + (versementMensuel * moisEcoules);
      const interetsAnnee = capitalAnnee - versementsAnnee;
      
      projectionYearly.push({
        annee: annee,
        capital: Math.round(capitalAnnee),
        versements: Math.round(versementsAnnee),
        interets: Math.round(interetsAnnee)
      });
    }
    
    setProjectionData(projectionYearly);
    
    // Calcul final
    for (let i = 0; i < nbMois; i++) {
      capital = capital * (1 + tauxMensuel) + versementMensuel;
    }
    
    const versementsTotal = montantInitial + (versementMensuel * nbMois);
    const interetsGeneres = capital - versementsTotal;
    
    // Calcul fiscal
    const optionFiscale = fiscaliteOptions.find(opt => opt.value === fiscalite);
    const impot = interetsGeneres * (optionFiscale?.taux || 0) / 100;
    const capitalFinal = capital - impot;
    const gainFiscal = interetsGeneres - impot;
    
    setSimulation({
      capitalFinal: Math.round(capitalFinal),
      interetsGeneres: Math.round(interetsGeneres),
      versementsTotal: Math.round(versementsTotal),
      gainFiscal: Math.round(gainFiscal)
    });
  };

  useEffect(() => {
    calculateSimulation();
  }, [formData]);

  const handleInputChange = (field: string, value: number | string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const scenarios = [
    { label: 'Conservateur', taux: 2.5, description: 'Fonds euros, livrets' },
    { label: 'Modéré', taux: 4.5, description: 'Allocation équilibrée' },
    { label: 'Dynamique', taux: 6.5, description: 'Actions majoritaires' },
    { label: 'Agressif', taux: 8.0, description: 'Actions internationales' }
  ];

  // Données pour le graphique en secteurs
  const pieData = [
    { name: 'Versements', value: simulation.versementsTotal, color: '#3B82F6' },
    { name: 'Plus-values', value: simulation.interetsGeneres, color: '#10B981' }
  ];

  // Données de comparaison des enveloppes
  const enveloppeComparison = fiscaliteOptions.map(option => {
    const impot = simulation.interetsGeneres * (option.taux / 100);
    const gainNet = simulation.interetsGeneres - impot;
    return {
      enveloppe: option.label,
      gainBrut: simulation.interetsGeneres,
      impot: impot,
      gainNet: gainNet,
      capitalFinal: simulation.versementsTotal + gainNet
    };
  });

  const renderTabContent = () => {
    switch (activeTab) {
      case 'simulator':
        return (
          <div className="space-y-8">
            {/* Simulateur principal */}
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Paramètres de simulation */}
              <div className="bg-gray-900 rounded-xl p-6 border border-green-500/20">
                <h3 className="text-xl font-bold text-white mb-6 flex items-center">
                  <i className="ri-money-dollar-circle-line text-green-400 mr-3"></i>
                  Simulateur d'Épargne
                </h3>
                
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Montant initial (€)
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="100000"
                      step="1000"
                      value={formData.montantInitial}
                      onChange={(e) => handleInputChange('montantInitial', Number(e.target.value))}
                      className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                    />
                    <div className="flex justify-between text-sm text-gray-400 mt-1">
                      <span>0€</span>
                      <span className="text-green-400 font-semibold">{formData.montantInitial.toLocaleString()}€</span>
                      <span>100k€</span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Versement mensuel (€)
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="2000"
                      step="50"
                      value={formData.versementMensuel}
                      onChange={(e) => handleInputChange('versementMensuel', Number(e.target.value))}
                      className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                    />
                    <div className="flex justify-between text-sm text-gray-400 mt-1">
                      <span>0€</span>
                      <span className="text-green-400 font-semibold">{formData.versementMensuel.toLocaleString()}€</span>
                      <span>2 000€</span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Durée (années)
                    </label>
                    <input
                      type="range"
                      min="1"
                      max="30"
                      step="1"
                      value={formData.duree}
                      onChange={(e) => handleInputChange('duree', Number(e.target.value))}
                      className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                    />
                    <div className="flex justify-between text-sm text-gray-400 mt-1">
                      <span>1 an</span>
                      <span className="text-green-400 font-semibold">{formData.duree} ans</span>
                      <span>30 ans</span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Rendement annuel (%)
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="12"
                      step="0.1"
                      value={formData.tauxRendement}
                      onChange={(e) => handleInputChange('tauxRendement', Number(e.target.value))}
                      className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                    />
                    <div className="flex justify-between text-sm text-gray-400 mt-1">
                      <span>0%</span>
                      <span className="text-green-400 font-semibold">{formData.tauxRendement}%</span>
                      <span>12%</span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Enveloppe fiscale
                    </label>
                    <select
                      value={formData.fiscalite}
                      onChange={(e) => handleInputChange('fiscalite', e.target.value)}
                      className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-white"
                    >
                      {fiscaliteOptions.map(option => (
                        <option key={option.value} value={option.value}>
                          {option.label} ({option.taux}% de prélèvement)
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Résultats */}
              <div className="bg-gray-900 rounded-xl p-6 border border-green-500/20">
                <h3 className="text-xl font-bold text-white mb-6 flex items-center">
                  <i className="ri-line-chart-line text-green-400 mr-3"></i>
                  Résultats de Simulation
                </h3>
                
                <div className="space-y-4">
                  <div className="bg-black/30 rounded-lg p-4">
                    <div className="text-sm text-gray-400 mb-1">Capital final</div>
                    <div className="text-2xl font-bold text-green-400">
                      {simulation.capitalFinal.toLocaleString()}€
                    </div>
                  </div>

                  <div className="bg-black/30 rounded-lg p-4">
                    <div className="text-sm text-gray-400 mb-1">Versements total</div>
                    <div className="text-xl font-semibold text-white">
                      {simulation.versementsTotal.toLocaleString()}€
                    </div>
                  </div>

                  <div className="bg-black/30 rounded-lg p-4">
                    <div className="text-sm text-gray-400 mb-1">Plus-values brutes</div>
                    <div className="text-xl font-semibold text-blue-400">
                      +{simulation.interetsGeneres.toLocaleString()}€
                    </div>
                  </div>

                  <div className="bg-black/30 rounded-lg p-4">
                    <div className="text-sm text-gray-400 mb-1">Gain net fiscal</div>
                    <div className="text-xl font-semibold text-emerald-400">
                      {simulation.gainFiscal.toLocaleString()}€
                    </div>
                  </div>

                  <div className="bg-black/30 rounded-lg p-4">
                    <div className="text-sm text-gray-400 mb-1">Rendement total</div>
                    <div className="text-lg font-semibold text-yellow-400">
                      {simulation.versementsTotal > 0 ? ((simulation.gainFiscal / simulation.versementsTotal) * 100).toFixed(1) : 0}%
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      Sur {formData.duree} années
                    </div>
                  </div>
                </div>

                <button className="w-full mt-6 bg-green-500 text-white py-3 rounded-lg font-semibold hover:bg-green-400 transition-colors cursor-pointer whitespace-nowrap">
                  Optimiser mon Épargne
                </button>
              </div>
            </div>

            {/* Scénarios prédéfinis */}
            <div className="bg-gray-900 rounded-xl p-6 border border-green-500/20">
              <h3 className="text-xl font-bold text-white mb-6 flex items-center">
                <i className="ri-settings-line text-green-400 mr-3"></i>
                Scénarios de Rendement
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {scenarios.map((scenario, index) => (
                  <button
                    key={index}
                    onClick={() => handleInputChange('tauxRendement', scenario.taux)}
                    className={`p-4 text-center rounded-lg border transition-all cursor-pointer ${
                      formData.tauxRendement === scenario.taux
                        ? 'bg-green-500/20 border-green-400 text-green-400'
                        : 'bg-black/30 border-gray-700 text-gray-300 hover:bg-black/50'
                    }`}
                  >
                    <div className="font-semibold text-lg">{scenario.label}</div>
                    <div className="text-sm opacity-75 mb-2">{scenario.taux}%</div>
                    <div className="text-xs">{scenario.description}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Évolution du capital dans le temps */}
            <div className="bg-gray-900 rounded-xl p-6 border border-green-500/20">
              <h3 className="text-xl font-bold text-white mb-6 flex items-center">
                <i className="ri-line-chart-line text-green-400 mr-3"></i>
                Évolution du Capital
              </h3>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={projectionData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis 
                      dataKey="annee" 
                      stroke="#9CA3AF"
                      fontSize={12}
                      tickFormatter={(value) => `${value} ans`}
                    />
                    <YAxis 
                      stroke="#9CA3AF"
                      fontSize={12}
                      tickFormatter={(value) => `${(value / 1000).toFixed(0)}k€`}
                    />
                    <Tooltip 
                      contentStyle={{
                        backgroundColor: '#1F2937',
                        border: '1px solid #10B981',
                        borderRadius: '8px',
                        color: '#FFFFFF'
                      }}
                      formatter={(value, name) => [
                        `${Math.round(value).toLocaleString()}€`, 
                        name === 'capital' ? 'Capital Total' : name === 'versements' ? 'Versements' : 'Plus-values'
                      ]}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="versements" 
                      stackId="1"
                      stroke="#3B82F6" 
                      fill="#3B82F6"
                      fillOpacity={0.6}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="interets" 
                      stackId="1"
                      stroke="#10B981" 
                      fill="#10B981"
                      fillOpacity={0.8}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Répartition Capital/Plus-values et Comparaison enveloppes */}
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Répartition */}
              <div className="bg-gray-900 rounded-xl p-6 border border-green-500/20">
                <h3 className="text-xl font-bold text-white mb-6">Répartition Capital Final</h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip 
                        contentStyle={{
                          backgroundColor: '#1F2937',
                          border: '1px solid #10B981',
                          borderRadius: '8px',
                          color: '#FFFFFF'
                        }}
                        formatter={(value) => `${Math.round(value).toLocaleString()}€`}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex justify-center space-x-6 mt-4">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
                    <span className="text-sm text-gray-300">Versements ({((simulation.versementsTotal/(simulation.versementsTotal + simulation.interetsGeneres))*100).toFixed(0)}%)</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                    <span className="text-sm text-gray-300">Plus-values ({((simulation.interetsGeneres/(simulation.versementsTotal + simulation.interetsGeneres))*100).toFixed(0)}%)</span>
                  </div>
                </div>
              </div>

              {/* Comparaison des enveloppes fiscales */}
              <div className="bg-gray-900 rounded-xl p-6 border border-green-500/20">
                <h3 className="text-xl font-bold text-white mb-6">Comparaison Enveloppes Fiscales</h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={enveloppeComparison}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis 
                        dataKey="enveloppe" 
                        stroke="#9CA3AF"
                        fontSize={10}
                        angle={-45}
                        textAnchor="end"
                        height={60}
                      />
                      <YAxis 
                        stroke="#9CA3AF"
                        fontSize={12}
                        tickFormatter={(value) => `${(value / 1000).toFixed(0)}k€`}
                      />
                      <Tooltip 
                        contentStyle={{
                          backgroundColor: '#1F2937',
                          border: '1px solid #10B981',
                          borderRadius: '8px',
                          color: '#FFFFFF'
                        }}
                        formatter={(value, name) => [
                          `${Math.round(value).toLocaleString()}€`, 
                          name === 'gainNet' ? 'Gain Net' : name === 'impot' ? 'Impôts' : 'Capital Final'
                        ]}
                      />
                      <Bar dataKey="gainNet" fill="#10B981" />
                      <Bar dataKey="impot" fill="#EF4444" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            {/* Conseils personnalisés */}
            <div className="bg-gray-900 rounded-xl p-6 border border-green-500/20">
              <h3 className="text-xl font-bold text-white mb-6 flex items-center">
                <i className="ri-lightbulb-line text-green-400 mr-3"></i>
                Conseils Personnalisés
              </h3>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="bg-black/30 rounded-lg p-4">
                  <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center mb-4">
                    <i className="ri-shield-check-line text-blue-400 text-xl"></i>
                  </div>
                  <h4 className="font-semibold text-white mb-2">Optimisation Fiscale</h4>
                  <p className="text-sm text-gray-300">
                    {formData.fiscalite === 'PEA' 
                      ? 'Excellent choix ! Le PEA offre une exonération totale après 5 ans.'
                      : `Envisagez le PEA pour économiser ${Math.round(simulation.interetsGeneres * (fiscaliteOptions.find(f => f.value === formData.fiscalite)?.taux || 0) / 100).toLocaleString()}€ d'impôts.`
                    }
                  </p>
                </div>

                <div className="bg-black/30 rounded-lg p-4">
                  <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center mb-4">
                    <i className="ri-time-line text-green-400 text-xl"></i>
                  </div>
                  <h4 className="font-semibold text-white mb-2">Horizon de Placement</h4>
                  <p className="text-sm text-gray-300">
                    {formData.duree < 5 
                      ? 'Pour un placement court terme, privilégiez la sécurité avec des fonds euros.'
                      : formData.duree < 10
                      ? 'Votre horizon permet un placement équilibré actions/obligations.'
                      : 'Excellent horizon long terme ! Vous pouvez optimiser avec plus d\'actions.'
                    }
                  </p>
                </div>

                <div className="bg-black/30 rounded-lg p-4">
                  <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center mb-4">
                    <i className="ri-trending-up-line text-yellow-400 text-xl"></i>
                  </div>
                  <h4 className="font-semibold text-white mb-2">Stratégie de Versement</h4>
                  <p className="text-sm text-gray-300">
                    {formData.versementMensuel < 200 
                      ? 'Augmentez progressivement vos versements selon vos possibilités.'
                      : formData.versementMensuel > 1000
                      ? 'Excellente capacité d\'épargne ! Diversifiez sur plusieurs enveloppes.'
                      : 'Bon rythme d\'épargne. Maintenez la régularité pour maximiser les gains.'
                    }
                  </p>
                </div>
              </div>
            </div>
          </div>
        );
      case 'liquidity':
        return <LiquidityStressTest />;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Onglets de navigation */}
      <div className="bg-gray-900 rounded-xl p-6 border border-green-500/20">
        <div className="flex space-x-1 bg-gray-800 p-1 rounded-lg">
          <button
            onClick={() => setActiveTab('simulator')}
            className={`flex-1 px-4 py-2 rounded-md text-sm font-medium transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'simulator'
                ? 'bg-green-500 text-white'
                : 'text-gray-300 hover:text-white hover:bg-gray-700'
            }`}
          >
            <i className="ri-bank-line mr-2"></i>
            Simulation Épargne
          </button>
          <button
            onClick={() => setActiveTab('liquidity')}
            className={`flex-1 px-4 py-2 rounded-md text-sm font-medium transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'liquidity'
                ? 'bg-green-500 text-white'
                : 'text-gray-300 hover:text-white hover:bg-gray-700'
            }`}
          >
            <i className="ri-drop-line mr-2"></i>
            Test de Liquidité
          </button>
        </div>
      </div>

      {/* Contenu des onglets */}
      {renderTabContent()}
    </div>
  );
}
