
'use client';

import { useState, useEffect } from 'react';

export default function InternationalTransmission() {
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedAsset, setSelectedAsset] = useState('');
  const [selectedCountry, setSelectedCountry] = useState('');
  const [beneficiaryType, setBeneficiaryType] = useState('');
  const [assetValue, setAssetValue] = useState('');
  const [exchangeRate, setExchangeRate] = useState(1.0);
  const [taxAdjustment, setTaxAdjustment] = useState(1.0);
  const [showComparison, setShowComparison] = useState(false);
  const [simulationResults, setSimulationResults] = useState(null);
  const [alternativeScenarios, setAlternativeScenarios] = useState([]);
  const [userProfile, setUserProfile] = useState({
    fiscalResidence: 'France',
    hasExistingTransmissions: false,
    preferredLanguage: 'fr'
  });
  const [smartTips, setSmartTips] = useState([]);
  const [isCalculating, setIsCalculating] = useState(false);

  const assetTypes = [
    { 
      id: 'immobilier', 
      name: 'Immobilier', 
      icon: 'ri-home-4-fill',
      description: 'Résidences, bureaux, terrains',
      color: 'from-blue-500 to-blue-600',
      legalRef: 'Art. 750 ter CGI'
    },
    { 
      id: 'actions', 
      name: 'Actions & Titres', 
      icon: 'ri-line-chart-fill',
      description: 'Portefeuilles, participations',
      color: 'from-green-500 to-green-600',
      legalRef: 'Art. 150-0 A CGI'
    },
    { 
      id: 'entreprise', 
      name: 'Entreprise', 
      icon: 'ri-building-fill',
      description: 'Parts sociales, fonds de commerce',
      color: 'from-purple-500 to-purple-600',
      legalRef: 'Art. 787 B CGI'
    },
    { 
      id: 'liquidites', 
      name: 'Liquidités', 
      icon: 'ri-money-euro-circle-fill',
      description: 'Comptes, assurance-vie',
      color: 'from-yellow-500 to-yellow-600',
      legalRef: 'Art. 757 B CGI'
    }
  ];

  const countries = [
    { 
      code: 'CH', 
      name: 'Suisse', 
      flag: '🇨🇭',
      taxRate: 0.12,
      donationRate: 0.08,
      convention: true,
      conventionDate: '1966-09-09',
      delays: '2-4 mois',
      specialRegime: 'Impatriate',
      complexity: 'Faible',
      docs: ['Attestation fiscale', 'Justificatif résidence']
    },
    { 
      code: 'LU', 
      name: 'Luxembourg', 
      flag: '🇱🇺',
      taxRate: 0.18,
      donationRate: 0.12,
      convention: true,
      conventionDate: '1958-04-01',
      delays: '3-6 mois',
      specialRegime: 'Société de gestion',
      complexity: 'Modérée',
      docs: ['Certificat résidence', 'Déclaration patrimoine']
    },
    { 
      code: 'BE', 
      name: 'Belgique', 
      flag: '🇧🇪',
      taxRate: 0.25,
      donationRate: 0.20,
      convention: true,
      conventionDate: '1959-03-10',
      delays: '4-8 mois',
      specialRegime: 'Régime des expats',
      complexity: 'Élevée',
      docs: ['Acte notarié', 'Extrait registre']
    },
    { 
      code: 'DE', 
      name: 'Allemagne', 
      flag: '🇩🇪',
      taxRate: 0.30,
      donationRate: 0.25,
      convention: true,
      conventionDate: '1959-07-21',
      delays: '6-12 mois',
      specialRegime: 'Pacte familial',
      complexity: 'Élevée',
      docs: ['Erbschein', 'Steuerliche Unbedenklichkeit']
    },
    { 
      code: 'UK', 
      name: 'Royaume-Uni', 
      flag: '🇬🇧',
      taxRate: 0.40,
      donationRate: 0.35,
      convention: true,
      conventionDate: '1963-05-22',
      delays: '8-15 mois',
      specialRegime: 'Trust',
      complexity: 'Très élevée',
      docs: ['Grant of Probate', 'IHT400 Form']
    },
    { 
      code: 'US', 
      name: 'États-Unis', 
      flag: '🇺🇸',
      taxRate: 0.45,
      donationRate: 0.40,
      convention: true,
      conventionDate: '1995-11-24',
      delays: '12-24 mois',
      specialRegime: 'Estate Planning',
      complexity: 'Très élevée',
      docs: ['Form 706', 'Estate Tax Return']
    }
  ];

  const beneficiaryTypes = [
    {
      id: 'enfant',
      name: 'Enfant/Descendant',
      icon: 'ri-parent-fill',
      abatement: 100000,
      color: 'from-green-400 to-green-500',
      legalRef: 'Art. 779 CGI'
    },
    {
      id: 'conjoint',
      name: 'Époux/Épouse',
      icon: 'ri-heart-fill',
      abatement: 80724,
      color: 'from-pink-400 to-pink-500',
      legalRef: 'Art. 796-0 bis CGI'
    },
    {
      id: 'autre',
      name: 'Autre famille',
      icon: 'ri-group-fill',
      abatement: 15932,
      color: 'from-blue-400 to-blue-500',
      legalRef: 'Art. 779 II CGI'
    },
    {
      id: 'tiers',
      name: 'Tiers',
      icon: 'ri-user-fill',
      abatement: 1594,
      color: 'from-gray-400 to-gray-500',
      legalRef: 'Art. 777 CGI'
    }
  ];

  const generateSmartTips = () => {
    const tips = [];
    
    if (selectedCountry && selectedAsset) {
      const country = countries.find(c => c.code === selectedCountry);
      const asset = assetTypes.find(a => a.id === selectedAsset);
      
      // Tips RGPD/KYC
      if (country.complexity === 'Très élevée') {
        tips.push({
          type: 'warning',
          icon: 'ri-shield-keyhole-line',
          title: 'KYC Renforcé Requis',
          content: `Pour ${country.name}, justificatifs d'origine des fonds obligatoires`,
          priority: 'high'
        });
      }
      
      // Tips documentaires
      tips.push({
        type: 'info',
        icon: 'ri-file-list-3-line',
        title: 'Documents Requis',
        content: `${country.docs.join(', ')}`,
        priority: 'medium'
      });
      
      // Tips délais
      if (parseInt(country.delays.split('-')[1]) > 6) {
        tips.push({
          type: 'alert',
          icon: 'ri-time-line',
          title: 'Délais Importants',
          content: `Prévoir ${country.delays} pour finaliser la transmission`,
          priority: 'high'
        });
      }
      
      // Tips optimisation
      if (assetValue && parseFloat(assetValue) > 500000) {
        tips.push({
          type: 'success',
          icon: 'ri-lightbulb-line',
          title: 'Optimisation Fiscale',
          content: `Démembrement de propriété possible pour ${asset.name}`,
          priority: 'medium'
        });
      }
    }
    
    setSmartTips(tips);
  };

  const calculateTransmission = () => {
    if (!selectedAsset || !selectedCountry || !beneficiaryType || !assetValue) return null;

    setIsCalculating(true);
    
    setTimeout(() => {
      const country = countries.find(c => c.code === selectedCountry);
      const beneficiary = beneficiaryTypes.find(b => b.id === beneficiaryType);
      const value = parseFloat(assetValue) * exchangeRate;

      // Calcul succession
      const successionNetValue = Math.max(0, value - beneficiary.abatement);
      const successionTax = successionNetValue * (country.taxRate * taxAdjustment);
      const successionNetReceived = value - successionTax;

      // Calcul donation
      const donationNetValue = Math.max(0, value - beneficiary.abatement);
      const donationTax = donationNetValue * (country.donationRate * taxAdjustment);
      const donationNetReceived = value - donationTax;

      // Scénarios alternatifs
      const alternatives = [
        {
          name: 'Démembrement',
          netReceived: value - (successionTax * 0.7),
          tax: successionTax * 0.7,
          description: 'Usufruit conservé'
        },
        {
          name: 'Donation graduelle',
          netReceived: value - (donationTax * 0.8),
          tax: donationTax * 0.8,
          description: 'Étalée sur 15 ans'
        },
        {
          name: 'Trust/SCI',
          netReceived: value - (successionTax * 0.6),
          tax: successionTax * 0.6,
          description: 'Structure optimisée'
        }
      ];

      const results = {
        succession: {
          tax: successionTax,
          netReceived: successionNetReceived,
          effectiveRate: (successionTax / value) * 100
        },
        donation: {
          tax: donationTax,
          netReceived: donationNetReceived,
          effectiveRate: (donationTax / value) * 100
        },
        savings: donationNetReceived - successionNetReceived,
        country: country,
        beneficiary: beneficiary,
        value: value,
        timeline: generateTimeline(country)
      };

      setSimulationResults(results);
      setAlternativeScenarios(alternatives);
      setShowComparison(true);
      setIsCalculating(false);
    }, 800);
  };

  const generateTimeline = (country) => {
    const baseSteps = [
      { step: 'Déclaration', duration: '1-2 semaines', status: 'pending' },
      { step: 'Évaluation', duration: '1-3 mois', status: 'pending' },
      { step: 'Taxation', duration: '2-4 semaines', status: 'pending' },
      { step: 'Versement', duration: '1-2 semaines', status: 'pending' }
    ];
    
    return baseSteps.map((step, index) => ({
      ...step,
      id: index + 1,
      icon: ['ri-file-text-line', 'ri-calculator-line', 'ri-money-euro-circle-line', 'ri-check-line'][index]
    }));
  };

  useEffect(() => {
    if (selectedAsset || selectedCountry || beneficiaryType) {
      generateSmartTips();
    }
  }, [selectedAsset, selectedCountry, beneficiaryType, assetValue]);

  useEffect(() => {
    if (currentStep === 4 && selectedAsset && selectedCountry && beneficiaryType && assetValue) {
      calculateTransmission();
    }
  }, [currentStep, selectedAsset, selectedCountry, beneficiaryType, assetValue, exchangeRate, taxAdjustment]);

  const nextStep = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const resetWizard = () => {
    setCurrentStep(1);
    setSelectedAsset('');
    setSelectedCountry('');
    setBeneficiaryType('');
    setAssetValue('');
    setExchangeRate(1.0);
    setTaxAdjustment(1.0);
    setShowComparison(false);
    setSimulationResults(null);
    setAlternativeScenarios([]);
    setSmartTips([]);
  };

  const selectedCountryData = countries.find(c => c.code === selectedCountry);
  const progressPercentage = ((currentStep - 1) / 3) * 100;

  return (
    <div className="space-y-8">
      <div className="bg-gray-900 border border-red-500/20 rounded-xl p-6">
        <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
          <i className="ri-global-line text-red-400 mr-3"></i>
          Transmission Internationale
        </h2>

        {/* Barre de progression améliorée */}
        <div className="mb-8">
          <div className="flex items-center justify-between relative mb-6">
            <div className="absolute top-1/2 left-0 right-0 h-1 bg-gray-700 rounded-full -translate-y-1/2"></div>
            <div 
              className="absolute top-1/2 left-0 h-1 bg-gradient-to-r from-red-500 via-red-400 to-red-300 rounded-full -translate-y-1/2 transition-all duration-700 ease-out"
              style={{ width: `${progressPercentage}%` }}
            ></div>
            
            {[
              { num: 1, label: 'Type d\'actif', icon: 'ri-home-line', completed: selectedAsset !== '' },
              { num: 2, label: 'Pays destination', icon: 'ri-map-pin-line', completed: selectedCountry !== '' },
              { num: 3, label: 'Bénéficiaire', icon: 'ri-user-line', completed: beneficiaryType !== '' && assetValue !== '' },
              { num: 4, label: 'Résultats', icon: 'ri-bar-chart-line', completed: simulationResults !== null }
            ].map((step, index) => (
              <div
                key={step.num}
                className={`relative z-10 w-14 h-14 rounded-full border-3 flex items-center justify-center transition-all duration-500 transform ${
                  currentStep >= step.num
                    ? 'bg-red-500 border-red-500 text-white scale-110 shadow-lg shadow-red-500/25'
                    : step.completed
                    ? 'bg-green-500 border-green-500 text-white'
                    : 'bg-gray-800 border-gray-600 text-gray-400 hover:border-gray-500'
                } ${currentStep === step.num ? 'animate-pulse' : ''}`}
              >
                {step.completed && currentStep > step.num ? (
                  <i className="ri-check-line text-xl"></i>
                ) : (
                  <i className={`${step.icon} text-xl`}></i>
                )}
              </div>
            ))}
          </div>
          
          <div className="flex justify-between">
            {[
              { num: 1, label: 'Type d\'actif' },
              { num: 2, label: 'Pays destination' },
              { num: 3, label: 'Bénéficiaire' },
              { num: 4, label: 'Résultats' }
            ].map((step) => (
              <div
                key={step.num}
                className={`text-center text-sm transition-all duration-300 ${
                  currentStep >= step.num 
                    ? 'text-red-400 font-semibold transform scale-105' 
                    : 'text-gray-500'
                }`}
              >
                {step.label}
              </div>
            ))}
          </div>

          {/* Feedback instantané */}
          {currentStep > 1 && (
            <div className="mt-4 bg-gray-800/50 rounded-lg p-3 backdrop-blur-sm">
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center space-x-4">
                  {selectedAsset && (
                    <span className="flex items-center text-green-400">
                      <i className="ri-check-line mr-1"></i>
                      {assetTypes.find(a => a.id === selectedAsset)?.name}
                    </span>
                  )}
                  {selectedCountry && (
                    <span className="flex items-center text-blue-400">
                      <i className="ri-map-pin-line mr-1"></i>
                      {countries.find(c => c.code === selectedCountry)?.name}
                    </span>
                  )}
                  {beneficiaryType && (
                    <span className="flex items-center text-purple-400">
                      <i className="ri-user-line mr-1"></i>
                      {beneficiaryTypes.find(b => b.id === beneficiaryType)?.name}
                    </span>
                  )}
                </div>
                {assetValue && parseFloat(assetValue) > 0 && (
                  <span className="text-yellow-400 font-semibold">
                    {parseFloat(assetValue).toLocaleString('fr-FR')} €
                  </span>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Smart Tips Panel */}
        {smartTips.length > 0 && (
          <div className="mb-6 space-y-2">
            {smartTips.map((tip, index) => (
              <div
                key={index}
                className={`p-3 rounded-lg border-l-4 animate-slide-in-right ${
                  tip.priority === 'high'
                    ? 'bg-red-900/20 border-red-500 text-red-200'
                    : tip.priority === 'medium'
                    ? 'bg-yellow-900/20 border-yellow-500 text-yellow-200'
                    : 'bg-blue-900/20 border-blue-500 text-blue-200'
                }`}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex items-center space-x-3">
                  <i className={`${tip.icon} text-lg`}></i>
                  <div>
                    <div className="font-semibold text-sm">{tip.title}</div>
                    <div className="text-xs opacity-90">{tip.content}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Étape 1: Type d'actif avec pré-remplissage */}
        {currentStep === 1 && (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-xl font-bold text-white mb-2">Quel type d'actif souhaitez-vous transmettre ?</h3>
              <p className="text-gray-400">Sélectionnez le type d'actif principal de votre transmission</p>
              {userProfile.hasExistingTransmissions && (
                <div className="mt-2 text-sm text-blue-400 bg-blue-900/20 p-2 rounded">
                  <i className="ri-information-line mr-1"></i>
                  Suggestion basée sur votre profil : Actions & Titres
                </div>
              )}
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              {assetTypes.map((asset) => (
                <div
                  key={asset.id}
                  onClick={() => {
                    setSelectedAsset(asset.id);
                    setTimeout(nextStep, 500);
                  }}
                  className={`p-6 rounded-xl border-2 cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-lg ${
                    selectedAsset === asset.id
                      ? 'border-red-500 bg-red-500/10 transform scale-105 shadow-lg'
                      : 'border-gray-700 bg-gray-800 hover:border-gray-600'
                  }`}
                >
                  <div className={`w-16 h-16 rounded-xl bg-gradient-to-r ${asset.color} flex items-center justify-center mb-4 mx-auto transition-transform duration-300 hover:rotate-6`}>
                    <i className={`${asset.icon} text-2xl text-white`}></i>
                  </div>
                  <h4 className="text-lg font-semibold text-white text-center mb-2">{asset.name}</h4>
                  <p className="text-gray-400 text-sm text-center mb-2">{asset.description}</p>
                  <div className="text-xs text-center text-blue-400 bg-blue-900/20 px-2 py-1 rounded">
                    {asset.legalRef}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Étape 2: Pays avec carte interactive */}
        {currentStep === 2 && (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-xl font-bold text-white mb-2">Vers quel pays souhaitez-vous transmettre ?</h3>
              <p className="text-gray-400">Choisissez le pays de résidence du bénéficiaire</p>
            </div>

            {/* Carte interactive simplifiée */}
            <div className="bg-gray-800 rounded-xl p-6 mb-6">
              <h4 className="text-lg font-bold text-white mb-4 flex items-center">
                <i className="ri-map-line text-blue-400 mr-2"></i>
                Conventions Fiscales Bilatérales
              </h4>
              <div className="grid grid-cols-3 lg:grid-cols-6 gap-2">
                {countries.map((country) => (
                  <div
                    key={country.code}
                    onClick={() => setSelectedCountry(country.code)}
                    className={`p-2 text-center rounded-lg cursor-pointer transition-all duration-300 hover:scale-110 ${
                      selectedCountry === country.code
                        ? 'bg-red-500/20 border border-red-500'
                        : 'bg-gray-700 hover:bg-gray-600'
                    }`}
                  >
                    <div className="text-2xl mb-1">{country.flag}</div>
                    <div className="text-xs text-white">{country.code}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {countries.map((country) => (
                <div
                  key={country.code}
                  onClick={() => {
                    setSelectedCountry(country.code);
                    setTimeout(nextStep, 500);
                  }}
                  className={`p-4 rounded-xl border-2 cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-lg ${
                    selectedCountry === country.code
                      ? 'border-red-500 bg-red-500/10 transform scale-105 shadow-lg'
                      : 'border-gray-700 bg-gray-800 hover:border-gray-600'
                  }`}
                >
                  <div className="flex items-center space-x-3 mb-3">
                    <span className="text-3xl">{country.flag}</span>
                    <div>
                      <h4 className="font-semibold text-white">{country.name}</h4>
                      <div className="flex items-center space-x-2 text-xs">
                        <span className="text-green-400">✓ Convention {country.conventionDate.split('-')[0]}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Succession:</span>
                      <span className="text-red-400 font-semibold">{(country.taxRate * 100).toFixed(0)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Donation:</span>
                      <span className="text-green-400 font-semibold">{(country.donationRate * 100).toFixed(0)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Délais:</span>
                      <span className="text-blue-400">{country.delays}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Complexité:</span>
                      <span className={`font-semibold ${
                        country.complexity === 'Faible' ? 'text-green-400' :
                        country.complexity === 'Modérée' ? 'text-yellow-400' : 'text-red-400'
                      }`}>
                        {country.complexity}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Étape 3: Bénéficiaire avec calculs temps réel */}
        {currentStep === 3 && (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-xl font-bold text-white mb-2">Qui est le bénéficiaire ?</h3>
              <p className="text-gray-400">Le lien de parenté détermine les abattements fiscaux</p>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              {beneficiaryTypes.map((beneficiary) => (
                <div
                  key={beneficiary.id}
                  onClick={() => {
                    setBeneficiaryType(beneficiary.id);
                  }}
                  className={`p-6 rounded-xl border-2 cursor-pointer transition-all duration-300 hover:scale-105 ${
                    beneficiaryType === beneficiary.id
                      ? 'border-red-500 bg-red-500/10 transform scale-105'
                      : 'border-gray-700 bg-gray-800 hover:border-gray-600'
                  }`}
                >
                  <div className={`w-16 h-16 rounded-xl bg-gradient-to-r ${beneficiary.color} flex items-center justify-center mb-4 mx-auto`}>
                    <i className={`${beneficiary.icon} text-2xl text-white`}></i>
                  </div>
                  <h4 className="text-lg font-semibold text-white text-center mb-2">{beneficiary.name}</h4>
                  <div className="text-center space-y-1">
                    <span className="text-green-400 font-semibold block">
                      Abattement: {beneficiary.abatement.toLocaleString('fr-FR')} €
                    </span>
                    <div className="text-xs text-blue-400 bg-blue-900/20 px-2 py-1 rounded">
                      {beneficiary.legalRef}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {beneficiaryType && (
              <div className="mt-6 space-y-4">
                <div>
                  <label className="block text-gray-300 font-medium mb-3">Valeur de l'actif (€)</label>
                  <input
                    type="number"
                    value={assetValue}
                    onChange={(e) => setAssetValue(e.target.value)}
                    placeholder="Montant en euros"
                    className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white text-lg text-center focus:border-red-400 focus:outline-none transition-colors"
                  />
                </div>

                {/* Curseurs what-if */}
                {assetValue && parseFloat(assetValue) > 0 && (
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="bg-gray-800 p-4 rounded-lg">
                      <label className="block text-gray-300 font-medium mb-2">
                        Taux de change: {exchangeRate.toFixed(2)}
                      </label>
                      <input
                        type="range"
                        min="0.8"
                        max="1.2"
                        step="0.01"
                        value={exchangeRate}
                        onChange={(e) => setExchangeRate(parseFloat(e.target.value))}
                        className="w-full accent-red-500"
                      />
                    </div>
                    <div className="bg-gray-800 p-4 rounded-lg">
                      <label className="block text-gray-300 font-medium mb-2">
                        Ajustement fiscal: {(taxAdjustment * 100).toFixed(0)}%
                      </label>
                      <input
                        type="range"
                        min="0.5"
                        max="1.5"
                        step="0.1"
                        value={taxAdjustment}
                        onChange={(e) => setTaxAdjustment(parseFloat(e.target.value))}
                        className="w-full accent-red-500"
                      />
                    </div>
                  </div>
                )}

                {/* Aperçu temps réel */}
                {assetValue && parseFloat(assetValue) > 0 && beneficiaryType && selectedCountry && (
                  <div className="bg-gray-800 p-4 rounded-lg">
                    <h5 className="font-semibold text-white mb-2 flex items-center">
                      <i className="ri-calculator-line text-blue-400 mr-2"></i>
                      Aperçu Temps Réel
                    </h5>
                    <div className="grid md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <div className="text-red-400 font-semibold">Succession</div>
                        <div className="text-white">
                          Net reçu: {(parseFloat(assetValue) * exchangeRate * (1 - countries.find(c => c.code === selectedCountry)?.taxRate * taxAdjustment)).toLocaleString('fr-FR')} €
                        </div>
                      </div>
                      <div>
                        <div className="text-green-400 font-semibold">Donation</div>
                        <div className="text-white">
                          Net reçu: {(parseFloat(assetValue) * exchangeRate * (1 - countries.find(c => c.code === selectedCountry)?.donationRate * taxAdjustment)).toLocaleString('fr-FR')} €
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {beneficiaryType && assetValue && parseFloat(assetValue) > 0 && (
              <button
                onClick={nextStep}
                className="w-full bg-red-500 hover:bg-red-600 text-white py-3 rounded-lg font-semibold transition-all duration-300 hover:scale-105 cursor-pointer whitespace-nowrap"
              >
                <i className="ri-calculator-line mr-2"></i>
                Calculer la Transmission
              </button>
            )}
          </div>
        )}

        {/* Étape 4: Résultats avec comparaisons et visualisations */}
        {currentStep === 4 && (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-xl font-bold text-white mb-2">Simulation de Transmission</h3>
              <p className="text-gray-400">
                Transmission de {assetValue ? parseFloat(assetValue).toLocaleString('fr-FR') : '0'} € vers {selectedCountryData?.name} {selectedCountryData?.flag}
              </p>
            </div>

            {/* Indicateur de calcul */}
            {isCalculating && (
              <div className="text-center py-8">
                <div className="inline-flex items-center space-x-3">
                  <div className="animate-spin w-8 h-8 border-4 border-red-500 border-t-transparent rounded-full"></div>
                  <span className="text-white">Calcul en cours...</span>
                </div>
              </div>
            )}

            {/* Résultats principaux */}
            {simulationResults && !isCalculating && (
              <>
                {/* Comparaison côte-à-côte */}
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Succession */}
                  <div className="bg-gradient-to-br from-red-900/20 to-red-800/10 border border-red-500/30 rounded-xl p-6 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-24 h-24 bg-red-500/10 rounded-full -translate-y-12 translate-x-12"></div>
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-lg font-bold text-white flex items-center">
                        <i className="ri-skull-line text-red-400 mr-2"></i>
                        Par Succession
                      </h4>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-red-400">
                          -{simulationResults.succession.tax.toLocaleString('fr-FR')} €
                        </div>
                        <div className="text-sm text-red-300">
                          Taux effectif: {simulationResults.succession.effectiveRate.toFixed(1)}%
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Valeur brute:</span>
                        <span className="text-white">{simulationResults.value.toLocaleString('fr-FR')} €</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Abattement:</span>
                        <span className="text-green-400">-{simulationResults.beneficiary.abatement.toLocaleString('fr-FR')} €</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Impôt:</span>
                        <span className="text-red-400">-{simulationResults.succession.tax.toLocaleString('fr-FR')} €</span>
                      </div>
                      <div className="border-t border-red-500/20 pt-3 flex justify-between font-semibold">
                        <span className="text-white">Net reçu:</span>
                        <span className="text-white text-xl">{simulationResults.succession.netReceived.toLocaleString('fr-FR')} €</span>
                      </div>
                    </div>

                    <div className="mt-4 bg-red-500/10 p-3 rounded-lg">
                      <div className="text-xs text-red-300">
                        <i className="ri-time-line mr-1"></i>
                        Délais estimés: {simulationResults.country.delays}
                      </div>
                    </div>
                  </div>

                  {/* Donation */}
                  <div className="bg-gradient-to-br from-green-900/20 to-green-800/10 border border-green-500/30 rounded-xl p-6 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-24 h-24 bg-green-500/10 rounded-full -translate-y-12 translate-x-12"></div>
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-lg font-bold text-white flex items-center">
                        <i className="ri-gift-line text-green-400 mr-2"></i>
                        Par Donation
                      </h4>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-green-400">
                          -{simulationResults.donation.tax.toLocaleString('fr-FR')} €
                        </div>
                        <div className="text-sm text-green-300">
                          Taux effectif: {simulationResults.donation.effectiveRate.toFixed(1)}%
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Valeur brute:</span>
                        <span className="text-white">{simulationResults.value.toLocaleString('fr-FR')} €</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Abattement:</span>
                        <span className="text-green-400">-{simulationResults.beneficiary.abatement.toLocaleString('fr-FR')} €</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Impôt:</span>
                        <span className="text-green-400">-{simulationResults.donation.tax.toLocaleString('fr-FR')} €</span>
                      </div>
                      <div className="border-t border-green-500/20 pt-3 flex justify-between font-semibold">
                        <span className="text-white">Net reçu:</span>
                        <span className="text-white text-xl">{simulationResults.donation.netReceived.toLocaleString('fr-FR')} €</span>
                      </div>
                    </div>

                    <div className="mt-4 bg-green-500/10 p-3 rounded-lg">
                      <div className="text-xs text-green-300">
                        <i className="ri-calendar-check-line mr-1"></i>
                        Délais estimés: Immédiat
                      </div>
                    </div>
                  </div>
                </div>

                {/* Économie réalisée */}
                {simulationResults.savings > 0 && (
                  <div className="bg-gradient-to-r from-blue-900/20 to-purple-900/20 border border-blue-500/30 rounded-xl p-6 text-center relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-500/5 to-purple-500/5"></div>
                    <div className="relative z-10">
                      <h4 className="text-xl font-bold text-white mb-2 flex items-center justify-center">
                        <i className="ri-money-dollar-circle-line text-blue-400 mr-2"></i>
                        Économie avec la Donation
                      </h4>
                      <div className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400 mb-2">
                        +{simulationResults.savings.toLocaleString('fr-FR')} €
                      </div>
                      <p className="text-blue-300 text-sm">
                        Soit {((simulationResults.savings / simulationResults.value) * 100).toFixed(1)}% d'économie sur la valeur transmise
                      </p>
                    </div>
                  </div>
                )}

                {/* Frise animée des étapes */}
                <div className="bg-gray-800 rounded-xl p-6">
                  <h4 className="text-lg font-bold text-white mb-4 flex items-center">
                    <i className="ri-roadmap-line text-purple-400 mr-2"></i>
                    Processus de Transmission
                  </h4>
                  <div className="space-y-4">
                    {simulationResults.timeline.map((step, index) => (
                      <div key={step.id} className="flex items-center space-x-4 group">
                        <div className={`w-12 h-12 rounded-full bg-gradient-to-r from-purple-500 to-blue-500 flex items-center justify-center text-white font-semibold transition-all duration-300 group-hover:scale-110`}>
                          <i className={step.icon}></i>
                        </div>
                        <div className="flex-1">
                          <div className="font-semibold text-white">{step.step}</div>
                          <div className="text-sm text-gray-400">{step.duration}</div>
                        </div>
                        <div className="w-4 h-4 rounded-full bg-gray-600 group-hover:bg-purple-500 transition-colors duration-300"></div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Scénarios alternatifs */}
                {alternativeScenarios.length > 0 && (
                  <div className="bg-gray-800 rounded-xl p-6">
                    <h4 className="text-lg font-bold text-white mb-4 flex items-center">
                      <i className="ri-lightbulb-line text-yellow-400 mr-2"></i>
                      Montages Alternatifs
                    </h4>
                    <div className="grid md:grid-cols-3 gap-4">
                      {alternativeScenarios.map((scenario, index) => (
                        <div key={index} className="bg-gray-700 p-4 rounded-lg hover:bg-gray-600 transition-colors cursor-pointer">
                          <h5 className="font-semibold text-white mb-2">{scenario.name}</h5>
                          <div className="text-sm text-gray-300 mb-2">{scenario.description}</div>
                          <div className="text-lg font-bold text-green-400">
                            {scenario.netReceived.toLocaleString('fr-FR')} €
                          </div>
                          <div className="text-xs text-gray-400">
                            Impôt: {scenario.tax.toLocaleString('fr-FR')} €
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Carte des conventions avec références légales */}
                <div className="bg-gray-800 rounded-xl p-6">
                  <h4 className="text-lg font-bold text-white mb-4 flex items-center">
                    <i className="ri-map-line text-blue-400 mr-2"></i>
                    Convention Fiscale & Références Légales
                  </h4>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <div className="flex items-center space-x-3 mb-4">
                        <span className="text-4xl">🇫🇷</span>
                        <i className="ri-arrow-right-line text-2xl text-blue-400"></i>
                        <span className="text-4xl">{simulationResults.country.flag}</span>
                      </div>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center text-green-400">
                          <i className="ri-check-line mr-2"></i>
                          Convention du {new Date(simulationResults.country.conventionDate).toLocaleDateString('fr-FR')}
                        </div>
                        <div className="flex items-center text-blue-400">
                          <i className="ri-shield-check-line mr-2"></i>
                          Protection contre double imposition
                        </div>
                        <div className="flex items-center text-purple-400">
                          <i className="ri-star-line mr-2"></i>
                          Régime spécial: {simulationResults.country.specialRegime}
                        </div>
                      </div>
                    </div>
                    <div className="bg-gray-900 p-4 rounded-lg">
                      <h5 className="font-semibold text-white mb-2">Références Légales</h5>
                      <ul className="text-sm text-gray-300 space-y-1">
                        <li>• {assetTypes.find(a => a.id === selectedAsset)?.legalRef}</li>
                        <li>• {beneficiaryTypes.find(b => b.id === beneficiaryType)?.legalRef}</li>
                        <li>• Convention bilatérale France-{simulationResults.country.name}</li>
                        <li>• BOI-ENR-DMTG (Doctrine fiscale)</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex space-x-4">
                  <button
                    onClick={resetWizard}
                    className="flex-1 bg-gray-700 hover:bg-gray-600 text-white py-3 rounded-lg font-semibold transition-all duration-300 hover:scale-105 cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-refresh-line mr-2"></i>
                    Nouvelle Simulation
                  </button>
                  <button
                    onClick={() => {
                      const report = {
                        timestamp: new Date().toISOString(),
                        scenario: {
                          asset: assetTypes.find(a => a.id === selectedAsset)?.name,
                          country: simulationResults.country.name,
                          beneficiary: simulationResults.beneficiary.name,
                          value: simulationResults.value
                        },
                        results: simulationResults,
                        alternatives: alternativeScenarios,
                        legalReferences: [
                          assetTypes.find(a => a.id === selectedAsset)?.legalRef,
                          beneficiaryTypes.find(b => b.id === beneficiaryType)?.legalRef,
                          `Convention France-${simulationResults.country.name} du ${simulationResults.country.conventionDate}`
                        ],
                        checklist: simulationResults.country.docs
                      };
                      console.log('Rapport PDF détaillé généré:', report);
                      alert('Rapport PDF avec méthodologie et checklist documentaire généré avec succès !');
                    }}
                    className="flex-1 bg-blue-500 hover:bg-blue-600 text-white py-3 rounded-lg font-semibold transition-all duration-300 hover:scale-105 cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-file-pdf-line mr-2"></i>
                    Générer le Rapport PDF Complet
                  </button>
                </div>
              </>
            )}
          </div>
        )}

        {/* Navigation */}
        {currentStep > 1 && currentStep < 4 && (
          <div className="flex justify-between mt-8">
            <button
              onClick={prevStep}
              className="px-6 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-lg font-semibold transition-all duration-300 hover:scale-105 cursor-pointer whitespace-nowrap"
            >
              <i className="ri-arrow-left-line mr-2"></i>
              Précédent
            </button>
            {currentStep === 3 && (!beneficiaryType || !assetValue || parseFloat(assetValue) <= 0) && (
              <div className="px-6 py-3 bg-gray-800 text-gray-500 rounded-lg font-semibold cursor-not-allowed">
                <i className="ri-arrow-right-line mr-2"></i>
                Suivant
              </div>
            )}
          </div>
        )}
      </div>

      <style jsx>{`
        @keyframes slide-in-right {
          from {
            transform: translateX(20px);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }
        .animate-slide-in-right {
          animation: slide-in-right 0.3s ease-out forwards;
        }
      `}</style>
    </div>
  );
}