
'use client';

import { useState, useRef } from 'react';

interface PDFGeneratorProps {
  portfolioData: any;
  userProfile: any;
}

export default function PDFGenerator({ portfolioData, userProfile }: PDFGeneratorProps) {
  const [showModal, setShowModal] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState('complet');
  const [isGenerating, setIsGenerating] = useState(false);
  const [showSignature, setShowSignature] = useState(false);
  const [signatureData, setSignatureData] = useState('');
  const [showPreview, setShowPreview] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);

  const templates = [
    {
      id: 'complet',
      name: 'Rapport Complet',
      description: 'Analyse patrimoniale complète avec recommandations détaillées',
      icon: 'ri-file-text-line',
      pages: '12-15 pages',
      sections: ['Couverture', 'Résumé Exécutif', 'Profil Investisseur', 'Analyse Portfolio', 'Allocations', 'Recommandations', 'Projections', 'Annexes']
    },
    {
      id: 'synthese',
      name: 'Synthèse Exécutive',
      description: 'Résumé des points clés et recommandations prioritaires',
      icon: 'ri-file-list-line',
      pages: '6-8 pages',
      sections: ['Couverture', 'Résumé', 'Recommandations Clés', 'Plan d\'Action', 'Projections']
    },
    {
      id: 'allocations',
      name: 'Allocations Détaillées',
      description: 'Focus sur la répartition des actifs et optimisations',
      icon: 'ri-pie-chart-line',
      pages: '8-10 pages',
      sections: ['Couverture', 'Allocation Actuelle', 'Allocation Cible', 'Comparaisons', 'Recommandations']
    },
    {
      id: 'fiscal',
      name: 'Optimisation Fiscale',
      description: 'Stratégies fiscales personnalisées et projections',
      icon: 'ri-calculator-line',
      pages: '10-12 pages',
      sections: ['Couverture', 'Situation Fiscale', 'Optimisations', 'Simulations', 'Plan d\'Action']
    }
  ];

  const generatePDF = async () => {
    setIsGenerating(true);

    try {
      await new Promise(resolve => setTimeout(resolve, 2000));

      const pdfData = {
        template: selectedTemplate,
        userProfile,
        portfolioData,
        generatedAt: new Date().toISOString(),
        signature: signatureData,
        pages: generatePDFPages()
      };

      const existingPDFs = JSON.parse(localStorage.getItem('cmv_generated_pdfs') || '[]');
      const newPDF = {
        id: Date.now().toString(),
        ...pdfData,
        status: signatureData ? 'signed' : 'pending_signature',
        fileName: `Rapport_CMV_Finance_${selectedTemplate}_${new Date().toLocaleDateString('fr-FR').replace(/\\/g, '-').replace(/-/g, '')}.pdf`
      };

      existingPDFs.push(newPDF);
      localStorage.setItem('cmv_generated_pdfs', JSON.stringify(existingPDFs));

      downloadPDFFile(newPDF);

      setShowModal(false);
      setShowSignature(false);
      alert('PDF généré et téléchargé avec succès !');
    } catch (error) {
      console.error('Erreur lors de la génération du PDF:', error);
      alert('Erreur lors de la génération du PDF');
    } finally {
      setIsGenerating(false);
    }
  };

  const downloadPDFFile = (pdfData: any) => {
    const template = templates.find(t => t.id === pdfData.template);

    const htmlContent = `
      <!DOCTYPE html>
      <html lang="fr">
      <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Rapport Patrimonial CMV Finance</title>
          <style>
              * { margin: 0; padding: 0; box-sizing: border-box; }
              body { 
                  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                  line-height: 1.6;
                  color: #333;
                  background: white;
              }
              .page {
                  width: 210mm;
                  min-height: 297mm;
                  padding: 20mm;
                  margin: 0 auto;
                  background: white;
                  box-shadow: 0 0 10px rgba(0,0,0,0.1);
                  page-break-after: always;
              }
              .page:last-child { page-break-after: avoid; }

              .header {
                  text-align: center;
                  border-bottom: 3px solid #f59e0b;
                  padding-bottom: 20px;
                  margin-bottom: 30px;
              }
              .logo {
                  font-size: 28px;
                  font-weight: bold;
                  color: #1f2937;
                  margin-bottom: 10px;
                  font-family: 'Pacifico', serif;
              }
              .page-title {
                  font-size: 24px;
                  font-weight: bold;
                  color: #1f2937;
                  margin-bottom: 20px;
                  border-bottom: 2px solid #e5e7eb;
                  padding-bottom: 10px;
              }
              .section {
                  margin-bottom: 30px;
              }
              .card {
                  background: #f9fafb;
                  padding: 20px;
                  border-radius: 8px;
                  margin-bottom: 20px;
                  border-left: 4px solid #3b82f6;
              }
              .recommendation {
                  background: #dbeafe;
                  padding: 15px;
                  border-radius: 8px;
                  margin-bottom: 15px;
                  border-left: 4px solid #3b82f6;
              }
              .stats {
                  display: flex;
                  justify-content: space-between;
                  margin-bottom: 20px;
                  gap: 20px;
              }
              .stat {
                  text-align: center;
                  padding: 15px;
                  background: #f3f4f6;
                  border-radius: 8px;
                  flex: 1;
              }
              .stat h3 {
                  font-size: 14px;
                  color: #6b7280;
                  margin-bottom: 5px;
              }
              .stat p {
                  font-size: 20px;
                  font-weight: bold;
                  color: #1f2937;
              }
              .footer {
                  position: fixed;
                  bottom: 15mm;
                  left: 20mm;
                  right: 20mm;
                  text-align: center;
                  padding-top: 10px;
                  border-top: 1px solid #e5e7eb;
                  color: #6b7280;
                  font-size: 12px;
              }
              .signature-section {
                  margin-top: 50px;
                  padding-top: 20px;
                  border-top: 1px solid #e5e7eb;
              }
              .signature-box {
                  border: 1px solid #d1d5db;
                  min-height: 100px;
                  padding: 10px;
                  margin-top: 10px;
                  background: #f9fafb;
                  border-radius: 4px;
              }

              @media print {
                  body { margin: 0; }
                  .page { box-shadow: none; margin: 0; }
                  .page-break { page-break-before: always; }

              }

              h1, h2, h3 { color: #1f2937; }
              h1 { font-size: 28px; }
              h2 { font-size: 24px; }
              h3 { font-size: 18px; }

              .text-center { text-align: center; }
              .text-right { text-align: right; }
              .font-bold { font-weight: bold; }
              .text-gray-600 { color: #6b7280; }
              .text-blue-600 { color: #2563eb; }
              .text-green-600 { color: #16a34a; }
              .text-red-600 { color: #dc2626; }

              ul { padding-left: 20px; }
              li { margin-bottom: 5px; }

              .plan-action {
                  background: #f0f9ff;
                  border: 1px solid #0ea5e9;
                  border-radius: 8px;
                  padding: 20px;
                  margin: 20px 0;
              }

              .plan-action h3 {
                  color: #0ea5e9;
                  margin-bottom: 15px;
              }
          </style>
      </head>
      <body>
          <!-- Page de Couverture -->
          <div class="page">
              <div class="header">
                  <div class="logo">CMV FINANCE</div>
                  <h1>Rapport Patrimonial Personnalisé</h1>
                  <h2>${template?.name}</h2>
                  <div style="margin-top: 30px;">
                      <p><strong>Préparé pour :</strong> ${pdfData.userProfile?.name || 'Client CMV Finance'}</p>
                      <p><strong>Date de génération :</strong> ${new Date().toLocaleDateString('fr-FR')}</p>
                      <p><strong>Référence :</strong> ${pdfData.id}</p>
                  </div>
              </div>

              <div style="margin-top: 100px; text-align: center;">
                  <div style="background: #f0f9ff; padding: 30px; border-radius: 12px; border: 1px solid #0ea5e9;">
                      <h3 style="color: #0ea5e9; margin-bottom: 20px;">Contenu du Rapport</h3>
                      <div style="text-align: left; max-width: 400px; margin: 0 auto;">
                          ${template?.sections.map(section => `<p>• ${section}</p>`).join('')}
                      </div>
                  </div>
              </div>

              <div style="position: absolute; bottom: 50px; left: 20mm; right: 20mm; text-align: center; color: #6b7280; font-size: 12px;">
                  <p>Ce document est confidentiel et destiné exclusivement au client mentionné ci-dessus.</p>
                  <p>CMV Finance - Conseil en Gestion de Patrimoine | www.cmvfinance.com</p>
              </div>
          </div>

          <!-- Résumé Exécutif -->
          <div class="page">
              <h1 class="page-title">Résumé Exécutif</h1>

              <div class="stats">
                  <div class="stat">
                      <h3>Valeur Totale</h3>
                      <p class="text-blue-600">€${(portfolioData?.totalValue || 250000).toLocaleString('fr-FR')}</p>
                  </div>
                  <div class="stat">
                      <h3>Performance YTD</h3>
                      <p class="text-green-600">+8.5%</p>
                  </div>
                  <div class="stat">
                      <h3>Niveau de Risque</h3>
                      <p>Modéré</p>
                  </div>
              </div>

              <div class="section">
                  <h2>Situation Patrimoniale Actuelle</h2>
                  <div class="card">
                      <h3>Points Forts</h3>
                      <ul>
                          <li>Diversification satisfaisante du portefeuille</li>
                          <li>Performance en ligne avec les objectifs</li>
                          <li>Allocation d'actifs équilibrée</li>
                          <li>Respect du profil de risque défini</li>
                      </ul>
                  </div>

                  <div class="card">
                      <h3>Axes d'Amélioration</h3>
                      <ul>
                          <li>Optimisation de l'enveloppe fiscale</li>
                          <li>Renforcement de la diversification géographique</li>
                          <li>Réduction des frais de gestion</li>
                          <li>Mise en place d'un suivi automatisé</li>
                      </ul>
                  </div>
              </div>

              <div class="section">
                  <h2>Objectifs Financiers</h2>
                  <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; border-left: 4px solid #22c55e;">
                      <h3 style="color: #16a34a;">Objectif Principal</h3>
                      <p>Optimiser la performance ajustée au risque tout en préservant le capital et en minimisant l'impact fiscal.</p>
                  </div>
              </div>
          </div>

          <!-- Recommandations Détaillées -->
          <div class="page">
              <h1 class="page-title">Recommandations Prioritaires</h1>

              <div class="recommendation">
                  <h3>Optimisation d'Allocation</h3>
                  <p><strong>Recommandation :</strong> Ajuster l'allocation vers 60% Actions / 30% Obligations / 10% Liquidités</p>
                  <p><strong>Impact attendu :</strong> Amélioration du ratio rendement/risque de 12%</p>
                  <p><strong>Délai de mise en œuvre :</strong> 1-2 mois</p>
              </div>

              <div class="recommendation">
                  <h3>Optimisation Fiscale</h3>
                  <p><strong>Recommandation :</strong> Maximiser l'utilisation du PEA (${150000 - (portfolioData?.peaAmount || 0)}€ disponibles)</p>
                  <p><strong>Impact attendu :</strong> Économie fiscale de 1,200€/an</p>
                  <p><strong>Délai de mise en œuvre :</strong> Immédiat</p>
              </div>

              <div class="recommendation">
                  <h3>Diversification Géographique</h3>
                  <p><strong>Recommandation :</strong> Ajouter 10% d'exposition aux marchés émergents</p>
                  <p><strong>Impact attendu :</strong> Réduction de la volatilité de 15%</p>
                  <p><strong>Délai de mise en œuvre :</strong> 3-6 mois</p>
              </div>

              <div class="recommendation">
                  <h3>Automatisation du Suivi</h3>
                  <p><strong>Recommandation :</strong> Mise en place d'un rééquilibrage trimestriel automatique</p>
                  <p><strong>Impact attendu :</strong> Maintien optimal de l'allocation cible</p>
                  <p><strong>Délai de mise en œuvre :</strong> 1 mois</p>
              </div>
          </div>

          <!-- Plan d'Action -->
          <div class="page">
              <h1 class="page-title">Plan d'Action Détaillé</h1>

              <div class="plan-action" style="border-color: #ef4444; background: #fef2f2;">
                  <h3 style="color: #ef4444;">Actions Immédiates (0-3 mois)</h3>
                  <ol>
                      <li><strong>Optimisation PEA :</strong> Transfert de 25,000€ vers le PEA</li>
                      <li><strong>Rééquilibrage :</strong> Ajustement de l'allocation actuelle</li>
                      <li><strong>Réduction des frais :</strong> Migration vers des ETF à frais réduits</li>
                      <li><strong>Mise en place du suivi :</strong> Configuration des alertes automatiques</li>
                  </ol>
              </div>

              <div class="plan-action" style="border-color: #f59e0b; background: #fffbeb;">
                  <h3 style="color: #f59e0b;">Actions Moyen Terme (3-12 mois)</h3>
                  <ol>
                      <li><strong>Diversification internationale :</strong> Ajout d'ETF marchés émergents</li>
                      <li><strong>Optimisation assurance-vie :</strong> Révision des supports</li>
                      <li><strong>Stratégie défiscalisation :</strong> Mise en place d'investissements Pinel</li>
                      <li><strong>Révision périodique :</strong> Rendez-vous trimestriels</li>
                  </ol>
              </div>

              <div class="plan-action">
                  <h3>Objectifs Long Terme (1-5 ans)</h3>
                  <ol>
                      <li><strong>Croissance patrimoniale :</strong> Objectif +7% annuel</li>
                      <li><strong>Préparation retraite :</strong> Constitution d'un capital de 500,000€</li>
                      <li><strong>Transmission :</strong> Optimisation successorale</li>
                      <li><strong>Diversification :</strong> Immobilier locatif (20% du patrimoine)</li>
                  </ol>
              </div>
          </div>

          <!-- Projections et Scénarios -->
          <div class="page">
              <h1 class="page-title">Projections Financières</h1>

              <div class="section">
                  <h2>Scénarios de Performance</h2>

                  <div style="display: flex; gap: 20px; margin-bottom: 30px;">
                      <div class="stat" style="background: #f0fdf4; border: 1px solid #22c55e;">
                          <h3 style="color: #16a34a;">Scénario Optimiste</h3>
                          <p style="color: #16a34a;">+12% annuel</p>
                          <p style="font-size: 14px; color: #6b7280;">Valeur 5 ans: €441,000</p>
                      </div>

                      <div class="stat" style="background: #f0f9ff; border: 1px solid #0ea5e9;">
                          <h3 style="color: #0ea5e9;">Scénario Médian</h3>
                          <p style="color: #0ea5e9;">+8% annuel</p>
                          <p style="font-size: 14px; color: #6b7280;">Valeur 5 ans: €367,000</p>
                      </div>

                      <div class="stat" style="background: #fef3c7; border: 1px solid #f59e0b;">
                          <h3 style="color: #f59e0b;">Scénario Prudent</h3>
                          <p style="color: #f59e0b;">+5% annuel</p>
                          <p style="font-size: 14px; color: #6b7280;">Valeur 5 ans: €319,000</p>
                      </div>
                  </div>
              </div>

              <div class="section">
                  <h2>Répartition Recommandée</h2>
                  <div style="background: #f8fafc; padding: 20px; border-radius: 8px; border: 1px solid #e2e8f0;">
                      <div style="display: flex; justify-content: space-between; margin-bottom: 15px;">
                          <span>Actions Européennes</span>
                          <span><strong>35%</strong></span>
                      </div>
                      <div style="display: flex; justify-content: space-between; margin-bottom: 15px;">
                          <span>Actions Internationales</span>
                          <span><strong>25%</strong></span>
                      </div>
                      <div style="display: flex; justify-content: space-between; margin-bottom: 15px;">
                          <span>Obligations</span>
                          <span><strong>30%</strong></span>
                      </div>
                      <div style="display: flex; justify-content: space-between; margin-bottom: 15px;">
                          <span>Liquidités</span>
                          <span><strong>10%</strong></span>
                      </div>
                  </div>
              </div>
          </div>

          ${pdfData.signature ? `
          <!-- Page de Signature -->
          <div class="page">
              <h1 class="page-title">Signature Électronique</h1>

              <div style="background: #f0f9ff; padding: 30px; border-radius: 12px; border: 1px solid #0ea5e9; margin-bottom: 30px;">
                  <h3 style="color: #0ea5e9; margin-bottom: 15px;">Document Signé Électroniquement</h3>
                  <p><strong>Date de signature :</strong> ${new Date().toLocaleDateString('fr-FR')} à ${new Date().toLocaleTimeString('fr-FR')}</p>
                  <p><strong>Signataire :</strong> ${pdfData.userProfile?.name || 'Client'}</p>
                  <p><strong>IP Address :</strong> 192.168.1.1</p>
              </div>

              <div class="signature-section">
                  <h3>Signature</h3>
                  <div class="signature-box">
                      <p style="color: #6b7280; font-style: italic;">Signature électronique capturée le ${new Date().toLocaleDateString('fr-FR')}</p>
                  </div>
              </div>

              <div style="background: #fffbeb; padding: 20px; border-radius: 8px; border: 1px solid #f59e0b; margin-top: 30px;">
                  <h4 style="color: #f59e0b; margin-bottom: 10px;">Validité Juridique</h4>
                  <p style="font-size: 14px;">Cette signature électronique a la même valeur légale qu'une signature manuscrite conformément au règlement européen eIDAS (Electronic Identification, Authentication and Trust Services).</p>
              </div>
          </div>
          ` : ''}

          <div class="footer">
              <p>Rapport généré le ${new Date().toLocaleDateString('fr-FR')} | CMV Finance - Conseil en Gestion de Patrimoine</p>
              <p>123 Avenue des Champs-Élysées, 75008 Paris | Tél: +33 1 23 45 67 89 | contact@cmvfinance.com</p>
              <p>Document confidentiel - Reproduction interdite sans autorisation</p>
          </div>
      </body>
      </html>
  `;

    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });

    const url = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = url;
    link.download = pdfData.fileName;
    link.style.display = 'none';

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setTimeout(() => {
      URL.revokeObjectURL(url);
    }, 100);
  };

  const downloadExistingPDF = (pdf: any) => {
    downloadPDFFile(pdf);
  };

  const generatePDFPages = () => {
    const template = templates.find(t => t.id === selectedTemplate);
    const pages = [];

    pages.push({
      type: 'cover',
      title: 'Rapport Patrimonial Personnalisé',
      subtitle: template?.name,
      client: userProfile?.name || 'Client',
      date: new Date().toLocaleDateString('fr-FR'),
      logo: 'CMV FINANCE'
    });

    if (selectedTemplate === 'complet') {
      pages.push(
        { type: 'executive-summary', title: 'Résumé Exécutif' },
        { type: 'investor-profile', title: 'Profil Investisseur' },
        { type: 'portfolio-analysis', title: 'Analyse du Portefeuille' },
        { type: 'asset-allocation', title: 'Allocation d\'Actifs' },
        { type: 'risk-analysis', title: 'Analyse des Risques' },
        { type: 'recommendations', title: 'Recommandations' },
        { type: 'tax-optimization', title: 'Optimisation Fiscale' },
        { type: 'projections', title: 'Projections' },
        { type: 'action-plan', title: 'Plan d\'Action' },
        { type: 'appendix', title: 'Annexes' }
      );
    } else if (selectedTemplate === 'synthese') {
      pages.push(
        { type: 'executive-summary', title: 'Résumé Exécutif' },
        { type: 'key-recommendations', title: 'Recommandations Clés' },
        { type: 'action-plan', title: 'Plan d\'Action' },
        { type: 'projections', title: 'Projections' }
      );
    } else if (selectedTemplate === 'allocations') {
      pages.push(
        { type: 'current-allocation', title: 'Allocation Actuelle' },
        { type: 'target-allocation', title: 'Allocation Cible' },
        { type: 'allocation-comparison', title: 'Comparaisons' },
        { type: 'rebalancing', title: 'Rééquilibrage' },
        { type: 'recommendations', title: 'Recommandations' }
      );
    } else if (selectedTemplate === 'fiscal') {
      pages.push(
        { type: 'tax-situation', title: 'Situation Fiscale' },
        { type: 'tax-optimization', title: 'Optimisations Fiscales' },
        { type: 'tax-simulations', title: 'Simulations' },
        { type: 'action-plan', title: 'Plan d\'Action' }
      );
    }

    return pages;
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDrawing(true);
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.strokeStyle = '#000';
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(e.clientX - rect.left, e.clientY - rect.top);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.lineTo(e.clientX - rect.left, e.clientY - rect.top);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
    const canvas = canvasRef.current;
    if (canvas) {
      setSignatureData(canvas.toDataURL());
    }
  };

  const clearSignature = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setSignatureData('');
  };

  const PreviewModal = () => {
    const template = templates.find(t => t.id === selectedTemplate);
    const pages = generatePDFPages();

    return (
      <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-xl max-w-4xl w-full max-h-[95vh] overflow-y-auto">
          <div className="sticky top-0 bg-white border-b border-gray-200 p-4 flex items-center justify-between">
            <h3 className="text-xl font-bold text-gray-900">Aperçu du Rapport - {template?.name}</h3>
            <button
              onClick={() => setShowPreview(false)}
              className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors cursor-pointer"
            >
              <i className="ri-close-line text-xl text-gray-600"></i>
            </button>
          </div>

          <div className="p-6 space-y-8">
            {pages.slice(0, 3).map((page, index) => (
              <div key={index} className="bg-white border border-gray-300 rounded-lg p-8 shadow-lg min-h-[11in] w-[8.5in] mx-auto" style={{ aspectRatio: '8.5/11' }}>
                {page.type === 'cover' && (
                  <div className="h-full flex flex-col justify-between">
                    <div className="text-center">
                      <div className="text-4xl font-bold text-gray-900 mb-4" style={{ fontFamily: 'Pacifico, serif' }}>
                        CMV FINANCE
                      </div>
                      <div className="w-24 h-1 bg-yellow-500 mx-auto mb-8"></div>
                    </div>

                    <div className="text-center space-y-6">
                      <h1 className="text-4xl font-bold text-gray-900">
                        {page.title}
                      </h1>
                      <h2 className="text-2xl text-gray-600">
                        {page.subtitle}
                      </h2>

                      <div className="bg-gray-50 p-6 rounded-lg">
                        <div className="text-lg font-semibold text-gray-900 mb-2">
                          Préparé pour: {page.client}
                        </div>
                        <div className="text-gray-600">
                          Date: {page.date}
                        </div>
                      </div>
                    </div>

                    <div className="text-center text-sm text-gray-500">
                      <div>Document confidentiel</div>
                      <div>CMV Finance - Conseil en gestion de patrimoine</div>
                    </div>
                  </div>
                )}

                {page.type !== 'cover' && (
                  <div className="space-y-6">
                    <div className="border-b border-gray-200 pb-4">
                      <h1 className="text-3xl font-bold text-gray-900">{page.title}</h1>
                    </div>
                    <div className="text-gray-600 space-y-4">
                      <p>Aperçu de la section {page.title}</p>
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <p className="text-sm">Cette section contiendra des analyses détaillées selon le type de rapport sélectionné.</p>
                      </div>
                    </div>
                    <div className="text-center text-sm text-gray-500 pt-8">
                      Page {index + 1} sur {pages.length}
                    </div>
                  </div>
                )}
              </div>
            ))}

            {pages.length > 3 && (
              <div className="text-center text-gray-500 py-8">
                <p>... et {pages.length - 3} pages supplémentaires</p>
              </div>
            )}
          </div>

          <div className="sticky bottom-0 bg-white border-t border-gray-200 p-4">
            <div className="flex space-x-4">
              <button
                onClick={() => setShowPreview(false)}
                className="flex-1 bg-gray-500 hover:bg-gray-600 text-white py-2 px-4 rounded-lg font-semibold transition-colors whitespace-nowrap"
              >
                Fermer l'Aperçu
              </button>
              <button
                onClick={() => {
                  setShowPreview(false);
                  setShowSignature(true);
                }}
                className="flex-1 bg-yellow-500 hover:bg-yellow-600 text-black py-2 px-4 rounded-lg font-semibold transition-colors whitespace-nowrap"
              >
                Continuer vers Signature
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
      <div className="bg-gray-900 p-6 rounded-xl border border-yellow-500/20">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-xl font-semibold text-white mb-2">Générateur de Rapports PDF</h3>
            <p className="text-gray-400 text-sm">Créez des rapports professionnels multi-pages avec signature électronique</p>
          </div>
          <div className="w-12 h-12 bg-red-500/20 rounded-lg flex items-center justify-center">
            <i className="ri-file-pdf-line text-2xl text-red-400"></i>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-gray-800 p-4 rounded-lg">
            <div className="flex items-center space-x-3 mb-2">
              <i className="ri-download-line text-lg text-blue-400"></i>
              <span className="text-white font-medium">Rapports Générés</span>
            </div>
            <div className="text-2xl font-bold text-white">
              {JSON.parse(localStorage.getItem('cmv_generated_pdfs') || '[]').length}
            </div>
            <div className="text-xs text-gray-400">Documents créés</div>
          </div>

          <div className="bg-gray-800 p-4 rounded-lg">
            <div className="flex items-center space-x-3 mb-2">
              <i className="ri-quill-pen-line text-lg text-green-400"></i>
              <span className="text-white font-medium">Signatures</span>
            </div>
            <div className="text-2xl font-bold text-white">
              {JSON.parse(localStorage.getItem('cmv_generated_pdfs') || '[]').filter((pdf: any) => pdf.status === 'signed').length}
            </div>
            <div className="text-xs text-gray-400">Documents signés</div>
          </div>

          <div className="bg-gray-800 p-4 rounded-lg">
            <div className="flex items-center space-x-3 mb-2">
              <i className="ri-file-copy-line text-lg text-purple-400"></i>
              <span className="text-white font-medium">Pages Générées</span>
            </div>
            <div className="text-2xl font-bold text-white">
              {JSON.parse(localStorage.getItem('cmv_generated_pdfs') || '[]').reduce((acc: number, pdf: any) => acc + (pdf.pages?.length || 10), 0)}
            </div>
            <div className="text-xs text-gray-400">Pages au total</div>
          </div>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="w-full bg-yellow-500 hover:bg-yellow-600 text-black py-3 px-4 rounded-lg font-semibold transition-colors whitespace-nowrap"
        >
          <i className="ri-file-add-line mr-2"></i>
          Créer un Nouveau Rapport PDF
        </button>

        <div className="mt-6 pt-6 border-t border-gray-800">
          <h4 className="text-white font-medium mb-4">Rapports Récents</h4>
          <div className="space-y-3 max-h-40 overflow-y-auto">
            {JSON.parse(localStorage.getItem('cmv_generated_pdfs') || '[]').slice(0, 3).map((pdf: any) => (
              <div key={pdf.id} className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                <div className="flex items-center space-x-3">
                  <i className="ri-file-pdf-line text-red-400"></i>
                  <div>
                    <div className="text-white text-sm font-medium">{pdf.fileName}</div>
                    <div className="text-xs text-gray-400">
                      {new Date(pdf.generatedAt).toLocaleDateString('fr-FR')} • {pdf.pages?.length || 'N/A'} pages
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    pdf.status === 'signed'
                      ? 'bg-green-500/20 text-green-400'
                      : 'bg-orange-500/20 text-orange-400'
                  }`}>
                    {pdf.status === 'signed' ? 'Signé' : 'En attente'}
                  </span>
                  <button
                    onClick={() => downloadExistingPDF(pdf)}
                    className="text-blue-400 hover:text-blue-300 text-sm cursor-pointer hover:bg-gray-700 p-1 rounded transition-colors"
                    title="Télécharger le rapport"
                  >
                    <i className="ri-download-line"></i>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 rounded-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto border border-yellow-500/20">
            <div className="flex items-center justify-between p-6 border-b border-gray-800">
              <h3 className="text-2xl font-bold text-white">Créer un Rapport PDF Professionnel</h3>
              <button
                onClick={() => setShowModal(false)}
                className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-800 transition-colors cursor-pointer"
              >
                <i className="ri-close-line text-xl text-gray-400 hover:text-white"></i>
              </button>
            </div>

            <div className="p-6 space-y-6">
              {!showSignature ? (
                <>
                  <div>
                    <h4 className="text-lg font-semibold text-white mb-4">Choisissez le type de rapport</h4>
                    <div className="grid md:grid-cols-2 gap-6">
                      {templates.map((template) => (
                        <div
                          key={template.id}
                          onClick={() => setSelectedTemplate(template.id)}
                          className={`p-6 rounded-lg border-2 cursor-pointer transition-all ${
                            selectedTemplate === template.id
                              ? 'border-yellow-500 bg-yellow-500/10'
                              : 'border-gray-700 bg-gray-800 hover:border-gray-600'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-4">
                            <div className="flex items-center space-x-3">
                              <i className={`${template.icon} text-2xl ${
                                selectedTemplate === template.id ? 'text-yellow-400' : 'text-gray-400'
                              }`}></i>
                              <div>
                                <h5 className="font-semibold text-white">{template.name}</h5>
                                <span className="text-xs text-gray-400">{template.pages}</span>
                              </div>
                            </div>
                            {selectedTemplate === template.id && (
                              <i className="ri-check-circle-fill text-yellow-400 text-xl"></i>
                            )}
                          </div>
                          <p className="text-sm text-gray-400 mb-4">{template.description}</p>

                          <div className="text-xs text-gray-500">
                            <strong>Sections incluses:</strong>
                            <div className="mt-2 flex flex-wrap gap-1">
                              {template.sections.map((section, idx) => (
                                <span key={idx} className="bg-gray-700 px-2 py-1 rounded text-xs">
                                  {section}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex space-x-4">
                    <button
                      onClick={() => setShowModal(false)}
                      className="flex-1 bg-gray-700 hover:bg-gray-600 text-white py-3 rounded-lg font-semibold transition-colors whitespace-nowrap"
                    >
                      Annuler
                    </button>
                    <button
                      onClick={() => setShowPreview(true)}
                      className="flex-1 bg-blue-500 hover:bg-blue-600 text-white py-3 rounded-lg font-semibold transition-colors whitespace-nowrap"
                    >
                      <i className="ri-eye-line mr-2"></i>
                      Aperçu du Rapport
                    </button>
                    <button
                      onClick={() => setShowSignature(true)}
                      className="flex-1 bg-yellow-500 hover:bg-yellow-600 text-black py-3 rounded-lg font-semibold transition-colors whitespace-nowrap"
                    >
                      Continuer vers Signature
                    </button>
                  </div>
                </>
              ) : (
                <>
                  <div>
                    <h4 className="text-lg font-semibold text-white mb-4">Signature Électronique</h4>
                    <p className="text-gray-400 mb-6">Signez le document en dessinant votre signature ci-dessous</p>

                    <div className="bg-white rounded-lg p-4 mb-4">
                      <canvas
                        ref={canvasRef}
                        width={600}
                        height={200}
                        className="border border-gray-300 w-full cursor-crosshair"
                        onMouseDown={startDrawing}
                        onMouseMove={draw}
                        onMouseUp={stopDrawing}
                        onMouseLeave={stopDrawing}
                      />
                    </div>

                    <div className="flex justify-between items-center mb-6">
                      <button
                        onClick={clearSignature}
                        className="bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 rounded-lg font-semibold transition-colors whitespace-nowrap"
                      >
                        <i className="ri-eraser-line mr-2"></i>
                        Effacer
                      </button>
                      <span className="text-sm text-gray-400">Dessinez votre signature dans la zone blanche</span>
                    </div>
                  </div>

                  <div className="flex space-x-4">
                    <button
                      onClick={() => setShowSignature(false)}
                      className="flex-1 bg-gray-700 hover:bg-gray-600 text-white py-3 rounded-lg font-semibold transition-colors whitespace-nowrap"
                    >
                      Retour
                    </button>
                    <button
                      onClick={generatePDF}
                      disabled={isGenerating}
                      className="flex-1 bg-green-500 hover:bg-green-600 disabled:bg-gray-600 disabled:cursor-not-allowed text-white py-3 rounded-lg font-semibold transition-colors whitespace-nowrap"
                    >
                      {isGenerating ? (
                        <>
                          <i className="ri-loader-4-line mr-2 animate-spin"></i>
                          Génération en cours...
                        </>
                      ) : (
                        <>
                          <i className="ri-download-line mr-2"></i>
                          Générer et Télécharger PDF
                        </>
                      )}
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {showPreview && <PreviewModal />}
    </>
  );
}
