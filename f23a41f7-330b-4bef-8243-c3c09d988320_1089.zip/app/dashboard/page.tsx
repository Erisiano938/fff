
'use client';

import { useState } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import DashboardOverview from './DashboardOverview';
import AssetAllocation from './AssetAllocation';
import PortfolioChart from './PortfolioChart';
import RecentTransactions from './RecentTransactions';
import AIRecommendations from './AIRecommendations';
import TaxCalculator from './TaxCalculator';
import RetirementSimulator from './RetirementSimulator';
import SavingsSimulator from './SavingsSimulator';
import CreditSimulator from './CreditSimulator';
import InternationalTransmission from './InternationalTransmission';
import PatrimonialEngineering from './PatrimonialEngineering';
import UserProfile from './UserProfile';
import LegalAssistant from './LegalAssistant';

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState('overview');
  const [showProfileModal, setShowProfileModal] = useState(false);

  const tabs = [
    { id: 'overview', label: 'Aperçu', icon: 'ri-dashboard-line' },
    { id: 'savings', label: 'Simulateur Épargne', icon: 'ri-bank-line' },
    { id: 'credit', label: 'Simulateur de crédit', icon: 'ri-bank-card-line' },
    { id: 'ai', label: 'IA Recommandations', icon: 'ri-robot-line' },
    { id: 'tax', label: 'Fiscalité', icon: 'ri-calculator-line' },
    { id: 'retirement', label: 'Retraite', icon: 'ri-time-line' },
    { id: 'transmission', label: 'Transmission Internationale', icon: 'ri-global-line' },
    { id: 'legal', label: 'Assistant Juridique', icon: 'ri-scales-line' },
    { id: 'engineering', label: 'Ingénierie', icon: 'ri-settings-3-line' },
    { id: 'profile', label: 'Profil', icon: 'ri-user-line' }
  ];

  const handleProfileClick = () => {
    setShowProfileModal(true);
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return <DashboardOverview />;
      case 'savings':
        return <SavingsSimulator />;
      case 'credit':
        return <CreditSimulator />;
      case 'ai':
        return <AIRecommendations />;
      case 'tax':
        return <TaxCalculator />;
      case 'retirement':
        return <RetirementSimulator />;
      case 'transmission':
        return <InternationalTransmission />;
      case 'legal':
        return <LegalAssistant />;
      case 'engineering':
        return <PatrimonialEngineering />;
      case 'profile':
        return (
          <div className="bg-gray-900 rounded-xl p-8 border border-gray-800">
            <div className="text-center">
              <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-yellow-500/20 flex items-center justify-center">
                <i className="ri-user-line text-3xl text-yellow-400"></i>
              </div>
              <h3 className="text-2xl font-bold text-white mb-4">Mon Profil Utilisateur</h3>
              <p className="text-gray-400 mb-8">
                Gérez vos informations personnelles et vos préférences d'investissement
              </p>
              <button
                onClick={handleProfileClick}
                className="bg-yellow-500 hover:bg-yellow-600 text-black px-8 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
              >
                <i className="ri-edit-line mr-2"></i>
                Ouvrir Mon Profil
              </button>
            </div>
          </div>
        );
      default:
        return <DashboardOverview />;
    }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <Header />
      
      <main className="pt-32 pb-16">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-white mb-4">
              Gestion de Patrimoine
            </h1>
            <p className="text-gray-400 text-lg">
              Tableau de bord complet pour la gestion et l'optimisation de votre patrimoine
            </p>
          </div>

          {/* Navigation Tabs */}
          <div className="mb-8">
            <div className="flex flex-wrap gap-2 bg-gray-900/50 p-2 rounded-xl border border-gray-800">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 px-4 py-3 rounded-lg transition-all whitespace-nowrap cursor-pointer ${
                    activeTab === tab.id
                      ? 'bg-yellow-500 text-black font-semibold'
                      : 'text-gray-400 hover:text-white hover:bg-gray-800'
                  }`}
                >
                  <i className={`${tab.icon} text-lg`}></i>
                  <span>{tab.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Content */}
          <div className="min-h-[600px]">
            {renderContent()}
          </div>
        </div>
      </main>

      <Footer />

      {/* Profile Modal */}
      {showProfileModal && (
        <UserProfile onClose={() => setShowProfileModal(false)} />
      )}
    </div>
  );
}
