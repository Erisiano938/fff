
'use client';

import { useState, useEffect } from 'react';

interface UserProfileProps {
  onClose: () => void;
}

interface UserProfile {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  birthDate: string;
  profession: string;
  experience: string;
  riskProfile: string;
  investmentGoals: string;
}

interface ProfileHistory {
  date: string;
  time: string;
  changes: string[];
  user: string;
}

export default function UserProfile({ onClose }: UserProfileProps) {
  const [userProfile, setUserProfile] = useState<UserProfile>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    birthDate: '',
    profession: '',
    experience: 'debutant',
    riskProfile: 'modere',
    investmentGoals: ''
  });

  const [originalProfile, setOriginalProfile] = useState<UserProfile | null>(null);
  const [profileHistory, setProfileHistory] = useState<ProfileHistory[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [isFirstTime, setIsFirstTime] = useState(false);
  const [mifidData, setMifidData] = useState<any>(null);

  useEffect(() => {
    // Charger le profil utilisateur et les données MiFID
    const savedProfile = localStorage.getItem('user_profile');
    const savedHistory = localStorage.getItem('profile_history');
    const savedMifid = localStorage.getItem('mifidProfile');

    // Charger les données MiFID si disponibles
    if (savedMifid) {
      try {
        const mifidProfile = JSON.parse(savedMifid);
        setMifidData(mifidProfile);
      } catch (error) {
        console.error('Erreur lors du chargement MiFID:', error);
      }
    }

    if (savedProfile) {
      const profile = JSON.parse(savedProfile);

      // Synchroniser avec MiFID si disponible
      if (savedMifid) {
        try {
          const mifidProfile = JSON.parse(savedMifid);
          const syncedProfile = syncWithMifid(profile, mifidProfile);
          setUserProfile(syncedProfile);
        } catch (error) {
          setUserProfile(profile);
        }
      } else {
        setUserProfile(profile);
      }
      setIsFirstTime(false);
    } else {
      // Si aucun profil sauvegardé, c'est la première fois
      setIsFirstTime(true);
      setIsEditing(true);

      // Si MiFID disponible, pré-remplir avec les données MiFID
      if (savedMifid) {
        try {
          const mifidProfile = JSON.parse(savedMifid);
          const initialProfile = createProfileFromMifid(mifidProfile);
          setUserProfile(initialProfile);
        } catch (error) {
          // Profil vide par défaut
          setUserProfile({
            firstName: '',
            lastName: '',
            email: '',
            phone: '',
            birthDate: '',
            profession: '',
            experience: 'debutant',
            riskProfile: 'modere',
            investmentGoals: ''
          });
        }
      }
    }

    if (savedHistory) {
      setProfileHistory(JSON.parse(savedHistory));
    }
  }, []);

  // Synchroniser le profil avec les données MiFID
  const syncWithMifid = (profile: UserProfile, mifidProfile: any): UserProfile => {
    const syncedProfile = { ...profile };

    // Mapper l'expérience MiFID vers le profil utilisateur
    if (mifidProfile.experience) {
      switch (mifidProfile.experience) {
        case 'aucune':
          syncedProfile.experience = 'debutant';
          break;
        case 'limitee':
          syncedProfile.experience = 'debutant';
          break;
        case 'bonne':
          syncedProfile.experience = 'intermediaire';
          break;
        case 'tres_bonne':
          syncedProfile.experience = 'expert';
          break;
        default:
          syncedProfile.experience = 'debutant';
      }
    }

    // Mapper la classification MiFID vers le profil de risque
    if (mifidProfile.classification) {
      switch (mifidProfile.classification) {
        case 'Investisseur Très Prudent':
          syncedProfile.riskProfile = 'conservateur';
          break;
        case 'Investisseur Prudent':
          syncedProfile.riskProfile = 'conservateur';
          break;
        case 'Investisseur Intermédiaire':
          syncedProfile.riskProfile = 'modere';
          break;
        case 'Investisseur Expérimenté':
          syncedProfile.riskProfile = 'dynamique';
          break;
        case 'Investisseur Très Expérimenté':
          syncedProfile.riskProfile = 'speculatif';
          break;
        default:
          syncedProfile.riskProfile = 'modere';
      }
    }

    return syncedProfile;
  };

  // Créer un profil initial à partir des données MiFID
  const createProfileFromMifid = (mifidProfile: any): UserProfile => {
    const profile: UserProfile = {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      birthDate: '',
      profession: '',
      experience: 'debutant',
      riskProfile: 'modere',
      investmentGoals: ''
    };

    // Mapper la profession MiFID
    if (mifidProfile.profession) {
      switch (mifidProfile.profession) {
        case 'salarie':
          profile.profession = 'Salarié';
          break;
        case 'independant':
          profile.profession = 'Travailleur indépendant';
          break;
        case 'fonctionnaire':
          profile.profession = 'Fonctionnaire';
          break;
        case 'retraite':
          profile.profession = 'Retraité';
          break;
        case 'etudiant':
          profile.profession = 'Étudiant';
          break;
        case 'sans_emploi':
          profile.profession = 'Sans emploi';
          break;
        default:
          profile.profession = '';
      }
    }

    // Synchroniser expérience et risque
    return syncWithMifid(profile, mifidProfile);
  };

  const detectChanges = (original: UserProfile, updated: UserProfile): string[] => {
    const changes: string[] = [];
    const fieldLabels: { [key: string]: string } = {
      firstName: 'Prénom',
      lastName: 'Nom',
      email: 'Email',
      phone: 'Téléphone',
      birthDate: 'Date de naissance',
      profession: 'Profession',
      experience: 'Niveau d\'expérience',
      riskProfile: 'Profil de risque',
      investmentGoals: 'Objectifs d\'investissement'
    };

    const experienceLabels: { [key: string]: string } = {
      debutant: 'Débutant',
      intermediaire: 'Intermédiaire',
      avance: 'Avancé',
      expert: 'Expert'
    };

    const riskLabels: { [key: string]: string } = {
      conservateur: 'Conservateur',
      modere: 'Modéré',
      dynamique: 'Dynamique',
      speculatif: 'Spéculatif'
    };

    Object.keys(original).forEach(key => {
      const typedKey = key as keyof UserProfile;
      if (original[typedKey] !== updated[typedKey]) {
        let oldValue = original[typedKey];
        let newValue = updated[typedKey];

        if (key === 'experience') {
          oldValue = experienceLabels[oldValue] || oldValue;
          newValue = experienceLabels[newValue] || newValue;
        } else if (key === 'riskProfile') {
          oldValue = riskLabels[oldValue] || oldValue;
          newValue = riskLabels[newValue] || newValue;
        } else if (key === 'birthDate' && oldValue && newValue) {
          oldValue = new Date(oldValue).toLocaleDateString('fr-FR');
          newValue = new Date(newValue).toLocaleDateString('fr-FR');
        }

        changes.push(`${fieldLabels[key]}: "${oldValue}" → "${newValue}"`);
      }
    });

    return changes;
  };

  const handleStartEditing = () => {
    setOriginalProfile({ ...userProfile });
    setIsEditing(true);
  };

  const handleSaveProfile = () => {
    // Vérifier que les champs obligatoires sont remplis
    if (!userProfile.firstName.trim() || !userProfile.lastName.trim() || !userProfile.email.trim()) {
      alert('Veuillez remplir au moins le prénom, nom et email');
      return;
    }

    // Resynchroniser avec MiFID avant de sauvegarder
    let finalProfile = { ...userProfile };
    if (mifidData) {
      finalProfile = syncWithMifid(userProfile, mifidData);
    }

    if (originalProfile && !isFirstTime) {
      const changes = detectChanges(originalProfile, finalProfile);

      if (changes.length > 0) {
        const now = new Date();
        const newHistoryEntry: ProfileHistory = {
          date: now.toLocaleDateString('fr-FR'),
          time: now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
          changes: changes,
          user: `${finalProfile.firstName} ${finalProfile.lastName}`
        };

        const updatedHistory = [newHistoryEntry, ...profileHistory];
        setProfileHistory(updatedHistory);
        localStorage.setItem('profile_history', JSON.stringify(updatedHistory));
      }
    } else if (isFirstTime) {
      // Pour la première création, ajouter un historique de création
      const now = new Date();
      const creationEntry: ProfileHistory = {
        date: now.toLocaleDateString('fr-FR'),
        time: now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
        changes: mifidData ? ['Profil créé et synchronisé avec MiFID II'] : ['Profil créé'],
        user: `${finalProfile.firstName} ${finalProfile.lastName}`
      };

      const updatedHistory = [creationEntry];
      setProfileHistory(updatedHistory);
      localStorage.setItem('profile_history', JSON.stringify(updatedHistory));
      setIsFirstTime(false);
    }

    setUserProfile(finalProfile);
    localStorage.setItem('user_profile', JSON.stringify(finalProfile));
    setIsEditing(false);
    setOriginalProfile(null);
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  const handleCancelEditing = () => {
    if (isFirstTime) {
      // Si c'est la première fois et qu'on annule, fermer le modal
      onClose();
      return;
    }

    if (originalProfile) {
      setUserProfile(originalProfile);
    }
    setIsEditing(false);
    setOriginalProfile(null);
  };

  const handleResetProfile = () => {
    if (confirm('Êtes-vous sûr de vouloir effacer complètement votre profil et son historique ?')) {
      localStorage.removeItem('user_profile');
      localStorage.removeItem('profile_history');
      setUserProfile({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        birthDate: '',
        profession: '',
        experience: 'debutant',
        riskProfile: 'modere',
        investmentGoals: ''
      });
      setProfileHistory([]);
      setIsFirstTime(true);
      setIsEditing(true);
    }
  };

  const experienceOptions = [
    { value: 'debutant', label: 'Débutant', description: 'Moins d\'1 an d\'expérience' },
    { value: 'intermediaire', label: 'Intermédiaire', description: '1 à 5 ans d\'expérience' },
    { value: 'avance', label: 'Avancé', description: 'Plus de 5 ans d\'expérience' },
    { value: 'expert', label: 'Expert', description: 'Professionnel de la finance' }
  ];

  const riskProfileOptions = [
    { value: 'conservateur', label: 'Conservateur', description: 'Privilégie la sécurité', color: 'text-green-400' },
    { value: 'modere', label: 'Modéré', description: 'Équilibre risque/rendement', color: 'text-blue-400' },
    { value: 'dynamique', label: 'Dynamique', description: 'Accepte plus de risques', color: 'text-orange-400' },
    { value: 'speculatif', label: 'Spéculatif', description: 'Recherche la performance', color: 'text-red-400' }
  ];

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto border border-yellow-500/20">
        <div className="flex items-center justify-between p-6 border-b border-gray-800">
          <h3 className="text-2xl font-bold text-white flex items-center">
            <i className="ri-user-line text-yellow-400 mr-3"></i>
            {isFirstTime ? 'Créer Mon Profil' : 'Mon Profil'}
          </h3>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-800 transition-colors cursor-pointer"
          >
            <i className="ri-close-line text-xl text-gray-400 hover:text-white"></i>
          </button>
        </div>

        {showSuccess && (
          <div className="m-6 bg-green-500/20 border border-green-500/40 text-green-400 p-4 rounded-lg">
            <i className="ri-check-line mr-2"></i>
            {isFirstTime ? 'Profil créé avec succès !' : 'Profil mis à jour avec succès !'}
          </div>
        )}

        {isFirstTime && (
          <div className="m-6 bg-blue-500/20 border border-blue-500/40 text-blue-400 p-4 rounded-lg">
            <i className="ri-information-line mr-2"></i>
            Bienvenue ! Veuillez remplir vos informations pour créer votre profil.
          </div>
        )}

        {mifidData && (
          <div className="m-6 bg-purple-500/20 border border-purple-500/40 text-purple-400 p-4 rounded-lg">
            <i className="ri-shield-check-line mr-2"></i>
            Profil synchronisé avec votre évaluation MiFID II. Le niveau d'expérience et le profil de risque sont automatiquement mis à jour.
          </div>
        )}

        <div className="p-6">
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Section Profil et Actions */}
            <div className="lg:col-span-1 space-y-6">
              <div className="text-center">
                <div className="w-32 h-32 mx-auto mb-4 rounded-full border-4 border-yellow-500/20 overflow-hidden bg-gray-800">
                  <div className="w-full h-full flex items-center justify-center text-gray-500">
                    <i className="ri-user-line text-4xl"></i>
                  </div>
                </div>
                <h4 className="text-xl font-bold text-white mb-2">
                  {userProfile.firstName && userProfile.lastName ? 
                    `${userProfile.firstName} ${userProfile.lastName}` : 
                    'Nouveau Profil'
                  }
                </h4>
                <p className="text-gray-400 mb-4">{userProfile.profession || 'Profession non renseignée'}</p>

                <div className="space-y-3">
                  {!isFirstTime && (
                    <button
                      onClick={() => isEditing ? handleCancelEditing() : handleStartEditing()}
                      className="w-full bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
                    >
                      <i className={`${isEditing ? 'ri-close-line' : 'ri-edit-line'} mr-2`}></i>
                      {isEditing ? 'Annuler' : 'Modifier Profil'}
                    </button>
                  )}

                  {!isFirstTime && !isEditing && (
                    <button
                      onClick={handleResetProfile}
                      className="w-full bg-red-500/20 hover:bg-red-500/30 text-red-400 py-2 px-4 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer border border-red-500/30"
                    >
                      <i className="ri-delete-bin-line mr-2"></i>
                      Effacer le Profil
                    </button>
                  )}
                </div>
              </div>

              {/* Badges et Statistiques */}
              {userProfile.firstName && (
                <>
                  <div className="bg-gray-800 rounded-xl p-4">
                    <h5 className="font-semibold text-white mb-3 flex items-center justify-between">
                      Niveau d'Expérience
                      {mifidData && (
                        <span className="text-xs bg-purple-500/20 text-purple-400 px-2 py-1 rounded">
                          MiFID II
                        </span>
                      )}
                    </h5>
                    <div className="space-y-3">
                      <div className={`p-3 rounded-lg border-2 ${userProfile.experience === 'debutant' ? 'border-yellow-500 bg-yellow-500/20' : userProfile.experience === 'intermediaire' ? 'border-blue-500 bg-blue-500/20' : userProfile.experience === 'avance' ? 'border-purple-500 bg-purple-500/20' : 'border-red-500 bg-red-500/20'}`}>
                        <div className="flex items-center space-x-2">
                          <i className={`ri-medal-line text-lg ${userProfile.experience === 'debutant' ? 'text-yellow-400' : userProfile.experience === 'intermediaire' ? 'text-blue-400' : userProfile.experience === 'avance' ? 'text-purple-400' : 'text-red-400'}`}></i>
                          <span className="font-medium text-white">
                            {experienceOptions.find(opt => opt.value === userProfile.experience)?.label}
                          </span>
                          {mifidData && (
                            <i className="ri-lock-line text-purple-400 text-sm" title="Synchronisé avec MiFID II"></i>
                          )}
                        </div>
                        <p className="text-xs text-gray-400 mt-1">
                          {experienceOptions.find(opt => opt.value === userProfile.experience)?.description}
                        </p>
                        {mifidData && (
                          <p className="text-xs text-purple-400 mt-1">
                            Basé sur votre évaluation MiFID II
                          </p>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-800 rounded-xl p-4">
                    <h5 className="font-semibold text-white mb-3 flex items-center justify-between">
                      Profil de Risque
                      {mifidData && (
                        <span className="text-xs bg-purple-500/20 text-purple-400 px-2 py-1 rounded">
                          MiFID II
                        </span>
                      )}
                    </h5>
                    <div className={`p-3 rounded-lg border-2 ${userProfile.riskProfile === 'conservateur' ? 'border-green-500 bg-green-500/20' : userProfile.riskProfile === 'modere' ? 'border-blue-500 bg-blue-500/20' : userProfile.riskProfile === 'dynamique' ? 'border-orange-500 bg-orange-500/20' : 'border-red-500 bg-red-500/20'}`}>
                      <div className="flex items-center space-x-2">
                        <i className={`ri-shield-line text-lg ${riskProfileOptions.find(opt => opt.value === userProfile.riskProfile)?.color}`}></i>
                        <span className="font-medium text-white">
                          {riskProfileOptions.find(opt => opt.value === userProfile.riskProfile)?.label}
                        </span>
                        {mifidData && (
                          <i className="ri-lock-line text-purple-400 text-sm" title="Synchronisé avec MiFID II"></i>
                        )}
                      </div>
                      <p className="text-xs text-gray-400 mt-1">
                        {riskProfileOptions.find(opt => opt.value === userProfile.riskProfile)?.description}
                      </p>
                      {mifidData && (
                        <p className="text-xs text-purple-400 mt-1">
                          Classification: {mifidData.classification}
                        </p>
                      )}
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Informations du profil */}
            <div className="lg:col-span-2 space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-gray-400 text-sm mb-2">Prénom *</label>
                  {isEditing ? (
                    <input
                      type="text"
                      value={userProfile.firstName}
                      onChange={(e) => setUserProfile(prev => ({ ...prev, firstName: e.target.value }))}
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      placeholder="Votre prénom"
                      required
                    />
                  ) : (
                    <div className="p-3 bg-gray-800 rounded-lg text-white">{userProfile.firstName || 'Non renseigné'}</div>
                  )}
                </div>

                <div>
                  <label className="block text-gray-400 text-sm mb-2">Nom *</label>
                  {isEditing ? (
                    <input
                      type="text"
                      value={userProfile.lastName}
                      onChange={(e) => setUserProfile(prev => ({ ...prev, lastName: e.target.value }))}
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      placeholder="Votre nom"
                      required
                    />
                  ) : (
                    <div className="p-3 bg-gray-800 rounded-lg text-white">{userProfile.lastName || 'Non renseigné'}</div>
                  )}
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-gray-400 text-sm mb-2">Email *</label>
                  {isEditing ? (
                    <input
                      type="email"
                      value={userProfile.email}
                      onChange={(e) => setUserProfile(prev => ({ ...prev, email: e.target.value }))}
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      placeholder="votre@email.com"
                      required
                    />
                  ) : (
                    <div className="p-3 bg-gray-800 rounded-lg text-white">{userProfile.email || 'Non renseigné'}</div>
                  )}
                </div>

                <div>
                  <label className="block text-gray-400 text-sm mb-2">Téléphone</label>
                  {isEditing ? (
                    <input
                      type="tel"
                      value={userProfile.phone}
                      onChange={(e) => setUserProfile(prev => ({ ...prev, phone: e.target.value }))}
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      placeholder="+33 6 12 34 56 78"
                    />
                  ) : (
                    <div className="p-3 bg-gray-800 rounded-lg text-white">{userProfile.phone || 'Non renseigné'}</div>
                  )}
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-gray-400 text-sm mb-2">Date de naissance</label>
                  {isEditing ? (
                    <input
                      type="date"
                      value={userProfile.birthDate}
                      onChange={(e) => setUserProfile(prev => ({ ...prev, birthDate: e.target.value }))}
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                    />
                  ) : (
                    <div className="p-3 bg-gray-800 rounded-lg text-white">
                      {userProfile.birthDate ? new Date(userProfile.birthDate).toLocaleDateString('fr-FR') : 'Non renseigné'}
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-gray-400 text-sm mb-2">Profession</label>
                  {isEditing ? (
                    <input
                      type="text"
                      value={userProfile.profession}
                      onChange={(e) => setUserProfile(prev => ({ ...prev, profession: e.target.value }))}
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      placeholder="Votre profession"
                    />
                  ) : (
                    <div className="p-3 bg-gray-800 rounded-lg text-white">{userProfile.profession || 'Non renseigné'}</div>
                  )}
                </div>
              </div>

              {/* Expérience et Profil de risque - Lecture seule si MiFID disponible */}
              {!mifidData && isEditing && (
                <>
                  <div>
                    <label className="block text-gray-400 text-sm mb-2">Niveau d'expérience</label>
                    <div className="grid grid-cols-2 gap-3">
                      {experienceOptions.map((option) => (
                        <button
                          key={option.value}
                          onClick={() => setUserProfile(prev => ({ ...prev, experience: option.value }))}
                          className={`p-3 rounded-lg border-2 transition-colors text-left cursor-pointer ${userProfile.experience === option.value ? 'border-yellow-500 bg-yellow-500/20' : 'border-gray-700 hover:border-gray-600'}`}
                        >
                          <div className="font-medium text-white">{option.label}</div>
                          <div className="text-xs text-gray-400">{option.description}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-gray-400 text-sm mb-2">Profil de risque</label>
                    <div className="grid grid-cols-2 gap-3">
                      {riskProfileOptions.map((option) => (
                        <button
                          key={option.value}
                          onClick={() => setUserProfile(prev => ({ ...prev, riskProfile: option.value }))}
                          className={`p-3 rounded-lg border-2 transition-colors text-left cursor-pointer ${userProfile.riskProfile === option.value ? 'border-yellow-500 bg-yellow-500/20' : 'border-gray-700 hover:border-gray-600'}`}
                        >
                          <div className={`font-medium ${option.color}`}>{option.label}</div>
                          <div className="text-xs text-gray-400">{option.description}</div>
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              )}

              {mifidData && isEditing && (
                <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <i className="ri-lock-line text-purple-400"></i>
                    <h4 className="text-white font-medium">Profil MiFID II Synchronisé</h4>
                  </div>
                  <p className="text-gray-300 text-sm mb-3">
                    Votre niveau d'expérience et profil de risque sont automatiquement synchronisés avec votre évaluation MiFID II et ne peuvent pas être modifiés manuellement.
                  </p>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-400">Classification MiFID:</span>
                      <div className="text-purple-400 font-medium">{mifidData.classification}</div>
                    </div>
                    <div>
                      <span className="text-gray-400">Score de risque:</span>
                      <div className="text-purple-400 font-medium">{mifidData.riskScore}/17</div>
                    </div>
                  </div>
                </div>
              )}

              <div>
                <label className="block text-gray-400 text-sm mb-2">Objectifs d'investissement</label>
                {isEditing ? (
                  <textarea
                    value={userProfile.investmentGoals}
                    onChange={(e) => setUserProfile(prev => ({ ...prev, investmentGoals: e.target.value }))}
                    rows={4}
                    maxLength={500}
                    className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none resize-none"
                    placeholder="Décrivez vos objectifs d'investissement..."
                  />
                ) : (
                  <div className="p-3 bg-gray-800 rounded-lg text-white min-h-[100px]">
                    {userProfile.investmentGoals || 'Objectifs non renseignés'}
                  </div>
                )}
              </div>

              {isEditing && (
                <div className="flex space-x-4 pt-4">
                  <button
                    onClick={handleCancelEditing}
                    className="flex-1 bg-gray-700 hover:bg-gray-600 text-white py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
                  >
                    {isFirstTime ? 'Fermer' : 'Annuler'}
                  </button>
                  <button
                    onClick={handleSaveProfile}
                    className="flex-1 bg-yellow-500 hover:bg-yellow-600 text-black py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
                  >
                    <i className="ri-save-line mr-2"></i>
                    {isFirstTime ? 'Créer le Profil' : 'Sauvegarder'}
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Historique des modifications */}
          {profileHistory.length > 0 && !isFirstTime && (
            <div className="mt-8 border-t border-gray-800 pt-6">
              <h4 className="text-xl font-bold text-white mb-4 flex items-center">
                <i className="ri-history-line text-yellow-400 mr-3"></i>
                Historique des Modifications
              </h4>

              <div className="space-y-4 max-h-96 overflow-y-auto">
                {profileHistory.map((entry, index) => (
                  <div key={index} className="bg-gray-800 rounded-lg p-4 border-l-4 border-yellow-500">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <i className="ri-user-line text-yellow-400"></i>
                        <span className="font-medium text-white">{entry.user}</span>
                      </div>
                      <div className="flex items-center space-x-4 text-sm text-gray-400">
                        <span className="flex items-center">
                          <i className="ri-calendar-line mr-1"></i>
                          {entry.date}
                        </span>
                        <span className="flex items-center">
                          <i className="ri-time-line mr-1"></i>
                          {entry.time}
                        </span>
                      </div>
                    </div>

                    <div className="space-y-1">
                      {entry.changes.map((change, changeIndex) => (
                        <div key={changeIndex} className="text-sm text-gray-300 flex items-start">
                          <i className="ri-arrow-right-line text-yellow-400 mr-2 mt-0.5 flex-shrink-0"></i>
                          <span>{change}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              {profileHistory.length > 5 && (
                <div className="text-center mt-4">
                  <button
                    onClick={() => {
                      if (confirm('Effacer tout l\'historique des modifications ?')) {
                        localStorage.setItem('profile_history', JSON.stringify([]));
                        setProfileHistory([]);
                      }
                    }}
                    className="text-sm text-red-400 hover:text-red-300 transition-colors cursor-pointer"
                  >
                    <i className="ri-delete-bin-line mr-1"></i>
                    Effacer l'historique
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
