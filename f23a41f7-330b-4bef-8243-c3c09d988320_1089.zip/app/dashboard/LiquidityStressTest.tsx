'use client';

import { useState, useEffect } from 'react';

export default function LiquidityStressTest() {
  const [stressTestParams, setStressTestParams] = useState({
    urgentNeed: 50000,
    timeframe: 30,
    deathCapital: 100000,
    creditLine: 20000,
    cash: 15000,
    lifeInsurance: 80000,
    realestate: 200000,
    stocks: 60000,
    bonds: 40000,
    crypto: 10000,
    pea: 45000,
    livretA: 22950,
    assuranceVie: 120000,
    immobilierScpi: 75000,
    or: 25000,
    artObjets: 35000
  });

  const [selectedScenario, setSelectedScenario] = useState('realiste');
  const [showDetails, setShowDetails] = useState(false);
  const [recommendations, setRecommendations] = useState([]);

  const stressScenarios = [
    { 
      id: 'optimiste', 
      name: 'Optimiste', 
      color: 'from-green-500 to-green-600',
      description: 'Conditions de marché favorables',
      cashDiscount: 0, 
      lifeDiscount: 5, 
      realestateDiscount: 15, 
      stocksDiscount: 10, 
      bondsDiscount: 2, 
      cryptoDiscount: 30,
      peaDiscount: 8,
      scpiDiscount: 12,
      orDiscount: 5,
      artDiscount: 20
    },
    { 
      id: 'realiste', 
      name: 'Réaliste', 
      color: 'from-yellow-500 to-yellow-600',
      description: 'Conditions de marché normales',
      cashDiscount: 0, 
      lifeDiscount: 15, 
      realestateDiscount: 30, 
      stocksDiscount: 25, 
      bondsDiscount: 5, 
      cryptoDiscount: 50,
      peaDiscount: 20,
      scpiDiscount: 25,
      orDiscount: 10,
      artDiscount: 40
    },
    { 
      id: 'pessimiste', 
      name: 'Pessimiste', 
      color: 'from-red-500 to-red-600',
      description: 'Conditions de marché défavorables',
      cashDiscount: 0, 
      lifeDiscount: 30, 
      realestateDiscount: 50, 
      stocksDiscount: 40, 
      bondsDiscount: 10, 
      cryptoDiscount: 70,
      peaDiscount: 35,
      scpiDiscount: 45,
      orDiscount: 15,
      artDiscount: 60
    }
  ];

  const assetCategories = [
    {
      id: 'liquidites',
      name: 'Liquidités Immédiates',
      icon: 'ri-money-euro-circle-line',
      color: 'from-green-500 to-green-600',
      description: 'Disponible immédiatement',
      assets: [
        { key: 'cash', label: 'Comptes courants', delay: '0 jour', fiscality: 'Aucune' },
        { key: 'livretA', label: 'Livret A/LDD', delay: '0 jour', fiscality: 'Exonéré' },
        { key: 'creditLine', label: 'Lignes de crédit', delay: '0-1 jour', fiscality: 'Intérêts déductibles' }
      ]
    },
    {
      id: 'court-terme',
      name: 'Court Terme (1-30 jours)',
      icon: 'ri-time-line',
      color: 'from-blue-500 to-blue-600',
      description: 'Mobilisable rapidement',
      assets: [
        { key: 'lifeInsurance', label: 'Assurance-vie (rachat)', delay: '3-15 jours', fiscality: 'Fiscalité dégressive' },
        { key: 'bonds', label: 'Obligations', delay: '1-3 jours', fiscality: 'Plus-values mobilières' },
        { key: 'or', label: 'Or physique', delay: '1-5 jours', fiscality: 'Taxe forfaitaire 11,5%' }
      ]
    },
    {
      id: 'moyen-terme',
      name: 'Moyen Terme (1-6 mois)',
      icon: 'ri-calendar-line',
      color: 'from-purple-500 to-purple-600',
      description: 'Mobilisable avec délais',
      assets: [
        { key: 'stocks', label: 'Actions/PEA', delay: '1-30 jours', fiscality: 'PFU 30% ou barème' },
        { key: 'pea', label: 'PEA (si >5 ans)', delay: '3-10 jours', fiscality: 'Exonéré si >5 ans' },
        { key: 'immobilierScpi', label: 'SCPI', delay: '1-6 mois', fiscality: 'Plus-values immobilières' }
      ]
    },
    {
      id: 'long-terme',
      name: 'Long Terme (6+ mois)',
      icon: 'ri-building-line',
      color: 'from-orange-500 to-orange-600',
      description: 'Mobilisable avec contraintes',
      assets: [
        { key: 'realestate', label: 'Immobilier direct', delay: '3-12 mois', fiscality: 'Plus-values immobilières' },
        { key: 'artObjets', label: 'Art & objets de collection', delay: '1-18 mois', fiscality: 'Taxe forfaitaire 6,5%' },
        { key: 'crypto', label: 'Cryptomonnaies', delay: '1-7 jours', fiscality: 'PFU 30% ou barème' }
      ]
    },
    {
      id: 'exceptionnel',
      name: 'Ressources Exceptionnelles',
      icon: 'ri-shield-line',
      color: 'from-gray-500 to-gray-600',
      description: 'Cas particuliers',
      assets: [
        { key: 'deathCapital', label: 'Capital décès', delay: '30-90 jours', fiscality: 'Exonéré sous conditions' }
      ]
    }
  ];

  const calculateStressTest = () => {
    const scenario = stressScenarios.find(s => s.id === selectedScenario);
    if (!scenario) return null;

    const results = {};
    
    // Calcul par catégorie d'actifs
    assetCategories.forEach(category => {
      const categoryResults = {
        name: category.name,
        totalGross: 0,
        totalNet: 0,
        assets: []
      };

      category.assets.forEach(asset => {
        const grossValue = stressTestParams[asset.key] || 0;
        const discountKey = `${asset.key}Discount`;
        const discount = scenario[discountKey] || 0;
        const netValue = grossValue * (1 - discount / 100);
        
        categoryResults.totalGross += grossValue;
        categoryResults.totalNet += netValue;
        categoryResults.assets.push({
          ...asset,
          grossValue,
          netValue,
          discount
        });
      });

      results[category.id] = categoryResults;
    });

    // Calcul global
    const totalGross = Object.values(results).reduce((sum, cat) => sum + cat.totalGross, 0);
    const totalNet = Object.values(results).reduce((sum, cat) => sum + cat.totalNet, 0);
    const coverage = (totalNet / stressTestParams.urgentNeed) * 100;

    // Calcul par horizon temporel
    const immediateAssets = results.liquidites.totalNet;
    const shortTermAssets = immediateAssets + results['court-terme'].totalNet;
    const mediumTermAssets = shortTermAssets + results['moyen-terme'].totalNet;
    const longTermAssets = mediumTermAssets + results['long-terme'].totalNet + results.exceptionnel.totalNet;

    return {
      scenario,
      results,
      totalGross,
      totalNet,
      coverage,
      horizons: {
        immediate: immediateAssets,
        shortTerm: shortTermAssets,
        mediumTerm: mediumTermAssets,
        longTerm: longTermAssets
      },
      coverageByHorizon: {
        immediate: (immediateAssets / stressTestParams.urgentNeed) * 100,
        shortTerm: (shortTermAssets / stressTestParams.urgentNeed) * 100,
        mediumTerm: (mediumTermAssets / stressTestParams.urgentNeed) * 100,
        longTerm: (longTermAssets / stressTestParams.urgentNeed) * 100
      }
    };
  };

  const generateRecommendations = (testResults) => {
    const recs = [];
    
    if (testResults.coverage < 80) {
      recs.push({
        type: 'warning',
        priority: 'high',
        title: 'Liquidité insuffisante',
        description: 'Votre capacité à faire face au besoin urgent est limitée',
        action: 'Augmentez vos liquidités immédiates ou constituez une réserve de précaution'
      });
    }
    
    if (testResults.horizons.immediate < stressTestParams.urgentNeed * 0.3) {
      recs.push({
        type: 'alert',
        priority: 'high',
        title: 'Liquidités immédiates faibles',
        description: 'Moins de 30% du besoin urgent est couvert par les liquidités immédiates',
        action: 'Augmentez votre épargne de précaution (livrets, comptes courants)'
      });
    }
    
    if (stressTestParams.realestate > stressTestParams.cash * 10) {
      recs.push({
        type: 'info',
        priority: 'medium',
        title: 'Patrimoine peu liquide',
        description: 'Votre patrimoine est majoritairement composé d\'actifs peu liquides',
        action: 'Diversifiez vers des actifs plus liquides (assurance-vie, obligations)'
      });
    }
    
    if (testResults.coverage > 150) {
      recs.push({
        type: 'success',
        priority: 'low',
        title: 'Excellente liquidité',
        description: 'Votre capacité de liquidité est très confortable',
        action: 'Optimisez le rendement de vos liquidités excédentaires'
      });
    }

    return recs;
  };

  const testResults = calculateStressTest();
  
  useEffect(() => {
    if (testResults) {
      setRecommendations(generateRecommendations(testResults));
    }
  }, [stressTestParams, selectedScenario]);

  return (
    <div className="space-y-8">
      <div className="bg-gray-900 border border-blue-500/20 rounded-xl p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2 flex items-center">
              <i className="ri-pulse-line text-blue-400 mr-3"></i>
              Test de Stress de Liquidité
            </h2>
            <p className="text-gray-400">
              Évaluez votre capacité à mobiliser des liquidités en cas de besoin urgent
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setShowDetails(!showDetails)}
              className={`px-4 py-2 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                showDetails ? 'bg-blue-500 text-white' : 'bg-gray-800 text-gray-300 hover:text-white'
              }`}
            >
              <i className="ri-eye-line mr-2"></i>
              {showDetails ? 'Masquer' : 'Détails'}
            </button>
          </div>
        </div>

        {/* Configuration du test */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          <div className="bg-gray-800 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
              <i className="ri-settings-3-line text-yellow-400 mr-2"></i>
              Paramètres du Test
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-gray-300 font-medium mb-2">Besoin urgent (€)</label>
                <input
                  type="number"
                  value={stressTestParams.urgentNeed}
                  onChange={(e) => setStressTestParams({...stressTestParams, urgentNeed: parseInt(e.target.value) || 0})}
                  className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white focus:border-blue-400 focus:outline-none"
                  placeholder="50000"
                />
              </div>
              <div>
                <label className="block text-gray-300 font-medium mb-2">Délai maximum (jours)</label>
                <input
                  type="number"
                  value={stressTestParams.timeframe}
                  onChange={(e) => setStressTestParams({...stressTestParams, timeframe: parseInt(e.target.value) || 0})}
                  className="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-2 text-white focus:border-blue-400 focus:outline-none"
                  placeholder="30"
                />
              </div>
            </div>
          </div>

          <div className="bg-gray-800 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
              <i className="ri-compass-3-line text-purple-400 mr-2"></i>
              Scénario de Stress
            </h3>
            <div className="grid grid-cols-3 gap-2">
              {stressScenarios.map((scenario) => (
                <button
                  key={scenario.id}
                  onClick={() => setSelectedScenario(scenario.id)}
                  className={`p-3 rounded-lg transition-all cursor-pointer ${
                    selectedScenario === scenario.id
                      ? `bg-gradient-to-r ${scenario.color} text-white transform scale-105`
                      : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                  }`}
                >
                  <div className="font-semibold text-sm">{scenario.name}</div>
                  <div className="text-xs opacity-80">{scenario.description}</div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Configuration des actifs */}
        <div className="space-y-6">
          {assetCategories.map((category) => (
            <div
              key={category.id}
              className={`bg-gradient-to-r ${category.color}/10 border border-gray-700 rounded-xl p-6`}
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-white flex items-center">
                  <i className={`${category.icon} mr-3`}></i>
                  {category.name}
                </h3>
                <span className="text-gray-400 text-sm">{category.description}</span>
              </div>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {category.assets.map((asset) => (
                  <div key={asset.key} className="bg-gray-800 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-gray-300 font-medium text-sm">{asset.label}</label>
                      {showDetails && (
                        <div className="text-xs text-gray-500">
                          {asset.delay}
                        </div>
                      )}
                    </div>
                    <input
                      type="number"
                      value={stressTestParams[asset.key] || 0}
                      onChange={(e) => setStressTestParams({
                        ...stressTestParams,
                        [asset.key]: parseInt(e.target.value) || 0
                      })}
                      className="w-full bg-gray-700 border border-gray-600 rounded-lg px-3 py-2 text-white text-sm focus:border-blue-400 focus:outline-none"
                      placeholder="0"
                    />
                    {showDetails && (
                      <div className="text-xs text-gray-500 mt-1">
                        {asset.fiscality}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Résultats du test */}
        {testResults && (
          <div className="mt-8 space-y-6">
            {/* Résumé global */}
            <div className="bg-gray-800 rounded-xl p-6">
              <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
                <i className="ri-bar-chart-line text-green-400 mr-2"></i>
                Résultats du Test - Scénario {testResults.scenario.name}
              </h3>
              
              <div className="grid md:grid-cols-4 gap-4 mb-6">
                <div className="bg-gray-700 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-blue-400 mb-1">
                    {testResults.totalGross.toLocaleString('fr-FR')} €
                  </div>
                  <div className="text-sm text-gray-400">Patrimoine brut</div>
                </div>
                <div className="bg-gray-700 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-yellow-400 mb-1">
                    {testResults.totalNet.toLocaleString('fr-FR')} €
                  </div>
                  <div className="text-sm text-gray-400">Liquidité nette</div>
                </div>
                <div className="bg-gray-700 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-red-400 mb-1">
                    {stressTestParams.urgentNeed.toLocaleString('fr-FR')} €
                  </div>
                  <div className="text-sm text-gray-400">Besoin urgent</div>
                </div>
                <div className="bg-gray-700 rounded-lg p-4 text-center">
                  <div className={`text-2xl font-bold mb-1 ${
                    testResults.coverage >= 100 ? 'text-green-400' : 
                    testResults.coverage >= 80 ? 'text-yellow-400' : 'text-red-400'
                  }`}>
                    {testResults.coverage.toFixed(1)}%
                  </div>
                  <div className="text-sm text-gray-400">Couverture</div>
                </div>
              </div>

              {/* Barre de progression de couverture */}
              <div className="mb-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-gray-300">Couverture du besoin urgent</span>
                  <span className={`font-semibold ${
                    testResults.coverage >= 100 ? 'text-green-400' : 
                    testResults.coverage >= 80 ? 'text-yellow-400' : 'text-red-400'
                  }`}>
                    {testResults.coverage.toFixed(1)}%
                  </span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-4 overflow-hidden">
                  <div 
                    className={`h-full transition-all duration-1000 ${
                      testResults.coverage >= 100 ? 'bg-gradient-to-r from-green-500 to-green-400' :
                      testResults.coverage >= 80 ? 'bg-gradient-to-r from-yellow-500 to-yellow-400' :
                      'bg-gradient-to-r from-red-500 to-red-400'
                    }`}
                    style={{ width: `${Math.min(testResults.coverage, 100)}%` }}
                  ></div>
                </div>
              </div>

              {/* Analyse par horizon temporel */}
              <div className="grid md:grid-cols-4 gap-4">
                {Object.entries(testResults.coverageByHorizon).map(([horizon, coverage], index) => {
                  const horizonLabels = {
                    immediate: 'Immédiat',
                    shortTerm: 'Court terme',
                    mediumTerm: 'Moyen terme',
                    longTerm: 'Long terme'
                  };
                  const horizonValues = {
                    immediate: testResults.horizons.immediate,
                    shortTerm: testResults.horizons.shortTerm,
                    mediumTerm: testResults.horizons.mediumTerm,
                    longTerm: testResults.horizons.longTerm
                  };
                  
                  return (
                    <div key={horizon} className="bg-gray-700 rounded-lg p-4">
                      <div className="text-center">
                        <div className={`text-lg font-bold mb-1 ${
                          coverage >= 100 ? 'text-green-400' : 
                          coverage >= 80 ? 'text-yellow-400' : 'text-red-400'
                        }`}>
                          {coverage.toFixed(0)}%
                        </div>
                        <div className="text-sm text-gray-400 mb-2">{horizonLabels[horizon]}</div>
                        <div className="text-xs text-gray-500">
                          {horizonValues[horizon].toLocaleString('fr-FR')} €
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Détail par catégorie */}
            {showDetails && (
              <div className="bg-gray-800 rounded-xl p-6">
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
                  <i className="ri-pie-chart-line text-purple-400 mr-2"></i>
                  Analyse Détaillée par Catégorie
                </h3>
                
                <div className="space-y-4">
                  {Object.entries(testResults.results).map(([categoryId, categoryData]) => {
                    const category = assetCategories.find(cat => cat.id === categoryId);
                    if (!category) return null;
                    
                    return (
                      <div key={categoryId} className="bg-gray-700 rounded-lg p-4">
                        <div className="flex items-center justify-between mb-3">
                          <h4 className="font-semibold text-white flex items-center">
                            <i className={`${category.icon} mr-2`}></i>
                            {categoryData.name}
                          </h4>
                          <div className="text-right">
                            <div className="text-white font-semibold">
                              {categoryData.totalNet.toLocaleString('fr-FR')} €
                            </div>
                            <div className="text-gray-400 text-sm">
                              Décote: {((categoryData.totalGross - categoryData.totalNet) / categoryData.totalGross * 100).toFixed(1)}%
                            </div>
                          </div>
                        </div>
                        
                        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
                          {categoryData.assets.map((asset, idx) => (
                            <div key={idx} className="bg-gray-800 rounded p-3">
                              <div className="flex items-center justify-between mb-1">
                                <span className="text-sm text-gray-300">{asset.label}</span>
                                <span className="text-sm text-red-400">-{asset.discount}%</span>
                              </div>
                              <div className="flex items-center justify-between">
                                <span className="text-xs text-gray-500">
                                  {asset.grossValue.toLocaleString('fr-FR')} €
                                </span>
                                <span className="text-sm text-white font-semibold">
                                  {asset.netValue.toLocaleString('fr-FR')} €
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Recommandations */}
            {recommendations.length > 0 && (
              <div className="bg-gray-800 rounded-xl p-6">
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
                  <i className="ri-lightbulb-line text-yellow-400 mr-2"></i>
                  Recommandations Personnalisées
                </h3>
                
                <div className="space-y-3">
                  {recommendations.map((rec, index) => (
                    <div
                      key={index}
                      className={`p-4 rounded-lg border-l-4 ${
                        rec.type === 'warning' ? 'bg-red-900/20 border-red-500' :
                        rec.type === 'alert' ? 'bg-yellow-900/20 border-yellow-500' :
                        rec.type === 'success' ? 'bg-green-900/20 border-green-500' :
                        'bg-blue-900/20 border-blue-500'
                      }`}
                    >
                      <div className="flex items-start space-x-3">
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${
                          rec.type === 'warning' ? 'bg-red-500' :
                          rec.type === 'alert' ? 'bg-yellow-500' :
                          rec.type === 'success' ? 'bg-green-500' :
                          'bg-blue-500'
                        }`}>
                          <i className={`text-white text-sm ${
                            rec.type === 'warning' ? 'ri-alert-line' :
                            rec.type === 'alert' ? 'ri-error-warning-line' :
                            rec.type === 'success' ? 'ri-check-line' :
                            'ri-information-line'
                          }`}></i>
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold text-white mb-1">{rec.title}</h4>
                          <p className="text-gray-300 text-sm mb-2">{rec.description}</p>
                          <p className="text-gray-400 text-xs">
                            <i className="ri-arrow-right-line mr-1"></i>
                            {rec.action}
                          </p>
                        </div>
                        <span className={`px-2 py-1 rounded text-xs font-medium ${
                          rec.priority === 'high' ? 'bg-red-500/20 text-red-300' :
                          rec.priority === 'medium' ? 'bg-yellow-500/20 text-yellow-300' :
                          'bg-green-500/20 text-green-300'
                        }`}>
                          {rec.priority === 'high' ? 'Urgent' : 
                           rec.priority === 'medium' ? 'Modéré' : 'Faible'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="flex space-x-4">
        <button
          onClick={() => {
            const report = {
              timestamp: new Date().toISOString(),
              scenario: testResults?.scenario.name,
              parameters: stressTestParams,
              results: testResults,
              recommendations: recommendations
            };
            console.log('Rapport de stress test généré:', report);
            alert('Rapport de stress test généré avec succès !');
          }}
          className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-300 hover:scale-105 cursor-pointer whitespace-nowrap"
        >
          <i className="ri-file-pdf-line mr-2"></i>
          Générer Rapport PDF
        </button>
        
        <button
          onClick={() => {
            setStressTestParams({
              urgentNeed: 50000,
              timeframe: 30,
              deathCapital: 100000,
              creditLine: 20000,
              cash: 15000,
              lifeInsurance: 80000,
              realestate: 200000,
              stocks: 60000,
              bonds: 40000,
              crypto: 10000,
              pea: 45000,
              livretA: 22950,
              assuranceVie: 120000,
              immobilierScpi: 75000,
              or: 25000,
              artObjets: 35000
            });
            setSelectedScenario('realiste');
          }}
          className="bg-gray-700 hover:bg-gray-600 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-300 hover:scale-105 cursor-pointer whitespace-nowrap"
        >
          <i className="ri-refresh-line mr-2"></i>
          Réinitialiser
        </button>
      </div>

      {/* Note informative */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-4 border border-blue-200">
        <div className="flex items-start space-x-3">
          <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
            <i className="ri-information-line text-blue-600"></i>
          </div>
          <div>
            <h4 className="font-semibold text-blue-900 mb-1">À propos du Test de Stress de Liquidité</h4>
            <p className="text-blue-800 text-sm">
              Ce test simule votre capacité à mobiliser des liquidités selon différents scénarios de marché.
              Il prend en compte les délais de mobilisation, la fiscalité applicable et les décotes potentielles
              en cas de cession forcée. Les résultats vous aident à optimiser votre allocation patrimoniale
              pour maintenir un niveau de liquidité adapté à vos besoins.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}