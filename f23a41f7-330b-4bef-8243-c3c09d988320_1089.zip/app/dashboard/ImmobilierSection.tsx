'use client';

import { useState } from 'react';

export default function ImmobilierSection() {
  const [activeTab, setActiveTab] = useState('overview');
  const [filters, setFilters] = useState({
    sector: 'all',
    minReturn: 'all',
    minInvestment: 'all'
  });
  const [filteredSCPIs, setFilteredSCPIs] = useState([]);
  const [showFilterResults, setShowFilterResults] = useState(false);

  // Données des SCPI complètes
  const allSCPIs = [
    {
      id: 1,
      name: 'Corum XL',
      sector: 'bureaux',
      return: 6.2,
      price: 245,
      minimum: 2450,
      available: true,
      status: 'Nouveauté',
      statusColor: 'bg-white/20',
      description: 'Bureaux Europe • Cap. 1,2 Md€',
      image: 'https://readdy.ai/api/search-image?query=modern%20office%20buildings%20in%20european%20city%20center%20glass%20architecture%20business%20district%20professional%20real%20estate%20investment%20photography%20clean%20urban%20landscape&width=400&height=200&seq=corum-xl&orientation=landscape',
      gradient: 'from-blue-500 to-indigo-600',
      bgColor: 'bg-blue-600/80',
      buttonColor: 'bg-blue-600 hover:bg-blue-700',
      iconColor: 'text-blue-600',
      icon: 'ri-building-2-line'
    },
    {
      id: 2,
      name: 'Remake Live',
      sector: 'commerces',
      return: 5.8,
      price: 198,
      minimum: 1980,
      available: false,
      status: 'Liste d\'attente',
      statusColor: 'bg-orange-500',
      description: 'Commerces • Cap. 890 M€',
      image: 'https://readdy.ai/api/search-image?query=modern%20shopping%20center%20retail%20commercial%20real%20estate%20glass%20facade%20contemporary%20architecture%20business%20investment%20property%20clean%20professional%20photography&width=400&height=200&seq=remake-live&orientation=landscape',
      gradient: 'from-emerald-500 to-green-600',
      bgColor: 'bg-emerald-600/80',
      buttonColor: 'bg-gray-300',
      iconColor: 'text-emerald-600',
      icon: 'ri-store-2-line'
    },
    {
      id: 3,
      name: 'Santé Haussmann',
      sector: 'sante',
      return: 4.7,
      price: 189,
      minimum: 1890,
      available: true,
      status: 'Performante',
      statusColor: 'bg-white/20',
      description: 'Santé • Cap. 420 M€',
      image: 'https://readdy.ai/api/search-image?query=modern%20healthcare%20facility%20medical%20center%20hospital%20building%20contemporary%20architecture%20health%20real%20estate%20investment%20clean%20professional%20medical%20environment&width=400&height=200&seq=healthcare-scpi&orientation=landscape',
      gradient: 'from-purple-500 to-violet-600',
      bgColor: 'bg-purple-600/80',
      buttonColor: 'bg-purple-600 hover:bg-purple-700',
      iconColor: 'text-purple-600',
      icon: 'ri-heart-pulse-line'
    },
    {
      id: 4,
      name: 'Notapierre',
      sector: 'residentiel',
      return: 4.9,
      price: 156,
      minimum: 1560,
      available: true,
      status: 'Équilibrée',
      statusColor: 'bg-white/20',
      description: 'Diversifiée • Cap. 650 M€',
      image: 'https://readdy.ai/api/search-image?query=modern%20residential%20apartment%20building%20luxury%20housing%20contemporary%20residential%20real%20estate%20investment%20property%20clean%20architecture%20urban%20living%20space&width=400&height=200&seq=notapierre&orientation=landscape',
      gradient: 'from-orange-500 to-amber-600',
      bgColor: 'bg-orange-600/80',
      buttonColor: 'bg-orange-600 hover:bg-orange-700',
      iconColor: 'text-orange-600',
      icon: 'ri-home-4-line'
    },
    {
      id: 5,
      name: 'Eurovalys',
      sector: 'bureaux',
      return: 5.1,
      price: 220,
      minimum: 2200,
      available: true,
      status: 'Stable',
      statusColor: 'bg-white/20',
      description: 'Bureaux France • Cap. 780 M€',
      image: 'https://readdy.ai/api/search-image?query=elegant%20french%20office%20buildings%20paris%20business%20district%20modern%20glass%20architecture%20professional%20investment%20real%20estate%20clean%20urban%20photography&width=400&height=200&seq=eurovalys&orientation=landscape',
      gradient: 'from-blue-600 to-indigo-700',
      bgColor: 'bg-blue-700/80',
      buttonColor: 'bg-blue-600 hover:bg-blue-700',
      iconColor: 'text-blue-600',
      icon: 'ri-building-2-line'
    },
    {
      id: 6,
      name: 'Corum Butler',
      sector: 'commerces',
      return: 3.8,
      price: 165,
      minimum: 1650,
      available: true,
      status: 'Prudente',
      statusColor: 'bg-white/20',
      description: 'Commerces Premium • Cap. 320 M€',
      image: 'https://readdy.ai/api/search-image?query=premium%20retail%20shopping%20district%20luxury%20commercial%20real%20estate%20modern%20storefronts%20elegant%20business%20investment%20property%20clean%20architecture&width=400&height=200&seq=corum-butler&orientation=landscape',
      gradient: 'from-emerald-600 to-teal-600',
      bgColor: 'bg-emerald-700/80',
      buttonColor: 'bg-emerald-600 hover:bg-emerald-700',
      iconColor: 'text-emerald-600',
      icon: 'ri-store-2-line'
    }
  ];

  const handleFilterChange = (filterType, value) => {
    setFilters(prev => ({
      ...prev,
      [filterType]: value
    }));
  };

  const applyFilters = () => {
    let filtered = [...allSCPIs];

    // Filtrer par secteur
    if (filters.sector !== 'all') {
      filtered = filtered.filter(scpi => scpi.sector === filters.sector);
    }

    // Filtrer par rendement minimum
    if (filters.minReturn !== 'all') {
      const minReturn = parseFloat(filters.minReturn);
      filtered = filtered.filter(scpi => scpi.return >= minReturn);
    }

    // Filtrer par investissement minimum
    if (filters.minInvestment !== 'all') {
      if (filters.minInvestment === 'low') {
        filtered = filtered.filter(scpi => scpi.minimum < 5000);
      } else if (filters.minInvestment === 'medium') {
        filtered = filtered.filter(scpi => scpi.minimum >= 5000 && scpi.minimum <= 10000);
      } else if (filters.minInvestment === 'high') {
        filtered = filtered.filter(scpi => scpi.minimum > 10000);
      }
    }

    setFilteredSCPIs(filtered);
    setShowFilterResults(true);
  };

  const resetFilters = () => {
    setFilters({
      sector: 'all',
      minReturn: 'all',
      minInvestment: 'all'
    });
    setShowFilterResults(false);
    setFilteredSCPIs([]);
  };

  const renderSCPICard = (scpi) => (
    <div key={scpi.id} className="bg-white rounded-2xl border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow">
      <div className={`h-48 bg-gradient-to-br ${scpi.gradient} relative`}
           style={{
             backgroundImage: `url('${scpi.image}')`,
             backgroundSize: 'cover',
             backgroundPosition: 'center'
           }}>
        <div className={`absolute inset-0 ${scpi.bgColor}`}></div>
        <div className="absolute top-4 left-4">
          <span className={`${scpi.statusColor} text-white px-3 py-1 rounded-full text-sm font-medium`}>{scpi.status}</span>
        </div>
        <div className="absolute bottom-4 left-4 text-white">
          <div className="text-2xl font-bold">{scpi.return}%</div>
          <div className="text-sm text-white/80">Rendement 2023</div>
        </div>
      </div>
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h4 className="text-lg font-bold text-gray-900">{scpi.name}</h4>
            <p className="text-sm text-gray-600">{scpi.description}</p>
          </div>
          <div className={`w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center`}>
            <i className={`${scpi.icon} ${scpi.iconColor} w-6 h-6 flex items-center justify-center`}></i>
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="text-center">
            <div className="text-xs text-gray-500 mb-1">Prix de part</div>
            <div className="font-semibold">{scpi.price} €</div>
          </div>
          <div className="text-center">
            <div className="text-xs text-gray-500 mb-1">Minimum</div>
            <div className="font-semibold">{scpi.minimum.toLocaleString()} €</div>
          </div>
          <div className="text-center">
            <div className="text-xs text-gray-500 mb-1">Disponibilité</div>
            <div className={`font-semibold text-sm ${scpi.available ? 'text-green-600' : 'text-orange-600'}`}>
              {scpi.available ? '✓ Oui' : '⏳ Attente'}
            </div>
          </div>
        </div>

        <div className="flex space-x-3">
          <button className={`flex-1 ${scpi.available ? scpi.buttonColor : 'bg-gray-300 cursor-not-allowed'} text-white py-3 px-4 rounded-xl font-medium transition-colors cursor-pointer whitespace-nowrap`}>
            {scpi.available ? 'Investir' : 'Liste d\'attente'}
          </button>
          <button className="px-4 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap">
            <i className="ri-information-line w-5 h-5 flex items-center justify-center"></i>
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-8">
      {/* Header avec gradient */}
      <div className="relative overflow-hidden bg-gradient-to-br from-emerald-500 via-teal-600 to-cyan-700 rounded-2xl p-8 text-white"
           style={{
             backgroundImage: `url('https://readdy.ai/api/search-image?query=modern%20luxury%20real%20estate%20cityscape%22with%20glass%20buildings%20and%20green%20spaces%20elegant%20architectural%20photography%20professional%20investment%20atmosphere%20clean%20minimalist%20background%20high%20quality&width=1200&height=400&seq=immobilier-hero&orientation=landscape')`,
             backgroundSize: 'cover',
             backgroundPosition: 'center'
           }}>
        <div className="absolute inset-0 bg-gradient-to-r from-emerald-600/90 to-teal-700/80"></div>
        <div className="relative z-10">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Immobilier & SCPI</h1>
              <p className="text-emerald-100 text-lg">Diversifiez votre patrimoine avec l'immobilier d'investissement</p>
            </div>
            <div className="text-right">
              <div className="text-4xl font-bold">185 400 €</div>
              <div className="text-emerald-200">Valorisation totale</div>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation moderne avec design pills */}
      <div className="flex space-x-2 bg-gray-100 p-2 rounded-2xl">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-6 py-3 rounded-xl font-medium text-sm transition-all duration-200 cursor-pointer whitespace-nowrap ${
            activeTab === 'overview'
              ? 'bg-white text-gray-900 shadow-md'
              : 'text-gray-600 hover:text-gray-900 hover:bg-white/50'
          }`}
        >
          <span className="flex items-center space-x-2">
            <i className="ri-dashboard-3-line w-4 h-4 flex items-center justify-center"></i>
            <span>Vue d'ensemble</span>
          </span>
        </button>
        <button
          onClick={() => setActiveTab('portfolio')}
          className={`px-6 py-3 rounded-xl font-medium text-sm transition-all duration-200 cursor-pointer whitespace-nowrap ${
            activeTab === 'portfolio'
              ? 'bg-white text-gray-900 shadow-md'
              : 'text-gray-600 hover:text-gray-900 hover:bg-white/50'
          }`}
        >
          <span className="flex items-center space-x-2">
            <i className="ri-building-line w-4 h-4 flex items-center justify-center"></i>
            <span>Mon portefeuille</span>
          </span>
        </button>
        <button
          onClick={() => setActiveTab('marketplace')}
          className={`px-6 py-3 rounded-xl font-medium text-sm transition-all duration-200 cursor-pointer whitespace-nowrap ${
            activeTab === 'marketplace'
              ? 'bg-white text-gray-900 shadow-md'
              : 'text-gray-600 hover:text-gray-900 hover:bg-white/50'
          }`}
        >
          <span className="flex items-center space-x-2">
            <i className="ri-store-2-line w-4 h-4 flex items-center justify-center"></i>
            <span>Marketplace</span>
          </span>
        </button>
        <button
          onClick={() => setActiveTab('analysis')}
          className={`px-6 py-3 rounded-xl font-medium text-sm transition-all duration-200 cursor-pointer whitespace-nowrap ${
            activeTab === 'analysis'
              ? 'bg-white text-gray-900 shadow-md'
              : 'text-gray-600 hover:text-gray-900 hover:bg-white/50'
          }`}
        >
          <span className="flex items-center space-x-2">
            <i className="ri-bar-chart-box-line w-4 h-4 flex items-center justify-center"></i>
            <span>Analyses</span>
          </span>
        </button>
      </div>

      {/* Vue d'ensemble */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          {/* KPIs avec design moderne */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-gradient-to-br from-blue-50 to-indigo-100 p-6 rounded-2xl border border-blue-200">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center">
                  <i className="ri-money-euro-circle-line text-white text-xl w-6 h-6 flex items-center justify-center"></i>
                </div>
                <div className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">+2.4%</div>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">185 400 €</div>
              <div className="text-sm text-gray-600">Valeur totale</div>
            </div>

            <div className="bg-gradient-to-br from-emerald-50 to-green-100 p-6 rounded-2xl border border-emerald-200">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-emerald-500 rounded-xl flex items-center justify-center">
                  <i className="ri-line-chart-line text-white text-xl w-6 h-6 flex items-center justify-center"></i>
                </div>
                <div className="text-xs bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full">5.2%</div>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">9 640 €</div>
              <div className="text-sm text-gray-600">Revenus annuels</div>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-violet-100 p-6 rounded-2xl border border-purple-200">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-purple-500 rounded-xl flex items-center justify-center">
                  <i className="ri-pie-chart-2-line text-white text-xl w-6 h-6 flex items-center justify-center"></i>
                </div>
                <div className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded-full">4 SCPI</div>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">847</div>
              <div className="text-sm text-gray-600">Parts détenues</div>
            </div>

            <div className="bg-gradient-to-br from-orange-50 to-amber-100 p-6 rounded-2xl border border-orange-200">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-orange-500 rounded-xl flex items-center justify-center">
                  <i className="ri-wallet-3-line text-white text-xl w-6 h-6 flex items-center justify-center"></i>
                </div>
                <div className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Disponible</div>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">12 600 €</div>
              <div className="text-sm text-gray-600">Liquidités</div>
            </div>
          </div>

          {/* Répartition par secteur */}
          <div className="bg-white rounded-2xl border border-gray-200 p-8">
            <h3 className="text-xl font-bold text-gray-900 mb-6">Répartition par secteur</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-blue-400 to-blue-600 rounded-2xl mx-auto mb-4 flex items-center justify-center">
                  <i className="ri-building-2-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
                </div>
                <div className="font-semibold text-gray-900">Bureaux</div>
                <div className="text-2xl font-bold text-blue-600">36%</div>
                <div className="text-sm text-gray-500">67 200 €</div>
              </div>
              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-emerald-400 to-emerald-600 rounded-2xl mx-auto mb-4 flex items-center justify-center">
                  <i className="ri-store-2-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
                </div>
                <div className="font-semibold text-gray-900">Commerces</div>
                <div className="text-2xl font-bold text-emerald-600">25%</div>
                <div className="text-sm text-gray-500">45 540 €</div>
              </div>
              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-purple-400 to-purple-600 rounded-2xl mx-auto mb-4 flex items-center justify-center">
                  <i className="ri-heart-pulse-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
                </div>
                <div className="font-semibold text-gray-900">Santé</div>
                <div className="text-2xl font-bold text-purple-600">21%</div>
                <div className="text-sm text-gray-500">39 820 €</div>
              </div>
              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-orange-400 to-orange-600 rounded-2xl mx-auto mb-4 flex items-center justify-center">
                  <i className="ri-home-4-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
                </div>
                <div className="font-semibold text-gray-900">Résidentiel</div>
                <div className="text-2xl font-bold text-orange-600">18%</div>
                <div className="text-sm text-gray-500">32 840 €</div>
              </div>
            </div>
          </div>

          {/* Actions rapides */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white p-6 rounded-2xl transition-all duration-200 cursor-pointer whitespace-nowrap">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <i className="ri-add-line text-white text-2xl w-6 h-6 flex items-center justify-center"></i>
                </div>
                <div className="text-left">
                  <div className="font-semibold">Nouvel investissement</div>
                  <div className="text-sm text-blue-100">Explorer les SCPI</div>
                </div>
              </div>
            </button>
            
            <button className="bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 text-white p-6 rounded-2xl transition-all duration-200 cursor-pointer whitespace-nowrap">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <i className="ri-calculator-line text-white text-2xl w-6 h-6 flex items-center justify-center"></i>
                </div>
                <div className="text-left">
                  <div className="font-semibold">Simulateur</div>
                  <div className="text-sm text-emerald-100">Calculer rendement</div>
                </div>
              </div>
            </button>

            <button className="bg-gradient-to-r from-purple-600 to-violet-600 hover:from-purple-700 hover:to-violet-700 text-white p-6 rounded-2xl transition-all duration-200 cursor-pointer whitespace-nowrap">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
                  <i className="ri-file-chart-line text-white text-2xl w-6 h-6 flex items-center justify-center"></i>
                </div>
                <div className="text-left">
                  <div className="font-semibold">Rapport mensuel</div>
                  <div className="text-sm text-purple-100">Télécharger PDF</div>
                </div>
              </div>
            </button>
          </div>
        </div>
      )}

      {/* Mon portefeuille */}
      {activeTab === 'portfolio' && (
        <div className="space-y-8">
          {/* Performance du portefeuille */}
          <div className="bg-white rounded-2xl border border-gray-200 p-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-900">Performance du portefeuille</h3>
              <div className="flex space-x-2">
                <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm cursor-pointer whitespace-nowrap">1M</button>
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm cursor-pointer whitespace-nowrap">3M</button>
                <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm cursor-pointer whitespace-nowrap">1A</button>
              </div>
            </div>
            
            <div className="h-64 bg-gradient-to-t from-blue-50 to-transparent rounded-xl flex items-end justify-center">
              <div className="text-gray-500 text-center">
                <i className="ri-line-chart-line text-4xl mb-2 w-12 h-12 flex items-center justify-center mx-auto"></i>
                <div className="text-sm">Graphique de performance</div>
              </div>
            </div>
          </div>

          {/* Mes investissements avec design amélioré */}
          <div className="bg-white rounded-2xl border border-gray-200 p-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-900">Mes investissements SCPI</h3>
              <button className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 cursor-pointer whitespace-nowrap">
                <span className="text-sm font-medium">Gérer</span>
                <i className="ri-settings-3-line w-4 h-4 flex items-center justify-center"></i>
              </button>
            </div>
            
            <div className="space-y-4">
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center">
                      <i className="ri-building-2-line text-white w-6 h-6 flex items-center justify-center"></i>
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">Corum Origin</div>
                      <div className="text-sm text-gray-600">Bureaux Europe • 285 parts</div>
                      <div className="flex items-center space-x-2 mt-1">
                        <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">+3.2%</span>
                        <span className="text-xs text-gray-500">ce mois</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xl font-bold text-gray-900">67 200 €</div>
                    <div className="text-sm text-gray-500">Rendement 5.8%</div>
                    <div className="text-xs text-green-600 font-medium">+2 040 € cette année</div>
                  </div>
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-emerald-50 to-green-50 border border-emerald-200 rounded-xl p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-green-600 rounded-xl flex items-center justify-center">
                      <i className="ri-store-2-line text-white w-6 h-6 flex items-center justify-center"></i>
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">Primopierre</div>
                      <div className="text-sm text-gray-600">Commerces France • 198 parts</div>
                      <div className="flex items-center space-x-2 mt-1">
                        <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">+1.8%</span>
                        <span className="text-xs text-gray-500">ce mois</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xl font-bold text-gray-900">45 540 €</div>
                    <div className="text-sm text-gray-500">Rendement 4.2%</div>
                    <div className="text-xs text-green-600 font-medium">+1 913 € cette année</div>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-purple-50 to-violet-50 border border-purple-200 rounded-xl p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-violet-600 rounded-xl flex items-center justify-center">
                      <i className="ri-heart-pulse-line text-white w-6 h-6 flex items-center justify-center"></i>
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">Immorente</div>
                      <div className="text-sm text-gray-600">Santé • 222 parts</div>
                      <div className="flex items-center space-x-2 mt-1">
                        <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">+2.1%</span>
                        <span className="text-xs text-gray-500">ce mois</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xl font-bold text-gray-900">39 820 €</div>
                    <div className="text-sm text-gray-500">Rendement 4.7%</div>
                    <div className="text-xs text-green-600 font-medium">+1 872 € cette année</div>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-orange-50 to-amber-50 border border-orange-200 rounded-xl p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-amber-600 rounded-xl flex items-center justify-center">
                      <i className="ri-home-4-line text-white w-6 h-6 flex items-center justify-center"></i>
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">Épargne Foncière</div>
                      <div className="text-sm text-gray-600">Résidentiel • 142 parts</div>
                      <div className="flex items-center space-x-2 mt-1">
                        <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded-full">-0.5%</span>
                        <span className="text-xs text-gray-500">ce mois</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xl font-bold text-gray-900">32 840 €</div>
                    <div className="text-sm text-gray-500">Rendement 3.9%</div>
                    <div className="text-xs text-green-600 font-medium">+1 281 € cette année</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Marketplace */}
      {activeTab === 'marketplace' && (
        <div className="space-y-8">
          {/* Filtres */}
          <div className="bg-white rounded-2xl border border-gray-200 p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Secteur</label>
                <select 
                  value={filters.sector}
                  onChange={(e) => handleFilterChange('sector', e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm pr-8"
                >
                  <option value="all">Tous secteurs</option>
                  <option value="bureaux">Bureaux</option>
                  <option value="commerces">Commerces</option>
                  <option value="sante">Santé</option>
                  <option value="residentiel">Résidentiel</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Rendement min.</label>
                <select 
                  value={filters.minReturn}
                  onChange={(e) => handleFilterChange('minReturn', e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm pr-8"
                >
                  <option value="all">Tous</option>
                  <option value="3">3%+</option>
                  <option value="4">4%+</option>
                  <option value="5">5%+</option>
                  <option value="6">6%+</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Investissement min.</label>
                <select 
                  value={filters.minInvestment}
                  onChange={(e) => handleFilterChange('minInvestment', e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm pr-8"
                >
                  <option value="all">Tous</option>
                  <option value="low">Moins de 5K€</option>
                  <option value="medium">5K€ - 10K€</option>
                  <option value="high">Plus de 10K€</option>
                </select>
              </div>
              <div className="flex items-end space-x-2">
                <button 
                  onClick={applyFilters}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg text-sm transition-colors cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-filter-line mr-2"></i>
                  Filtrer
                </button>
                {showFilterResults && (
                  <button 
                    onClick={resetFilters}
                    className="px-3 py-2 border border-gray-300 text-gray-600 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap"
                    title="Réinitialiser les filtres"
                  >
                    <i className="ri-refresh-line w-4 h-4 flex items-center justify-center"></i>
                  </button>
                )}
              </div>
            </div>

            {/* Résultats de filtrage */}
            {showFilterResults && (
              <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <i className="ri-filter-2-line text-blue-600"></i>
                    <span className="text-sm font-medium text-blue-900">
                      {filteredSCPIs.length} SCPI{filteredSCPIs.length > 1 ? 's' : ''} trouvée{filteredSCPIs.length > 1 ? 's' : ''}
                    </span>
                  </div>
                  <div className="flex items-center space-x-4 text-xs text-blue-700">
                    {filters.sector !== 'all' && (
                      <span className="bg-blue-100 px-2 py-1 rounded-full">
                        {filters.sector === 'bureaux' ? 'Bureaux' : 
                         filters.sector === 'commerces' ? 'Commerces' :
                         filters.sector === 'sante' ? 'Santé' : 'Résidentiel'}
                      </span>
                    )}
                    {filters.minReturn !== 'all' && (
                      <span className="bg-green-100 text-green-700 px-2 py-1 rounded-full">
                        Rendement {filters.minReturn}%+
                      </span>
                    )}
                    {filters.minInvestment !== 'all' && (
                      <span className="bg-purple-100 text-purple-700 px-2 py-1 rounded-full">
                        {filters.minInvestment === 'low' ? '< 5K€' :
                         filters.minInvestment === 'medium' ? '5-10K€' : '> 10K€'}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Affichage des SCPI */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {showFilterResults ? (
              filteredSCPIs.length > 0 ? (
                filteredSCPIs.map(renderSCPICard)
              ) : (
                <div className="col-span-2 text-center py-12">
                  <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className="ri-search-line text-gray-400 text-2xl w-8 h-8 flex items-center justify-center"></i>
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Aucune SCPI trouvée</h3>
                  <p className="text-gray-500 mb-4">Essayez de modifier vos critères de recherche</p>
                  <button 
                    onClick={resetFilters}
                    className="text-blue-600 hover:text-blue-700 font-medium cursor-pointer whitespace-nowrap"
                  >
                    Voir toutes les SCPI
                  </button>
                </div>
              )
            ) : (
              // Affichage par défaut (4 premières SCPI)
              allSCPIs.slice(0, 4).map(renderSCPICard)
            )}
          </div>

          {/* Afficher plus */}
          {!showFilterResults && (
            <div className="text-center">
              <button 
                onClick={() => {
                  setFilteredSCPIs(allSCPIs);
                  setShowFilterResults(true);
                }}
                className="text-blue-600 hover:text-blue-700 font-medium cursor-pointer whitespace-nowrap"
              >
                <i className="ri-arrow-down-line mr-2"></i>
                Voir toutes les SCPI disponibles ({allSCPIs.length})
              </button>
            </div>
          )}
        </div>
      )}

      {/* Analyses */}
      {activeTab === 'analysis' && (
        <div className="space-y-8">
          {/* Tendances du marché */}
          <div className="bg-white rounded-2xl border border-gray-200 p-8">
            <h3 className="text-xl font-bold text-gray-900 mb-6">Tendances du marché 2024</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200 rounded-xl p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center">
                    <i className="ri-arrow-up-line text-white w-5 h-5 flex items-center justify-center"></i>
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900">Secteur en hausse</div>
                    <div className="text-sm text-gray-600">Bureaux flexibles</div>
                  </div>
                </div>
                <p className="text-sm text-gray-600 mb-3">La demande pour les espaces de coworking et bureaux modulables continue de croître, portée par les nouvelles façons de travailler.</p>
                <div className="text-2xl font-bold text-green-600">+15%</div>
                <div className="text-sm text-gray-500">Croissance prévue</div>
              </div>

              <div className="bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                    <i className="ri-shield-check-line text-white w-5 h-5 flex items-center justify-center"></i>
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900">Secteur résilient</div>
                    <div className="text-sm text-gray-600">Santé & Senior</div>
                  </div>
                </div>
                <p className="text-sm text-gray-600 mb-3">Le vieillissement démographique soutient durablement la demande en établissements de santé et résidences seniors.</p>
                <div className="text-2xl font-bold text-blue-600">4.8%</div>
                <div className="text-sm text-gray-500">Rendement moyen</div>
              </div>

              <div className="bg-gradient-to-br from-orange-50 to-amber-50 border border-orange-200 rounded-xl p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center">
                    <i className="ri-refresh-line text-white w-5 h-5 flex items-center justify-center"></i>
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900">Secteur en mutation</div>
                    <div className="text-sm text-gray-600">Commerce</div>
                  </div>
                </div>
                <p className="text-sm text-gray-600 mb-3">Le commerce physique s'adapte avec de nouveaux concepts (click & collect, showrooms) pour rester attractif.</p>
                <div className="text-2xl font-bold text-orange-600">3.2%</div>
                <div className="text-sm text-gray-500">Rendement ajusté</div>
              </div>

              <div className="bg-gradient-to-br from-purple-50 to-violet-50 border border-purple-200 rounded-xl p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center">
                    <i className="ri-bar-chart-box-line text-white w-5 h-5 flex items-center justify-center"></i>
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900">Performance 2023</div>
                    <div className="text-sm text-gray-600">Global SCPI</div>
                  </div>
                </div>
                <p className="text-sm text-gray-600 mb-3">Les SCPI affichent une performance globale positive malgré un contexte économique incertain.</p>
                <div className="text-2xl font-bold text-purple-600">4.6%</div>
                <div className="text-sm text-gray-500">Rendement moyen</div>
              </div>
            </div>
          </div>

          {/* Recommandations d'allocation */}
          <div className="bg-white rounded-2xl border border-gray-200 p-8">
            <h3 className="text-xl font-bold text-gray-900 mb-6">Recommandations d'allocation par profil</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-green-400 to-emerald-500 rounded-2xl mx-auto mb-4 flex items-center justify-center">
                  <i className="ri-shield-check-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
                </div>
                <h4 className="font-bold text-gray-900 mb-4">Profil Prudent</h4>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Bureaux premium</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-16 h-2 bg-blue-200 rounded-full">
                        <div className="w-2/5 h-full bg-blue-500 rounded-full"></div>
                      </div>
                      <span className="text-sm font-medium">40%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Santé</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-16 h-2 bg-purple-200 rounded-full">
                        <div className="w-3/10 h-full bg-purple-500 rounded-full"></div>
                      </div>
                      <span className="text-sm font-medium">30%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Diversifiée</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-16 h-2 bg-gray-200 rounded-full">
                        <div className="w-3/10 h-full bg-gray-500 rounded-full"></div>
                      </div>
                      <span className="text-sm font-medium">30%</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-blue-400 to-indigo-500 rounded-2xl mx-auto mb-4 flex items-center justify-center">
                  <i className="ri-scales-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
                </div>
                <h4 className="font-bold text-gray-900 mb-4">Profil Équilibré</h4>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Bureaux</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-16 h-2 bg-blue-200 rounded-full">
                        <div className="w-1/2 h-full bg-blue-500 rounded-full"></div>
                      </div>
                      <span className="text-sm font-medium">50%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Commerces</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-16 h-2 bg-emerald-200 rounded-full">
                        <div className="w-1/4 h-full bg-emerald-500 rounded-full"></div>
                      </div>
                      <span className="text-sm font-medium">25%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Santé</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-16 h-2 bg-purple-200 rounded-full">
                        <div className="w-1/4 h-full bg-purple-500 rounded-full"></div>
                      </div>
                      <span className="text-sm font-medium">25%</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-orange-400 to-red-500 rounded-2xl mx-auto mb-4 flex items-center justify-center">
                  <i className="ri-rocket-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
                </div>
                <h4 className="font-bold text-gray-900 mb-4">Profil Dynamique</h4>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Bureaux Europe</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-16 h-2 bg-blue-200 rounded-full">
                        <div className="w-3/5 h-full bg-blue-500 rounded-full"></div>
                      </div>
                      <span className="text-sm font-medium">60%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Spécialisée</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-16 h-2 bg-orange-200 rounded-full">
                        <div className="w-1/4 h-full bg-orange-500 rounded-full"></div>
                      </div>
                      <span className="text-sm font-medium">25%</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Émergente</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-16 h-2 bg-red-200 rounded-full">
                        <div className="w-15/100 h-full bg-red-500 rounded-full"></div>
                      </div>
                      <span className="text-sm font-medium">15%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Performance comparative */}
          <div className="bg-white rounded-2xl border border-gray-200 p-8">
            <h3 className="text-xl font-bold text-gray-900 mb-6">Performance comparative par secteur</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center">
                    <i className="ri-building-2-line text-white w-6 h-6 flex items-center justify-center"></i>
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900">Bureaux Europe</div>
                    <div className="text-sm text-gray-600">Performance 2023</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xl font-bold text-green-600">+5.8%</div>
                  <div className="text-sm text-gray-500">vs +4.2% en 2022</div>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 bg-gradient-to-r from-emerald-50 to-green-50 rounded-xl">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-emerald-500 rounded-xl flex items-center justify-center">
                    <i className="ri-heart-pulse-line text-white w-6 h-6 flex items-center justify-center"></i>
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900">Santé & Senior</div>
                    <div className="text-sm text-gray-600">Performance 2023</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xl font-bold text-green-600">+4.9%</div>
                  <div className="text-sm text-gray-500">vs +4.1% en 2022</div>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 bg-gradient-to-r from-purple-50 to-violet-50 rounded-xl">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-purple-500 rounded-xl flex items-center justify-center">
                    <i className="ri-store-2-line text-white w-6 h-6 flex items-center justify-center"></i>
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900">Commerces</div>
                    <div className="text-sm text-gray-600">Performance 2023</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xl font-bold text-green-600">+3.2%</div>
                  <div className="text-sm text-gray-500">vs +2.8% en 2022</div>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 bg-gradient-to-r from-orange-50 to-amber-50 rounded-xl">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-orange-500 rounded-xl flex items-center justify-center">
                    <i className="ri-home-4-line text-white w-6 h-6 flex items-center justify-center"></i>
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900">Résidentiel</div>
                    <div className="text-sm text-gray-600">Performance 2023</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xl font-bold text-red-600">-1.2%</div>
                  <div className="text-sm text-gray-500">vs +1.5% en 2022</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}