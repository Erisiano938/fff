
'use client';

import { useState } from 'react';
import Link from 'next/link';
import AssetAllocation from './AssetAllocation';
import PortfolioChart from './PortfolioChart';
import RecentTransactions from './RecentTransactions';

export default function DashboardOverview() {
  const [selectedPeriod, setSelectedPeriod] = useState('6M');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* En-tête principal style moderne inspiré de l'image */}
        <div className="bg-white rounded-3xl shadow-2xl border border-slate-200/50 overflow-hidden">
          <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 p-8 text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-emerald-500/20 to-transparent rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-gradient-to-tr from-blue-500/20 to-transparent rounded-full blur-2xl"></div>
            
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-3 h-3 bg-emerald-400 rounded-full animate-pulse"></div>
                <span className="text-emerald-400 text-sm font-medium">Temps réel</span>
                <span className="text-slate-400">•</span>
                <span className="text-slate-400 text-sm">Vendredi 23 juillet</span>
                <span className="text-slate-400">•</span>
                <span className="text-slate-400 text-sm">12:45</span>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center">
                <div className="lg:col-span-2">
                  <h1 className="text-7xl font-bold mb-4 bg-gradient-to-r from-white via-emerald-200 to-white bg-clip-text text-transparent">
                    285 000 €
                  </h1>
                  <p className="text-xl text-slate-300 mb-6">Patrimoine financier total</p>
                  
                  <div className="flex flex-wrap items-center gap-4">
                    <div className="flex items-center gap-2 bg-emerald-500/20 px-6 py-3 rounded-full border border-emerald-500/30 backdrop-blur-sm">
                      <i className="ri-arrow-up-line text-emerald-400 text-lg"></i>
                      <span className="text-emerald-400 font-semibold text-lg">+36 500 € (+12,8%)</span>
                    </div>
                    <span className="text-slate-400 text-lg">depuis le début d'année</span>
                  </div>
                </div>

                {/* Métriques rapides redesignées */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-5 border border-white/20 hover:bg-white/15 transition-all duration-300">
                    <div className="flex items-center gap-2 mb-3">
                      <i className="ri-arrow-up-line text-emerald-400 text-lg"></i>
                      <span className="text-emerald-400 text-sm font-semibold">+12,4%</span>
                    </div>
                    <div className="text-3xl font-bold text-white mb-1">63 000 €</div>
                    <div className="text-xs text-slate-300">Revenus quotidiens</div>
                  </div>
                  
                  <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-5 border border-white/20 hover:bg-white/15 transition-all duration-300">
                    <div className="flex items-center gap-2 mb-3">
                      <i className="ri-arrow-down-line text-orange-400 text-lg"></i>
                      <span className="text-orange-400 text-sm font-semibold">-3,9%</span>
                    </div>
                    <div className="text-3xl font-bold text-white mb-1">42 000 €</div>
                    <div className="text-xs text-slate-300">Revenus hebdomadaires</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Sélecteur de période amélioré */}
          <div className="p-6 bg-white border-b border-slate-200">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold text-slate-800">Statistiques de performance</h3>
              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl shadow-inner">
                {['Tout', 'Cette année', 'Cette semaine', 'Aujourd\'hui'].map((period, index) => (
                  <button
                    key={period}
                    className={`px-5 py-2 text-sm font-medium rounded-lg transition-all duration-300 ${
                      index === 0 
                        ? 'bg-emerald-500 text-white shadow-lg transform scale-105' 
                        : 'text-slate-600 hover:text-slate-800 hover:bg-slate-200 hover:scale-105'
                    }`}
                  >
                    {period}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Graphique principal redesigné */}
          <div className="p-8 bg-white">
            <div className="relative h-96 bg-gradient-to-br from-slate-50 via-white to-slate-100 rounded-3xl p-8 overflow-hidden shadow-inner border border-slate-200/50">
              {/* Grille de fond améliorée */}
              <div className="absolute inset-0 opacity-20">
                {[...Array(6)].map((_, i) => (
                  <div 
                    key={i} 
                    className="absolute w-full border-t border-slate-400"
                    style={{ top: `${(i + 1) * 16.66}%` }}
                  ></div>
                ))}
                {[...Array(8)].map((_, i) => (
                  <div 
                    key={i} 
                    className="absolute h-full border-l border-slate-400"
                    style={{ left: `${(i + 1) * 12.5}%` }}
                  ></div>
                ))}
              </div>

              {/* Courbes de performance améliorées */}
              <svg className="w-full h-full relative z-10" viewBox="0 0 400 250">
                <defs>
                  <linearGradient id="orangeGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#F97316" stopOpacity="0.4"/>
                    <stop offset="100%" stopColor="#F97316" stopOpacity="0"/>
                  </linearGradient>
                  <linearGradient id="blueGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#3B82F6" stopOpacity="0.3"/>
                    <stop offset="100%" stopColor="#3B82F6" stopOpacity="0"/>
                  </linearGradient>
                  <filter id="glow">
                    <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
                    <feMerge> 
                      <feMergeNode in="coloredBlur"/>
                      <feMergeNode in="SourceGraphic"/>
                    </feMerge>
                  </filter>
                </defs>
                
                {/* Courbe orange (Produits vendus) */}
                <path
                  d="M 0 200 Q 50 180 100 150 T 200 100 T 300 70 T 400 50"
                  stroke="#F97316"
                  strokeWidth="4"
                  fill="none"
                  filter="url(#glow)"
                  className="drop-shadow-lg"
                />
                <path
                  d="M 0 200 Q 50 180 100 150 T 200 100 T 300 70 T 400 50 L 400 250 L 0 250 Z"
                  fill="url(#orangeGradient)"
                />
                
                {/* Courbe bleue (Vues totales) */}
                <path
                  d="M 0 220 Q 50 210 100 180 T 200 160 T 300 140 T 400 120"
                  stroke="#3B82F6"
                  strokeWidth="4"
                  fill="none"
                  filter="url(#glow)"
                  className="drop-shadow-lg"
                />
                <path
                  d="M 0 220 Q 50 210 100 180 T 200 160 T 300 140 T 400 120 L 400 250 L 0 250 Z"
                  fill="url(#blueGradient)"
                />

                {/* Points de données améliorés */}
                {[
                  { x: 100, y: 150, color: '#F97316' },
                  { x: 200, y: 100, color: '#F97316' },
                  { x: 300, y: 70, color: '#F97316' },
                  { x: 400, y: 50, color: '#F97316' }
                ].map((point, index) => (
                  <g key={index}>
                    <circle
                      cx={point.x}
                      cy={point.y}
                      r="8"
                      fill="white"
                      stroke={point.color}
                      strokeWidth="3"
                      className="drop-shadow-lg"
                    />
                    <circle
                      cx={point.x}
                      cy={point.y}
                      r="4"
                      fill={point.color}
                    />
                  </g>
                ))}
              </svg>

              {/* Légende améliorée */}
              <div className="absolute bottom-6 left-6 flex items-center gap-8">
                <div className="flex items-center gap-3 bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg">
                  <div className="w-4 h-4 bg-orange-500 rounded-full shadow-sm"></div>
                  <span className="text-sm text-slate-700 font-semibold">Produits vendus</span>
                </div>
                <div className="flex items-center gap-3 bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg">
                  <div className="w-4 h-4 bg-blue-500 rounded-full shadow-sm"></div>
                  <span className="text-sm text-slate-700 font-semibold">Vues totales</span>
                </div>
              </div>

              {/* Indicateur de croissance amélioré */}
              <div className="absolute top-6 right-6 bg-white/95 backdrop-blur-sm rounded-2xl p-4 shadow-xl border border-emerald-200">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-emerald-100 rounded-full flex items-center justify-center">
                    <i className="ri-arrow-up-line text-emerald-600 text-lg"></i>
                  </div>
                  <div>
                    <div className="text-emerald-600 font-bold text-lg">+10,34%</div>
                    <div className="text-slate-500 text-xs">Croissance</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Métriques détaillées redesignées */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              title: 'Chiffre d\'affaires total',
              value: '123 457€',
              change: '+3,48%',
              changeType: 'positive',
              subtitle: 'Depuis le mois dernier',
              icon: 'ri-money-dollar-circle-fill',
              color: 'emerald',
              bgGradient: 'from-emerald-50 to-emerald-100'
            },
            {
              title: 'Revenus',
              value: '2 345€',
              change: '-1,6%',
              changeType: 'negative',
              subtitle: 'Depuis le mois dernier',
              icon: 'ri-line-chart-fill',
              color: 'orange',
              bgGradient: 'from-orange-50 to-orange-100'
            },
            {
              title: 'Ventes',
              value: '924',
              change: '+3,48%',
              changeType: 'positive',
              subtitle: 'Depuis le mois dernier',
              icon: 'ri-shopping-cart-fill',
              color: 'blue',
              bgGradient: 'from-blue-50 to-blue-100'
            },
            {
              title: 'Revenus totaux',
              value: '48,65%',
              change: '+3,48%',
              changeType: 'positive',
              subtitle: 'Depuis le mois dernier',
              icon: 'ri-pie-chart-fill',
              color: 'purple',
              bgGradient: 'from-purple-50 to-purple-100'
            }
          ].map((metric, index) => (
            <div key={index} className={`bg-gradient-to-br ${metric.bgGradient} rounded-3xl p-6 shadow-xl border border-white/50 hover:shadow-2xl hover:scale-105 transition-all duration-500 group relative overflow-hidden`}>
              <div className="absolute top-0 right-0 w-20 h-20 bg-white/20 rounded-full blur-xl"></div>
              
              <div className="relative z-10">
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-14 h-14 bg-${metric.color}-500 rounded-2xl flex items-center justify-center group-hover:scale-110 group-hover:rotate-6 transition-all duration-500 shadow-lg`}>
                    <i className={`${metric.icon} text-white text-2xl`}></i>
                  </div>
                  <div className={`text-sm px-4 py-2 rounded-full font-bold shadow-sm ${
                    metric.changeType === 'positive' 
                      ? 'bg-emerald-500 text-white' 
                      : 'bg-red-500 text-white'
                  }`}>
                    {metric.change}
                  </div>
                </div>
                
                <div className="text-3xl font-bold text-slate-800 mb-2">{metric.value}</div>
                <div className="text-sm font-semibold text-slate-700 mb-1">{metric.title}</div>
                <div className="text-xs text-slate-600">{metric.subtitle}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Section répartition et graphique circulaire redesignée */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* Répartition des ventes redesignée */}
          <div className="bg-white rounded-3xl shadow-xl border border-slate-200/50 overflow-hidden">
            <div className="p-6 border-b border-slate-200 bg-gradient-to-r from-slate-50 to-white">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-slate-800">Répartition des ventes</h3>
                <select className="text-sm border border-slate-300 rounded-xl px-4 py-2 bg-white shadow-sm hover:shadow-md transition-shadow duration-300">
                  <option>Europe</option>
                  <option>Amérique</option>
                  <option>Asie</option>
                </select>
              </div>
            </div>
            
            <div className="p-8">
              <div className="relative w-56 h-56 mx-auto mb-8">
                {/* Graphique circulaire amélioré */}
                <div className="absolute inset-0 rounded-full bg-gradient-to-br from-slate-100 to-slate-200 shadow-inner"></div>
                <div className="absolute inset-6 rounded-full bg-white shadow-2xl"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-slate-800 mb-1">14 078</div>
                    <div className="text-sm text-slate-600 font-medium">Ventes totales</div>
                  </div>
                </div>
                
                {/* Segments colorés améliorés */}
                <div className="absolute top-0 left-1/2 w-3 h-28 bg-gradient-to-t from-orange-400 to-orange-600 rounded-full transform -translate-x-1/2 origin-bottom rotate-45 shadow-lg"></div>
                <div className="absolute top-0 left-1/2 w-3 h-28 bg-gradient-to-t from-blue-400 to-blue-600 rounded-full transform -translate-x-1/2 origin-bottom rotate-135 shadow-lg"></div>
                <div className="absolute top-0 left-1/2 w-3 h-28 bg-gradient-to-t from-emerald-400 to-emerald-600 rounded-full transform -translate-x-1/2 origin-bottom rotate-225 shadow-lg"></div>
                <div className="absolute top-0 left-1/2 w-3 h-28 bg-gradient-to-t from-purple-400 to-purple-600 rounded-full transform -translate-x-1/2 origin-bottom rotate-315 shadow-lg"></div>
              </div>
              
              <div className="space-y-4">
                {[
                  { country: 'UK', sales: '4320 Ventes', color: 'orange', percentage: '31%' },
                  { country: 'Pologne', sales: '3790 ventes', color: 'slate', percentage: '27%' },
                  { country: 'Autriche', sales: '3200 ventes', color: 'emerald', percentage: '23%' },
                  { country: 'Pays-Bas', sales: '2800 ventes', color: 'blue', percentage: '19%' }
                ].map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 transition-colors duration-300">
                    <div className="flex items-center gap-4">
                      <div className={`w-4 h-4 bg-gradient-to-br from-${item.color}-400 to-${item.color}-600 rounded-full shadow-sm`}></div>
                      <span className="text-slate-700 font-semibold">{item.country}</span>
                    </div>
                    <div className="text-right">
                      <div className="text-slate-600 text-sm font-medium">{item.sales}</div>
                      <div className="text-slate-500 text-xs">{item.percentage}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Budget et dépenses redesignés */}
          <div className="space-y-6">
            
            {/* Section Budget redesignée */}
            <div className="bg-white rounded-3xl shadow-xl border border-slate-200/50 p-8 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-emerald-100/50 to-transparent rounded-full blur-2xl"></div>
              
              <div className="relative z-10">
                <h3 className="text-xl font-bold text-slate-800 mb-6">Budget mensuel</h3>
                <div className="text-lg font-medium text-slate-600 mb-2">Budget total</div>
                <div className="text-4xl font-bold text-emerald-600 mb-8">550 000 €</div>
                
                <div className="relative w-40 h-40 mx-auto mb-6">
                  <div className="absolute inset-0 rounded-full bg-slate-200 shadow-inner"></div>
                  <div className="absolute inset-0 rounded-full" style={{
                    background: `conic-gradient(#10B981 0deg 172.8deg, #E5E7EB 172.8deg 360deg)`,
                    borderRadius: '50%'
                  }}></div>
                  <div className="absolute inset-6 rounded-full bg-white shadow-2xl flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-slate-800">48%</div>
                      <div className="text-xs text-slate-600 font-medium">Économisé</div>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-3">
                    <div className="w-4 h-4 bg-slate-400 rounded-full shadow-sm"></div>
                    <span className="text-slate-600 font-medium">Total dépensé</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-4 h-4 bg-emerald-500 rounded-full shadow-sm"></div>
                    <span className="text-slate-600 font-medium">Argent économisé</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Ventes par pays redesignées */}
            <div className="bg-white rounded-3xl shadow-xl border border-slate-200/50 p-8">
              <h3 className="text-xl font-bold text-slate-800 mb-2">Ventes par pays</h3>
              <div className="text-sm text-slate-600 mb-6">États-Unis d'Amérique • 3 États sur 50</div>
              
              <div className="space-y-5">
                {[
                  { country: 'Pologne', amount: '$ 467,000 de 50M', progress: 85, color: 'emerald' },
                  { country: 'Russie', amount: '$ 467,000 de 50M', progress: 70, color: 'blue' },
                  { country: 'Pays-Bas', amount: '$ 467,000 de 50M', progress: 60, color: 'orange' }
                ].map((item, index) => (
                  <div key={index} className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-700 font-semibold">{item.country}</span>
                      <span className="text-slate-600 text-sm font-medium">{item.amount}</span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-3 shadow-inner">
                      <div 
                        className={`h-3 bg-gradient-to-r from-${item.color}-400 to-${item.color}-600 rounded-full transition-all duration-1000 shadow-sm`}
                        style={{ width: `${item.progress}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Transactions récentes redesignées */}
        <div className="bg-white rounded-3xl shadow-xl border border-slate-200/50">
          <div className="p-6 border-b border-slate-200 bg-gradient-to-r from-slate-50 to-white">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold text-slate-800">Activité récente</h3>
              <button className="text-emerald-600 hover:text-emerald-700 text-sm font-semibold px-4 py-2 rounded-xl hover:bg-emerald-50 transition-all duration-300">
                Voir tout
              </button>
            </div>
          </div>
          <div className="p-6">
            <RecentTransactions />
          </div>
        </div>
      </div>
    </div>
  );
}
