
'use client';

import React, { useState } from 'react';
import { TaxEngine } from '../lib/taxEngine';
import TaxRecommendations from './TaxRecommendations';

export default function TaxSimulator() {
  const [activeTab, setActiveTab] = useState('revenus');
  const [results, setResults] = useState(null);
  const [isCalculating, setIsCalculating] = useState(false);
  const [showDetailedBreakdown, setShowDetailedBreakdown] = useState(false);

  // États pour les revenus
  const [revenus, setRevenus] = useState({
    salaires: '',
    pensions: '',
    foncier: '',
    bnc: '',
    bic: '',
    dividendes: '',
    interets: '',
    plus_values_immobilieres: '',
    revenus_financiers: '',
    option_bareme_progressif: false
  });

  // États pour la situation familiale
  const [situation, setSituation] = useState({
    statut_marital: 'celibataire',
    enfants_charge: 0,
    enfants_handicapes: 0,
    invalide: false,
    conjoint_invalide: false,
    age_contribuable: '',
    age_conjoint: '',
    imposition_commune: false,
    salaires_conjoint: '',
    revenus_conjoint: ''
  });

  // États pour les déductions et réductions
  const [options, setOptions] = useState({
    emploi_domicile: '',
    dons: '',
    pinel: '',
    deficit_foncier: '',
    frais_reels: false,
    montant_frais_reels: ''
  });

  const toNumber = (value) => {
    if (!value || value === '') return 0;
    const cleanValue = value.toString().replace(/[^0-9.,]/g, '').replace(',', '.');
    const num = parseFloat(cleanValue);
    return isNaN(num) ? 0 : Math.max(0, num);
  };

  const formatNumber = (value) => {
    return new Intl.NumberFormat('fr-FR').format(value);
  };

  const handleCalculate = async () => {
    setIsCalculating(true);

    try {
      // Préparer les données pour le calcul
      const revenusPrepares = {
        salaires: toNumber(revenus.salaires),
        pensions: toNumber(revenus.pensions),
        foncier: toNumber(revenus.foncier),
        bnc: toNumber(revenus.bnc),
        bic: toNumber(revenus.bic),
        dividendes: toNumber(revenus.dividendes),
        interets: toNumber(revenus.interets),
        plus_values_immobilieres: toNumber(revenus.plus_values_immobilieres),
        revenus_financiers: toNumber(revenus.revenus_financiers),
        option_bareme_progressif: revenus.option_bareme_progressif
      };

      // Ajouter les revenus du conjoint si imposition commune
      if (situation.imposition_commune) {
        revenusPrepares.salaires += toNumber(situation.salaires_conjoint);
        revenusPrepares.revenus_financiers += toNumber(situation.revenus_conjoint);
      }

      const situationPreparee = {
        ...situation,
        enfants_charge: Number(situation.enfants_charge),
        enfants_handicapes: Number(situation.enfants_handicapes),
        age_contribuable: toNumber(situation.age_contribuable),
        age_conjoint: toNumber(situation.age_conjoint)
      };

      const optionsPreparees = {
        emploi_domicile: toNumber(options.emploi_domicile),
        dons: toNumber(options.dons),
        pinel: toNumber(options.pinel),
        deficit_foncier: toNumber(options.deficit_foncier),
        frais_reels: options.frais_reels,
        montant_frais_reels: toNumber(options.montant_frais_reels)
      };

      // Calcul avec le moteur fiscal
      const taxEngine = new TaxEngine();
      const calculationResults = taxEngine.simulate(revenusPrepares, situationPreparee, optionsPreparees);

      // Restructurer les résultats pour correspondre au format attendu
      const formattedResults = {
        revenus: {
          total_brut: calculationResults.revenus.total_brut || 0,
          total_imposable: calculationResults.revenus.total_imposable || 0
        },
        impot_revenu: {
          impot_net: calculationResults.impots.ir || 0,
          taux_marginal: '30', // Valeur par défaut
          taux_moyen: calculationResults.detail_ir.taux_moyen || 0,
          quotient_familial: calculationResults.detail_ir.parts_fiscales || 1,
          reductions: {
            total: calculationResults.detail_ir.reductions || 0
          }
        },
        pfu: {
          total_pfu: calculationResults.impots.pfu_total || 0
        },
        prelevements_sociaux: {
          total: calculationResults.impots.prelevements_sociaux || 0
        },
        synthese: {
          total_impots: calculationResults.impots.total || 0,
          revenu_net_apres_impots: calculationResults.resultat.revenu_net || 0,
          taux_global: calculationResults.resultat.taux_global || 0
        }
      };

      setResults(formattedResults);
    } catch (error) {
      console.error('Erreur lors du calcul:', error);
      alert('Une erreur est survenue lors du calcul. Veuillez vérifier vos données.');
    } finally {
      setIsCalculating(false);
    }
  };

  const generatePDF = async () => {
    if (!results) return;

    try {
      // Dynamic import to avoid build issues
      const { default: jsPDF } = await import('jspdf');
      const pdf = new jsPDF();

      // En-tête
      pdf.setFontSize(20);
      pdf.text('Simulation Fiscale 2025', 20, 30);

      pdf.setFontSize(12);
      pdf.text(`Date de simulation: ${new Date().toLocaleDateString('fr-FR')}`, 20, 45);

      // Revenus
      pdf.setFontSize(16);
      pdf.text('REVENUS', 20, 65);
      pdf.setFontSize(12);
      pdf.text(`Total des revenus bruts: ${formatNumber(results.revenus.total_brut)} €`, 30, 80);
      pdf.text(`Revenu imposable: ${formatNumber(results.revenus.total_imposable)} €`, 30, 95);

      // Impôts
      pdf.setFontSize(16);
      pdf.text('IMPOTS ET TAXES', 20, 120);
      pdf.setFontSize(12);
      pdf.text(`Impôt sur le revenu: ${formatNumber(results.impot_revenu.impot_net)} €`, 30, 135);
      if (results.pfu.total_pfu > 0) {
        pdf.text(`PFU (revenus financiers): ${formatNumber(results.pfu.total_pfu)} €`, 30, 150);
      }
      if (results.prelevements_sociaux.total > 0) {
        pdf.text(`Prélèvements sociaux: ${formatNumber(results.prelevements_sociaux.total)} €`, 30, 165);
      }

      // Synthèse
      pdf.setFontSize(16);
      pdf.text('SYNTHESE', 20, 190);
      pdf.setFontSize(12);
      pdf.text(`Total des impôts: ${formatNumber(results.synthese.total_impots)} €`, 30, 205);
      pdf.text(`Revenu net après impôts: ${formatNumber(results.synthese.revenu_net_apres_impots)} €`, 30, 220);
      pdf.text(`Taux global d'imposition: ${results.synthese.taux_global.toFixed(2)} %`, 30, 235);

      pdf.save('simulation-fiscale-2025.pdf');
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Erreur lors de la génération du PDF. Utilisez l\'export CSV.');
    }
  };

  const generateCSV = () => {
    if (!results) return;

    const csvData = [
      ['Poste', 'Montant (€)'],
      ['Revenus bruts totaux', results.revenus.total_brut],
      ['Revenu imposable', results.revenus.total_imposable],
      ['Impôt sur le revenu', results.impot_revenu.impot_net],
      ['PFU', results.pfu.total_pfu],
      ['Prélèvements sociaux', results.prelevements_sociaux.total],
      ['Total impôts', results.synthese.total_impots],
      ['Revenu net après impôts', results.synthese.revenu_net_apres_impots],
      ['Taux global (%)', results.synthese.taux_global.toFixed(2)]
    ];

    const csvContent = csvData.map(row => row.join(';')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'simulation-fiscale-2025.csv';
    link.click();
  };

  return (
    <div className="space-y-8">
      {/* En-tête */}
      <div className="bg-gray-900 rounded-xl p-8 border border-blue-500/20">
        <h2 className="text-3xl font-bold text-white mb-4 flex items-center">
          <i className="ri-calculator-line text-blue-400 mr-4"></i>
          Simulateur Fiscal 2025
        </h2>
        <p className="text-gray-300">
          Calculez votre impôt sur le revenu, PFU et prélèvements sociaux selon la législation française 2025
        </p>
      </div>

      {/* Navigation par onglets */}
      <div className="bg-gray-900 rounded-xl p-2 border border-gray-700">
        <div className="flex space-x-2">
          {[{
            id: 'revenus',
            label: 'Revenus',
            icon: 'ri-money-euro-circle-line'
          }, {
            id: 'situation',
            label: 'Situation',
            icon: 'ri-group-line'
          }, {
            id: 'deductions',
            label: 'Déductions',
            icon: 'ri-receipt-line'
          }, {
            id: 'calcul',
            label: 'Calcul',
            icon: 'ri-calculator-line'
          }].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 py-3 px-4 rounded-lg font-medium transition-colors cursor-pointer whitespace-nowrap flex items-center justify-center space-x-2 ${
                activeTab === tab.id
                  ? 'bg-blue-500 text-white'
                  : 'text-gray-400 hover:text-white hover:bg-gray-800'
              }`}
            >
              <i className={`${tab.icon} text-lg`}></i>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Contenu des onglets */}
      <div className="bg-gray-900 rounded-xl p-8 border border-gray-700">
        {activeTab === 'revenus' && (
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-white mb-6">Déclaration des revenus 2024</h3>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Salaires et traitements (€)
                </label>
                <input
                  type="text"
                  value={revenus.salaires}
                  onChange={(e) => setRevenus({ ...revenus, salaires: e.target.value })}
                  className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="45 000"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Pensions et retraites (€)
                </label>
                <input
                  type="text"
                  value={revenus.pensions}
                  onChange={(e) => setRevenus({ ...revenus, pensions: e.target.value })}
                  className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Revenus fonciers (€)
                </label>
                <input
                  type="text"
                  value={revenus.foncier}
                  onChange={(e) => setRevenus({ ...revenus, foncier: e.target.value })}
                  className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  BNC - Bénéfices non commerciaux (€)
                </label>
                <input
                  type="text"
                  value={revenus.bnc}
                  onChange={(e) => setRevenus({ ...revenus, bnc: e.target.value })}
                  className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  BIC - Bénéfices industriels et commerciaux (€)
                </label>
                <input
                  type="text"
                  value={revenus.bic}
                  onChange={(e) => setRevenus({ ...revenus, bic: e.target.value })}
                  className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Dividendes (€)
                </label>
                <input
                  type="text"
                  value={revenus.dividendes}
                  onChange={(e) => setRevenus({ ...revenus, dividendes: e.target.value })}
                  className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Intérêts et autres revenus financiers (€)
                </label>
                <input
                  type="text"
                  value={revenus.revenus_financiers}
                  onChange={(e) => setRevenus({ ...revenus, revenus_financiers: e.target.value })}
                  className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Plus-values immobilières (€)
                </label>
                <input
                  type="text"
                  value={revenus.plus_values_immobilieres}
                  onChange={(e) => setRevenus({ ...revenus, plus_values_immobilieres: e.target.value })}
                  className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
              </div>
            </div>

            <div className="bg-blue-500/10 p-4 rounded-lg border border-blue-500/20">
              <label className="flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={revenus.option_bareme_progressif}
                  onChange={(e) => setRevenus({ ...revenus, option_bareme_progressif: e.target.checked })}
                  className="mr-3"
                />
                <span className="text-blue-400 font-medium">
                  Option pour le barème progressif (revenus financiers)
                </span>
              </label>
              <p className="text-sm text-gray-400 mt-2">
                Appliquer le barème progressif au lieu du PFU (30%) pour les revenus financiers
              </p>
            </div>
          </div>
        )}

        {activeTab === 'situation' && (
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-white mb-6">Situation familiale</h3>

            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-3">
                  Statut marital
                </label>
                <div className="space-y-2">
                  {[{
                    value: 'celibataire',
                    label: 'Célibataire'
                  }, {
                    value: 'marie',
                    label: 'Marié(e)'
                  }, {
                    value: 'pacs',
                    label: 'Pacsé(e)'
                  }, {
                    value: 'divorce',
                    label: 'Divorcé(e)'
                  }, {
                    value: 'veuf',
                    label: 'Veuf/Veuve'
                  }].map((status) => (
                    <label key={status.value} className="flex items-center cursor-pointer">
                      <input
                        type="radio"
                        name="statut_marital"
                        value={status.value}
                        checked={situation.statut_marital === status.value}
                        onChange={(e) => setSituation({ ...situation, statut_marital: e.target.value })}
                        className="mr-3"
                      />
                      <span className="text-white">{status.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Nombre d'enfants à charge
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="15"
                    value={situation.enfants_charge}
                    onChange={(e) => setSituation({ ...situation, enfants_charge: e.target.value })}
                    className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Enfants handicapés
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="10"
                    value={situation.enfants_handicapes}
                    onChange={(e) => setSituation({ ...situation, enfants_handicapes: e.target.value })}
                    className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Votre âge
                    </label>
                    <input
                      type="number"
                      min="18"
                      max="120"
                      value={situation.age_contribuable}
                      onChange={(e) => setSituation({ ...situation, age_contribuable: e.target.value })}
                      className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Âge conjoint
                    </label>
                    <input
                      type="number"
                      min="18"
                      max="120"
                      value={situation.age_conjoint}
                      onChange={(e) => setSituation({ ...situation, age_conjoint: e.target.value })}
                      className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                      disabled={situation.statut_marital === 'celibataire' || situation.statut_marital === 'divorce' || situation.statut_marital === 'veuf'}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Section imposition commune */}
            {(situation.statut_marital === 'marie' || situation.statut_marital === 'pacs') && (
              <div className="bg-green-500/10 p-6 rounded-lg border border-green-500/20">
                <label className="flex items-center cursor-pointer mb-4">
                  <input
                    type="checkbox"
                    checked={situation.imposition_commune}
                    onChange={(e) => setSituation({ ...situation, imposition_commune: e.target.checked })}
                    className="mr-3"
                  />
                  <span className="text-green-400 font-medium text-lg">
                    Imposition commune (déclaration jointe)
                  </span>
                </label>

                {situation.imposition_commune && (
                  <div className="grid md:grid-cols-2 gap-4 mt-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Salaires du conjoint (€)
                      </label>
                      <input
                        type="text"
                        value={situation.salaires_conjoint}
                        onChange={(e) => setSituation({ ...situation, salaires_conjoint: e.target.value })}
                        className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-green-500 focus:outline-none"
                        placeholder="35 000"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Autres revenus du conjoint (€)
                      </label>
                      <input
                        type="text"
                        value={situation.revenus_conjoint}
                        onChange={(e) => setSituation({ ...situation, revenus_conjoint: e.target.value })}
                        className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-green-500 focus:outline-none"
                        placeholder="0"
                      />
                    </div>
                  </div>
                )}

                <p className="text-sm text-gray-400 mt-3">
                  💡 L'imposition commune permet de bénéficier du quotient familial et peut être plus avantageuse
                </p>
              </div>
            )}

            <div className="grid md:grid-cols-2 gap-4">
              <label className="flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={situation.invalide}
                  onChange={(e) => setSituation({ ...situation, invalide: e.target.checked })}
                  className="mr-3"
                />
                <span className="text-white">Vous êtes invalide (carte d'invalidité 80%+)</span>
              </label>

              <label className="flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={situation.conjoint_invalide}
                  onChange={(e) => setSituation({ ...situation, conjoint_invalide: e.target.checked })}
                  className="mr-3"
                  disabled={situation.statut_marital === 'celibataire' || situation.statut_marital === 'divorce' || situation.statut_marital === 'veuf'}
                />
                <span className="text-white">Conjoint invalide</span>
              </label>
            </div>
          </div>
        )}

        {activeTab === 'deductions' && (
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-white mb-6">Déductions et réductions d'impôt</h3>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Emploi à domicile (€)
                </label>
                <input
                  type="text"
                  value={options.emploi_domicile}
                  onChange={(e) => setOptions({ ...options, emploi_domicile: e.target.value })}
                  className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
                <p className="text-xs text-gray-400 mt-1">Réduction de 50% plafonnée à 12 000€</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Dons aux associations (€)
                </label>
                <input
                  type="text"
                  value={options.dons}
                  onChange={(e) => setOptions({ ...options, dons: e.target.value })}
                  className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
                <p className="text-xs text-gray-400 mt-1">Réduction de 66% jusqu'à 20% du revenu</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Investissement Pinel (€)
                </label>
                <input
                  type="text"
                  value={options.pinel}
                  onChange={(e) => setOptions({ ...options, pinel: e.target.value })}
                  className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
                <p className="text-xs text-gray-400 mt-1">Réduction calculée selon la durée</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Déficit foncier (€)
                </label>
                <input
                  type="text"
                  value={options.deficit_foncier}
                  onChange={(e) => setOptions({ ...options, deficit_foncier: e.target.value })}
                  className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                  placeholder="0"
                />
                <p className="text-xs text-gray-400 mt-1">Imputable sur le revenu global</p>
              </div>
            </div>

            <div className="bg-green-500/10 p-4 rounded-lg border border-green-500/20">
              <label className="flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={options.frais_reels}
                  onChange={(e) => setOptions({ ...options, frais_reels: e.target.checked })}
                  className="mr-3"
                />
                <span className="text-green-400 font-medium">
                  Option pour les frais réels (salariés)
                </span>
              </label>

              {options.frais_reels && (
                <div className="mt-4">
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Montant des frais réels (€)
                  </label>
                  <input
                    type="text"
                    value={options.montant_frais_reels}
                    onChange={(e) => setOptions({ ...options, montant_frais_reels: e.target.value })}
                    className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:border-green-500 focus:outline-none"
                    placeholder="0"
                  />
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'calcul' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-bold text-white">Calculer votre impôt 2025</h3>

              <button
                onClick={handleCalculate}
                disabled={isCalculating}
                className="bg-blue-500 hover:bg-blue-400 text-white px-8 py-4 rounded-xl font-bold text-lg transition-colors cursor-pointer whitespace-nowrap flex items-center space-x-3 shadow-lg hover:shadow-xl transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
              >
                {isCalculating ? (
                  <>
                    <i className="ri-loader-4-line text-2xl animate-spin"></i>
                    <span>Calcul en cours...</span>
                  </>
                ) : (
                  <>
                    <i className="ri-calculator-line text-2xl"></i>
                    <span>Calculer</span>
                  </>
                )}
              </button>
            </div>

            {results && (
              <div className="space-y-6">
                {/* Résultats principaux */}
                <div className="grid md:grid-columns-2 lg:grid-columns-4 gap-6">
                  <div className="bg-blue-500/20 rounded-xl p-6 border border-blue-500/30">
                    <div className="text-sm text-gray-400 mb-2">Revenus bruts</div>
                    <div className="text-2xl font-bold text-blue-400">
                      {formatNumber(results.revenus.total_brut)} €
                    </div>
                  </div>

                  <div className="bg-green-500/20 rounded-xl p-6 border border-green-500/30">
                    <div className="text-sm text-gray-400 mb-2">Revenu imposable</div>
                    <div className="text-2xl font-bold text-green-400">
                      {formatNumber(results.revenus.total_imposable)} €
                    </div>
                  </div>

                  <div className="bg-red-500/20 rounded-xl p-6 border border-red-500/30">
                    <div className="text-sm text-gray-400 mb-2">Total impôts</div>
                    <div className="text-2xl font-bold text-red-400">
                      {formatNumber(results.synthese.total_impots)} €
                    </div>
                  </div>

                  <div className="bg-yellow-500/20 rounded-xl p-6 border border-yellow-500/30">
                    <div className="text-sm text-gray-400 mb-2">Revenu net</div>
                    <div className="text-2xl font-bold text-yellow-400">
                      {formatNumber(results.synthese.revenu_net_apres_impots)} €
                    </div>
                  </div>
                </div>

                {/* Détail des impôts */}
                <div className="bg-gray-800 rounded-xl p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h4 className="text-lg font-bold text-white">Détail des impôts et taxes</h4>
                    <button
                      onClick={() => setShowDetailedBreakdown(!showDetailedBreakdown)}
                      className="text-blue-400 hover:text-blue-300 cursor-pointer flex items-center space-x-2"
                    >
                      <span>{showDetailedBreakdown ? 'Masquer' : 'Voir'} le détail complet</span>
                      <i className={`ri-arrow-${showDetailedBreakdown ? 'up' : 'down'}-s-line`}></i>
                    </button>
                  </div>

                  <div className="space-y-4">
                    <div className="flex justify-between items-center py-2 border-b border-gray-700">
                      <span className="text-gray-300">Impôt sur le revenu</span>
                      <span className="text-white font-semibold">
                        {formatNumber(results.impot_revenu.impot_net)} €
                      </span>
                    </div>

                    <div className="flex justify-between items-center py-2 border-b border-gray-700">
                      <span className="text-gray-300">Taux marginal d'imposition</span>
                      <span className="text-white font-semibold">
                        {results.impot_revenu.taux_marginal} %
                      </span>
                    </div>

                    <div className="flex justify-between items-center py-2 border-b border-gray-700">
                      <span className="text-gray-300">Taux moyen d'imposition</span>
                      <span className="text-white font-semibold">
                        {results.impot_revenu.taux_moyen.toFixed(2)} %
                      </span>
                    </div>

                    {results.pfu.total_pfu > 0 && (
                      <div className="flex justify-between items-center py-2 border-b border-gray-700">
                        <span className="text-gray-300">PFU (revenus financiers)</span>
                        <span className="text-white font-semibold">
                          {formatNumber(results.pfu.total_pfu)} €
                        </span>
                      </div>
                    )}

                    {results.prelevements_sociaux.total > 0 && (
                      <div className="flex justify-between items-center py-2 border-b border-gray-700">
                        <span className="text-gray-300">Prélèvements sociaux</span>
                        <span className="text-white font-semibold">
                          {formatNumber(results.prelevements_sociaux.total)} €
                        </span>
                      </div>
                    )}

                    <div className="flex justify-between items-center py-2 font-bold text-lg">
                      <span className="text-white">Taux global d'imposition</span>
                      <span className="text-yellow-400">
                        {results.synthese.taux_global.toFixed(2)} %
                      </span>
                    </div>
                  </div>

                  {/* Détail complet des calculs */}
                  {showDetailedBreakdown && results.impot_revenu.calcul_detaille && (
                    <div className="mt-6 p-4 bg-black/30 rounded-lg">
                      <h5 className="text-white font-semibold mb-4">Calcul détaillé de l'impôt sur le revenu</h5>

                      {/* Détail par tranche */}
                      <div className="space-y-3 mb-4">
                        <div className="text-sm text-gray-400 font-medium">Calcul par tranche d'imposition :</div>
                        {results.impot_revenu.calcul_detaille.tranches.map((tranche, index) => (
                          <div key={index} className="flex justify-between items-center text-sm">
                            <span className="text-gray-300">
                              {tranche.min === 0 ? 'Jusqu\'à' : `De ${formatNumber(tranche.min)} à`} {formatNumber(tranche.max)} € ({tranche.taux}%)
                            </span>
                            <span className="text-white">
                              {formatNumber(tranche.impot)} €
                            </span>
                          </div>
                        ))}
                      </div>

                      {/* Quotient familial */}
                      <div className="grid md:grid-columns-2 gap-4 text-sm">
                        <div>
                          <div className="text-gray-400 mb-2">Quotient familial :</div>
                          <div className="text-white">
                            {results.impot_revenu.quotient_familial} parts
                          </div>
                        </div>
                        <div>
                          <div className="text-gray-400 mb-2">Revenu par part :</div>
                          <div className="text-white">
                            {formatNumber(Math.round(results.revenus.total_imposable / results.impot_revenu.quotient_familial))} €
                          </div>
                        </div>
                      </div>

                      {/* Réductions appliquées */}
                      {results.impot_revenu.reductions && results.impot_revenu.reductions.total > 0 && (
                        <div className="mt-4 pt-4 border-t border-gray-700">
                          <div className="text-sm text-gray-400 font-medium mb-2">Réductions d'impôt appliquées :</div>
                          {Object.entries(results.impot_revenu.reductions).map(([key, value]) => {
                            if (key !== 'total' && value > 0) {
                              return (
                                <div key={key} className="flex justify-between items-center text-sm">
                                  <span className="text-gray-300">
                                    {key === 'emploi_domicile' ? 'Emploi à domicile' :
                                      key === 'dons' ? 'Dons aux associations' :
                                        key === 'pinel' ? 'Investissement Pinel' : key}
                                  </span>
                                  <span className="text-green-400">-{formatNumber(value)} €</span>
                                </div>
                              );
                            }
                            return null;
                          })}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Boutons de téléchargement */}
                <div className="flex justify-center space-x-4">
                  <button
                    onClick={generatePDF}
                    className="bg-red-500 hover:bg-red-400 text-white px-6 py-3 rounded-lg font-medium transition-colors cursor-pointer whitespace-nowrap flex items-center space-x-2"
                  >
                    <i className="ri-file-pdf-line"></i>
                    <span>Télécharger PDF</span>
                  </button>

                  <button
                    onClick={generateCSV}
                    className="bg-green-500 hover:bg-green-400 text-white px-6 py-3 rounded-lg font-medium transition-colors cursor-pointer whitespace-nowrap flex items-center space-x-2"
                  >
                    <i className="ri-file-excel-line"></i>
                    <span>Télécharger CSV</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Recommandations */}
      {results && (
        <TaxRecommendations
          results={results}
          revenus={revenus}
          situation={situation}
          options={options}
        />
      )}
    </div>
  );
}
