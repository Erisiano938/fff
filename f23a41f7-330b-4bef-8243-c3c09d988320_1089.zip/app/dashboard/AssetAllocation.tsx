
'use client';

import { useState, useEffect } from 'react';

export default function AssetAllocation() {
  const [showModal, setShowModal] = useState(false);
  const [selectedAllocation, setSelectedAllocation] = useState(null);
  const [allocations, setAllocations] = useState([
    { name: 'Actions', percentage: 45, value: '€57,395', color: '#EAB308', bgColor: 'bg-yellow-500' },
    { name: 'Obligations', percentage: 25, value: '€31,886', color: '#3B82F6', bgColor: 'bg-blue-500' },
    { name: 'ETF', percentage: 20, value: '€25,509', color: '#10B981', bgColor: 'bg-green-500' },
    { name: 'Crypto', percentage: 7, value: '€8,928', color: '#8B5CF6', bgColor: 'bg-purple-500' },
    { name: 'Cash', percentage: 3, value: '€3,826', color: '#6B7280', bgColor: 'bg-gray-500' }
  ]);

  // Charger la configuration personnalisée
  useEffect(() => {
    const loadCustomConfig = () => {
      const savedConfig = localStorage.getItem('portfolio_config');
      const lastUpdate = localStorage.getItem('dashboard_portfolio_updated');

      if (savedConfig && lastUpdate) {
        try {
          const config = JSON.parse(savedConfig);
          if (config.allocations && config.allocations.length > 0) {
            const customAllocations = config.allocations.map(allocation => ({
              name: allocation.name,
              percentage: allocation.percentage,
              value: `€${allocation.value.toLocaleString()}`,
              color: allocation.color,
              bgColor: '', // Nous utiliserons directement la couleur hex
              icon: allocation.icon
            }));
            setAllocations(customAllocations);
          }
        } catch (error) {
          console.log('Erreur lors du chargement de la configuration:', error);
        }
      }
    };

    loadCustomConfig();

    // Écouter les changements
    const handleStorageChange = () => {
      loadCustomConfig();
    };

    window.addEventListener('storage', handleStorageChange);

    // Vérifier périodiquement les mises à jour
    const interval = setInterval(loadCustomConfig, 1000);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(interval);
    };
  }, []);

  const handleLearnMore = () => {
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setSelectedAllocation(null);
  };

  return (
    <div>
      <div className="bg-gray-900 rounded-xl p-6 border border-yellow-500/20">
        <h3 className="text-xl font-bold text-white mb-6">Répartition des Actifs</h3>

        <div className="space-y-4">
          {allocations.map((allocation, index) => (
            <div key={index} className="space-y-2">
              <div className="flex justify-between items-center">
                <div className="flex items-center space-x-3">
                  {allocation.icon && (
                    <div
                      className="w-6 h-6 rounded flex items-center justify-center"
                      style={{ backgroundColor: allocation.color + '20' }}
                    >
                      <i
                        className={`${allocation.icon} text-sm`}
                        style={{ color: allocation.color }}
                      ></i>
                    </div>
                  )}
                  <span className="text-white font-medium">{allocation.name}</span>
                </div>
                <span className="text-gray-400 text-sm">{allocation.percentage}%</span>
              </div>
              <div className="w-full bg-gray-800 rounded-full h-2">
                <div
                  className="h-2 rounded-full transition-all duration-300"
                  style={{
                    width: `${allocation.percentage}%`,
                    backgroundColor: allocation.color
                  }}
                />
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-400">{allocation.value}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 pt-4 border-t border-yellow-500/20">
          <button
            onClick={handleLearnMore}
            className="w-full bg-yellow-500/20 text-yellow-400 py-2 rounded-lg hover:bg-yellow-500/30 transition-colors cursor-pointer whitespace-nowrap"
          >
            En savoir plus
          </button>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 rounded-xl border border-yellow-500/30 max-w-6xl w-full max-h-[95vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-700">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center">
                    <i className="ri-pie-chart-line text-2xl text-yellow-400"></i>
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-white">Diversification & Allocation d'Actifs</h2>
                    <p className="text-gray-400">Stratégies professionnelles pour optimiser votre portefeuille d'investissement</p>
                  </div>
                </div>
                <button
                  onClick={closeModal}
                  className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-gray-700 transition-colors cursor-pointer"
                >
                  <i className="ri-close-line text-xl text-gray-400"></i>
                </button>
              </div>
            </div>

            <div className="p-6 space-y-8">
              {/* Vue d'ensemble */}
              <div>
                <h3 className="text-xl font-bold text-white mb-4">Pourquoi Diversifier son Portefeuille ?</h3>
                <div className="bg-black/30 p-6 rounded-xl">
                  <p className="text-gray-300 leading-relaxed mb-4">
                    La diversification est <strong className="text-white">LA règle d'or de l'investissement</strong>. 
                    En répartissant vos investissements sur différentes classes d'actifs, zones géographiques et secteurs,
                    vous <strong className="text-yellow-400">réduisez significativement les risques</strong> tout en optimisant 
                    le potentiel de rendement. C'est la différence entre un investisseur amateur et professionnel.
                  </p>
                  <div className="grid md:grid-cols-4 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-yellow-400">-40%</div>
                      <div className="text-sm text-gray-400">Réduction du risque</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-400">+25%</div>
                      <div className="text-sm text-gray-400">Rendement optimisé</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-400">8-12</div>
                      <div className="text-sm text-gray-400">Classes d'actifs</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-400">Global</div>
                      <div className="text-sm text-gray-400">Exposition mondiale</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Analyse détaillée de votre allocation */}
              <div>
                <h3 className="text-xl font-bold text-white mb-4">Analyse de Votre Allocation Actuelle</h3>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {allocations.map((allocation, index) => (
                    <div key={index} className="bg-black/30 p-6 rounded-xl border border-gray-700">
                      <div className="flex items-center space-x-3 mb-4">
                        <div 
                          className="w-8 h-8 rounded-lg flex items-center justify-center"
                          style={{ backgroundColor: allocation.color || '#EAB308' }}
                        >
                          <i className={`${getAllocationIcon(allocation.name)} text-white text-lg`}></i>
                        </div>
                        <div>
                          <h4 className="font-semibold text-white">{allocation.name}</h4>
                          <p className="text-2xl font-bold text-yellow-400">{allocation.percentage}%</p>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-gray-400 text-sm">Valeur:</span>
                          <span className="text-white font-semibold">{allocation.value}</span>
                        </div>

                        {allocation.name === 'Actions' && (
                          <>
                            <div className="flex justify-between">
                              <span className="text-gray-400 text-sm">Rendement potentiel:</span>
                              <span className="text-green-400 font-semibold">6-10%/an</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400 text-sm">Horizon optimal:</span>
                              <span className="text-white">10+ ans</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400 text-sm">Volatilité:</span>
                              <span className="text-orange-400">Élevée</span>
                            </div>
                            <p className="text-xs text-gray-300 mt-2 bg-black/30 p-2 rounded">
                              <strong>Recommandation:</strong> Allocation appropriée pour la croissance long terme. 
                              Diversifiez géographiquement (USA, Europe, Asie).
                            </p>
                          </>
                        )}

                        {allocation.name === 'Obligations' && (
                          <>
                            <div className="flex justify-between">
                              <span className="text-gray-400 text-sm">Rendement potentiel:</span>
                              <span className="text-green-400 font-semibold">3-5%/an</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400 text-sm">Rôle:</span>
                              <span className="text-white">Stabilité</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400 text-sm">Volatilité:</span>
                              <span className="text-green-400">Faible</span>
                            </div>
                            <p className="text-xs text-gray-300 mt-2 bg-black/30 p-2 rounded">
                              <strong>Recommandation:</strong> Bonne allocation défensive. 
                              Mélangez obligations d'État et corporate pour optimiser.
                            </p>
                          </>
                        )}

                        {allocation.name === 'ETF' && (
                          <>
                            <div className="flex justify-between">
                              <span className="text-gray-400 text-sm">Frais annuels:</span>
                              <span className="text-green-400 font-semibold">0.1-0.5%</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400 text-sm">Diversification:</span>
                              <span className="text-white">Automatique</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400 text-sm">Liquidité:</span>
                              <span className="text-green-400">Excellente</span>
                            </div>
                            <p className="text-xs text-gray-300 mt-2 bg-black/30 p-2 rounded">
                              <strong>Recommandation:</strong> Excellente base de portefeuille. 
                              Privilégiez ETF World, émergents et thématiques.
                            </p>
                          </>
                        )}

                        {allocation.name === 'Crypto' && (
                          <>
                            <div className="flex justify-between">
                              <span className="text-gray-400 text-sm">Potentiel:</span>
                              <span className="text-green-400 font-semibold">Très élevé</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400 text-sm">Allocation max:</span>
                              <span className="text-orange-400">5-10%</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400 text-sm">Volatilité:</span>
                              <span className="text-red-400">Extrême</span>
                            </div>
                            <p className="text-xs text-gray-300 mt-2 bg-black/30 p-2 rounded">
                              <strong>Recommandation:</strong> Allocation raisonnable (≤10%). 
                              Privilégiez Bitcoin et Ethereum (75%+ du crypto).
                            </p>
                          </>
                        )}

                        {allocation.name === 'Cash' && (
                          <>
                            <div className="flex justify-between">
                              <span className="text-gray-400 text-sm">Rendement réel:</span>
                              <span className="text-red-400 font-semibold">Négatif</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400 text-sm">Rôle:</span>
                              <span className="text-white">Opportunités</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400 text-sm">Recommandation:</span>
                              <span className="text-yellow-400">2-5% max</span>
                            </div>
                            <p className="text-xs text-gray-300 mt-2 bg-black/30 p-2 rounded">
                              <strong>Recommandation:</strong> Juste pour les opportunités. 
                              Placez sur livret A ou compte rémunéré.
                            </p>
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Allocations modèles selon le profil */}
              <div>
                <h3 className="text-xl font-bold text-white mb-4">Allocations Modèles selon votre Profil</h3>
                <div className="space-y-4">
                  <div className="bg-green-500/10 p-4 rounded-xl border border-green-500/20">
                    <h4 className="font-semibold text-white mb-2 flex items-center">
                      <i className="ri-shield-check-line text-green-400 mr-2"></i>
                      Profil Conservateur - Préservation du Capital
                    </h4>
                    <p className="text-sm text-gray-300 mb-3">Priorité à la sécurité avec croissance modérée</p>
                    <div className="grid md:grid-cols-6 gap-3 text-sm">
                      <div className="bg-black/30 p-3 rounded">
                        <div className="text-white font-semibold">50%</div>
                        <div className="text-gray-400">Obligations</div>
                      </div>
                      <div className="bg-black/30 p-3 rounded">
                        <div className="text-white font-semibold">25%</div>
                        <div className="text-gray-400">Actions défensives</div>
                      </div>
                      <div className="bg-black/30 p-3 rounded">
                        <div className="text-white font-semibold">15%</div>
                        <div className="text-gray-400">ETF diversifiés</div>
                      </div>
                      <div className="bg-black/30 p-3 rounded">
                        <div className="text-white font-semibold">5%</div>
                        <div className="text-gray-400">REIT/Immobilier</div>
                      </div>
                      <div className="bg-black/30 p-3 rounded">
                        <div className="text-white font-semibold">3%</div>
                        <div className="text-gray-400">Matières premières</div>
                      </div>
                      <div className="bg-black/30 p-3 rounded">
                        <div className="text-white font-semibold">2%</div>
                        <div className="text-gray-400">Cash</div>
                      </div>
                    </div>
                    <p className="text-green-300 text-xs mt-2">Objectif : 4-6% de rendement avec volatilité limitée</p>
                  </div>

                  <div className="bg-blue-500/10 p-4 rounded-xl border border-blue-500/20">
                    <h4 className="font-semibold text-white mb-2 flex items-center">
                      <i className="ri-scales-line text-blue-400 mr-2"></i>
                      Profil Équilibré - Croissance Modérée
                    </h4>
                    <p className="text-sm text-gray-300 mb-3">Équilibre optimal entre rendement et sécurité</p>
                    <div className="grid md:grid-cols-6 gap-3 text-sm">
                      <div className="bg-black/30 p-3 rounded">
                        <div className="text-white font-semibold">40%</div>
                        <div className="text-gray-400">Actions diversifiées</div>
                      </div>
                      <div className="bg-black/30 p-3 rounded">
                        <div className="text-white font-semibold">25%</div>
                        <div className="text-gray-400">ETF internationaux</div>
                      </div>
                      <div className="bg-black/30 p-3 rounded">
                        <div className="text-white font-semibold">20%</div>
                        <div className="text-gray-400">Obligations</div>
                      </div>
                      <div className="bg-black/30 p-3 rounded">
                        <div className="text-white font-semibold">8%</div>
                        <div className="text-gray-400">REIT/Immobilier</div>
                      </div>
                      <div className="bg-black/30 p-3 rounded">
                        <div className="text-white font-semibold">5%</div>
                        <div className="text-gray-400">Matières premières</div>
                      </div>
                      <div className="bg-black/30 p-3 rounded">
                        <div className="text-white font-semibold">2%</div>
                        <div className="text-gray-400">Cash</div>
                      </div>
                    </div>
                    <p className="text-blue-300 text-xs mt-2">Objectif : 6-8% de rendement avec volatilité modérée</p>
                  </div>

                  <div className="bg-purple-500/10 p-4 rounded-xl border border-purple-500/20">
                    <h4 className="font-semibold text-white mb-2 flex items-center">
                      <i className="ri-rocket-line text-purple-400 mr-2"></i>
                      Profil Dynamique - Croissance Agressive
                    </h4>
                    <p className="text-sm text-gray-300 mb-3">Maximum de croissance avec acceptation de la volatilité</p>
                    <div className="grid md:grid-cols-6 gap-3 text-sm">
                      <div className="bg-black/30 p-3 rounded">
                        <div className="text-white font-semibold">50%</div>
                        <div className="text-gray-400">Actions croissance</div>
                      </div>
                      <div className="bg-black/30 p-3 rounded">
                        <div className="text-white font-semibold">25%</div>
                        <div className="text-gray-400">ETF émergents</div>
                      </div>
                      <div className="bg-black/30 p-3 rounded">
                        <div className="text-white font-semibold">10%</div>
                        <div className="text-gray-400">Small caps</div>
                      </div>
                      <div className="bg-black/30 p-3 rounded">
                        <div className="text-white font-semibold">8%</div>
                        <div className="text-gray-400">Crypto</div>
                      </div>
                      <div className="bg-black/30 p-3 rounded">
                        <div className="text-white font-semibold">5%</div>
                        <div className="text-gray-400">Thématiques</div>
                      </div>
                      <div className="bg-black/30 p-3 rounded">
                        <div className="text-white font-semibold">2%</div>
                        <div className="text-gray-400">Cash</div>
                      </div>
                    </div>
                    <p className="text-purple-300 text-xs mt-2">Objectif : 8-12% de rendement avec forte volatilité acceptée</p>
                  </div>
                </div>
              </div>

              {/* Diversification géographique */}
              <div>
                <h3 className="text-xl font-bold text-white mb-4">Diversification Géographique Recommandée</h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-black/30 p-6 rounded-xl border border-gray-700">
                    <h4 className="font-semibold text-white mb-4 flex items-center">
                      <i className="ri-global-line text-blue-400 mr-2"></i>
                      Répartition Géographique Optimale
                    </h4>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">🇺🇸 États-Unis</span>
                        <div className="flex items-center space-x-2">
                          <div className="w-20 h-2 bg-gray-700 rounded">
                            <div className="w-3/5 h-2 bg-blue-500 rounded"></div>
                          </div>
                          <span className="text-white font-semibold">60%</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">🇪🇺 Europe</span>
                        <div className="flex items-center space-x-2">
                          <div className="w-20 h-2 bg-gray-700 rounded">
                            <div className="w-1/5 h-2 bg-green-500 rounded"></div>
                          </div>
                          <span className="text-white font-semibold">20%</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">🌏 Asie-Pacifique</span>
                        <div className="flex items-center space-x-2">
                          <div className="w-20 h-2 bg-gray-700 rounded">
                            <div className="w-1/8 h-2 bg-yellow-500 rounded"></div>
                          </div>
                          <span className="text-white font-semibold">12%</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-300">🌍 Marchés émergents</span>
                        <div className="flex items-center space-x-2">
                          <div className="w-20 h-2 bg-gray-700 rounded">
                            <div className="w-1/12 h-2 bg-purple-500 rounded"></div>
                          </div>
                          <span className="text-white font-semibold">8%</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-black/30 p-6 rounded-xl border border-gray-700">
                    <h4 className="font-semibold text-white mb-4 flex items-center">
                      <i className="ri-building-line text-orange-400 mr-2"></i>
                      Diversification Sectorielle
                    </h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-300">Technologie</span>
                        <span className="text-white font-semibold">25%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Santé</span>
                        <span className="text-white font-semibold">15%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Finance</span>
                        <span className="text-white font-semibold">12%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Consommation</span>
                        <span className="text-white font-semibold">10%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Industrie</span>
                        <span className="text-white font-semibold">8%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Énergie</span>
                        <span className="text-white font-semibold">8%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Immobilier</span>
                        <span className="text-white font-semibold">7%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Matières premières</span>
                        <span className="text-white font-semibold">5%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Utilities</span>
                        <span className="text-white font-semibold">5%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-300">Télécommunications</span>
                        <span className="text-white font-semibold">5%</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Rééquilibrage et gestion */}
              <div>
                <h3 className="text-xl font-bold text-white mb-4">Stratégies de Rééquilibrage</h3>
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="bg-green-500/10 p-6 rounded-xl border border-green-500/20">
                    <h4 className="font-semibold text-white mb-3 flex items-center">
                      <i className="ri-calendar-line text-green-400 mr-2"></i>
                      Rééquilibrage Temporel
                    </h4>
                    <div className="space-y-2 text-sm text-gray-300">
                      <p><strong>Fréquence:</strong> Trimestrielle ou semestrielle</p>
                      <p><strong>Méthode:</strong> Revenir aux allocations cibles</p>
                      <p><strong>Avantage:</strong> Discipline et automatisation</p>
                      <p><strong>Inconvénient:</strong> Peut être sous-optimal</p>
                    </div>
                    <div className="mt-3 p-2 bg-green-500/20 rounded text-xs text-green-300">
                      Recommandé pour investisseurs débutants
                    </div>
                  </div>

                  <div className="bg-blue-500/10 p-6 rounded-xl border border-blue-500/20">
                    <h4 className="font-semibold text-white mb-3 flex items-center">
                      <i className="ri-percent-line text-blue-400 mr-2"></i>
                      Rééquilibrage par Seuils
                    </h4>
                    <div className="space-y-2 text-sm text-gray-300">
                      <p><strong>Déclencheur:</strong> Écart de +/- 5% de la cible</p>
                      <p><strong>Méthode:</strong> Ajustement dès dépassement</p>
                      <p><strong>Avantage:</strong> Plus réactif aux mouvements</p>
                      <p><strong>Inconvénient:</strong> Plus de transactions</p>
                    </div>
                    <div className="mt-3 p-2 bg-blue-500/20 rounded text-xs text-blue-300">
                      Recommandé pour investisseurs expérimentés
                    </div>
                  </div>

                  <div className="bg-purple-500/10 p-6 rounded-xl border border-purple-500/20">
                    <h4 className="font-semibold text-white mb-3 flex items-center">
                      <i className="ri-line-chart-line text-purple-400 mr-2"></i>
                      Rééquilibrage Tactique
                    </h4>
                    <div className="space-y-2 text-sm text-gray-300">
                      <p><strong>Approche:</strong> Ajustements selon cycle économique</p>
                      <p><strong>Méthode:</strong> Sur/sous-pondération temporaire</p>
                      <p><strong>Avantage:</strong> Potentiel de surperformance</p>
                      <p><strong>Inconvénient:</strong> Risque de timing errors</p>
                    </div>
                    <div className="mt-3 p-2 bg-purple-500/20 rounded text-xs text-purple-300">
                      Pour investisseurs très expérimentés
                    </div>
                  </div>
                </div>
              </div>

              {/* ETF recommandés par catégorie */}
              <div>
                <h3 className="text-xl font-bold text-white mb-4">ETF Recommandés par Catégorie</h3>
                <div className="space-y-4">
                  <div className="bg-black/30 p-4 rounded-xl">
                    <h4 className="font-semibold text-white mb-3 flex items-center">
                      <i className="ri-global-line text-blue-400 mr-2"></i>
                      ETF Globaux & Larges
                    </h4>
                    <div className="grid md:grid-cols-3 gap-4 text-sm">
                      <div className="bg-blue-500/10 p-3 rounded border border-blue-500/20">
                        <div className="font-semibold text-white">EWLD (Amundi)</div>
                        <div className="text-blue-400">MSCI World</div>
                        <div className="text-gray-400 text-xs">Frais: 0.45% - 1600+ actions</div>
                      </div>
                      <div className="bg-blue-500/10 p-3 rounded border border-blue-500/20">
                        <div className="font-semibold text-white">CW8 (iShares)</div>
                        <div className="text-blue-400">MSCI World</div>
                        <div className="text-gray-400 text-xs">Frais: 0.50% - PEA éligible</div>
                      </div>
                      <div className="bg-blue-500/10 p-3 rounded border border-blue-500/20">
                        <div className="font-semibold text-white">PAEEM (Amundi)</div>
                        <div className="text-blue-400">Marchés émergents</div>
                        <div className="text-gray-400 text-xs">Frais: 0.20% - PEA éligible</div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-black/30 p-4 rounded-xl">
                    <h4 className="font-semibold text-white mb-3 flex items-center">
                      <i className="ri-line-chart-line text-green-400 mr-2"></i>
                      ETF Sectoriels & Thématiques
                    </h4>
                    <div className="grid md:grid-cols-3 gap-4 text-sm">
                      <div className="bg-green-500/10 p-3 rounded border border-green-500/20">
                        <div className="font-semibold text-white">TNZZ (iShares)</div>
                        <div className="text-green-400">Tech Nasdaq-100</div>
                        <div className="text-gray-400 text-xs">Frais: 0.55% - FAANG++</div>
                      </div>
                      <div className="bg-green-500/10 p-3 rounded border border-green-500/20">
                        <div className="font-semibold text-white">HEAL (Lyxor)</div>
                        <div className="text-green-400">Healthcare</div>
                        <div className="text-gray-400 text-xs">Frais: 0.30% - Défensif</div>
                      </div>
                      <div className="bg-green-500/10 p-3 rounded border border-green-500/20">
                        <div className="font-semibold text-white">RBOT (Lyxor)</div>
                        <div className="text-green-400">Robotique & IA</div>
                        <div className="text-gray-400 text-xs">Frais: 0.40% - Futur</div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-black/30 p-4 rounded-xl">
                    <h4 className="font-semibold text-white mb-3 flex items-center">
                      <i className="ri-shield-line text-yellow-400 mr-2"></i>
                      ETF Obligations & Défensifs
                    </h4>
                    <div className="grid md:grid-cols-3 gap-4 text-sm">
                      <div className="bg-yellow-500/10 p-3 rounded border border-yellow-500/20">
                        <div className="font-semibold text-white">AGGH (iShares)</div>
                        <div className="text-yellow-400">Obligations globales</div>
                        <div className="text-gray-400 text-xs">Frais: 0.10% - Très diversifié</div>
                      </div>
                      <div className="bg-yellow-500/10 p-3 rounded border border-yellow-500/20">
                        <div className="font-semibold text-white">COAL (Lyxor)</div>
                        <div className="text-yellow-400">Matières premières</div>
                        <div className="text-gray-400 text-xs">Frais: 0.30% - Inflation hedge</div>
                      </div>
                      <div className="bg-yellow-500/10 p-3 rounded border border-yellow-500/20">
                        <div className="font-semibold text-white">EPRA (Amundi)</div>
                        <div className="text-yellow-400">REIT Europe</div>
                        <div className="text-gray-400 text-xs">Frais: 0.23% - Immobilier</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Erreurs courantes à éviter */}
              <div>
                <h3 className="text-xl font-bold text-white mb-4">Erreurs de Diversification à Éviter</h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-red-500/10 p-6 rounded-xl border border-red-500/20">
                    <h4 className="font-semibold text-white mb-4 flex items-center">
                      <i className="ri-close-circle-line text-red-400 mr-2"></i>
                      Pièges Classiques
                    </h4>
                    <ul className="space-y-3">
                      <li className="flex items-start space-x-3">
                        <i className="ri-arrow-right-line text-red-400 mt-0.5"></i>
                        <div>
                          <span className="text-white font-medium">Fausse diversification</span>
                          <p className="text-gray-300 text-xs">10 ETF qui suivent le même indice</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <i className="ri-arrow-right-line text-red-400 mt-0.5"></i>
                        <div>
                          <span className="text-white font-medium">Biais domestique</span>
                          <p className="text-gray-300 text-xs">Trop concentré sur la France/Europe</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <i className="ri-arrow-right-line text-red-400 mt-0.5"></i>
                        <div>
                          <span className="text-white font-medium">Sur-diversification</span>
                          <p className="text-gray-300 text-xs">Trop d'actifs = dilution performance</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <i className="ri-arrow-right-line text-red-400 mt-0.5"></i>
                        <div>
                          <span className="text-white font-medium">Negliger les corrélations</span>
                          <p className="text-gray-300 text-xs">Actifs qui bougent ensemble</p>
                        </div>
                      </li>
                    </ul>
                  </div>

                  <div className="bg-green-500/10 p-6 rounded-xl border border-green-500/20">
                    <h4 className="font-semibold text-white mb-4 flex items-center">
                      <i className="ri-check-circle-line text-green-400 mr-2"></i>
                      Bonnes Pratiques
                    </h4>
                    <ul className="space-y-3">
                      <li className="flex items-start space-x-3">
                        <i className="ri-arrow-right-line text-green-400 mt-0.5"></i>
                        <div>
                          <span className="text-white font-medium">Core-Satellite</span>
                          <p className="text-gray-300 text-xs">Base ETF larges + positions ciblées</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <i className="ri-arrow-right-line text-green-400 mt-0.5"></i>
                        <div>
                          <span className="text-white font-medium">Exposition géographique</span>
                          <p className="text-gray-300 text-xs">USA, Europe, Asie, Émergents</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <i className="ri-arrow-right-line text-green-400 mt-0.5"></i>
                        <div>
                          <span className="text-white font-medium">Mix cyclique/défensif</span>
                          <p className="text-gray-300 text-xs">Équilibrer selon cycles économiques</p>
                        </div>
                      </li>
                      <li className="flex items-start space-x-3">
                        <i className="ri-arrow-right-line text-green-400 mt-0.5"></i>
                        <div>
                          <span className="text-white font-medium">Monitoring régulier</span>
                          <p className="text-gray-300 text-xs">Surveiller dérives et rééquilibrer</p>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Conseils d'experts */}
              <div className="bg-gradient-to-r from-yellow-500/20 to-yellow-600/20 p-6 rounded-xl border border-yellow-500/30">
                <h3 className="text-xl font-bold text-white mb-4 flex items-center">
                  <i className="ri-lightbulb-line text-yellow-400 mr-3"></i>
                  Conseils d'Experts - Allocation Optimale 2024
                </h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-white mb-3">Stratégies Gagnantes</h4>
                    <ul className="space-y-2 text-sm text-gray-300">
                      <li className="flex items-start space-x-2">
                        <i className="ri-checkbox-circle-line text-green-400 mt-0.5"></i>
                        <span>Commencer par ETF World comme base (30-50%)</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <i className="ri-checkbox-circle-line text-green-400 mt-0.5"></i>
                        <span>Ajouter exposition USA tech (15-25%)</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <i className="ri-checkbox-circle-line text-green-400 mt-0.5"></i>
                        <span>Intégrer marchés émergents (5-15%)</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <i className="ri-checkbox-circle-line text-green-400 mt-0.5"></i>
                        <span>Obligations comme stabilisateur (10-30%)</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <i className="ri-checkbox-circle-line text-green-400 mt-0.5"></i>
                        <span>Alternative assets (REIT, commodities) 5-10%</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <i className="ri-checkbox-circle-line text-green-400 mt-0.5"></i>
                        <span>Crypto allocation modérée (max 5-10%)</span>
                      </li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-white mb-3">Erreurs à Éviter Absolument</h4>
                    <ul className="space-y-2 text-sm text-gray-300">
                      <li className="flex items-start space-x-2">
                        <i className="ri-close-circle-line text-red-400 mt-0.5"></i>
                        <span>Concentrer >30% sur un seul actif/secteur</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <i className="ri-close-circle-line text-red-400 mt-0.5"></i>
                        <span>Ignorer les frais de gestion (>0.5% = cher)</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <i className="ri-close-circle-line text-red-400 mt-0.5"></i>
                        <span>Rééquilibrer trop souvent (coûts élevés)</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <i className="ri-close-circle-line text-red-400 mt-0.5"></i>
                        <span>Paniquer en cas de baisse et tout vendre</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <i className="ri-close-circle-line text-red-400 mt-0.5"></i>
                        <span>Courir après la performance passée</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <i className="ri-close-circle-line text-red-400 mt-0.5"></i>
                        <span>Négliger horizon temporel et profil risque</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Actions disponibles */}
              <div className="flex space-x-4 pt-4 border-t border-gray-700">
                <button className="flex-1 bg-yellow-500 text-black py-3 px-6 rounded-lg font-semibold hover:bg-yellow-400 transition-colors cursor-pointer whitespace-nowrap">
                  Rééquilibrer mon Portefeuille
                </button>
                <button className="flex-1 bg-blue-500 text-white py-3 px-6 rounded-lg font-semibold hover:bg-blue-400 transition-colors cursor-pointer whitespace-nowrap">
                  Analyse Risque/Rendement
                </button>
                <button className="flex-1 bg-green-500 text-white py-3 px-6 rounded-lg font-semibold hover:bg-green-400 transition-colors cursor-pointer whitespace-nowrap">
                  Simuler Allocations
                </button>
                <button
                  onClick={closeModal}
                  className="px-6 py-3 border border-gray-600 text-gray-300 rounded-lg hover:bg-gray-700 transition-colors cursor-pointer whitespace-nowrap"
                >
                  Fermer
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Fonction utilitaire pour obtenir les icônes selon le type d'actif
function getAllocationIcon(name: string): string {
  const iconMap: { [key: string]: string } = {
    'Actions': 'ri-line-chart-line',
    'Obligations': 'ri-file-chart-line',
    'ETF': 'ri-funds-line',
    'Crypto': 'ri-bit-coin-line',
    'Cash': 'ri-money-dollar-circle-line',
    'REIT': 'ri-building-line',
    'Matières premières': 'ri-oil-line',
    'Immobilier': 'ri-home-line'
  };

  return iconMap[name] || 'ri-pie-chart-line';
}
