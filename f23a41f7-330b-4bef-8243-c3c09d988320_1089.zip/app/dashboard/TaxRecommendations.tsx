
'use client';

import React, { useState, useEffect } from 'react';

export default function TaxRecommendations({ results, revenus, situation, options }) {
  const [expandedSection, setExpandedSection] = useState(null);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  const toNumber = (value) => {
    if (!value || value === '') return 0;
    const cleanValue = value.toString().replace(/[^0-9.,]/g, '').replace(',', '.');
    const num = parseFloat(cleanValue);
    return isNaN(num) ? 0 : Math.max(0, num);
  };

  const formatNumber = (value) => {
    return new Intl.NumberFormat('fr-FR').format(value);
  };

  // Calcul des recommandations d'optimisation
  const generateRecommendations = () => {
    if (!isMounted || !results) return [];
    
    const recommendations = [];
    const totalRevenus = results.revenus.total_brut;
    const tauxMarginal = results.impot_revenu.taux_marginal / 100;

    // PEA - Plan d'Épargne en Actions
    if (totalRevenus > 20000 && revenus && toNumber(revenus.revenus_financiers) > 0) {
      const economie = Math.min(toNumber(revenus.revenus_financiers), 150000) * 0.172;
      recommendations.push({
        type: 'PEA',
        title: 'Plan d\'Épargne en Actions (PEA)',
        description: 'Investissez jusqu\'à 150 000€ dans un PEA pour exonérer vos plus-values d\'impôt après 5 ans.',
        economie: economie,
        icon: 'ri-line-chart-line',
        color: 'blue',
        priority: 'haute',
        details: [
          'Exonération fiscale des plus-values après 5 ans',
          'Seuls les prélèvements sociaux (17,2%) restent dus',
          'Plafond de versement : 150 000€',
          'Investissement en actions européennes uniquement'
        ]
      });
    }

    // Assurance Vie
    if (totalRevenus > 25000) {
      const versementAnnuel = Math.min(totalRevenus * 0.10, 30000);
      const economie = versementAnnuel * tauxMarginal;
      recommendations.push({
        type: 'AV',
        title: 'Assurance Vie',
        description: 'Optimisez votre fiscalité avec les avantages de l\'assurance vie.',
        economie: economie,
        icon: 'ri-shield-check-line',
        color: 'green',
        priority: 'haute',
        details: [
          'Abattement annuel de 4 600€ (9 200€ couple) sur les intérêts',
          'Fiscalité réduite après 8 ans : 7,5% au lieu du barème',
          'Transmission avantageuse (152 500€ par bénéficiaire)',
          'Liquidités disponibles à tout moment'
        ]
      });
    }

    // PER - Plan d'Épargne Retraite
    if (revenus && toNumber(revenus.salaires) > 20000) {
      const plafondPER = Math.min(toNumber(revenus.salaires) * 0.10, 35000);
      const economie = plafondPER * tauxMarginal;
      recommendations.push({
        type: 'PER',
        title: 'Plan d\'Épargne Retraite (PER)',
        description: 'Déduisez vos versements de vos revenus imposables.',
        economie: economie,
        icon: 'ri-time-line',
        color: 'purple',
        priority: 'moyenne',
        details: [
          `Plafond de déduction : ${formatNumber(plafondPER)}€`,
          'Réduction d\'impôt immédiate',
          'Capitalisation exonérée d\'impôt',
          'Sortie en rente ou capital à la retraite'
        ]
      });
    }

    // Déficit foncier
    if (revenus && toNumber(revenus.foncier) > 0 && options && toNumber(options.deficit_foncier) === 0) {
      const economieEstimee = 5000 * tauxMarginal;
      recommendations.push({
        type: 'FONCIER',
        title: 'Optimisation du déficit foncier',
        description: 'Créez un déficit foncier pour réduire vos impôts.',
        economie: economieEstimee,
        icon: 'ri-home-4-line',
        color: 'orange',
        priority: 'moyenne',
        details: [
          'Travaux déductibles : isolation, chauffage, plomberie...',
          'Déficit imputable sur le revenu global (10 700€/an max)',
          'Report possible sur 10 ans',
          'Intérêts d\'emprunt déductibles'
        ]
      });
    }

    // FCPI / FIP
    if (totalRevenus > 50000 && results.impot_revenu.impot_net > 5000) {
      const investissement = Math.min(12000, totalRevenus * 0.05);
      const economie = investissement * 0.18;
      recommendations.push({
        type: 'FCPI',
        title: 'FCPI / FIP - Fonds d\'investissement',
        description: 'Réduction d\'impôt de 18% pour investissement en PME.',
        economie: economie,
        icon: 'ri-building-line',
        color: 'indigo',
        priority: 'faible',
        details: [
          'Réduction d\'impôt de 18%',
          'Plafond : 12 000€ (24 000€ couple)',
          'Conservation 5 ans minimum',
          'Investissement en PME françaises'
        ]
      });
    }

    // SOFICA
    if (results.impot_revenu.impot_net > 3000) {
      const investissement = Math.min(18000, results.impot_revenu.impot_net);
      const economie = investissement * 0.30;
      recommendations.push({
        type: 'SOFICA',
        title: 'SOFICA - Sociétés de financement du cinéma',
        description: 'Réduction d\'impôt jusqu\'à 36% pour le financement du cinéma.',
        economie: economie,
        icon: 'ri-movie-line',
        color: 'pink',
        priority: 'faible',
        details: [
          'Réduction de 30% à 36% selon les films',
          'Plafond : 18 000€ par an',
          'Conservation 5 ans minimum',
          'Financement de la production française'
        ]
      });
    }

    // Dons aux associations
    if (options && toNumber(options.dons) === 0 && totalRevenus > 30000) {
      const donRecommande = Math.min(totalRevenus * 0.02, 1000);
      const economie = donRecommande * 0.66;
      recommendations.push({
        type: 'DONS',
        title: 'Dons aux associations',
        description: 'Réduction d\'impôt de 66% pour vos dons.',
        economie: economie,
        icon: 'ri-heart-line',
        color: 'red',
        priority: 'faible',
        details: [
          'Réduction de 66% (75% pour certains organismes)',
          'Plafond : 20% du revenu imposable',
          'Report possible sur 5 ans en cas de dépassement',
          'Reçu fiscal obligatoire'
        ]
      });
    }

    return recommendations.sort((a, b) => {
      const priorityOrder = { 'haute': 3, 'moyenne': 2, 'faible': 1 };
      if (priorityOrder[a.priority] !== priorityOrder[b.priority]) {
        return priorityOrder[b.priority] - priorityOrder[a.priority];
      }
      return b.economie - a.economie;
    });
  };

  const recommendations = generateRecommendations();
  const totalEconomie = recommendations.reduce((sum, rec) => sum + rec.economie, 0);

  const toggleSection = (index) => {
    setExpandedSection(expandedSection === index ? null : index);
  };

  const getColorClasses = (color) => {
    const colors = {
      blue: 'border-blue-500/30 bg-blue-500/10',
      green: 'border-green-500/30 bg-green-500/10',
      purple: 'border-purple-500/30 bg-purple-500/10',
      orange: 'border-orange-500/30 bg-orange-500/10',
      indigo: 'border-indigo-500/30 bg-indigo-500/10',
      pink: 'border-pink-500/30 bg-pink-500/10',
      red: 'border-red-500/30 bg-red-500/10'
    };
    return colors[color] || 'border-gray-500/30 bg-gray-500/10';
  };

  const getIconColor = (color) => {
    const colors = {
      blue: 'text-blue-400',
      green: 'text-green-400',
      purple: 'text-purple-400',
      orange: 'text-orange-400',
      indigo: 'text-indigo-400',
      pink: 'text-pink-400',
      red: 'text-red-400'
    };
    return colors[color] || 'text-gray-400';
  };

  const getPriorityBadge = (priority) => {
    const badges = {
      'haute': { text: 'Priorité haute', class: 'bg-red-500 text-white' },
      'moyenne': { text: 'Priorité moyenne', class: 'bg-yellow-500 text-black' },
      'faible': { text: 'À considérer', class: 'bg-gray-500 text-white' }
    };
    return badges[priority] || badges['faible'];
  };

  if (!isMounted) {
    return (
      <div className="bg-gray-900 rounded-xl p-8 border border-gray-700">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-700 rounded mb-4"></div>
          <div className="h-4 bg-gray-700 rounded mb-2"></div>
          <div className="h-4 bg-gray-700 rounded mb-2"></div>
        </div>
      </div>
    );
  }

  if (recommendations.length === 0) {
    return (
      <div className="bg-gray-900 rounded-xl p-8 border border-gray-700">
        <h3 className="text-xl font-bold text-white mb-4 flex items-center">
          <i className="ri-lightbulb-line text-yellow-400 mr-3"></i>
          Recommandations d'optimisation fiscale
        </h3>
        <div className="text-center py-8">
          <i className="ri-check-double-line text-6xl text-green-400 mb-4"></i>
          <p className="text-gray-300 text-lg">
            Votre situation fiscale semble déjà bien optimisée !
          </p>
          <p className="text-gray-400 mt-2">
            Aucune optimisation majeure détectée avec les données actuelles.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-900 rounded-xl p-8 border border-gray-700 space-y-6" suppressHydrationWarning={true}>
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-bold text-white flex items-center">
          <i className="ri-lightbulb-line text-yellow-400 mr-3"></i>
          Recommandations d'optimisation fiscale
        </h3>
        
        <div className="bg-yellow-500/20 rounded-lg px-4 py-2 border border-yellow-500/30">
          <div className="text-sm text-gray-400">Économie potentielle</div>
          <div className="text-xl font-bold text-yellow-400">
            {formatNumber(Math.round(totalEconomie))} €
          </div>
        </div>
      </div>

      <div className="grid gap-4">
        {recommendations.map((rec, index) => (
          <div
            key={rec.type}
            className={`rounded-xl border p-6 transition-all ${getColorClasses(rec.color)}`}
          >
            <div 
              className="flex items-center justify-between cursor-pointer"
              onClick={() => toggleSection(index)}
            >
              <div className="flex items-center space-x-4">
                <i className={`${rec.icon} text-2xl ${getIconColor(rec.color)}`}></i>
                
                <div>
                  <h4 className="text-lg font-bold text-white">{rec.title}</h4>
                  <p className="text-gray-300 text-sm">{rec.description}</p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <div className="text-sm text-gray-400">Économie</div>
                  <div className="text-lg font-bold text-white">
                    {formatNumber(Math.round(rec.economie))} €
                  </div>
                </div>

                <div className="flex flex-col items-end space-y-2">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityBadge(rec.priority).class}`}>
                    {getPriorityBadge(rec.priority).text}
                  </span>
                  
                  <i className={`ri-arrow-${expandedSection === index ? 'up' : 'down'}-s-line text-gray-400`}></i>
                </div>
              </div>
            </div>

            {expandedSection === index && (
              <div className="mt-6 pt-6 border-t border-gray-700">
                <h5 className="text-white font-semibold mb-3">Détails et avantages :</h5>
                <ul className="space-y-2">
                  {rec.details.map((detail, idx) => (
                    <li key={idx} className="flex items-start space-x-2">
                      <i className="ri-arrow-right-s-line text-gray-400 mt-0.5 flex-shrink-0"></i>
                      <span className="text-gray-300 text-sm">{detail}</span>
                    </li>
                  ))}
                </ul>

                <div className="mt-4 p-4 bg-black/30 rounded-lg">
                  <div className="flex items-center space-x-2 mb-2">
                    <i className="ri-information-line text-blue-400"></i>
                    <span className="text-blue-400 font-medium">À retenir</span>
                  </div>
                  <p className="text-gray-300 text-sm">
                    {rec.type === 'PEA' && 'Le PEA est idéal pour investir en bourse avec une fiscalité avantageuse après 5 ans.'}
                    {rec.type === 'AV' && 'L\'assurance vie reste le placement préféré des Français pour sa souplesse et sa fiscalité.'}
                    {rec.type === 'PER' && 'Le PER remplace le PERP avec plus de souplesse et les mêmes avantages fiscaux.'}
                    {rec.type === 'FONCIER' && 'Les travaux de rénovation énergétique sont particulièrement avantageux fiscalement.'}
                    {rec.type === 'FCPI' && 'Investissement risqué mais avec des avantages fiscaux intéressants pour les hauts revenus.'}
                    {rec.type === 'SOFICA' && 'Placement spécialisé avec un fort avantage fiscal mais un risque élevé.'}
                    {rec.type === 'DONS' && 'Les dons permettent de réduire son impôt tout en soutenant des causes importantes.'}
                  </p>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="bg-blue-500/10 rounded-lg p-6 border border-blue-500/20">
        <div className="flex items-start space-x-3">
          <i className="ri-information-line text-blue-400 text-xl mt-0.5"></i>
          <div>
            <h4 className="text-blue-400 font-semibold mb-2">Avertissement important</h4>
            <p className="text-gray-300 text-sm">
              Ces recommandations sont basées sur votre situation déclarée et les règles fiscales 2025. 
              Nous vous conseillons de consulter un conseiller fiscal ou un expert-comptable avant de 
              prendre des décisions d'investissement importantes. Les économies calculées sont des estimations 
              qui peuvent varier selon votre situation complète.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
