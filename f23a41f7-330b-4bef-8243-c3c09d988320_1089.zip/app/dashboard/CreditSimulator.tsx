
'use client';

import { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, BarChart, Bar, AreaChart, Area } from 'recharts';

export default function CreditSimulator() {
  // États pour revenus et charges
  const [revenus, setRevenus] = useState({
    salaire: '3500',
    primes: '500',
    autresRevenus: '200',
    conjointSalaire: '2800',
    conjointAutres: '150'
  });

  const [charges, setCharges] = useState({
    loyer: '1200',
    creditEnCours: '350',
    pensionAlimentaire: '0',
    autresCharges: '800'
  });

  // États pour le simulateur de crédit
  const [creditData, setCreditData] = useState({
    montant: '250000',
    duree: '20',
    taux: '3.5',
    type: 'immobilier',
    apport: '50000'
  });

  const [results, setResults] = useState(null);
  const [amortissementData, setAmortissementData] = useState([]);

  // Calculs revenus et charges
  const totalRevenus = Object.values(revenus).reduce((sum, val) => sum + (parseFloat(val) || 0), 0);
  const totalCharges = Object.values(charges).reduce((sum, val) => sum + (parseFloat(val) || 0), 0);
  const resteAVivre = totalRevenus - totalCharges;
  
  // Taux d'endettement AVANT acquisition (charges actuelles seulement)
  const tauxEndettementActuel = (totalCharges / totalRevenus) * 100;
  
  // CORRECTION: Calcul de la capacité d'endettement selon les barèmes bancaires
  // Règle bancaire: 33% maximum des revenus nets pour TOUTES les charges de crédit
  const seuilEndettement = 0.35; // 35% pour être plus réaliste (certaines banques acceptent jusqu'à 35%)
  const capaciteEndettementMax = totalRevenus * seuilEndettement;
  
  // Capacité d'emprunt = Capacité max - crédits en cours (SANS le loyer car il sera remplacé)
  const capaciteEmprunt = Math.max(0, capaciteEndettementMax - (parseFloat(charges.creditEnCours) || 0) - (parseFloat(charges.pensionAlimentaire) || 0));
  
  // Reste à vivre minimum requis par les banques (généralement 800-1200€ selon la composition familiale)
  const resteAVivreMinimum = 1000; // Barème standard pour un couple
  const resteAVivreApresCredit = totalRevenus - (parseFloat(charges.autresCharges) || 0) - (parseFloat(charges.creditEnCours) || 0) - (parseFloat(charges.pensionAlimentaire) || 0);
  
  // Capacité réelle = minimum entre capacité d'endettement et reste à vivre
  const capaciteReelle = Math.min(capaciteEmprunt, resteAVivreApresCredit - resteAVivreMinimum);

  const calculateCredit = () => {
    const montant = parseFloat(creditData.montant);
    const duree = parseInt(creditData.duree);
    const tauxAnnuel = parseFloat(creditData.taux) / 100;
    const tauxMensuel = tauxAnnuel / 12;
    const nbMensualites = duree * 12;

    if (montant && duree && tauxMensuel > 0) {
      // Formule correcte de calcul de mensualité
      // M = C × [i × (1 + i)^n] / [(1 + i)^n - 1]
      const mensualite = (montant * tauxMensuel * Math.pow(1 + tauxMensuel, nbMensualites)) / (Math.pow(1 + tauxMensuel, nbMensualites) - 1);
      
      const coutTotal = mensualite * nbMensualites;
      const interets = coutTotal - montant;
      
      // Nouveau taux d'endettement APRÈS acquisition
      // Toutes les charges de crédit (crédits en cours + nouvelle mensualité + pension)
      const chargesCredit = (parseFloat(charges.creditEnCours) || 0) + mensualite + (parseFloat(charges.pensionAlimentaire) || 0);
      const nouveauTauxEndettement = (chargesCredit / totalRevenus) * 100;
      
      // Nouveau reste à vivre = Revenus - (autres charges + charges de crédit)
      const nouveauResteAVivre = totalRevenus - (parseFloat(charges.autresCharges) || 0) - chargesCredit;

      // Critères de faisabilité bancaire
      const tauxAcceptable = nouveauTauxEndettement <= 35; // 35% maximum
      const resteAVivreAcceptable = nouveauResteAVivre >= resteAVivreMinimum;
      const faisable = tauxAcceptable && resteAVivreAcceptable;

      // Génération du tableau d'amortissement
      const amortissement = [];
      let capitalRestant = montant;
      
      for (let annee = 1; annee <= duree; annee++) {
        let interetsAnnee = 0;
        let capitalAnnee = 0;
        
        for (let mois = 1; mois <= 12; mois++) {
          const interetsMois = capitalRestant * tauxMensuel;
          const capitalMois = mensualite - interetsMois;
          
          interetsAnnee += interetsMois;
          capitalAnnee += capitalMois;
          capitalRestant -= capitalMois;
        }
        
        amortissement.push({
          annee: annee,
          capital: Math.round(capitalAnnee),
          interets: Math.round(interetsAnnee),
          capitalRestant: Math.max(0, Math.round(capitalRestant)),
          mensualite: Math.round(mensualite)
        });
      }
      
      setAmortissementData(amortissement);

      setResults({
        mensualite: mensualite.toFixed(2),
        coutTotal: coutTotal.toFixed(2),
        interets: interets.toFixed(2),
        nouveauTauxEndettement: nouveauTauxEndettement.toFixed(1),
        nouveauResteAVivre: nouveauResteAVivre.toFixed(2),
        faisable: faisable,
        raisonRefus: !faisable ? (
          !tauxAcceptable ? 'Taux d\'endettement trop élevé' : 'Reste à vivre insuffisant'
        ) : null
      });
    }
  };

  useEffect(() => {
    calculateCredit();
  }, [creditData, totalRevenus, totalCharges]);

  // Données pour les graphiques
  const pieDataRevenus = [
    { name: 'Salaire principal', value: parseFloat(revenus.salaire) || 0, color: '#3B82F6' },
    { name: 'Primes', value: parseFloat(revenus.primes) || 0, color: '#10B981' },
    { name: 'Autres revenus', value: parseFloat(revenus.autresRevenus) || 0, color: '#F59E0B' },
    { name: 'Salaire conjoint', value: parseFloat(revenus.conjointSalaire) || 0, color: '#8B5CF6' },
    { name: 'Autres conjoint', value: parseFloat(revenus.conjointAutres) || 0, color: '#EF4444' }
  ].filter(item => item.value > 0);

  const pieDataCharges = [
    { name: 'Loyer', value: parseFloat(charges.loyer) || 0, color: '#EF4444' },
    { name: 'Crédits en cours', value: parseFloat(charges.creditEnCours) || 0, color: '#F97316' },
    { name: 'Pension alimentaire', value: parseFloat(charges.pensionAlimentaire) || 0, color: '#EAB308' },
    { name: 'Autres charges', value: parseFloat(charges.autresCharges) || 0, color: '#DC2626' }
  ].filter(item => item.value > 0);

  const budgetData = [
    { name: 'Revenus', value: totalRevenus, color: '#10B981' },
    { name: 'Charges actuelles', value: totalCharges, color: '#EF4444' },
    { name: 'Nouvelle mensualité', value: results ? parseFloat(results.mensualite) : 0, color: '#F59E0B' },
    { name: 'Nouveau reste à vivre', value: results ? parseFloat(results.nouveauResteAVivre) : resteAVivre, color: '#3B82F6' }
  ];

  const scenariosData = [
    { duree: '15 ans', mensualite: results ? (parseFloat(results.mensualite) * 1.25).toFixed(0) : 0, cout: results ? (parseFloat(results.coutTotal) * 0.85).toFixed(0) : 0 },
    { duree: '20 ans', mensualite: results ? results.mensualite : 0, cout: results ? results.coutTotal : 0 },
    { duree: '25 ans', mensualite: results ? (parseFloat(results.mensualite) * 0.85).toFixed(0) : 0, cout: results ? (parseFloat(results.coutTotal) * 1.15).toFixed(0) : 0 },
    { duree: '30 ans', mensualite: results ? (parseFloat(results.mensualite) * 0.75).toFixed(0) : 0, cout: results ? (parseFloat(results.coutTotal) * 1.35).toFixed(0) : 0 }
  ];

  return (
    <div className="space-y-8">
      {/* Section 1: Analyse Revenus et Charges avec graphiques */}
      <div className="bg-gray-900 rounded-xl shadow-sm border border-green-500/20 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
            <i className="ri-money-euro-circle-line text-green-600 text-xl"></i>
          </div>
          <div>
            <h2 className="text-xl font-semibold text-white">Analyse Revenus et Charges</h2>
            <p className="text-gray-400">Évaluez votre situation financière selon les barèmes bancaires</p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Paramètres revenus */}
          <div className="space-y-4">
            <h3 className="font-medium text-white flex items-center gap-2">
              <i className="ri-add-circle-line text-green-400"></i>
              Revenus mensuels nets
            </h3>
            
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Salaire principal</label>
                <input
                  type="range"
                  min="1500"
                  max="8000"
                  step="100"
                  value={revenus.salaire}
                  onChange={(e) => setRevenus({...revenus, salaire: e.target.value})}
                  className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-sm text-gray-400 mt-1">
                  <span>1 500€</span>
                  <span className="text-green-400 font-semibold">{parseFloat(revenus.salaire).toLocaleString()}€</span>
                  <span>8 000€</span>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Primes et bonus</label>
                <input
                  type="range"
                  min="0"
                  max="2000"
                  step="50"
                  value={revenus.primes}
                  onChange={(e) => setRevenus({...revenus, primes: e.target.value})}
                  className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-sm text-gray-400 mt-1">
                  <span>0€</span>
                  <span className="text-green-400 font-semibold">{parseFloat(revenus.primes).toLocaleString()}€</span>
                  <span>2 000€</span>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Autres revenus</label>
                <input
                  type="range"
                  min="0"
                  max="1500"
                  step="25"
                  value={revenus.autresRevenus}
                  onChange={(e) => setRevenus({...revenus, autresRevenus: e.target.value})}
                  className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-sm text-gray-400 mt-1">
                  <span>0€</span>
                  <span className="text-green-400 font-semibold">{parseFloat(revenus.autresRevenus).toLocaleString()}€</span>
                  <span>1 500€</span>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Salaire conjoint</label>
                <input
                  type="range"
                  min="0"
                  max="6000"
                  step="100"
                  value={revenus.conjointSalaire}
                  onChange={(e) => setRevenus({...revenus, conjointSalaire: e.target.value})}
                  className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-sm text-gray-400 mt-1">
                  <span>0€</span>
                  <span className="text-green-400 font-semibold">{parseFloat(revenus.conjointSalaire).toLocaleString()}€</span>
                  <span>6 000€</span>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Autres revenus conjoint</label>
                <input
                  type="range"
                  min="0"
                  max="1000"
                  step="25"
                  value={revenus.conjointAutres}
                  onChange={(e) => setRevenus({...revenus, conjointAutres: e.target.value})}
                  className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-sm text-gray-400 mt-1">
                  <span>0€</span>
                  <span className="text-green-400 font-semibold">{parseFloat(revenus.conjointAutres).toLocaleString()}€</span>
                  <span>1 000€</span>
                </div>
              </div>
            </div>
          </div>

          {/* Paramètres charges */}
          <div className="space-y-4">
            <h3 className="font-medium text-white flex items-center gap-2">
              <i className="ri-subtract-line text-red-400"></i>
              Charges mensuelles
            </h3>
            
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Loyer actuel</label>
                <input
                  type="range"
                  min="0"
                  max="3000"
                  step="50"
                  value={charges.loyer}
                  onChange={(e) => setCharges({...charges, loyer: e.target.value})}
                  className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-sm text-gray-400 mt-1">
                  <span>0€</span>
                  <span className="text-red-400 font-semibold">{parseFloat(charges.loyer).toLocaleString()}€</span>
                  <span>3 000€</span>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Crédits en cours</label>
                <input
                  type="range"
                  min="0"
                  max="1500"
                  step="25"
                  value={charges.creditEnCours}
                  onChange={(e) => setCharges({...charges, creditEnCours: e.target.value})}
                  className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-sm text-gray-400 mt-1">
                  <span>0€</span>
                  <span className="text-red-400 font-semibold">{parseFloat(charges.creditEnCours).toLocaleString()}€</span>
                  <span>1 500€</span>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Pension alimentaire</label>
                <input
                  type="range"
                  min="0"
                  max="1000"
                  step="25"
                  value={charges.pensionAlimentaire}
                  onChange={(e) => setCharges({...charges, pensionAlimentaire: e.target.value})}
                  className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-sm text-gray-400 mt-1">
                  <span>0€</span>
                  <span className="text-red-400 font-semibold">{parseFloat(charges.pensionAlimentaire).toLocaleString()}€</span>
                  <span>1 000€</span>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">Autres charges fixes</label>
                <input
                  type="range"
                  min="300"
                  max="2000"
                  step="50"
                  value={charges.autresCharges}
                  onChange={(e) => setCharges({...charges, autresCharges: e.target.value})}
                  className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-sm text-gray-400 mt-1">
                  <span>300€</span>
                  <span className="text-red-400 font-semibold">{parseFloat(charges.autresCharges).toLocaleString()}€</span>
                  <span>2 000€</span>
                </div>
              </div>
            </div>
          </div>

          {/* Graphiques revenus/charges */}
          <div className="space-y-6">
            <div className="bg-black/30 rounded-lg p-4">
              <h4 className="font-medium text-white mb-3">Répartition Revenus</h4>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieDataRevenus}
                      cx="50%"
                      cy="50%"
                      innerRadius={30}
                      outerRadius={70}
                      dataKey="value"
                    >
                      {pieDataRevenus.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{
                        backgroundColor: '#1F2937',
                        border: '1px solid #10B981',
                        borderRadius: '8px',
                        color: '#FFFFFF'
                      }}
                      formatter={(value) => `${Math.round(value).toLocaleString()}€`}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-black/30 rounded-lg p-4">
              <h4 className="font-medium text-white mb-3">Répartition Charges</h4>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieDataCharges}
                      cx="50%"
                      cy="50%"
                      innerRadius={30}
                      outerRadius={70}
                      dataKey="value"
                    >
                      {pieDataCharges.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{
                        backgroundColor: '#1F2937',
                        border: '1px solid #EF4444',
                        borderRadius: '8px',
                        color: '#FFFFFF'
                      }}
                      formatter={(value) => `${Math.round(value).toLocaleString()}€`}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>

        {/* Résumé financier corrigé */}
        <div className="mt-8 grid md:grid-cols-5 gap-4">
          <div className="bg-green-500/20 p-4 rounded-xl border border-green-500/30">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-green-400 font-semibold">Revenus Totaux</h3>
              <i className="ri-arrow-up-line text-2xl text-green-400"></i>
            </div>
            <p className="text-2xl font-bold text-white">{totalRevenus.toLocaleString()} €</p>
            <p className="text-xs text-gray-400">Base de calcul bancaire</p>
          </div>

          <div className="bg-red-500/20 p-4 rounded-xl border border-red-500/30">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-red-400 font-semibold">Charges Actuelles</h3>
              <i className="ri-arrow-down-line text-2xl text-red-400"></i>
            </div>
            <p className="text-2xl font-bold text-white">{totalCharges.toLocaleString()} €</p>
            <p className="text-xs text-gray-400">Situation actuelle</p>
          </div>

          <div className="bg-orange-500/20 p-4 rounded-xl border border-orange-500/30">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-orange-400 font-semibold">Taux Endettement</h3>
              <i className="ri-percent-line text-2xl text-orange-400"></i>
            </div>
            <p className="text-2xl font-bold text-white">{tauxEndettementActuel.toFixed(1)}%</p>
            <p className="text-xs text-gray-400">Avant acquisition</p>
          </div>

          <div className="bg-blue-500/20 p-4 rounded-xl border border-blue-500/30">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-blue-400 font-semibold">Reste à Vivre</h3>
              <i className="ri-wallet-line text-2xl text-blue-400"></i>
            </div>
            <p className="text-2xl font-bold text-white">{resteAVivre.toLocaleString()} €</p>
            <p className="text-xs text-gray-400">Disponible actuel</p>
          </div>

          <div className="bg-purple-500/20 p-4 rounded-xl border border-purple-500/30">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-purple-400 font-semibold">Capacité Réelle</h3>
              <i className="ri-bank-line text-2xl text-purple-400"></i>
            </div>
            <p className="text-2xl font-bold text-white">{Math.max(0, capaciteReelle).toLocaleString()} €</p>
            <p className="text-xs text-gray-400">Mensualité max possible</p>
          </div>
        </div>

        {/* Explication des calculs bancaires */}
        <div className="mt-6 bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
          <h4 className="text-blue-400 font-semibold mb-2 flex items-center gap-2">
            <i className="ri-information-line"></i>
            Barèmes Bancaires Appliqués
          </h4>
          <div className="grid md:grid-cols-3 gap-4 text-sm text-gray-300">
            <div>
              <strong className="text-blue-400">Taux d'endettement max :</strong> 35% des revenus nets
              <br />
              <span className="text-xs text-gray-400">Inclut tous les crédits + pension alimentaire</span>
            </div>
            <div>
              <strong className="text-blue-400">Reste à vivre minimum :</strong> {resteAVivreMinimum}€/mois
              <br />
              <span className="text-xs text-gray-400">Barème standard pour un couple</span>
            </div>
            <div>
              <strong className="text-blue-400">Capacité réelle :</strong> Min(35% revenus, reste à vivre)
              <br />
              <span className="text-xs text-gray-400">Le plus restrictif des deux critères</span>
            </div>
          </div>
        </div>
      </div>

      {/* Section 2: Simulateur de Crédit avec graphiques */}
      <div className="bg-gray-900 rounded-xl shadow-sm border border-blue-500/20 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
            <i className="ri-calculator-line text-blue-600 text-xl"></i>
          </div>
          <div>
            <h2 className="text-xl font-semibold text-white">Simulateur de Crédit</h2>
            <p className="text-gray-400">Calculez vos mensualités et analysez la faisabilité</p>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Paramètres du crédit */}
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Type de crédit</label>
              <select
                value={creditData.type}
                onChange={(e) => setCreditData({...creditData, type: e.target.value})}
                className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white pr-8"
              >
                <option value="immobilier">Crédit immobilier</option>
                <option value="auto">Crédit auto</option>
                <option value="travaux">Crédit travaux</option>
                <option value="personnel">Crédit personnel</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Montant emprunté (€)</label>
              <input
                type="range"
                min="10000"
                max="800000"
                step="5000"
                value={creditData.montant}
                onChange={(e) => setCreditData({...creditData, montant: e.target.value})}
                className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-sm text-gray-400 mt-1">
                <span>10K €</span>
                <span className="text-blue-400 font-semibold">{parseFloat(creditData.montant).toLocaleString()} €</span>
                <span>800K €</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Durée (années)</label>
              <input
                type="range"
                min="5"
                max="30"
                step="1"
                value={creditData.duree}
                onChange={(e) => setCreditData({...creditData, duree: e.target.value})}
                className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-sm text-gray-400 mt-1">
                <span>5 ans</span>
                <span className="text-blue-400 font-semibold">{creditData.duree} ans</span>
                <span>30 ans</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Taux d'intérêt (%)</label>
              <input
                type="range"
                min="1"
                max="8"
                step="0.1"
                value={creditData.taux}
                onChange={(e) => setCreditData({...creditData, taux: e.target.value})}
                className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-sm text-gray-400 mt-1">
                <span>1%</span>
                <span className="text-blue-400 font-semibold">{creditData.taux}%</span>
                <span>8%</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Apport personnel (€)</label>
              <input
                type="range"
                min="0"
                max="200000"
                step="2500"
                value={creditData.apport}
                onChange={(e) => setCreditData({...creditData, apport: e.target.value})}
                className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex justify-between text-sm text-gray-400 mt-1">
                <span>0 €</span>
                <span className="text-blue-400 font-semibold">{parseFloat(creditData.apport).toLocaleString()} €</span>
                <span>200K €</span>
              </div>
            </div>
          </div>

          {/* Résultats avec graphique */}
          <div className="space-y-6">
            {results ? (
              <>
                <div className={`p-4 rounded-lg ${results.faisable ? 'bg-green-500/20 border border-green-500/30' : 'bg-red-500/20 border border-red-500/30'}`}>
                  <div className="flex items-center gap-2 mb-2">
                    <i className={`${results.faisable ? 'ri-check-circle-line text-green-400' : 'ri-error-warning-line text-red-400'} text-xl`}></i>
                    <span className={`font-medium ${results.faisable ? 'text-green-400' : 'text-red-400'}`}>
                      {results.faisable ? 'Crédit faisable' : 'Crédit difficile'}
                    </span>
                  </div>
                  <p className={`text-sm ${results.faisable ? 'text-green-300' : 'text-red-300'}`}>
                    {results.faisable 
                      ? 'Votre dossier respecte les critères bancaires'
                      : 'Taux d\'endettement trop élevé ou reste à vivre insuffisant'
                    }
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-blue-500/20 p-4 rounded-xl border border-blue-500/30">
                    <div className="text-2xl font-bold text-blue-400">{parseFloat(results.mensualite).toLocaleString()} €</div>
                    <div className="text-sm text-blue-300">Mensualité</div>
                  </div>
                  <div className="bg-purple-500/20 p-4 rounded-xl border border-purple-500/30">
                    <div className="text-2xl font-bold text-purple-400">{results.nouveauTauxEndettement}%</div>
                    <div className="text-sm text-purple-300">Nouveau taux endettement</div>
                  </div>
                  <div className="bg-orange-500/20 p-4 rounded-xl border border-orange-500/30">
                    <div className="text-2xl font-bold text-orange-400">{parseFloat(results.coutTotal).toLocaleString()} €</div>
                    <div className="text-sm text-orange-300">Coût total</div>
                  </div>
                  <div className="bg-gray-500/20 p-4 rounded-xl border border-gray-500/30">
                    <div className="text-2xl font-bold text-gray-400">{parseFloat(results.nouveauResteAVivre).toLocaleString()} €</div>
                    <div className="text-sm text-gray-300">Nouveau reste à vivre</div>
                  </div>
                </div>

                {/* Graphique budget */}
                <div className="bg-black/30 rounded-lg p-4">
                  <h4 className="font-medium text-white mb-3">Impact sur votre Budget</h4>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={budgetData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                        <XAxis 
                          dataKey="name" 
                          stroke="#9CA3AF"
                          fontSize={12}
                          angle={-45}
                          textAnchor="end"
                          height={60}
                        />
                        <YAxis 
                          stroke="#9CA3AF"
                          fontSize={12}
                          tickFormatter={(value) => `${(value / 1000).toFixed(0)}k€`}
                        />
                        <Tooltip 
                          contentStyle={{
                            backgroundColor: '#1F2937',
                            border: '1px solid #3B82F6',
                            borderRadius: '8px',
                            color: '#FFFFFF'
                          }}
                          formatter={(value) => `${Math.round(value).toLocaleString()}€`}
                        />
                        <Bar 
                          dataKey="value" 
                          fill={(entry, index) => budgetData[index]?.color || '#3B82F6'}
                          radius={[4, 4, 0, 0]}
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <i className="ri-calculator-line text-4xl mb-4"></i>
                <p>Ajustez les paramètres pour voir les résultats</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Graphique d'amortissement */}
      {results && amortissementData.length > 0 && (
        <div className="bg-gray-900 rounded-xl shadow-sm border border-purple-500/20 p-6">
          <h3 className="text-xl font-semibold text-white mb-6 flex items-center">
            <i className="ri-line-chart-line text-purple-400 mr-3"></i>
            Évolution du Crédit dans le Temps
          </h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={amortissementData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis 
                  dataKey="annee" 
                  stroke="#9CA3AF"
                  fontSize={12}
                  tickFormatter={(value) => `${value} ans`}
                />
                <YAxis 
                  stroke="#9CA3AF"
                  fontSize={12}
                  tickFormatter={(value) => `${(value / 1000).toFixed(0)}k€`}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: '#1F2937',
                    border: '1px solid #8B5CF6',
                    borderRadius: '8px',
                    color: '#FFFFFF'
                  }}
                  formatter={(value, name) => [
                    `${Math.round(value).toLocaleString()}€`, 
                    name === 'capital' ? 'Remboursement Capital' : 
                    name === 'interets' ? 'Intérêts Payés' : 
                    name === 'capitalRestant' ? 'Capital Restant Dû' : 'Mensualité'
                  ]}
                />
                <Area 
                  type="monotone" 
                  dataKey="interets" 
                  stackId="1"
                  stroke="#EF4444" 
                  fill="#EF4444"
                  fillOpacity={0.6}
                />
                <Area 
                  type="monotone" 
                  dataKey="capital" 
                  stackId="1"
                  stroke="#10B981" 
                  fill="#10B981"
                  fillOpacity={0.8}
                />
                <Line 
                  type="monotone" 
                  dataKey="capitalRestant" 
                  stroke="#8B5CF6" 
                  strokeWidth={2}
                  dot={false}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center space-x-6 mt-4">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
              <span className="text-sm text-gray-300">Capital remboursé</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
              <span className="text-sm text-gray-300">Intérêts payés</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-purple-500 rounded-full mr-2"></div>
              <span className="text-sm text-gray-300">Capital restant dû</span>
            </div>
          </div>
        </div>
      )}

      {/* Comparaison des scénarios */}
      {results && (
        <div className="bg-gray-900 rounded-xl shadow-sm border border-yellow-500/20 p-6">
          <h3 className="text-xl font-semibold text-white mb-6 flex items-center">
            <i className="ri-bar-chart-line text-yellow-400 mr-3"></i>
            Comparaison des Durées
          </h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={scenariosData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis 
                  dataKey="duree" 
                  stroke="#9CA3AF"
                  fontSize={12}
                />
                <YAxis 
                  stroke="#9CA3AF"
                  fontSize={12}
                  tickFormatter={(value) => `${Math.round(value)}€`}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: '#1F2937',
                    border: '1px solid #F59E0B',
                    borderRadius: '8px',
                    color: '#FFFFFF'
                  }}
                  formatter={(value, name) => [
                    `${Math.round(value).toLocaleString()}€`, 
                    name === 'mensualite' ? 'Mensualité' : 'Coût Total'
                  ]}
                />
                <Bar dataKey="mensualite" fill="#3B82F6" name="mensualite" />
                <Bar dataKey="cout" fill="#F59E0B" name="cout" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Conseils personnalisés */}
      {results && (
        <div className="bg-gray-900 rounded-xl shadow-sm border border-green-500/20 p-6">
          <h3 className="text-lg font-semibold text-white mb-6 flex items-center">
            <i className="ri-lightbulb-line text-green-400 mr-3"></i>
            Conseils Personnalisés
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="bg-black/30 rounded-lg p-4">
              <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center mb-4">
                <i className="ri-shield-check-line text-blue-400 text-xl"></i>
              </div>
              <h4 className="font-semibold text-white mb-2">Optimisation Possible</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li className="flex items-start gap-2">
                  <i className="ri-arrow-right-s-line text-blue-400 mt-0.5"></i>
                  {parseFloat(results.tauxEndettement) > 30 ? 'Réduire la durée pour diminuer le coût' : 'Augmenter la durée pour réduire les mensualités'}
                </li>
                <li className="flex items-start gap-2">
                  <i className="ri-arrow-right-s-line text-blue-400 mt-0.5"></i>
                  Négocier le taux avec plusieurs banques
                </li>
                <li className="flex items-start gap-2">
                  <i className="ri-arrow-right-s-line text-blue-400 mt-0.5"></i>
                  {parseFloat(creditData.apport) < parseFloat(creditData.montant) * 0.1 ? 'Augmenter l\'apport personnel si possible' : 'Apport personnel optimal'}
                </li>
              </ul>
            </div>

            <div className="bg-black/30 rounded-lg p-4">
              <div className="w-12 h-12 bg-orange-500/20 rounded-lg flex items-center justify-center mb-4">
                <i className="ri-alert-line text-orange-400 text-xl"></i>
              </div>
              <h4 className="font-semibold text-white mb-2">Points d'Attention</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li className="flex items-start gap-2">
                  <i className="ri-alert-line text-orange-400 mt-0.5"></i>
                  Prévoir les frais de notaire et garantie
                </li>
                <li className="flex items-start gap-2">
                  <i className="ri-alert-line text-orange-400 mt-0.5"></i>
                  Souscrire une assurance emprunteur
                </li>
                <li className="flex items-start gap-2">
                  <i className="ri-alert-line text-orange-400 mt-0.5"></i>
                  {parseFloat(results.nouveauResteAVivre) < 1000 ? 'Reste à vivre insuffisant' : 'Maintenir un reste à vivre suffisant'}
                </li>
              </ul>
            </div>

            <div className="bg-black/30 rounded-lg p-4">
              <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center mb-4">
                <i className="ri-trending-up-line text-green-400 text-xl"></i>
              </div>
              <h4 className="font-semibold text-white mb-2">Stratégie Recommandée</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li className="flex items-start gap-2">
                  <i className="ri-check-line text-green-400 mt-0.5"></i>
                  {results.faisable ? 'Dossier bancable - Négocier les conditions' : 'Revoir les paramètres du projet'}
                </li>
                <li className="flex items-start gap-2">
                  <i className="ri-check-line text-green-400 mt-0.5"></i>
                  Comparer les offres de 3-4 banques
                </li>
                <li className="flex items-start gap-2">
                  <i className="ri-check-line text-green-400 mt-0.5"></i>
                  Prévoir une épargne de précaution
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
