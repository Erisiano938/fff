
'use client';

import { useState, useEffect } from 'react';

interface MifidProfile {
  // Étape 1: Connaissances et Expérience
  experience: string;
  knowledge: string;
  tradingFrequency: string;
  productTypes: string[];

  // Étape 2: Situation Financière
  age: string;
  profession: string;
  annualIncome: string;
  financialSituation: string;
  liquidSavings: string;
  totalAssets: string;

  // Étape 3: Objectifs d'Investissement
  investmentObjective: string;
  timeHorizon: string;
  investmentAmount: string;
  expectedReturn: string;

  // Étape 4: Tolérance au Risque
  riskTolerance: string;
  lossReaction: string;
  volatilityComfort: string;

  // Résultats
  classification: string;
  riskScore: number;
}

export default function MifidRecommendations() {
  const [currentStep, setCurrentStep] = useState(1);
  const [showResults, setShowResults] = useState(false);
  const [showAIRecommendations, setShowAIRecommendations] = useState(false);
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const [activeTab, setActiveTab] = useState('allocation');
  const [mifidProfile, setMifidProfile] = useState<MifidProfile>({
    // Étape 1
    experience: '',
    knowledge: '',
    tradingFrequency: '',
    productTypes: [],

    // Étape 2
    age: '',
    profession: '',
    annualIncome: '',
    financialSituation: '',
    liquidSavings: '',
    totalAssets: '',

    // Étape 3
    investmentObjective: '',
    timeHorizon: '',
    investmentAmount: '',
    expectedReturn: '',

    // Étape 4
    riskTolerance: '',
    lossReaction: '',
    volatilityComfort: '',

    // Résultats
    classification: '',
    riskScore: 0,
  });

  // Charger les données sauvegardées au démarrage
  useEffect(() => {
    const savedProfile = localStorage.getItem('mifidProfile');
    if (savedProfile) {
      try {
        const parsedProfile = JSON.parse(savedProfile);
        setMifidProfile(parsedProfile);

        // Si l'évaluation est complète, afficher les résultats
        if (parsedProfile.classification && parsedProfile.riskScore > 0) {
          setShowResults(true);
        }
      } catch (error) {
        console.error('Erreur lors du chargement du profil MiFID:', error);
      }
    }
  }, []);

  // Sauvegarder automatiquement à chaque modification
  useEffect(() => {
    if (mifidProfile.experience || mifidProfile.knowledge || mifidProfile.age) {
      localStorage.setItem('mifidProfile', JSON.stringify(mifidProfile));
    }
  }, [mifidProfile]);

  const handleNext = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    } else {
      // Calculer les résultats
      calculateMifidResults();
      setShowResults(true);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const calculateMifidResults = () => {
    let score = 0;
    let classification = '';

    // Calcul du score basé sur l'expérience
    if (mifidProfile.experience === 'tres_bonne') score += 4;
    else if (mifidProfile.experience === 'bonne') score += 3;
    else if (mifidProfile.experience === 'limitee') score += 2;
    else score += 1;

    // Calcul du score basé sur les connaissances
    if (mifidProfile.knowledge === 'avancee') score += 3;
    else if (mifidProfile.knowledge === 'intermediaire') score += 2;
    else score += 1;

    // Calcul du score basé sur la tolérance au risque
    if (mifidProfile.riskTolerance === 'tres_eleve') score += 4;
    else if (mifidProfile.riskTolerance === 'eleve') score += 3;
    else if (mifidProfile.riskTolerance === 'modere') score += 2;
    else score += 1;

    // Calcul du score basé sur la réaction aux pertes
    if (mifidProfile.lossReaction === 'racheter') score += 3;
    else if (mifidProfile.lossReaction === 'attendre') score += 2;
    else if (mifidProfile.lossReaction === 'vendre_partie') score += 1;
    else score += 0;

    // Calcul du score basé sur le confort avec la volatilité
    if (mifidProfile.volatilityComfort === 'tres_confortable') score += 3;
    else if (mifidProfile.volatilityComfort === 'confortable') score += 2;
    else if (mifidProfile.volatilityComfort === 'neutre') score += 1;
    else score += 0;

    // Classification améliorée basée sur le score total
    if (score >= 14) classification = 'Investisseur Très Expérimenté';
    else if (score >= 11) classification = 'Investisseur Expérimenté';
    else if (score >= 8) classification = 'Investisseur Intermédiaire';
    else if (score >= 5) classification = 'Investisseur Prudent';
    else classification = 'Investisseur Très Prudent';

    const updatedProfile = {
      ...mifidProfile,
      classification,
      riskScore: score
    };

    setMifidProfile(updatedProfile);

    // Sauvegarder le profil complet dans localStorage
    localStorage.setItem('mifidProfile', JSON.stringify(updatedProfile));
  };

  const resetMifidEvaluation = () => {
    if (confirm('Êtes-vous sûr de vouloir recommencer l\'évaluation MiFID II ? Toutes vos réponses actuelles seront supprimées.')) {
      const emptyProfile = {
        experience: '',
        knowledge: '',
        tradingFrequency: '',
        productTypes: [],
        age: '',
        profession: '',
        annualIncome: '',
        financialSituation: '',
        liquidSavings: '',
        totalAssets: '',
        investmentObjective: '',
        timeHorizon: '',
        investmentAmount: '',
        expectedReturn: '',
        riskTolerance: '',
        lossReaction: '',
        volatilityComfort: '',
        classification: '',
        riskScore: 0,
      };

      setMifidProfile(emptyProfile);
      localStorage.removeItem('mifidProfile');
      setShowResults(false);
      setShowAIRecommendations(false);
      setCurrentStep(1);
    }
  };

  const generateMifidReport = () => {
    const reportDate = new Date().toLocaleDateString('fr-FR');
    const reportTime = new Date().toLocaleTimeString('fr-FR');

    const reportContent = `
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rapport d'Évaluation MiFID II - CMV Finance</title>
    <style>
        @page {
            margin: 2cm;
            size: A4;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            background: white;
        }

        .header {
            text-align: center;
            border-bottom: 3px solid #2563eb;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }

        .logo {
            font-family: "Pacifico", serif;
            font-size: 28px;
            color: #2563eb;
            margin-bottom: 10px;
        }

        .company-info {
            color: #666;
            font-size: 14px;
        }

        .report-title {
            font-size: 24px;
            font-weight: bold;
            color: #1e40af;
            margin: 30px 0 20px 0;
            text-align: center;
        }

        .section {
            margin: 25px 0;
            padding: 20px;
            border-left: 4px solid #3b82f6;
            background: #f8fafc;
        }

        .section-title {
            font-size: 18px;
            font-weight: bold;
            color: #1e40af;
            margin-bottom: 15px;
        }

        .profile-summary {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin: 20px 0;
        }

        .profile-item {
            padding: 15px;
            background: white;
            border-radius: 8px;
            border: 1px solid #e2e8f0;
        }

        .profile-item strong {
            color: #1e40af;
            display: block;
            margin-bottom: 5px;
        }

        .classification-box {
            text-align: center;
            padding: 25px;
            background: linear-gradient(135deg, #3b82f6, #1d4ed8);
            color: white;
            border-radius: 12px;
            margin: 20px 0;
        }

        .classification-title {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .risk-score {
            font-size: 32px;
            font-weight: bold;
            margin: 10px 0;
        }

        .recommendations {
            background: #f0f9ff;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #0ea5e9;
        }

        .recommendation-item {
            margin: 10px 0;
            padding: 10px 0;
            border-bottom: 1px solid #e0f2fe;
        }

        .recommendation-item:last-child {
            border-bottom: none;
        }

        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 2px solid #e2e8f0;
            text-align: center;
            color: #666;
            font-size: 12px;
        }

        .signature-section {
            margin: 30px 0;
            padding: 20px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
        }

        .signature-line {
            border-bottom: 1px solid #333;
            width: 200px;
            margin: 20px auto;
            text-align: center;
            padding-bottom: 5px;
        }

        @media print {
            body { margin: 0; }
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">CMV Finance</div>
        <div class="company-info">
            Conseil en Gestion de Patrimoine<br>
            Évaluation MiFID II Conforme
        </div>
    </div>

    <div class="report-title">
        RAPPORT D'ÉVALUATION MiFID II
    </div>

    <div class="section">
        <div class="section-title"> Informations du Rapport</div>
        <div class="profile-summary">
            <div class="profile-item">
                <strong>Date d'évaluation :</strong>
                ${reportDate}
            </div>
            <div class="profile-item">
                <strong>Heure :</strong>
                ${reportTime}
            </div>
            <div class="profile-item">
                <strong>Type d'évaluation :</strong>
                MiFID II Complète
            </div>
            <div class="profile-item">
                <strong>Validité :</strong>
                12 mois
            </div>
        </div>
    </div>

    <div class="classification-box">
        <div class="classification-title">CLASSIFICATION INVESTISSEUR</div>
        <div class="risk-score">${mifidProfile.classification}</div>
        <div>Score de risque : ${mifidProfile.riskScore}/17</div>
    </div>

    <div class="section">
        <div class="section-title">Profil Investisseur</div>
        <div class="profile-summary">
            <div class="profile-item">
                <strong>Expérience :</strong>
                ${mifidProfile.experience === 'tres_bonne' ? 'Très bonne expérience' :
                  mifidProfile.experience === 'bonne' ? 'Bonne expérience' :
                  mifidProfile.experience === 'limitee' ? 'Expérience limitée' : 'Aucune expérience'}
            </div>
            <div class="profile-item">
                <strong>Connaissances :</strong>
                ${mifidProfile.knowledge === 'avancee' ? 'Connaissances avancées' :
                  mifidProfile.knowledge === 'intermediaire' ? 'Connaissances intermédiaires' : 'Connaissances basiques'}
            </div>
            <div class="profile-item">
                <strong>Âge :</strong>
                ${mifidProfile.age}
            </div>
            <div class="profile-item">
                <strong>Profession :</strong>
                ${mifidProfile.profession === 'salarie' ? 'Salarié' :
                  mifidProfile.profession === 'independant' ? 'Travailleur indépendant' :
                  mifidProfile.profession === 'fonctionnaire' ? 'Fonctionnaire' :
                  mifidProfile.profession === 'retraite' ? 'Retraité' :
                  mifidProfile.profession === 'etudiant' ? 'Étudiant' : 'Sans emploi'}
            </div>
            <div class="profile-item">
                <strong>Situation financière :</strong>
                ${mifidProfile.financialSituation === 'aisee' ? 'Aisée' :
                  mifidProfile.financialSituation === 'confortable' ? 'Confortable' :
                  mifidProfile.financialSituation === 'stable' ? 'Stable' : 'Précaire'}
            </div>
            <div class="profile-item">
                <strong>Horizon d'investissement :</strong>
                ${mifidProfile.timeHorizon}
            </div>
        </div>
    </div>

    <div class="section">
        <div class="section-title">Objectifs et Tolérance au Risque</div>
        <div class="profile-summary">
            <div class="profile-item">
                <strong>Objectif principal :</strong>
                ${mifidProfile.investmentObjective === 'preservation' ? 'Préservation du capital' :
                  mifidProfile.investmentObjective === 'croissance_moderee' ? 'Croissance modérée' :
                  mifidProfile.investmentObjective === 'croissance_forte' ? 'Croissance forte' :
                  mifidProfile.investmentObjective === 'revenus' ? 'Génération de revenus' :
                  mifidProfile.investmentObjective === 'retraite' ? 'Préparation retraite' : 'Financement d\'un projet'}
            </div>
            <div class="profile-item">
                <strong>Tolérance au risque :</strong>
                ${mifidProfile.riskTolerance === 'tres_eleve' ? 'Très élevée' :
                  mifidProfile.riskTolerance === 'eleve' ? 'Élevée' :
                  mifidProfile.riskTolerance === 'modere' ? 'Modérée' :
                  mifidProfile.riskTolerance === 'faible' ? 'Faible' : 'Très faible'}
            </div>
            <div class="profile-item">
                <strong>Réaction aux pertes :</strong>
                ${mifidProfile.lossReaction === 'racheter' ? 'Racheter davantage' :
                  mifidProfile.lossReaction === 'attendre' ? 'Attendre sans rien faire' :
                  mifidProfile.lossReaction === 'vendre_partie' ? 'Vendre une partie' : 'Vendre immédiatement'}
            </div>
            <div class="profile-item">
                <strong>Confort avec volatilité :</strong>
                ${mifidProfile.volatilityComfort === 'tres_confortable' ? 'Très confortable' :
                  mifidProfile.volatilityComfort === 'confortable' ? 'Confortable' :
                  mifidProfile.volatilityComfort === 'neutre' ? 'Neutre' :
                  mifidProfile.volatilityComfort === 'inconfortable' ? 'Inconfortable' : 'Très inconfortable'}
            </div>
        </div>
    </div>

    <div class="section">
        <div class="section-title">Recommandations Personnalisées</div>
        <div class="recommendations">
            ${mifidProfile.riskScore >= 14 ? `
                <div class="recommendation-item">
                    <strong>Allocation suggérée :</strong> 80% Actions, 15% Obligations, 5% Liquidités
                </div>
                <div class="recommendation-item">
                    <strong>Produits adaptés :</strong> ETF actions internationales, actions individuelles, produits structurés
                </div>
                <div class="recommendation-item">
                    <strong>Stratégie :</strong> Investissement progressif avec rééquilibrage trimestriel
                </div>
            ` : mifidProfile.riskScore >= 11 ? `
                <div class="recommendation-item">
                    <strong>Allocation suggérée :</strong> 70% Actions, 25% Obligations, 5% Liquidités
                </div>
                <div class="recommendation-item">
                    <strong>Produits adaptés :</strong> ETF diversifiés, fonds actions, obligations d'entreprises
                </div>
                <div class="recommendation-item">
                    <strong>Stratégie :</strong> Dollar Cost Averaging mensuel avec suivi régulier
                </div>
            ` : mifidProfile.riskScore >= 8 ? `
                <div class="recommendation-item">
                    <strong>Allocation suggérée :</strong> 60% Actions, 30% Obligations, 10% Liquidités
                </div>
                <div class="recommendation-item">
                    <strong>Produits adaptés :</strong> ETF équilibrés, fonds mixtes, obligations gouvernementales
                </div>
                <div class="recommendation-item">
                    <strong>Stratégie :</strong> Approche équilibrée avec diversification géographique
                </div>
            ` : mifidProfile.riskScore >= 5 ? `
                <div class="recommendation-item">
                    <strong>Allocation suggérée :</strong> 40% Actions, 50% Obligations, 10% Liquidités
                </div>
                <div class="recommendation-item">
                    <strong>Produits adaptés :</strong> Fonds prudents, obligations sécurisées, livrets réglementés
                </div>
                <div class="recommendation-item">
                    <strong>Stratégie :</strong> Investissement progressif avec priorité à la sécurité
                </div>
            ` : `
                <div class="recommendation-item">
                    <strong>Allocation suggérée :</strong> 20% Actions, 60% Obligations, 20% Liquidités
                </div>
                <div class="recommendation-item">
                    <strong>Produits adaptés :</strong> Fonds euros, obligations d'État, comptes à terme
                </div>
                <div class="recommendation-item">
                    <strong>Stratégie :</strong> Préservation du capital avec rendement sécurisé
                </div>
            `}
        </div>
    </div>

    <div class="section">
        <div class="section-title">Avertissements et Mentions Légales</div>
        <p><strong>Conformité MiFID II :</strong> Cette évaluation respecte les exigences de la directive MiFID II concernant l'évaluation de l'adéquation et du caractère approprié des services d'investissement.</p>

        <p><strong>Validité :</strong> Cette évaluation est valable 12 mois à compter de la date d'émission. Une réévaluation sera nécessaire en cas de changement significatif de votre situation.</p>

        <p><strong>Risques :</strong> Tout investissement comporte des risques de perte en capital. Les performances passées ne préjugent pas des performances futures.</p>

        <p><strong>Conseil personnalisé :</strong> Ce rapport constitue une base d'évaluation. Un conseil personnalisé avec un conseiller financier est recommandé avant tout investissement.</p>
    </div>

    <div class="signature-section">
        <div class="section-title">Validation</div>
        <p>Je certifie avoir pris connaissance de cette évaluation MiFID II et confirme l'exactitude des informations fournies.</p>

        <div style="display: flex; justify-content: space-between; margin-top: 30px;">
            <div>
                <div class="signature-line">Signature du client</div>
                <div style="text-align: center; margin-top: 10px;">Date : ${reportDate}</div>
            </div>
            <div>
                <div class="signature-line">CMV Finance</div>
                <div style="text-align: center; margin-top: 10px;">Conseiller financier</div>
            </div>
        </div>
    </div>

    <div class="footer">
        <p><strong>CMV Finance</strong> - Conseil en Gestion de Patrimoine</p>
        <p>Rapport généré automatiquement le ${reportDate} à ${reportTime}</p>
        <p>Document confidentiel - Usage strictement personnel</p>
    </div>
</body>
</html>
    `;

    // Créer et télécharger le fichier
    const blob = new Blob([reportContent], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Rapport_MiFID_${mifidProfile.classification.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const generateAIRecommendations = () => {
    setIsGeneratingAI(true);
    setTimeout(() => {
      setIsGeneratingAI(false);
      setShowAIRecommendations(true);
    }, 3000);
  };

  const handleProductTypeChange = (productType: string) => {
    const updatedTypes = mifidProfile.productTypes.includes(productType)
      ? mifidProfile.productTypes.filter(type => type !== productType)
      : [...mifidProfile.productTypes, productType];

    setMifidProfile({ ...mifidProfile, productTypes: updatedTypes });
  };

  // Fonction pour obtenir l'allocation recommandée basée sur le score
  const getRecommendedAllocation = () => {
    if (mifidProfile.riskScore >= 14) {
      return { actions: 80, obligations: 15, liquidites: 5 };
    } else if (mifidProfile.riskScore >= 11) {
      return { actions: 70, obligations: 25, liquidites: 5 };
    } else if (mifidProfile.riskScore >= 8) {
      return { actions: 60, obligations: 30, liquidites: 10 };
    } else if (mifidProfile.riskScore >= 5) {
      return { actions: 40, obligations: 50, liquidites: 10 };
    } else {
      return { actions: 20, obligations: 60, liquidites: 20 };
    }
  };

  if (showResults) {
    const allocation = getRecommendedAllocation();

    return (
      <div className="max-w-6xl mx-auto">
        <div className="bg-gradient-to-br from-gray-900/80 to-gray-800/80 backdrop-blur-sm rounded-2xl p-8 border border-gray-700/50 shadow-2xl">
          {/* En-tête des résultats */}
          <div className="text-center mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-shield-check-fill text-4xl text-white"></i>
            </div>
            <h2 className="text-3xl font-bold text-white mb-2">Évaluation MiFID II Terminée</h2>
            <p className="text-gray-400">Votre profil d'investisseur et nos recommandations personnalisées</p>
            <div className="flex items-center justify-center space-x-4 mt-4">
              <span className="px-3 py-1 bg-green-500/20 text-green-400 rounded-full text-sm">
                ✓ Évaluation sauvegardée
              </span>
              <span className="px-3 py-1 bg-blue-500/20 text-blue-400 rounded-full text-sm">
                Valide 12 mois
              </span>
            </div>
          </div>

          {/* Résultats du profil */}
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <div className="bg-gradient-to-br from-blue-500/20 to-purple-600/20 rounded-xl p-6 border border-blue-500/30">
              <div className="flex items-center space-x-3 mb-3">
                <i className="ri-user-star-line text-2xl text-blue-400"></i>
                <h3 className="text-xl font-bold text-white">Classification</h3>
              </div>
              <p className="text-2xl font-bold text-blue-400 mb-2">{mifidProfile.classification}</p>
              <p className="text-gray-400 text-sm">Basé sur votre expérience et vos objectifs</p>
            </div>

            <div className="bg-gradient-to-br from-green-500/20 to-teal-600/20 rounded-xl p-6 border border-green-500/30">
              <div className="flex items-center space-x-3 mb-3">
                <i className="ri-speed-line text-2xl text-green-400"></i>
                <h3 className="text-xl font-bold text-white">Score de Risque</h3>
              </div>
              <p className="text-2xl font-bold text-green-400 mb-2">{mifidProfile.riskScore}/17</p>
              <p className="text-gray-400 text-sm">Tolérance au risque évaluée</p>
            </div>

            <div className="bg-gradient-to-br from-yellow-500/20 to-orange-600/20 rounded-xl p-6 border border-yellow-500/30">
              <div className="flex items-center space-x-3 mb-3">
                <i className="ri-time-line text-2xl text-yellow-400"></i>
                <h3 className="text-xl font-bold text-white">Horizon</h3>
              </div>
              <p className="text-2xl font-bold text-yellow-400 mb-2">{mifidProfile.timeHorizon}</p>
              <p className="text-gray-400 text-sm">Durée d'investissement prévue</p>
            </div>
          </div>

          {/* Recommandations IA */}
          <div className="bg-gray-800/50 rounded-xl p-6 mb-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <i className="ri-robot-line text-2xl text-purple-400"></i>
                <h3 className="text-xl font-bold text-white">Recommandations IA Personnalisées</h3>
              </div>
              {!showAIRecommendations && !isGeneratingAI && (
                <button
                  onClick={generateAIRecommendations}
                  className="px-6 py-2 bg-gradient-to-r from-purple-500 to-pink-600 text-white rounded-lg hover:from-purple-400 hover:to-pink-500 transition-all cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-magic-line mr-2"></i>
                  Générer les recommandations
                </button>
              )}
            </div>

            {isGeneratingAI && (
              <div className="text-center py-8">
                <div className="inline-flex items-center space-x-3">
                  <div className="w-8 h-8 border-4 border-purple-500/30 border-t-purple-500 rounded-full animate-spin"></div>
                  <span className="text-gray-300">Génération des recommandations personnalisées...</span>
                </div>
              </div>
            )}

            {showAIRecommendations && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div className="flex space-x-1">
                    {['allocation', 'etf', 'risques', 'plan', 'formation'].map((tab) => (
                      <button
                        key={tab}
                        onClick={() => setActiveTab(tab)}
                        className={`px-4 py-2 rounded-lg font-medium transition-all cursor-pointer whitespace-nowrap ${
                          activeTab === tab
                            ? 'bg-purple-500 text-white'
                            : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                        }`}
                      >
                        {tab === 'allocation' && 'Allocation'}
                        {tab === 'etf' && 'ETF Recommandés'}
                        {tab === 'risques' && 'Points d\'Attention'}
                        {tab === 'plan' && 'Plan d\'Action'}
                        {tab === 'formation' && 'Formation'}
                      </button>
                    ))}
                  </div>
                  <div className="flex space-x-2">
                    <button className="p-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors cursor-pointer">
                      <i className="ri-printer-line text-gray-300"></i>
                    </button>
                    <button
                      onClick={() => setShowAIRecommendations(false)}
                      className="p-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors cursor-pointer"
                    >
                      <i className="ri-close-line text-gray-300"></i>
                    </button>
                  </div>
                </div>

                {/* Contenu des onglets */}
                {activeTab === 'allocation' && (
                  <div className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="text-lg font-bold text-white mb-4">Allocation Recommandée</h4>
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">Actions</span>
                            <div className="flex items-center space-x-2">
                              <div className="w-24 h-2 bg-gray-700 rounded-full overflow-hidden">
                                <div className="h-full bg-blue-500" style={{ width: `${allocation.actions}%` }}></div>
                              </div>
                              <span className="text-blue-400 font-medium">{allocation.actions}%</span>
                            </div>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">Obligations</span>
                            <div className="flex items-center space-x-2">
                              <div className="w-24 h-2 bg-gray-700 rounded-full overflow-hidden">
                                <div className="h-full bg-green-500" style={{ width: `${allocation.obligations}%` }}></div>
                              </div>
                              <span className="text-green-400 font-medium">{allocation.obligations}%</span>
                            </div>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">Liquidités</span>
                            <div className="flex items-center space-x-2">
                              <div className="w-24 h-2 bg-gray-700 rounded-full overflow-hidden">
                                <div className="h-full bg-yellow-500" style={{ width: `${allocation.liquidites}%` }}></div>
                              </div>
                              <span className="text-yellow-400 font-medium">{allocation.liquidites}%</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div>
                        <h4 className="text-lg font-bold text-white mb-4">Métriques de Confiance</h4>
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">Adéquation profil</span>
                            <span className="text-green-400 font-bold">95%</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">Diversification</span>
                            <span className="text-blue-400 font-bold">88%</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">Optimisation fiscale</span>
                            <span className="text-purple-400 font-bold">92%</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'etf' && (
                  <div className="space-y-4">
                    <h4 className="text-lg font-bold text-white mb-4">ETF Recommandés</h4>
                    <div className="grid gap-4">
                      {[{
                        name: 'MSCI World UCITS ETF',
                        ticker: 'EWLD',
                        allocation: `${Math.round(allocation.actions * 0.5)}%`,
                        fees: '0.20%',
                        risk: 'Modéré'
                      },
                      {
                        name: 'Euro Stoxx 50 UCITS ETF',
                        ticker: 'SX5E',
                        allocation: `${Math.round(allocation.actions * 0.3)}%`,
                        fees: '0.15%',
                        risk: 'Modéré'
                      },
                      {
                        name: 'Euro Government Bond UCITS ETF',
                        ticker: 'IEAG',
                        allocation: `${allocation.obligations}%`,
                        fees: '0.12%',
                        risk: 'Faible'
                      },
                      {
                        name: 'Money Market UCITS ETF',
                        ticker: 'LYXE',
                        allocation: `${allocation.liquidites}%`,
                        fees: '0.10%',
                        risk: 'Très Faible'
                      }
                      ].map((etf, index) => (
                        <div key={index} className="bg-gray-700/50 rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h5 className="font-bold text-white">{etf.name}</h5>
                            <span className="text-blue-400 font-bold">{etf.allocation}</span>
                          </div>
                          <div className="flex items-center space-x-4 text-sm text-gray-400">
                            <span>Ticker: {etf.ticker}</span>
                            <span>Frais: {etf.fees}</span>
                            <span>Risque: {etf.risk}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeTab === 'risques' && (
                  <div className="space-y-4">
                    <h4 className="text-lg font-bold text-white mb-4">Points d'Attention</h4>
                    <div className="grid gap-4">
                      {[{
                        icon: 'ri-alert-line',
                        title: 'Volatilité des marchés',
                        desc: 'Les actions peuvent subir des fluctuations importantes à court terme'
                      },
                      {
                        icon: 'ri-exchange-line',
                        title: 'Risque de change',
                        desc: 'Exposition aux devises étrangères via les ETF internationaux'
                      },
                      {
                        icon: 'ri-time-line',
                        title: 'Horizon d\'investissement',
                        desc: 'Respecter la durée recommandée pour optimiser les performances'
                      }
                      ].map((risk, index) => (
                        <div key={index} className="bg-orange-500/10 border border-orange-500/30 rounded-lg p-4">
                          <div className="flex items-start space-x-3">
                            <i className={`${risk.icon} text-xl text-orange-400 mt-1`}></i>
                            <div>
                              <h5 className="font-bold text-white mb-1">{risk.title}</h5>
                              <p className="text-gray-300 text-sm">{risk.desc}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeTab === 'plan' && (
                  <div className="space-y-4">
                    <h4 className="text-lg font-bold text-white mb-4">Plan d'Action Personnalisé</h4>
                    <div className="space-y-4">
                      {[{
                        step: 1,
                        title: 'Ouverture des comptes',
                        desc: 'Ouvrir un PEA et un compte-titres ordinaire',
                        status: 'À faire'
                      },
                      {
                        step: 2,
                        title: 'Premier investissement',
                        desc: `Investir ${allocation.actions}% du montant initial selon l'Allocation`,
                        status: 'À faire'
                      },
                      {
                        step: 3,
                        title: 'Mise en place du DCA',
                        desc: 'Programmer des versements mensuels automatiques',
                        status: 'À faire'
                      },
                      {
                        step: 4,
                        title: 'Suivi trimestriel',
                        desc: 'Réviser l\'Allocation et rééquilibrer si nécessaire',
                        status: 'Récurrent'
                      }
                      ].map((action) => (
                        <div key={action.step} className="flex items-start space-x-4 bg-gray-700/30 rounded-lg p-4">
                          <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                            {action.step}
                          </div>
                          <div className="flex-1">
                            <h5 className="font-bold text-white mb-1">{action.title}</h5>
                            <p className="text-gray-300 text-sm mb-2">{action.desc}</p>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              action.status === 'À faire'
                                ? 'bg-yellow-500/20 text-yellow-400'
                                : 'bg-blue-500/20 text-blue-400'
                            }`}>
                              {action.status}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeTab === 'formation' && (
                  <div className="space-y-4">
                    <h4 className="text-lg font-bold text-white mb-4">Modules de Formation Recommandés</h4>
                    <div className="grid gap-4">
                      {[{
                        title: 'Les ETF pour débutants',
                        duration: '45 min',
                        level: 'Débutant',
                        progress: 0
                      },
                      {
                        title: 'Diversification de portefeuille',
                        duration: '60 min',
                        level: 'Intermédiaire',
                        progress: 0
                      },
                      {
                        title: 'Fiscalité des investissements',
                        duration: '90 min',
                        level: 'Avancé',
                        progress: 0
                      }
                      ].map((course, index) => (
                        <div key={index} className="bg-gray-700/50 rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h5 className="font-bold text-white">{course.title}</h5>
                            <button className="px-3 py-1 bg-blue-500 hover:bg-blue-400 text-white rounded-lg text-sm transition-colors cursor-pointer whitespace-nowrap">
                              Commencer
                            </button>
                          </div>
                          <div className="flex items-center space-x-4 text-sm text-gray-400">
                            <span>Durée: {course.duration}</span>
                            <span>Niveau: {course.level}</span>
                            <span>Progression: {course.progress}%</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex justify-center space-x-4">
            <button
              onClick={resetMifidEvaluation}
              className="px-6 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-xl transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-refresh-line mr-2"></i>
              Recommencer l'évaluation
            </button>
            <button
              onClick={generateMifidReport}
              className="px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl hover:from-blue-400 hover:to-purple-500 transition-all cursor-pointer whitespace-nowrap"
            >
              <i className="ri-download-line mr-2"></i>
              Télécharger le rapport
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto">
      <div className="bg-gradient-to-br from-gray-900/80 to-gray-800/80 backdrop-blur-sm rounded-2xl p-10 border border-gray-700/50 shadow-2xl">
        {/* En-tête de l'évaluation modifié */}
        <div className="mb-10">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-6">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center">
                <i className="ri-shield-check-line text-3xl text-white"></i>
              </div>
              <div>
                <h2 className="text-3xl font-bold text-white mb-2">Évaluation MiFID II Complète</h2>
                <p className="text-gray-400 text-lg">Questionnaire approfondi conforme à la réglementation européenne</p>
                <div className="flex items-center space-x-4 mt-2">
                  <span className="text-blue-400 font-medium">Étape {currentStep} sur 4</span>
                  <span className="text-gray-500">•</span>
                  <span className="text-gray-400">{Math.round((currentStep / 4) * 100)}% complété</span>
                </div>
              </div>
            </div>

            {/* Bouton pour effacer si des données existent */}
            {(mifidProfile.experience || mifidProfile.knowledge || mifidProfile.age) && (
              <button
                onClick={resetMifidEvaluation}
                className="px-4 py-2 bg-red-600/20 hover:bg-red-600/30 text-red-400 border border-red-500/30 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
              >
                <i className="ri-delete-bin-line mr-2"></i>
                Recommencer
              </button>
            )}
          </div>

          {/* Barre de progression améliorée */}
          <div className="relative">
            <div className="w-full bg-gray-700 rounded-full h-3 overflow-hidden">
              <div
                className="bg-gradient-to-r from-blue-500 to-purple-600 h-3 rounded-full transition-all duration-500 relative overflow-hidden"
                style={{ width: `${(currentStep / 4) * 100}%` }}
              >
                <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
              </div>
            </div>
            <div className="flex justify-between mt-2 text-xs text-gray-400">
              <span>Connaissances</span>
              <span>Situation</span>
              <span>Objectifs</span>
              <span>Risques</span>
            </div>
          </div>
        </div>

        {/* Contenu des étapes */}
        <div className="min-h-[500px]">
          {/* Étape 1 */}
          {currentStep === 1 && (
            <div className="space-y-8">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-white mb-3">Connaissances et Expérience</h3>
                <p className="text-gray-400">Évaluons votre niveau d'expérience et de connaissances en investissement</p>
              </div>

              <div className="space-y-8">
                <div>
                  <label className="block text-white font-semibold mb-4 text-lg">Quel est votre niveau d'expérience en investissement ?</label>
                  <div className="grid gap-4">
                    {[{
                      value: 'aucune',
                      label: 'Aucune expérience',
                      desc: 'Je n\'ai jamais investi sur les marchés financiers'
                    },
                    {
                      value: 'limitee',
                      label: 'Expérience limitée',
                      desc: 'J\'ai déjà effectué quelques opérations simples (moins de 2 ans)'
                    },
                    {
                      value: 'bonne',
                      label: 'Bonne expérience',
                      desc: 'Je connais et pratique régulièrement les investissements (2-5 ans)'
                    },
                    {
                      value: 'tres_bonne',
                      label: 'Très bonne expérience',
                      desc: 'J\'ai une pratique approfondie des marchés financiers (plus de 5 ans)'
                    }
                    ].map((option) => (
                      <label
                        key={option.value}
                        className={`flex items-center space-x-4 p-4 rounded-xl border cursor-pointer transition-all hover:shadow-lg ${
                          mifidProfile.experience === option.value
                            ? 'border-blue-500 bg-blue-500/10 shadow-blue-500/20'
                            : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
                        }`}
                      >
                        <input
                          type="radio"
                          name="experience"
                          value={option.value}
                          checked={mifidProfile.experience === option.value}
                          onChange={(e) => setMifidProfile({ ...mifidProfile, experience: e.target.value })}
                          className="sr-only"
                        />
                        <div
                          className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                            mifidProfile.experience === option.value
                              ? 'border-blue-500 bg-blue-500'
                              : 'border-gray-400'
                          }`}
                        >
                          {mifidProfile.experience === option.value && <div className="w-2 h-2 bg-white rounded-full"></div>}
                        </div>
                        <div>
                          <div className="text-white font-medium">{option.label}</div>
                          <div className="text-gray-400 text-sm">{option.desc}</div>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-white font-semibold mb-4 text-lg">Quel est votre niveau de connaissances financières ?</label>
                  <div className="grid gap-4">
                    {[{
                      value: 'basique',
                      label: 'Connaissances basiques',
                      desc: 'Je comprends les concepts de base (épargne, intérêts)'
                    },
                    {
                      value: 'intermediaire',
                      label: 'Connaissances intermédiaires',
                      desc: 'Je connais les actions, obligations et fonds'
                    },
                    {
                      value: 'avancee',
                      label: 'Connaissances avancées',
                      desc: 'Je maîtrise les produits dérivés et stratégies complexes'
                    }
                    ].map((option) => (
                      <label
                        key={option.value}
                        className={`flex items-center space-x-4 p-4 rounded-xl border cursor-pointer transition-all hover:shadow-lg ${
                          mifidProfile.knowledge === option.value
                            ? 'border-blue-500 bg-blue-500/10 shadow-blue-500/20'
                            : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
                        }`}
                      >
                        <input
                          type="radio"
                          name="knowledge"
                          value={option.value}
                          checked={mifidProfile.knowledge === option.value}
                          onChange={(e) => setMifidProfile({ ...mifidProfile, knowledge: e.target.value })}
                          className="sr-only"
                        />
                        <div
                          className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                            mifidProfile.knowledge === option.value
                              ? 'border-blue-500 bg-blue-500'
                              : 'border-gray-400'
                          }`}
                        >
                          {mifidProfile.knowledge === option.value && <div className="w-2 h-2 bg-white rounded-full"></div>}
                        </div>
                        <div>
                          <div className="text-white font-medium">{option.label}</div>
                          <div className="text-gray-400 text-sm">{option.desc}</div>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-white font-semibold mb-4 text-lg">À quelle fréquence investissez-vous ?</label>
                  <div className="grid gap-4">
                    {[{
                      value: 'jamais',
                      label: 'Jamais',
                      desc: 'Je n\'ai jamais effectué d\'investissement'
                    },
                    {
                      value: 'rarement',
                      label: 'Rarement',
                      desc: 'Moins d\'une fois par an'
                    },
                    {
                      value: 'occasionnellement',
                      label: 'Occasionnellement',
                      desc: 'Quelques fois par an'
                    },
                    {
                      value: 'regulierement',
                      label: 'Régulièrement',
                      desc: 'Plusieurs fois par mois'
                    }
                    ].map((option) => (
                      <label
                        key={option.value}
                        className={`flex items-center space-x-4 p-4 rounded-xl border cursor-pointer transition-all hover:shadow-lg ${
                          mifidProfile.tradingFrequency === option.value
                            ? 'border-blue-500 bg-blue-500/10'
                            : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
                        }`}
                      >
                        <input
                          type="radio"
                          name="tradingFrequency"
                          value={option.value}
                          checked={mifidProfile.tradingFrequency === option.value}
                          onChange={(e) => setMifidProfile({ ...mifidProfile, tradingFrequency: e.target.value })}
                          className="sr-only"
                        />
                        <div
                          className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                            mifidProfile.tradingFrequency === option.value
                              ? 'border-blue-500 bg-blue-500'
                              : 'border-gray-400'
                          }`}
                        >
                          {mifidProfile.tradingFrequency === option.value && <div className="w-2 h-2 bg-white rounded-full"></div>}
                        </div>
                        <div>
                          <div className="text-white font-medium">{option.label}</div>
                          <div className="text-gray-400 text-sm">{option.desc}</div>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-white font-semibold mb-4 text-lg">Quels types de produits connaissez-vous ? (Plusieurs choix possibles)</label>
                  <div className="grid md:grid-cols-2 gap-4">
                    {[{
                      value: 'actions',
                      label: 'Actions',
                      desc: 'Titres de propriété d\'entreprises'
                    },
                    {
                      value: 'obligations',
                      label: 'Obligations',
                      desc: 'Titres de créance'
                    },
                    {
                      value: 'etf',
                      label: 'ETF',
                      desc: 'Fonds indiciels cotés'
                    },
                    {
                      value: 'opcvm',
                      label: 'OPCVM',
                      desc: 'Fonds de placement collectif'
                    },
                    {
                      value: 'derives',
                      label: 'Produits dérivés',
                      desc: 'Options, warrants, turbos'
                    },
                    {
                      value: 'forex',
                      label: 'Forex',
                      desc: 'Marché des changes'
                    }
                    ].map((option) => (
                      <label
                        key={option.value}
                        className={`flex items-center space-x-4 p-4 rounded-xl border cursor-pointer transition-all hover:shadow-lg ${
                          mifidProfile.productTypes.includes(option.value)
                            ? 'border-blue-500 bg-blue-500/10 shadow-blue-500/20'
                            : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
                        }`}
                      >
                        <input
                          type="checkbox"
                          value={option.value}
                          checked={mifidProfile.productTypes.includes(option.value)}
                          onChange={() => handleProductTypeChange(option.value)}
                          className="sr-only"
                        />
                        <div
                          className={`w-5 h-5 rounded border-2 flex items-center justify-center ${
                            mifidProfile.productTypes.includes(option.value)
                              ? 'border-blue-500 bg-blue-500'
                              : 'border-gray-400'
                          }`}
                        >
                          {mifidProfile.productTypes.includes(option.value) && <i className="ri-check-line text-white text-sm"></i>}
                        </div>
                        <div>
                          <div className="text-white font-medium">{option.label}</div>
                          <div className="text-gray-400 text-sm">{option.desc}</div>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Étape 2 */}
          {currentStep === 2 && (
            <div className="space-y-8">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-white mb-3">Situation Financière</h3>
                <p className="text-gray-400">Analysons votre situation patrimoniale et professionnelle</p>
              </div>

              <div className="space-y-8">
                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <label className="block text-white font-semibold mb-4 text-lg">Quelle est votre tranche d'âge ?</label>
                    <div className="space-y-3">
                      {[{
                        value: '18-25',
                        label: '18-25 ans'
                      },
                      {
                        value: '26-35',
                        label: '26-35 ans'
                      },
                      {
                        value: '36-45',
                        label: '36-45 ans'
                      },
                      {
                        value: '46-55',
                        label: '46-55 ans'
                      },
                      {
                        value: '56-65',
                        label: '56-65 ans'
                      },
                      {
                        value: '65+',
                        label: 'Plus de 65 ans'
                      }
                      ].map((option) => (
                        <label
                          key={option.value}
                          className={`flex items-center space-x-3 p-3 rounded-lg border cursor-pointer transition-all ${
                            mifidProfile.age === option.value
                              ? 'border-blue-500 bg-blue-500/10'
                              : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
                          }`}
                        >
                          <input
                            type="radio"
                            name="age"
                            value={option.value}
                            checked={mifidProfile.age === option.value}
                            onChange={(e) => setMifidProfile({ ...mifidProfile, age: e.target.value })}
                            className="sr-only"
                          />
                          <div
                            className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                              mifidProfile.age === option.value
                                ? 'border-blue-500 bg-blue-500'
                                : 'border-gray-400'
                            }`}
                          >
                            {mifidProfile.age === option.value && <div className="w-1.5 h-1.5 bg-white rounded-full"></div>}
                          </div>
                          <span className="text-white">{option.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-white font-semibold mb-4 text-lg">Quelle est votre situation professionnelle ?</label>
                    <div className="space-y-3">
                      {[{
                        value: 'salarie',
                        label: 'Salarié'
                      },
                      {
                        value: 'independant',
                        label: 'Travailleur indépendant'
                      },
                      {
                        value: 'fonctionnaire',
                        label: 'Fonctionnaire'
                      },
                      {
                        value: 'retraite',
                        label: 'Retraité'
                      },
                      {
                        value: 'etudiant',
                        label: 'Étudiant'
                      },
                      {
                        value: 'sans_emploi',
                        label: 'Sans emploi'
                      }
                      ].map((option) => (
                        <label
                          key={option.value}
                          className={`flex items-center space-x-3 p-3 rounded-lg border cursor-pointer transition-all ${
                            mifidProfile.profession === option.value
                              ? 'border-blue-500 bg-blue-500/10'
                              : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
                          }`}
                        >
                          <input
                            type="radio"
                            name="profession"
                            value={option.value}
                            checked={mifidProfile.profession === option.value}
                            onChange={(e) => setMifidProfile({ ...mifidProfile, profession: e.target.value })}
                            className="sr-only"
                          />
                          <div
                            className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                              mifidProfile.profession === option.value
                                ? 'border-blue-500 bg-blue-500'
                                : 'border-gray-400'
                            }`}
                          >
                            {mifidProfile.profession === option.value && <div className="w-1.5 h-1.5 bg-white rounded-full"></div>}
                          </div>
                          <span className="text-white">{option.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-white font-semibold mb-4 text-lg">Quel est votre revenu annuel net ?</label>
                  <div className="grid md:grid-cols-2 gap-4">
                    {[{
                      value: 'moins_20k',
                      label: 'Moins de 20 000 €'
                    },
                    {
                      value: '20k_40k',
                      label: '20 000 € - 40 000 €'
                    },
                    {
                      value: '40k_60k',
                      label: '40 000 € - 60 000 €'
                    },
                    {
                      value: '60k_100k',
                      label: '60 000 € - 100 000 €'
                    },
                    {
                      value: '100k_150k',
                      label: '100 000 € - 150 000 €'
                    },
                    {
                      value: 'plus_150k',
                      label: 'Plus de 150 000 €'
                    }
                    ].map((option) => (
                      <label
                        key={option.value}
                        className={`flex items-center space-x-4 p-4 rounded-lg border cursor-pointer transition-all ${
                          mifidProfile.annualIncome === option.value
                            ? 'border-blue-500 bg-blue-500/10'
                            : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
                        }`}
                      >
                        <input
                          type="radio"
                          name="annualIncome"
                          value={option.value}
                          checked={mifidProfile.annualIncome === option.value}
                          onChange={(e) => setMifidProfile({ ...mifidProfile, annualIncome: e.target.value })}
                          className="sr-only"
                        />
                        <div
                          className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                            mifidProfile.annualIncome === option.value
                              ? 'border-blue-500 bg-blue-500'
                              : 'border-gray-400'
                          }`}
                        >
                          {mifidProfile.annualIncome === option.value && <div className="w-1.5 h-1.5 bg-white rounded-full"></div>}
                        </div>
                        <span className="text-white">{option.label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-white font-semibold mb-4 text-lg">Quel est votre épargne liquide disponible ?</label>
                  <div className="grid md:grid-cols-2 gap-4">
                    {[{
                      value: 'moins_5k',
                      label: 'Moins de 5 000 €'
                    },
                    {
                      value: '5k_20k',
                      label: '5 000 € - 20 000 €'
                    },
                    {
                      value: '20k_50k',
                      label: '20 000 € - 50 000 €'
                    },
                    {
                      value: '50k_100k',
                      label: '50 000 € - 100 000 €'
                    },
                    {
                      value: '100k_250k',
                      label: '100 000 € - 250 000 €'
                    },
                    {
                      value: 'plus_250k',
                      label: 'Plus de 250 000 €'
                    }
                    ].map((option) => (
                      <label
                        key={option.value}
                        className={`flex items-center space-x-4 p-4 rounded-lg border cursor-pointer transition-all ${
                          mifidProfile.liquidSavings === option.value
                            ? 'border-blue-500 bg-blue-500/10'
                            : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
                        }`}
                      >
                        <input
                          type="radio"
                          name="liquidSavings"
                          value={option.value}
                          checked={mifidProfile.liquidSavings === option.value}
                          onChange={(e) => setMifidProfile({ ...mifidProfile, liquidSavings: e.target.value })}
                          className="sr-only"
                        />
                        <div
                          className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                            mifidProfile.liquidSavings === option.value
                              ? 'border-blue-500 bg-blue-500'
                              : 'border-gray-400'
                          }`}
                        >
                          {mifidProfile.liquidSavings === option.value && <div className="w-1.5 h-1.5 bg-white rounded-full"></div>}
                        </div>
                        <span className="text-white">{option.label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-white font-semibold mb-4 text-lg">Comment décririez-vous votre situation financière ?</label>
                  <div className="grid gap-4">
                    {[{
                      value: 'precaire',
                      label: 'Précaire',
                      desc: 'Difficultés à joindre les deux bouts'
                    },
                    {
                      value: 'stable',
                      label: 'Stable',
                      desc: 'Revenus réguliers, quelques économies'
                    },
                    {
                      value: 'confortable',
                      label: 'Confortable',
                      desc: 'Capacité d\'épargne régulière'
                    },
                    {
                      value: 'aisee',
                      label: 'Aisée',
                      desc: 'Patrimoine important, revenus élevés'
                    }
                    ].map((option) => (
                      <label
                        key={option.value}
                        className={`flex items-center space-x-4 p-4 rounded-xl border cursor-pointer transition-all hover:shadow-lg ${
                          mifidProfile.financialSituation === option.value
                            ? 'border-blue-500 bg-blue-500/10 shadow-blue-500/20'
                            : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
                        }`}
                      >
                        <input
                          type="radio"
                          name="financialSituation"
                          value={option.value}
                          checked={mifidProfile.financialSituation === option.value}
                          onChange={(e) => setMifidProfile({ ...mifidProfile, financialSituation: e.target.value })}
                          className="sr-only"
                        />
                        <div
                          className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                            mifidProfile.financialSituation === option.value
                              ? 'border-blue-500 bg-blue-500'
                              : 'border-gray-400'
                          }`}
                        >
                          {mifidProfile.financialSituation === option.value && <div className="w-2 h-2 bg-white rounded-full"></div>}
                        </div>
                        <div>
                          <div className="text-white font-medium">{option.label}</div>
                          <div className="text-gray-400 text-sm">{option.desc}</div>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Étape 3 */}
          {currentStep === 3 && (
            <div className="space-y-8">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-white mb-3">Objectifs d'Investissement</h3>
                <p className="text-gray-400">Définissons vos objectifs patrimoniaux et votre stratégie</p>
              </div>

              <div className="space-y-8">
                <div>
                  <label className="block text-white font-semibold mb-4 text-lg">Quel est votre objectif principal d'investissement ?</label>
                  <div className="grid gap-4">
                    {[{
                      value: 'preservation',
                      label: 'Préservation du capital',
                      desc: 'Protéger mon épargne de l\'inflation'
                    },
                    {
                      value: 'croissance_moderee',
                      label: 'Croissance modérée',
                      desc: 'Faire fructifier mon épargne prudemment'
                    },
                    {
                      value: 'croissance_forte',
                      label: 'Croissance forte',
                      desc: 'Maximiser les gains à long terme'
                    },
                    {
                      value: 'revenus',
                      label: 'Génération de revenus',
                      desc: 'Obtenir des revenus réguliers (dividendes, intérêts)'
                    },
                    {
                      value: 'retraite',
                      label: 'Préparation retraite',
                      desc: 'Constituer un capital pour la retraite'
                    },
                    {
                      value: 'projet',
                      label: 'Financement d\'un projet',
                      desc: 'Épargner pour un achat immobilier ou autre projet'
                    }
                    ].map((option) => (
                      <label
                        key={option.value}
                        className={`flex items-center space-x-4 p-4 rounded-xl border cursor-pointer transition-all hover:shadow-lg ${
                          mifidProfile.investmentObjective === option.value
                            ? 'border-blue-500 bg-blue-500/10 shadow-blue-500/20'
                            : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
                        }`}
                      >
                        <input
                          type="radio"
                          name="investmentObjective"
                          value={option.value}
                          checked={mifidProfile.investmentObjective === option.value}
                          onChange={(e) => setMifidProfile({ ...mifidProfile, investmentObjective: e.target.value })}
                          className="sr-only"
                        />
                        <div
                          className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                            mifidProfile.investmentObjective === option.value
                              ? 'border-blue-500 bg-blue-500'
                              : 'border-gray-400'
                          }`}
                        >
                          {mifidProfile.investmentObjective === option.value && <div className="w-2 h-2 bg-white rounded-full"></div>}
                        </div>
                        <div>
                          <div className="text-white font-medium">{option.label}</div>
                          <div className="text-gray-400 text-sm">{option.desc}</div>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-white font-semibold mb-4 text-lg">Quel est votre horizon d'investissement ?</label>
                  <div className="grid md:grid-cols-2 gap-4">
                    {[{
                      value: 'Court terme (moins de 2 ans)',
                      label: 'Court terme',
                      desc: 'Moins de 2 ans'
                    },
                    {
                      value: 'Moyen terme (2-5 ans)',
                      label: 'Moyen terme',
                      desc: '2 à 5 ans'
                    },
                    {
                      value: 'Long terme (5-10 ans)',
                      label: 'Long terme',
                      desc: '5 à 10 ans'
                    },
                    {
                      value: 'Très long terme (plus de 10 ans)',
                      label: 'Très long terme',
                      desc: 'Plus de 10 ans'
                    }
                    ].map((option) => (
                      <label
                        key={option.value}
                        className={`flex items-center space-x-4 p-4 rounded-xl border cursor-pointer transition-all hover:shadow-lg ${
                          mifidProfile.timeHorizon === option.value
                            ? 'border-blue-500 bg-blue-500/10 shadow-blue-500/20'
                            : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
                        }`}
                      >
                        <input
                          type="radio"
                          name="timeHorizon"
                          value={option.value}
                          checked={mifidProfile.timeHorizon === option.value}
                          onChange={(e) => setMifidProfile({ ...mifidProfile, timeHorizon: e.target.value })}
                          className="sr-only"
                        />
                        <div
                          className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                            mifidProfile.timeHorizon === option.value
                              ? 'border-blue-500 bg-blue-500'
                              : 'border-gray-400'
                          }`}
                        >
                          {mifidProfile.timeHorizon === option.value && <div className="w-2 h-2 bg-white rounded-full"></div>}
                        </div>
                        <div>
                          <div className="text-white font-medium">{option.label}</div>
                          <div className="text-gray-400 text-sm">{option.desc}</div>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-white font-semibold mb-4 text-lg">Quel montant souhaitez-vous investir initialement ?</label>
                  <div className="grid md:grid-cols-2 gap-4">
                    {[{
                      value: 'moins_1k',
                      label: 'Moins de 1 000 €'
                    },
                    {
                      value: '1k_5k',
                      label: '1 000 € - 5 000 €'
                    },
                    {
                      value: '5k_10k',
                      label: '5 000 € - 10 000 €'
                    },
                    {
                      value: '10k_25k',
                      label: '10 000 € - 25 000 €'
                    },
                    {
                      value: '25k_50k',
                      label: '25 000 € - 50 000 €'
                    },
                    {
                      value: 'plus_50k',
                      label: 'Plus de 50 000 €'
                    }
                    ].map((option) => (
                      <label
                        key={option.value}
                        className={`flex items-center space-x-4 p-4 rounded-lg border cursor-pointer transition-all ${
                          mifidProfile.investmentAmount === option.value
                            ? 'border-blue-500 bg-blue-500/10'
                            : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
                        }`}
                      >
                        <input
                          type="radio"
                          name="investmentAmount"
                          value={option.value}
                          checked={mifidProfile.investmentAmount === option.value}
                          onChange={(e) => setMifidProfile({ ...mifidProfile, investmentAmount: e.target.value })}
                          className="sr-only"
                        />
                        <div
                          className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                            mifidProfile.investmentAmount === option.value
                              ? 'border-blue-500 bg-blue-500'
                              : 'border-gray-400'
                          }`}
                        >
                          {mifidProfile.investmentAmount === option.value && <div className="w-1.5 h-1.5 bg-white rounded-full"></div>}
                        </div>
                        <span className="text-white">{option.label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-white font-semibold mb-4 text-lg">Quel rendement annuel espérez-vous ?</label>
                  <div className="grid md:grid-cols-2 gap-4">
                    {[{
                      value: '0-2%',
                      label: '0% - 2%',
                      desc: 'Rendement très sécurisé'
                    },
                    {
                      value: '2-5%',
                      label: '2% - 5%',
                      desc: 'Rendement modéré'
                    },
                    {
                      value: '5-8%',
                      label: '5% - 8%',
                      desc: 'Rendement attractif'
                    },
                    {
                      value: '8-12%',
                      label: '8% - 12%',
                      desc: 'Rendement élevé'
                    },
                    {
                      value: 'plus_12%',
                      label: 'Plus de 12%',
                      desc: 'Rendement très élevé'
                    },
                    {
                      value: 'pas_attente',
                      label: 'Pas d\'attente précise',
                      desc: 'Je m\'adapte au marché'
                    }
                    ].map((option) => (
                      <label
                        key={option.value}
                        className={`flex items-center space-x-4 p-4 rounded-xl border cursor-pointer transition-all hover:shadow-lg ${
                          mifidProfile.expectedReturn === option.value
                            ? 'border-blue-500 bg-blue-500/10 shadow-blue-500/20'
                            : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
                        }`}
                      >
                        <input
                          type="radio"
                          name="expectedReturn"
                          value={option.value}
                          checked={mifidProfile.expectedReturn === option.value}
                          onChange={(e) => setMifidProfile({ ...mifidProfile, expectedReturn: e.target.value })}
                          className="sr-only"
                        />
                        <div
                          className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                            mifidProfile.expectedReturn === option.value
                              ? 'border-blue-500 bg-blue-500'
                              : 'border-gray-400'
                          }`}
                        >
                          {mifidProfile.expectedReturn === option.value && <div className="w-2 h-2 bg-white rounded-full"></div>}
                        </div>
                        <div>
                          <div className="text-white font-medium">{option.label}</div>
                          <div className="text-gray-400 text-sm">{option.desc}</div>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Étape 4 */}
          {currentStep === 4 && (
            <div className="space-y-8">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-white mb-3">Tolérance au Risque</h3>
                <p className="text-gray-400">Évaluons votre capacité à supporter les fluctuations et les risques</p>
              </div>

              <div className="space-y-8">
                <div>
                  <label className="block text-white font-semibold mb-4 text-lg">Comment évaluez-vous votre tolérance au risque ?</label>
                  <div className="grid gap-4">
                    {[{
                      value: 'tres_faible',
                      label: 'Très faible',
                      desc: 'Je ne supporte aucune perte, même temporaire'
                    },
                    {
                      value: 'faible',
                      label: 'Faible',
                      desc: 'Je peux accepter de petites fluctuations (moins de 5%)'
                    },
                    {
                      value: 'modere',
                      label: 'Modérée',
                      desc: 'Je peux supporter des pertes temporaires modérées (5-15%)'
                    },
                    {
                      value: 'eleve',
                      label: 'Élevée',
                      desc: 'Je peux accepter des pertes importantes si le potentiel de gain est élevé (15-30%)'
                    },
                    {
                      value: 'tres_eleve',
                      label: 'Très élevée',
                      desc: 'Je suis prêt à prendre des risques importants pour maximiser les gains (plus de 30%)'
                    }
                    ].map((option) => (
                      <label
                        key={option.value}
                        className={`flex items-center space-x-4 p-4 rounded-xl border cursor-pointer transition-all hover:shadow-lg ${
                          mifidProfile.riskTolerance === option.value
                            ? 'border-blue-500 bg-blue-500/10 shadow-blue-500/20'
                            : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
                        }`}
                      >
                        <input
                          type="radio"
                          name="riskTolerance"
                          value={option.value}
                          checked={mifidProfile.riskTolerance === option.value}
                          onChange={(e) => setMifidProfile({ ...mifidProfile, riskTolerance: e.target.value })}
                          className="sr-only"
                        />
                        <div
                          className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                            mifidProfile.riskTolerance === option.value
                              ? 'border-blue-500 bg-blue-500'
                              : 'border-gray-400'
                          }`}
                        >
                          {mifidProfile.riskTolerance === option.value && <div className="w-2 h-2 bg-white rounded-full"></div>}
                        </div>
                        <div>
                          <div className="text-white font-medium">{option.label}</div>
                          <div className="text-gray-400 text-sm">{option.desc}</div>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-white font-semibold mb-4 text-lg">Si votre portefeuille perdait 20% de sa valeur en un mois, que feriez-vous ?</label>
                  <div className="grid gap-4">
                    {[{
                      value: 'vendre_tout',
                      label: 'Vendre immédiatement',
                      desc: 'Je ne peux pas supporter cette perte'
                    },
                    {
                      value: 'vendre_partie',
                      label: 'Vendre une partie',
                      desc: 'Je réduirais mon exposition au risque'
                    },
                    {
                      value: 'attendre',
                      label: 'Attendre sans rien faire',
                      desc: 'J\'attendrais que les marchés se reprennent'
                    },
                    {
                      value: 'racheter',
                      label: 'Racheter davantage',
                      desc: 'Je profiterais de la baisse pour renforcer mes positions'
                    }
                    ].map((option) => (
                      <label
                        key={option.value}
                        className={`flex items-center space-x-4 p-4 rounded-xl border cursor-pointer transition-all hover:shadow-lg ${
                          mifidProfile.lossReaction === option.value
                            ? 'border-blue-500 bg-blue-500/10 shadow-blue-500/20'
                            : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
                        }`}
                      >
                        <input
                          type="radio"
                          name="lossReaction"
                          value={option.value}
                          checked={mifidProfile.lossReaction === option.value}
                          onChange={(e) => setMifidProfile({ ...mifidProfile, lossReaction: e.target.value })}
                          className="sr-only"
                        />
                        <div
                          className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                            mifidProfile.lossReaction === option.value
                              ? 'border-blue-500 bg-blue-500'
                              : 'border-gray-400'
                          }`}
                        >
                          {mifidProfile.lossReaction === option.value && <div className="w-2 h-2 bg-white rounded-full"></div>}
                        </div>
                        <div>
                          <div className="text-white font-medium">{option.label}</div>
                          <div className="text-gray-400 text-sm">{option.desc}</div>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-white font-semibold mb-4 text-lg">Comment vous sentez-vous face à la volatilité des marchés ?</label>
                  <div className="grid gap-4">
                    {[{
                      value: 'tres_inconfortable',
                      label: 'Très inconfortable',
                      desc: 'Les fluctuations me stressent énormément'
                    },
                    {
                      value: 'inconfortable',
                      label: 'Inconfortable',
                      desc: 'Je préfère éviter les variations importantes'
                    },
                    {
                      value: 'neutre',
                      label: 'Neutre',
                      desc: 'Je comprends que c\'est normal sur les marchés'
                    },
                    {
                      value: 'confortable',
                      label: 'Confortable',
                      desc: 'Je sais que la volatilité peut créer des opportunités'
                    },
                    {
                      value: 'tres_confortable',
                      label: 'Très confortable',
                      desc: 'J\'aime la volatilité car elle offre plus de potentiel'
                    }
                    ].map((option) => (
                      <label
                        key={option.value}
                        className={`flex items-center space-x-4 p-4 rounded-xl border cursor-pointer transition-all hover:shadow-lg ${
                          mifidProfile.volatilityComfort === option.value
                            ? 'border-blue-500 bg-blue-500/10 shadow-blue-500/20'
                            : 'border-gray-600 bg-gray-800/30 hover:border-gray-500'
                        }`}
                      >
                        <input
                          type="radio"
                          name="volatilityComfort"
                          value={option.value}
                          checked={mifidProfile.volatilityComfort === option.value}
                          onChange={(e) => setMifidProfile({ ...mifidProfile, volatilityComfort: e.target.value })}
                          className="sr-only"
                        />
                        <div
                          className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                            mifidProfile.volatilityComfort === option.value
                              ? 'border-blue-500 bg-blue-500'
                              : 'border-gray-400'
                          }`}
                        >
                          {mifidProfile.volatilityComfort === option.value && <div className="w-2 h-2 bg-white rounded-full"></div>}
                        </div>
                        <div>
                          <div className="text-white font-medium">{option.label}</div>
                          <div className="text-gray-400 text-sm">{option.desc}</div>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="flex justify-between items-center pt-8 border-t border-gray-700">
          <button
            onClick={handlePrevious}
            disabled={currentStep === 1}
            className={`flex items-center space-x-2 px-6 py-3 rounded-xl font-medium transition-all cursor-pointer whitespace-nowrap ${
              currentStep === 1
                ? 'bg-gray-800 text-gray-500 cursor-not-allowed'
                : 'bg-gray-700 hover:bg-gray-600 text-white shadow-lg hover:shadow-xl'
            }`}
          >
            <i className="ri-arrow-left-line"></i>
            <span>Précédent</span>
          </button>

          <div className="flex items-center space-x-4">
            <div className="flex space-x-2">
              {[1, 2, 3, 4].map((step) => (
                <div
                  key={step}
                  className={`w-3 h-3 rounded-full transition-all ${
                    step === currentStep
                      ? 'bg-blue-500 shadow-lg shadow-blue-500/50'
                      : step < currentStep
                      ? 'bg-green-500'
                      : 'bg-gray-600'
                  }`}
                ></div>
              ))}
            </div>
          </div>

          <button
            onClick={handleNext}
            disabled={
              (currentStep === 1 && (!mifidProfile.experience || !mifidProfile.knowledge || !mifidProfile.tradingFrequency)) ||
              (currentStep === 2 && (!mifidProfile.age || !mifidProfile.profession || !mifidProfile.annualIncome || !mifidProfile.liquidSavings || !mifidProfile.financialSituation)) ||
              (currentStep === 3 && (!mifidProfile.investmentObjective || !mifidProfile.timeHorizon || !mifidProfile.investmentAmount || !mifidProfile.expectedReturn)) ||
              (currentStep === 4 && (!mifidProfile.riskTolerance || !mifidProfile.lossReaction || !mifidProfile.volatilityComfort))
            }
            className={`flex items-center space-x-2 px-6 py-3 rounded-xl font-medium transition-all cursor-pointer whitespace-nowrap ${
              (currentStep === 1 && (!mifidProfile.experience || !mifidProfile.knowledge || !mifidProfile.tradingFrequency)) ||
              (currentStep === 2 && (!mifidProfile.age || !mifidProfile.profession || !mifidProfile.annualIncome || !mifidProfile.liquidSavings || !mifidProfile.financialSituation)) ||
              (currentStep === 3 && (!mifidProfile.investmentObjective || !mifidProfile.timeHorizon || !mifidProfile.investmentAmount || !mifidProfile.expectedReturn)) ||
              (currentStep === 4 && (!mifidProfile.riskTolerance || !mifidProfile.lossReaction || !mifidProfile.volatilityComfort))
                ? 'bg-gray-700 text-gray-500 cursor-not-allowed'
                : 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg hover:shadow-xl hover:from-blue-400 hover:to-purple-500'
            }`}
          >
            <span>{currentStep === 4 ? 'Terminer l\'évaluation' : 'Suivant'}</span>
            <i className="ri-arrow-right-line"></i>
          </button>
        </div>
      </div>
    </div>
  );
}
