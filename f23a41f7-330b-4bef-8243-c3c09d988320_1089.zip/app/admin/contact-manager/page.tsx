
'use client';

import { useState } from 'react';
import Link from 'next/link';

interface Contact {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  status: 'new' | 'in-progress' | 'resolved';
  priority: 'low' | 'medium' | 'high';
  createdAt: string;
  updatedAt: string;
}

export default function ContactManager() {
  const [contacts, setContacts] = useState<Contact[]>([
    {
      id: '1',
      name: 'Marie Dubois',
      email: 'marie.dubois@email.com',
      subject: 'Question sur les plans Premium',
      message: 'Bonjour, je souhaiterais avoir plus d\'informations sur les fonctionnalités du plan Premium...',
      status: 'new',
      priority: 'medium',
      createdAt: '2024-01-20T10:30:00Z',
      updatedAt: '2024-01-20T10:30:00Z'
    },
    {
      id: '2',
      name: 'Pierre Martin',
      email: 'pierre.martin@email.com',
      subject: 'Problème de connexion',
      message: 'Je n\'arrive pas à me connecter à mon compte depuis ce matin...',
      status: 'in-progress',
      priority: 'high',
      createdAt: '2024-01-19T14:15:00Z',
      updatedAt: '2024-01-20T09:00:00Z'
    },
    {
      id: '3',
      name: 'Sophie Laurent',
      email: 'sophie.laurent@email.com',
      subject: 'Demande de remboursement',
      message: 'Suite à un problème technique, je souhaiterais demander un remboursement...',
      status: 'resolved',
      priority: 'low',
      createdAt: '2024-01-18T16:45:00Z',
      updatedAt: '2024-01-19T11:30:00Z'
    }
  ]);

  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterPriority, setFilterPriority] = useState<string>('all');

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'new': return 'bg-blue-100 text-blue-800';
      case 'in-progress': return 'bg-yellow-100 text-yellow-800';
      case 'resolved': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-orange-100 text-orange-800';
      case 'low': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'new': return 'Nouveau';
      case 'in-progress': return 'En cours';
      case 'resolved': return 'Résolu';
      default: return status;
    }
  };

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case 'high': return 'Haute';
      case 'medium': return 'Moyenne';
      case 'low': return 'Basse';
      default: return priority;
    }
  };

  const updateStatus = (id: string, newStatus: 'new' | 'in-progress' | 'resolved') => {
    setContacts(contacts.map(contact => 
      contact.id === id 
        ? { ...contact, status: newStatus, updatedAt: new Date().toISOString() }
        : contact
    ));
    if (selectedContact && selectedContact.id === id) {
      setSelectedContact({ ...selectedContact, status: newStatus, updatedAt: new Date().toISOString() });
    }
  };

  const filteredContacts = contacts.filter(contact => {
    if (filterStatus !== 'all' && contact.status !== filterStatus) return false;
    if (filterPriority !== 'all' && contact.priority !== filterPriority) return false;
    return true;
  });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <Link href="/admin/dashboard" className="text-blue-600 hover:text-blue-800">
                <i className="ri-arrow-left-line text-xl"></i>
              </Link>
              <h1 className="text-2xl font-bold text-gray-900">Gestion des Contacts</h1>
            </div>
            <div className="flex items-center space-x-4">
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">Tous les statuts</option>
                <option value="new">Nouveau</option>
                <option value="in-progress">En cours</option>
                <option value="resolved">Résolu</option>
              </select>
              <select
                value={filterPriority}
                onChange={(e) => setFilterPriority(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">Toutes les priorités</option>
                <option value="high">Haute</option>
                <option value="medium">Moyenne</option>
                <option value="low">Basse</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Contact List */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-900">
                  Messages ({filteredContacts.length})
                </h2>
              </div>
              <div className="divide-y divide-gray-200 max-h-[600px] overflow-y-auto">
                {filteredContacts.map((contact) => (
                  <div
                    key={contact.id}
                    onClick={() => setSelectedContact(contact)}
                    className={`p-4 cursor-pointer hover:bg-gray-50 ${
                      selectedContact?.id === contact.id ? 'bg-blue-50 border-r-4 border-blue-500' : ''
                    }`}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h3 className="font-medium text-gray-900">{contact.name}</h3>
                        <p className="text-sm text-gray-600">{contact.email}</p>
                      </div>
                      <div className="flex flex-col items-end space-y-1">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(contact.priority)}`}>
                          {getPriorityLabel(contact.priority)}
                        </span>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(contact.status)}`}>
                          {getStatusLabel(contact.status)}
                        </span>
                      </div>
                    </div>
                    <p className="text-sm font-medium text-gray-800 mb-1">{contact.subject}</p>
                    <p className="text-sm text-gray-600 truncate">{contact.message}</p>
                    <p className="text-xs text-gray-500 mt-2">{formatDate(contact.createdAt)}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Contact Detail */}
          <div className="lg:col-span-2">
            {selectedContact ? (
              <div className="bg-white rounded-lg shadow-sm">
                <div className="px-6 py-4 border-b border-gray-200">
                  <div className="flex justify-between items-start">
                    <div>
                      <h2 className="text-lg font-semibold text-gray-900">{selectedContact.subject}</h2>
                      <p className="text-sm text-gray-600">
                        De: {selectedContact.name} ({selectedContact.email})
                      </p>
                      <p className="text-sm text-gray-500">
                        Reçu le: {formatDate(selectedContact.createdAt)}
                      </p>
                      {selectedContact.updatedAt !== selectedContact.createdAt && (
                        <p className="text-sm text-gray-500">
                          Mis à jour le: {formatDate(selectedContact.updatedAt)}
                        </p>
                      )}
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${getPriorityLabel(selectedContact.priority)}`}>
                        {getPriorityLabel(selectedContact.priority)}
                      </span>
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(selectedContact.status)}`}>
                        {getStatusLabel(selectedContact.status)}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="p-6">
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-700 mb-2">Message:</h3>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <p className="text-gray-800 whitespace-pre-wrap">{selectedContact.message}</p>
                    </div>
                  </div>

                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-700 mb-3">Changer le statut:</h3>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => updateStatus(selectedContact.id, 'new')}
                        className={`px-4 py-2 rounded-lg text-sm font-medium ${
                          selectedContact.status === 'new'
                            ? 'bg-blue-600 text-white'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                      >
                        Nouveau
                      </button>
                      <button
                        onClick={() => updateStatus(selectedContact.id, 'in-progress')}
                        className={`px-4 py-2 rounded-lg text-sm font-medium ${
                          selectedContact.status === 'in-progress'
                            ? 'bg-yellow-600 text-white'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                      >
                        En cours
                      </button>
                      <button
                        onClick={() => updateStatus(selectedContact.id, 'resolved')}
                        className={`px-4 py-2 rounded-lg text-sm font-medium ${
                          selectedContact.status === 'resolved'
                            ? 'bg-green-600 text-white'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                      >
                        Résolu
                      </button>
                    </div>
                  </div>

                  <div className="border-t border-gray-200 pt-6">
                    <h3 className="text-sm font-medium text-gray-700 mb-3">Répondre:</h3>
                    <textarea
                      placeholder="Tapez votre réponse ici..."
                      rows={4}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                    />
                    <div className="flex justify-end mt-3">
                      <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center space-x-2">
                        <i className="ri-send-plane-line"></i>
                        <span>Envoyer</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-lg shadow-sm h-96 flex items-center justify-center">
                <div className="text-center">
                  <i className="ri-mail-line text-4xl text-gray-400 mb-4"></i>
                  <p className="text-gray-500">Sélectionnez un message pour voir les détails</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
