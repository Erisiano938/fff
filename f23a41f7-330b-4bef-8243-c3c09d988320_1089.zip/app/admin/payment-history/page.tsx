'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

interface Transaction {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  planName: string;
  planPrice: string;
  paymentMethod: string;
  status: 'completed' | 'pending' | 'failed' | 'refunded';
  transactionId: string;
  date: string;
  country: string;
}

const mockTransactions: Transaction[] = [
  {
    id: '1',
    email: 'jean.dupont@email.com',
    firstName: 'Jean',
    lastName: 'Dupont',
    planName: 'Accès Premium',
    planPrice: '79€',
    paymentMethod: 'Carte Bancaire',
    status: 'completed',
    transactionId: 'TXN_001234567',
    date: '2024-01-15T10:30:00Z',
    country: 'France'
  },
  {
    id: '2',
    email: 'marie.martin@email.com',
    firstName: 'Marie',
    lastName: 'Martin',
    planName: 'Accès VIP',
    planPrice: '199€',
    paymentMethod: 'PayPal',
    status: 'completed',
    transactionId: 'TXN_001234568',
    date: '2024-01-14T15:45:00Z',
    country: 'Belgique'
  },
  {
    id: '3',
    email: 'pierre.bernard@email.com',
    firstName: 'Pierre',
    lastName: 'Bernard',
    planName: 'Accès Basique',
    planPrice: '29€',
    paymentMethod: 'Carte Bancaire',
    status: 'pending',
    transactionId: 'TXN_001234569',
    date: '2024-01-14T09:20:00Z',
    country: 'France'
  },
  {
    id: '4',
    email: 'sophie.leroy@email.com',
    firstName: 'Sophie',
    lastName: 'Leroy',
    planName: 'Accès Premium',
    planPrice: '79€',
    paymentMethod: 'PayPal',
    status: 'failed',
    transactionId: 'TXN_001234570',
    date: '2024-01-13T14:10:00Z',
    country: 'Suisse'
  },
  {
    id: '5',
    email: 'antoine.moreau@email.com',
    firstName: 'Antoine',
    lastName: 'Moreau',
    planName: 'Accès VIP',
    planPrice: '199€',
    paymentMethod: 'Carte Bancaire',
    status: 'refunded',
    transactionId: 'TXN_001234571',
    date: '2024-01-12T11:55:00Z',
    country: 'Canada'
  },
  {
    id: '6',
    email: 'claire.dubois@email.com',
    firstName: 'Claire',
    lastName: 'Dubois',
    planName: 'Accès Premium',
    planPrice: '79€',
    paymentMethod: 'Carte Bancaire',
    status: 'completed',
    transactionId: 'TXN_001234572',
    date: '2024-01-11T16:30:00Z',
    country: 'France'
  },
  {
    id: '7',
    email: 'lucas.petit@email.com',
    firstName: 'Lucas',
    lastName: 'Petit',
    planName: 'Accès Basique',
    planPrice: '29€',
    paymentMethod: 'PayPal',
    status: 'completed',
    transactionId: 'TXN_001234573',
    date: '2024-01-10T13:25:00Z',
    country: 'France'
  },
  {
    id: '8',
    email: 'camille.rousseau@email.com',
    firstName: 'Camille',
    lastName: 'Rousseau',
    planName: 'Accès VIP',
    planPrice: '199€',
    paymentMethod: 'Carte Bancaire',
    status: 'completed',
    transactionId: 'TXN_001234574',
    date: '2024-01-09T08:45:00Z',
    country: 'Belgique'
  }
];

export default function PaymentHistoryPage() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [planFilter, setPlanFilter] = useState('all');
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);

  useEffect(() => {
    // En production, ceci viendrait d'une API
    setTransactions(mockTransactions);
    setFilteredTransactions(mockTransactions);
  }, []);

  useEffect(() => {
    let filtered = transactions;

    // Filtre de recherche
    if (searchTerm) {
      filtered = filtered.filter(t => 
        t.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.transactionId.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Filtre par statut
    if (statusFilter !== 'all') {
      filtered = filtered.filter(t => t.status === statusFilter);
    }

    // Filtre par plan
    if (planFilter !== 'all') {
      filtered = filtered.filter(t => t.planName === planFilter);
    }

    setFilteredTransactions(filtered);
  }, [searchTerm, statusFilter, planFilter, transactions]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-400 bg-green-400/10';
      case 'pending': return 'text-yellow-400 bg-yellow-400/10';
      case 'failed': return 'text-red-400 bg-red-400/10';
      case 'refunded': return 'text-gray-400 bg-gray-400/10';
      default: return 'text-gray-400 bg-gray-400/10';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed': return 'Complété';
      case 'pending': return 'En attente';
      case 'failed': return 'Échoué';
      case 'refunded': return 'Remboursé';
      default: return status;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getTotalRevenue = () => {
    return filteredTransactions
      .filter(t => t.status === 'completed')
      .reduce((sum, t) => sum + parseInt(t.planPrice), 0);
  };

  const getStatistics = () => {
    const total = filteredTransactions.length;
    const completed = filteredTransactions.filter(t => t.status === 'completed').length;
    const pending = filteredTransactions.filter(t => t.status === 'pending').length;
    const failed = filteredTransactions.filter(t => t.status === 'failed').length;
    
    return { total, completed, pending, failed };
  };

  const stats = getStatistics();

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <Link href="/admin/dashboard" className="inline-flex items-center text-yellow-500 hover:text-yellow-400 mb-4 cursor-pointer">
              <i className="ri-arrow-left-line mr-2"></i>
              Retour au Dashboard
            </Link>
            <h1 className="text-3xl font-bold">Historique des Paiements</h1>
            <p className="text-gray-400 mt-2">Consultez toutes les transactions effectuées</p>
          </div>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-gray-900 rounded-xl p-6 border border-gray-800">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Total Transactions</p>
                <p className="text-2xl font-bold text-white">{stats.total}</p>
              </div>
              <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                <i className="ri-file-list-line text-2xl text-blue-400"></i>
              </div>
            </div>
          </div>

          <div className="bg-gray-900 rounded-xl p-6 border border-gray-800">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Complétées</p>
                <p className="text-2xl font-bold text-green-400">{stats.completed}</p>
              </div>
              <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
                <i className="ri-check-line text-2xl text-green-400"></i>
              </div>
            </div>
          </div>

          <div className="bg-gray-900 rounded-xl p-6 border border-gray-800">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">En Attente</p>
                <p className="text-2xl font-bold text-yellow-400">{stats.pending}</p>
              </div>
              <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center">
                <i className="ri-time-line text-2xl text-yellow-400"></i>
              </div>
            </div>
          </div>

          <div className="bg-gray-900 rounded-xl p-6 border border-gray-800">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Revenus Total</p>
                <p className="text-2xl font-bold text-yellow-500">{getTotalRevenue()}€</p>
              </div>
              <div className="w-12 h-12 bg-yellow-500/20 rounded-lg flex items-center justify-center">
                <i className="ri-money-euro-circle-line text-2xl text-yellow-500"></i>
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-gray-900 rounded-xl p-6 border border-gray-800 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Rechercher</label>
              <div className="relative">
                <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Email, nom, ID transaction..."
                  className="w-full pl-10 pr-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:border-yellow-500 focus:outline-none text-white placeholder-gray-400"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Statut</label>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:border-yellow-500 focus:outline-none text-white pr-8"
              >
                <option value="all">Tous les statuts</option>
                <option value="completed">Complété</option>
                <option value="pending">En attente</option>
                <option value="failed">Échoué</option>
                <option value="refunded">Remboursé</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Plan</label>
              <select
                value={planFilter}
                onChange={(e) => setPlanFilter(e.target.value)}
                className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:border-yellow-500 focus:outline-none text-white pr-8"
              >
                <option value="all">Tous les plans</option>
                <option value="Accès Basique">Accès Basique</option>
                <option value="Accès Premium">Accès Premium</option>
                <option value="Accès VIP">Accès VIP</option>
              </select>
            </div>
          </div>
        </div>

        {/* Transactions Table */}
        <div className="bg-gray-900 rounded-xl border border-gray-800 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-800">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Client</th>
                  <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Plan</th>
                  <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Montant</th>
                  <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Paiement</th>
                  <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Statut</th>
                  <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Date</th>
                  <th className="px-6 py-4 text-left text-sm font-medium text-gray-300">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800">
                {filteredTransactions.map((transaction) => (
                  <tr key={transaction.id} className="hover:bg-gray-800/50">
                    <td className="px-6 py-4">
                      <div>
                        <div className="font-medium text-white">{transaction.firstName} {transaction.lastName}</div>
                        <div className="text-sm text-gray-400">{transaction.email}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-white font-medium">{transaction.planName}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-yellow-400 font-bold">{transaction.planPrice}</span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-2">
                        <i className={`${transaction.paymentMethod === 'PayPal' ? 'ri-paypal-line' : 'ri-bank-card-line'} text-gray-400`}></i>
                        <span className="text-gray-300">{transaction.paymentMethod}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(transaction.status)}`}>
                        {getStatusText(transaction.status)}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-gray-300">{formatDate(transaction.date)}</span>
                    </td>
                    <td className="px-6 py-4">
                      <button
                        onClick={() => setSelectedTransaction(transaction)}
                        className="text-yellow-500 hover:text-yellow-400 cursor-pointer"
                      >
                        <i className="ri-eye-line text-lg"></i>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredTransactions.length === 0 && (
            <div className="text-center py-12">
              <i className="ri-file-list-line text-4xl text-gray-600 mb-4"></i>
              <p className="text-gray-400">Aucune transaction trouvée</p>
            </div>
          )}
        </div>
      </div>

      {/* Transaction Detail Modal */}
      {selectedTransaction && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-900 rounded-xl p-6 max-w-2xl w-full border border-gray-800">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-white">Détails de la Transaction</h3>
              <button
                onClick={() => setSelectedTransaction(null)}
                className="text-gray-400 hover:text-white cursor-pointer"
              >
                <i className="ri-close-line text-2xl"></i>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-lg font-semibold text-white mb-4">Informations Client</h4>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm text-gray-400">Nom complet</label>
                    <p className="text-white">{selectedTransaction.firstName} {selectedTransaction.lastName}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-400">Email</label>
                    <p className="text-white">{selectedTransaction.email}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-400">Pays</label>
                    <p className="text-white">{selectedTransaction.country}</p>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-lg font-semibold text-white mb-4">Détails du Paiement</h4>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm text-gray-400">Plan acheté</label>
                    <p className="text-white">{selectedTransaction.planName}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-400">Montant</label>
                    <p className="text-yellow-400 font-bold">{selectedTransaction.planPrice}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-400">Méthode de paiement</label>
                    <p className="text-white">{selectedTransaction.paymentMethod}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-400">ID Transaction</label>
                    <p className="text-white font-mono text-sm">{selectedTransaction.transactionId}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-400">Statut</label>
                    <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(selectedTransaction.status)}`}>
                      {getStatusText(selectedTransaction.status)}
                    </span>
                  </div>
                  <div>
                    <label className="text-sm text-gray-400">Date</label>
                    <p className="text-white">{formatDate(selectedTransaction.date)}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end space-x-4 mt-8">
              <button
                onClick={() => setSelectedTransaction(null)}
                className="px-6 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-700 cursor-pointer"
              >
                Fermer
              </button>
              <button className="px-6 py-2 bg-yellow-500 text-black rounded-lg hover:bg-yellow-400 cursor-pointer">
                Exporter PDF
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}