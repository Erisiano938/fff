
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { isAuthenticated } from '../../lib/auth';

export default function SecuritySettingsPage() {
  const [authenticated, setAuthenticated] = useState(false);
  const [configName, setConfigName] = useState('');
  const [stringArray, setStringArray] = useState(true);
  const [deadCodeInjection, setDeadCodeInjection] = useState(true);
  const [controlFlow, setControlFlow] = useState(true);
  const [selfDefending, setSelfDefending] = useState(true);
  const [stringArrayThreshold, setStringArrayThreshold] = useState(75);
  const [encodingMethod, setEncodingMethod] = useState('Base64');
  const [identifierGenerator, setIdentifierGenerator] = useState('hexadecimal');
  const [isBuilding, setIsBuilding] = useState(false);
  const [buildLogs, setBuildLogs] = useState<string[]>([]);
  const router = useRouter();

  useEffect(() => {
    if (!isAuthenticated()) {
      router.push('/admin/login');
      return;
    }
    setAuthenticated(true);
  }, [router]);

  const handleSaveConfig = () => {
    const config = {
      name: configName,
      stringArray,
      deadCodeInjection,
      controlFlow,
      selfDefending,
      stringArrayThreshold,
      encodingMethod,
      identifierGenerator,
      savedAt: new Date().toISOString()
    };

    localStorage.setItem('obfuscation_config', JSON.stringify(config));
    alert('Configuration saved successfully!');
  };

  const handleStartObfuscation = () => {
    setIsBuilding(true);
    setBuildLogs(['Starting complete obfuscation...']);

    setTimeout(() => {
      setBuildLogs(prev => [...prev, 'Analyzing source files...']);
    }, 1000);

    setTimeout(() => {
      setBuildLogs(prev => [...prev, 'Applying transformations...']);
    }, 2000);

    setTimeout(() => {
      setBuildLogs(prev => [...prev, 'Injecting dead code...']);
    }, 3000);

    setTimeout(() => {
      setBuildLogs(prev => [...prev, 'Obfuscating strings...']);
    }, 4000);

    setTimeout(() => {
      setBuildLogs(prev => [...prev, 'Build completed successfully!']);
      setIsBuilding(false);
    }, 5500);
  };

  const handleConfigWebpack = () => {
    alert('Webpack configuration updated!');
  };

  const handleAnalyzeBundles = () => {
    alert('Bundle analysis launched!');
  };

  const handleExportConfig = () => {
    const config = {
      name: configName,
      stringArray,
      deadCodeInjection,
      controlFlow,
      selfDefending,
      stringArrayThreshold,
      encodingMethod,
      identifierGenerator
    };

    const dataStr = JSON.stringify(config, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);

    const exportFileDefaultName = 'obfuscation-config.json';

    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleResetConfig = () => {
    setConfigName('');
    setStringArray(true);
    setDeadCodeInjection(true);
    setControlFlow(true);
    setSelfDefending(true);
    setStringArrayThreshold(75);
    setEncodingMethod('Base64');
    setIdentifierGenerator('hexadecimal');
  };

  if (!authenticated) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-yellow-500 mx-auto mb-4"></div>
          <p className="text-white">Verifying access...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="bg-gray-900 border-b border-gray-800">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center space-x-4">
            <div className="text-2xl font-bold" style={{ fontFamily: 'Pacifico, serif' }}>
              logo
            </div>
            <div>
              <h1 className="text-xl font-semibold">CMV Administration</h1>
              <p className="text-sm text-gray-400">Wealth Management</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-400">Last login: 13/07/2025</span>
            <div className="flex items-center space-x-2">
              <i className="ri-user-line w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center text-black"></i>
              <div>
                <div className="text-sm font-medium">Administrator</div>
                <div className="text-xs text-gray-400">admin@cmvfinance.com</div>
              </div>
            </div>
            <button className="px-3 py-1 bg-blue-500 hover:bg-blue-600 rounded text-sm font-medium">
              <i className="ri-edit-line mr-1"></i>
              Editor
            </button>
            <button className="px-3 py-1 bg-red-500 hover:bg-red-600 rounded text-sm font-medium">
              <i className="ri-logout-box-line mr-1"></i>
              Logout
            </button>
          </div>
        </div>
      </div>

      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 bg-gray-900 min-h-screen p-4">
          <nav className="space-y-2">
            <Link
              href="/admin/dashboard"
              className="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
            >
              <i className="ri-dashboard-line"></i>
              <span>Overview</span>
            </Link>
            <Link
              href="/admin/create-blog"
              className="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
            >
              <i className="ri-file-text-line"></i>
              <span>Content Management</span>
            </Link>
            <Link
              href="/admin/academy-manager"
              className="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
            >
              <i className="ri-graduation-cap-line"></i>
              <span>Academy</span>
            </Link>
            <Link
              href="/admin/create-blog"
              className="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
            >
              <i className="ri-edit-line"></i>
              <span>Text Editor</span>
            </Link>
            <Link
              href="/admin/indicators-manager"
              className="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
            >
              <i className="ri-line-chart-line"></i>
              <span>Indicators</span>
            </Link>
            <Link
              href="/admin/security-settings"
              className="flex items-center space-x-3 px-4 py-3 rounded-lg bg-yellow-500 text-black font-medium"
            >
              <i className="ri-shield-check-line"></i>
              <span>Security & Compliance</span>
            </Link>
            <Link
              href="/admin/settings"
              className="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
            >
              <i className="ri-folder-line"></i>
              <span>Management Pages</span>
            </Link>
            <Link
              href="/admin/settings"
              className="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
            >
              <i className="ri-user-line"></i>
              <span>Users</span>
            </Link>
            <Link
              href="/admin/settings"
              className="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
            >
              <i className="ri-bar-chart-line"></i>
              <span>Analytics</span>
            </Link>
            <Link
              href="/admin/settings"
              className="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
            >
              <i className="ri-settings-line"></i>
              <span>Settings</span>
            </Link>
          </nav>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-6">
          <div className="mb-6">
            <h1 className="text-2xl font-bold mb-2">Security & Compliance</h1>
            <p className="text-gray-400">Manage your site easily</p>
          </div>

          {/* Alert Section */}
          <div className="bg-red-900/20 border border-red-500/30 rounded-lg p-4 mb-6">
            <div className="flex items-center">
              <i className="ri-error-warning-line text-red-400 mr-3"></i>
              <div>
                <h3 className="font-semibold text-red-400">Security & Compliance Dashboard</h3>
                <p className="text-sm text-gray-300">Real-time threat monitoring, identity management and regulatory compliance. All security aspects of your financial platform centralized.</p>
              </div>
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            {/* Advanced Obfuscation Configuration */}
            <div className="bg-gray-900 rounded-lg p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold flex items-center">
                  <i className="ri-code-line text-blue-400 mr-2"></i>
                  Advanced Obfuscation Configuration
                </h2>
                <div className="flex space-x-2">
                  <button
                    onClick={handleExportConfig}
                    className="px-3 py-1 bg-cyan-500 hover:bg-cyan-600 text-white rounded text-sm font-medium transition-colors"
                  >
                    <i className="ri-download-line mr-1"></i>
                    Export Config
                  </button>
                  <button
                    onClick={handleResetConfig}
                    className="px-3 py-1 bg-gray-600 hover:bg-gray-700 text-white rounded text-sm font-medium transition-colors"
                  >
                    <i className="ri-refresh-line mr-1"></i>
                    Reset
                  </button>
                </div>
              </div>

              {/* Configuration Management */}
              <div className="mb-6">
                <h3 className="text-lg font-medium mb-3">Configuration Management</h3>
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={configName}
                    onChange={(e) => setConfigName(e.target.value)}
                    placeholder="Configuration name"
                    className="flex-1 px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white text-sm focus:border-blue-500 focus:outline-none"
                  />
                  <button
                    onClick={handleSaveConfig}
                    className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded font-medium transition-colors"
                  >
                    Save
                  </button>
                </div>
              </div>

              {/* Main Parameters */}
              <div className="mb-6">
                <h3 className="text-lg font-medium mb-4">Main Parameters</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">String Array</div>
                      <div className="text-sm text-gray-400">String obfuscation</div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={stringArray}
                        onChange={(e) => setStringArray(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-gray-700 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-['] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500"></div>
                    </label>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Dead Code Injection</div>
                      <div className="text-sm text-gray-400">Dead code injection</div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={deadCodeInjection}
                        onChange={(e) => setDeadCodeInjection(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-gray-700 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-['] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500"></div>
                    </label>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Control Flow</div>
                      <div className="text-sm text-gray-400">Control flow flattening</div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={controlFlow}
                        onChange={(e) => setControlFlow(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-gray-700 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-['] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500"></div>
                    </label>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Self Defending</div>
                      <div className="text-sm text-gray-400">Self-defensive protection</div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selfDefending}
                        onChange={(e) => setSelfDefending(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-gray-700 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-['] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500"></div>
                    </label>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium">String Array Threshold: {stringArrayThreshold}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={stringArrayThreshold}
                      onChange={(e) => setStringArrayThreshold(parseInt(e.target.value))}
                      className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer slider"
                    />
                  </div>

                  <div>
                    <label className="block font-medium mb-2">String Encoding</label>
                    <select
                      value={encodingMethod}
                      onChange={(e) => setEncodingMethod(e.target.value)}
                      className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white focus:border-blue-500 focus:outline-none pr-8"
                    >
                      <option value="Base64">Base64</option>
                      <option value="RC4">RC4</option>
                      <option value="None">None</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-medium mb-2">Identifier Generator</label>
                    <select
                      value={identifierGenerator}
                      onChange={(e) => setIdentifierGenerator(e.target.value)}
                      className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white focus:border-blue-500 focus:outline-none pr-8"
                    >
                      <option value="hexadecimal">Hexadecimal</option>
                      <option value="mangled">Mangled</option>
                      <option value="dictionary">Dictionary</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* Build Process */}
            <div className="bg-gray-900 rounded-lg p-6">
              <h2 className="text-xl font-semibold mb-6 flex items-center">
                <i className="ri-play-circle-line text-green-400 mr-2"></i>
                Build Process
              </h2>

              <button
                onClick={handleStartObfuscation}
                disabled={isBuilding}
                className={`w-full py-3 rounded-lg font-medium mb-4 transition-colors ${
                  isBuilding
                    ? 'bg-gray-600 text-gray-400 cursor-not-allowed'
                    : 'bg-green-500 hover:bg-green-600 text-white'
                }`}
              >
                <i className="ri-play-line mr-2"></i>
                {isBuilding ? 'Obfuscation in progress...' : 'Start Complete Obfuscation'}
              </button>

              <div className="grid grid-cols-2 gap-3 mb-6">
                <button
                  onClick={handleConfigWebpack}
                  className="py-2 px-4 bg-purple-500 hover:bg-purple-600 text-white rounded font-medium transition-colors"
                >
                  <i className="ri-settings-3-line mr-1"></i>
                  Config Webpack
                </button>
                <button
                  onClick={handleAnalyzeBundles}
                  className="py-2 px-4 bg-pink-500 hover:bg-pink-600 text-white rounded font-medium transition-colors"
                >
                  <i className="ri-pie-chart-line mr-1"></i>
                  Analyze Bundles
                </button>
              </div>

              {/* Build Logs */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-lg font-medium flex items-center">
                    <i className="ri-terminal-line text-green-400 mr-2"></i>
                    Real-time Build Logs
                  </h3>
                  <button
                    onClick={() => setBuildLogs([])}
                    className="text-gray-400 hover:text-white"
                  >
                    <i className="ri-delete-bin-line"></i>
                  </button>
                </div>
                <div className="bg-gray-800 rounded-lg p-4 h-48 overflow-y-auto border border-gray-700">
                  {buildLogs.length === 0 ? (
                    <p className="text-gray-400 text-sm">No logs available. Start a build to see details.</p>
                  ) : (
                    <div className="space-y-1">
                      {buildLogs.map((log, index) => (
                        <div key={index} className="text-sm text-green-400 font-mono">
                          [{new Date().toLocaleTimeString()}] {log}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* RBAC Section */}
          <div className="mt-8 bg-gray-900 rounded-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold flex items-center">
                <i className="ri-shield-user-line text-yellow-400 mr-2"></i>
                RBAC Management & Role Delegation
              </h2>
              <div className="flex space-x-2">
                <button
                  onClick={() => {
                    alert('RBAC configuration exported successfully!');
                  }}
                  className="px-3 py-1 bg-yellow-500 hover:bg-yellow-600 text-black rounded text-sm font-medium transition-colors"
                >
                  <i className="ri-download-line mr-1"></i>
                  Export RBAC
                </button>
                <button
                  onClick={() => {
                    alert('New RBAC configuration created!');
                  }}
                  className="px-3 py-1 bg-blue-500 hover:bg-blue-600 text-white rounded text-sm font-medium transition-colors"
                >
                  <i className="ri-add-line mr-1"></i>
                  New Role
                </button>
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              {/* Role Matrix */}
              <div className="bg-gray-800 rounded-lg p-4">
                <h3 className="text-lg font-medium mb-4 flex items-center">
                  <i className="ri-user-settings-line text-blue-400 mr-2"></i>
                  Role Matrix
                </h3>
                <div className="space-y-3">
                  <div className="bg-red-900/20 border border-red-500/30 rounded p-3">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-red-400">Admin</span>
                      <span className="text-xs bg-red-500 text-white px-2 py-1 rounded">FULL</span>
                    </div>
                    <ul className="text-sm text-gray-300 space-y-1">
                      <li>• Full system access</li>
                      <li>• User management</li>
                      <li>• Critical configuration</li>
                      <li>• Delegation to Sub-Admin</li>
                    </ul>
                  </div>

                  <div className="bg-orange-900/20 border border-orange-500/30 rounded p-3">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-orange-400">Dev</span>
                      <span className="text-xs bg-orange-500 text-white px-2 py-1 rounded">HIGH</span>
                    </div>
                    <ul className="text-sm text-gray-300 space-y-1">
                      <li>• Repository & staging access</li>
                      <li>• Application logs</li>
                      <li>• Read delegation to Audit</li>
                      <li>• Production with approval</li>
                    </ul>
                  </div>

                  <div className="bg-blue-900/20 border border-blue-500/30 rounded p-3">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-blue-400">Audit</span>
                      <span className="text-xs bg-blue-500 text-white px-2 py-1 rounded">READ</span>
                    </div>
                    <ul className="text-sm text-gray-300 space-y-1">
                      <li>• Read-only access</li>
                      <li>• Report generation</li>
                      <li>• Compliance sharing</li>
                      <li>• No modifications</li>
                    </ul>
                  </div>

                  <div className="bg-green-900/20 border border-green-500/30 rounded p-3">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-green-400">Support</span>
                      <span className="text-xs bg-green-500 text-white px-2 py-1 rounded">LIMITED</span>
                    </div>
                    <ul className="text-sm text-gray-300 space-y-1">
                      <li>• Client & ticket access</li>
                      <li>• Documentation</li>
                      <li>• Escalation by criticality</li>
                      <li>• No sensitive data</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* MFA/SSO Configuration */}
              <div className="bg-gray-800 rounded-lg p-4">
                <h3 className="text-lg font-medium mb-4 flex items-center">
                  <i className="ri-shield-keyhole-line text-green-400 mr-2"></i>
                  MFA/SSO Configuration
                </h3>
                <div className="space-y-4">
                  <div className="bg-gray-700 rounded p-3">
                    <h4 className="font-medium text-green-400 mb-2">Protected Git Repositories</h4>
                    <div className="text-sm text-gray-300 space-y-1">
                      <div className="flex items-center justify-between">
                        <span>GPG Signing</span>
                        <i className="ri-check-line text-green-400"></i>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Mandatory MFA</span>
                        <i className="ri-check-line text-green-400"></i>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Branch Protection</span>
                        <i className="ri-check-line text-green-400"></i>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-700 rounded p-3">
                    <h4 className="font-medium text-blue-400 mb-2">Infrastructure Consoles</h4>
                    <div className="text-sm text-gray-300 space-y-1">
                      <div className="flex items-center justify-between">
                        <span>AWS Console</span>
                        <span className="text-xs bg-blue-500 text-white px-2 py-1 rounded">MFA+IP</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Kubernetes</span>
                        <span className="text-xs bg-blue-500 text-white px-2 py-1 rounded">RBAC+SSO</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Monitoring</span>
                        <span className="text-xs bg-blue-500 text-white px-2 py-1 rounded">Role-based</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Database</span>
                        <span className="text-xs bg-blue-500 text-white px-2 py-1 rounded">VPN+Cert</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-700 rounded p-3">
                    <h4 className="font-medium text-purple-400 mb-2">SSO Provider</h4>
                    <select className="w-full px-3 py-2 bg-gray-600 border border-gray-500 rounded text-white text-sm focus:border-purple-500 focus:outline-none pr-8">
                      <option>Azure AD</option>
                      <option>Okta</option>
                      <option>Auth0</option>
                      <option>Google Workspace</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Version Control & Audit */}
              <div className="bg-gray-800 rounded-lg p-4">
                <h3 className="text-lg font-medium mb-4 flex items-center">
                  <i className="ri-git-branch-line text-purple-400 mr-2"></i>
                  Version Control & Audit
                </h3>
                <div className="space-y-4">
                  <div className="bg-gray-700 rounded p-3">
                    <h4 className="font-medium text-purple-400 mb-2">Branch Protection</h4>
                    <div className="text-sm text-gray-300 space-y-2">
                      <div className="flex items-center justify-between">
                        <span>Required Reviews</span>
                        <input
                          type="number"
                          defaultValue="2"
                          className="w-12 px-2 py-1 bg-gray-600 rounded text-center text-xs"
                        />
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" defaultChecked className="rounded" onChange={() => {}} />
                        <span className="text-xs">Dismiss stale reviews</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" defaultChecked className="rounded" onChange={() => {}} />
                        <span className="text-xs">Code owner reviews</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" defaultChecked className="rounded" onChange={() => {}} />
                        <span className="text-xs">Status checks required</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-700 rounded p-3">
                    <h4 className="font-medium text-yellow-400 mb-2">Automatic Audit</h4>
                    <div className="space-y-2">
                      <button
                        onClick={() => {
                          alert('JSON export generated!\n\nAudited commits: 1,247\nMerge requests: 89\nViolations: 3\nCompliance: 97.6%');
                        }}
                        className="w-full py-2 bg-yellow-500 hover:bg-yellow-600 text-black rounded text-sm font-medium transition-colors"
                      >
                        <i className="ri-file-code-line mr-1"></i>
                        Export JSON
                      </button>
                      <button
                        onClick={() => {
                          alert('CSV export generated!\n\nFile: audit-commits-2024.csv\nRows: 1,247\nColumns: SHA, Author, Date, Message, Files, Reviewers, Status');
                        }}
                        className="w-full py-2 bg-green-500 hover:bg-green-600 text-white rounded text-sm font-medium transition-colors"
                      >
                        <i className="ri-file-excel-line mr-1"></i>
                        Export CSV
                      </button>
                    </div>
                  </div>

                  <div className="bg-gray-700 rounded p-3">
                    <h4 className="font-medium text-red-400 mb-2">Real-time Alerts</h4>
                    <div className="space-y-1 text-xs">
                      <div className="flex items-center justify-between">
                        <span>Critical</span>
                        <span className="bg-red-500 text-white px-2 py-1 rounded">0</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Important</span>
                        <span className="bg-orange-500 text-white px-2 py-1 rounded">1</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Medium</span>
                        <span className="bg-yellow-500 text-black px-2 py-1 rounded">2</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Informative</span>
                        <span className="bg-blue-500 text-white px-2 py-1 rounded">5</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* RBAC Actions */}
            <div className="mt-6 flex space-x-4">
              <button
                onClick={() => {
                  alert('RBAC system test launched!\n\n Admin → Sub-Admin delegation\n Dev permissions validated\n Audit access restricted\n Support limited confirmed\n\n RBAC system operational');
                }}
                className="flex-1 bg-yellow-500 hover:bg-yellow-600 text-black py-3 rounded-lg font-medium transition-colors"
              >
                <i className="ri-shield-check-line mr-2"></i>
                Test RBAC
              </button>
              <button
                onClick={() => {
                  alert('RBAC configuration applied!\n\n Role matrix updated\n Permissions synchronized\n Delegations activated\n MFA/SSO configured\n\n System secured');
                }}
                className="flex-1 bg-blue-500 hover:bg-blue-600 text-white py-3 rounded-lg font-medium transition-colors"
              >
                <i className="ri-settings-3-line mr-2"></i>
                Apply Config
              </button>
              <button
                onClick={() => {
                  const rbacData = {
                    roles: ['Admin', 'Dev', 'Audit', 'Support'],
                    permissions: 'Matrix configured',
                    mfa: 'Enabled on all services',
                    audit: 'JSON/CSV export available',
                    alerts: '4 levels configured'
                  };
                  alert(`RBAC & Compliance Report:\n\n Roles: ${rbacData.roles.join(', ')}\n MFA/SSO: ${rbacData.mfa}\n Audit: ${rbacData.audit}\n Alerts: ${rbacData.alerts}\n\n Compliance: 96.8%`);
                }}
                className="bg-green-500 hover:bg-green-600 text-white py-3 px-6 rounded-lg font-medium transition-colors"
              >
                <i className="ri-file-chart-line mr-2"></i>
                RBAC Report
              </button>
            </div>
          </div>

          {/* Security Documentation Generator */}
          <div className="mt-8 bg-gray-900 rounded-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold flex items-center">
                <i className="ri-code-s-slash-line text-purple-400 mr-2"></i>
                Security & Compliance Documentation Generator
              </h2>
              <div className="flex space-x-2">
                <button
                  onClick={() => {
                    alert('Documentation generated successfully!\n\n RBAC with role delegation\n MFA/SSO on Git and consoles\n Granular version control\n Commit audit with exports\n Non-compliance alerts\n\n File: security-compliance-doc.md');
                  }}
                  className="px-4 py-2 bg-purple-500 hover:bg-purple-600 text-white rounded font-medium transition-colors"
                >
                  <i className="ri-download-line mr-2"></i>
                  Download Script
                </button>
              </div>
            </div>

            <div className="bg-black rounded-lg p-4 overflow-x-auto text-sm font-mono">
              <div className="text-green-400 mb-2">// Node.js Script - Security & Compliance Documentation Generator</div>
              <div className="text-gray-300">
                <span className="text-blue-400">const</span> SecurityDocumentationGenerator = {'{'}
                <div className="ml-4 text-gray-400">// RBAC management with role delegation</div>
                <div className="ml-4 text-gray-400">// MFA/SSO on Git repositories and consoles</div>
                <div className="ml-4 text-gray-400">// Granular version control</div>
                <div className="ml-4 text-gray-400">// Commit audit with exports</div>
                <div className="ml-4 text-gray-400">// Non-compliance alerts</div>
                <div className="ml-4">
                  <span className="text-yellow-400">generateCompleteDocument</span>() {'{'}
                  <div className="ml-4 text-gray-400">// Generates complete Markdown documentation</div>
                  <div className="ml-4">
                    <span className="text-blue-400">return</span> markdown;
                  </div>
                  {'}'}
                </div>
                {'}'}
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4 mb-4">
              <div className="bg-gray-800 p-4 rounded-lg">
                <h4 className="font-semibold text-green-400 mb-2">
                  <i className="ri-shield-check-line mr-2"></i>
                  Included Features
                </h4>
                <ul className="text-sm text-gray-300 space-y-1">
                  <li>• RBAC management with delegation matrix</li>
                  <li>• Complete MFA/SSO configuration</li>
                  <li>• Automated branch protection rules</li>
                  <li>• Audit trails with JSON/CSV exports</li>
                  <li>• Real-time alert system</li>
                  <li>• Compliance dashboard</li>
                </ul>
              </div>

              <div className="bg-gray-800 p-4 rounded-lg">
                <h4 className="font-semibold text-blue-400 mb-2">
                  <i className="ri-terminal-line mr-2"></i>
                  Available Commands
                </h4>
                <div className="text-sm font-mono text-gray-300 space-y-1">
                  <div className="text-yellow-400">npm run audit:full</div>
                  <div className="text-yellow-400">npm run export:json</div>
                  <div className="text-yellow-400">npm run export:csv</div>
                  <div className="text-yellow-400">npm run test:alerts</div>
                  <div className="text-yellow-400">npm run compliance-report</div>
                </div>
              </div>
            </div>

            <div className="flex space-x-4">
              <button
                onClick={() => {
                  alert('Documentation generated successfully!\n\n RBAC with role delegation\n MFA/SSO on Git and consoles\n Granular version control\n Commit audit with exports\n Non-compliance alerts\n\n File: security-compliance-doc.md');
                }}
                className="flex-1 bg-green-500 hover:bg-green-600 text-white py-3 rounded-lg font-medium transition-colors"
              >
                <i className="ri-play-line mr-2"></i>
                Generate Documentation
              </button>
              <button
                onClick={() => {
                  alert('Alert system test launched!\n\n Critical alerts: 0\n Important alerts: 1\n Medium alerts: 2\n Info alerts: 5\n\n System operational');
                }}
                className="flex-1 bg-orange-500 hover:bg-orange-600 text-white py-3 rounded-lg font-medium transition-colors"
              >
                <i className="ri-alert-line mr-2"></i>
                Test Alerts
              </button>
              <button
                onClick={() => {
                  const reportData = {
                    compliance: '94.2%',
                    criticalIssues: 0,
                    resolvedThisWeek: 8,
                    pendingReviews: 3,
                    securityScore: '97.1%'
                  };
                  alert(`Compliance Report Generated:\n\n Global Compliance: ${reportData.compliance}\n Critical Issues: ${reportData.criticalIssues}\n Resolved This Week: ${reportData.resolvedThisWeek}\n Pending Reviews: ${reportData.pendingReviews}\n Security Score: ${reportData.securityScore}`);
                }}
                className="bg-blue-500 hover:bg-blue-600 text-white py-3 px-6 rounded-lg font-medium transition-colors"
              >
                <i className="ri-file-chart-line mr-2"></i>
                Report
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
