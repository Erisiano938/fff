'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    totalUsers: 2847,
    activeClients: 1923,
    monthlyRevenue: 485000,
    newSignups: 156
  });

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Tableau de Bord Admin</h1>
          <p className="text-gray-600">Vue d'ensemble de la plateforme</p>
        </div>
        <div className="flex items-center space-x-4">
          <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm transition-colors cursor-pointer">
            <i className="ri-refresh-line mr-2"></i>
            Actualiser
          </button>
          <Link
            href="/admin/unified-dashboard"
            className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-sm transition-colors cursor-pointer"
          >
            <i className="ri-dashboard-line mr-2"></i>
            Centre de Contrôle
          </Link>
        </div>
      </div>

      {/* Statistiques principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <i className="ri-user-line text-2xl text-blue-600"></i>
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Utilisateurs Total</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalUsers.toLocaleString()}</p>
            </div>
          </div>
          <div className="mt-4">
            <span className="text-green-600 text-sm font-medium">+12.5%</span>
            <span className="text-gray-600 text-sm ml-2">vs mois dernier</span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <i className="ri-user-star-line text-2xl text-green-600"></i>
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Clients Actifs</p>
              <p className="text-2xl font-bold text-gray-900">{stats.activeClients.toLocaleString()}</p>
            </div>
          </div>
          <div className="mt-4">
            <span className="text-green-600 text-sm font-medium">+8.2%</span>
            <span className="text-gray-600 text-sm ml-2">vs mois dernier</span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
              <i className="ri-money-euro-circle-line text-2xl text-yellow-600"></i>
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Revenus Mensuels</p>
              <p className="text-2xl font-bold text-gray-900">{stats.monthlyRevenue.toLocaleString()} €</p>
            </div>
          </div>
          <div className="mt-4">
            <span className="text-green-600 text-sm font-medium">+15.3%</span>
            <span className="text-gray-600 text-sm ml-2">vs mois dernier</span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <i className="ri-user-add-line text-2xl text-purple-600"></i>
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Nouvelles Inscriptions</p>
              <p className="text-2xl font-bold text-gray-900">{stats.newSignups}</p>
            </div>
          </div>
          <div className="mt-4">
            <span className="text-green-600 text-sm font-medium">+22.1%</span>
            <span className="text-gray-600 text-sm ml-2">vs mois dernier</span>
          </div>
        </div>
      </div>

      {/* Actions rapides */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Actions Rapides</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Link
            href="/admin/user-management"
            className="flex flex-col items-center p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors cursor-pointer"
          >
            <i className="ri-user-settings-line text-2xl text-blue-600 mb-2"></i>
            <span className="text-sm font-medium text-gray-900">Gestion Utilisateurs</span>
          </Link>

          <Link
            href="/admin/crm-client"
            className="flex flex-col items-center p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors cursor-pointer"
          >
            <i className="ri-contacts-line text-2xl text-green-600 mb-2"></i>
            <span className="text-sm font-medium text-gray-900">CRM Client</span>
          </Link>

          <Link
            href="/admin/academy-manager"
            className="flex flex-col items-center p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors cursor-pointer"
          >
            <i className="ri-book-line text-2xl text-purple-600 mb-2"></i>
            <span className="text-sm font-medium text-gray-900">Académie</span>
          </Link>

          <Link
            href="/admin/settings"
            className="flex flex-col items-center p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors cursor-pointer"
          >
            <i className="ri-settings-line text-2xl text-gray-600 mb-2"></i>
            <span className="text-sm font-medium text-gray-900">Paramètres</span>
          </Link>
        </div>
      </div>

      {/* Activité récente */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Activité Récente</h3>
          <div className="space-y-4">
            <div className="flex items-center p-3 bg-blue-50 rounded-lg">
              <i className="ri-user-add-line text-blue-600 mr-3"></i>
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-900">Nouvel utilisateur inscrit</p>
                <p className="text-xs text-gray-600">Sophie Martin - il y a 5 min</p>
              </div>
            </div>

            <div className="flex items-center p-3 bg-green-50 rounded-lg">
              <i className="ri-money-dollar-circle-line text-green-600 mr-3"></i>
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-900">Paiement reçu</p>
                <p className="text-xs text-gray-600">Plan Premium - 299€ - il y a 12 min</p>
              </div>
            </div>

            <div className="flex items-center p-3 bg-purple-50 rounded-lg">
              <i className="ri-article-line text-purple-600 mr-3"></i>
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-900">Nouvel article publié</p>
                <p className="text-xs text-gray-600">Guide Trading - il y a 1h</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Tâches Prioritaires</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
              <div className="flex items-center">
                <i className="ri-alert-line text-red-600 mr-3"></i>
                <div>
                  <p className="text-sm font-medium text-gray-900">Révision sécurité</p>
                  <p className="text-xs text-gray-600">Urgent - À faire aujourd'hui</p>
                </div>
              </div>
              <span className="text-red-600 text-xs font-medium">URGENT</span>
            </div>

            <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
              <div className="flex items-center">
                <i className="ri-file-text-line text-yellow-600 mr-3"></i>
                <div>
                  <p className="text-sm font-medium text-gray-900">Rapport mensuel</p>
                  <p className="text-xs text-gray-600">Échéance dans 2 jours</p>
                </div>
              </div>
              <span className="text-yellow-600 text-xs font-medium">IMPORTANT</span>
            </div>

            <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
              <div className="flex items-center">
                <i className="ri-mail-line text-blue-600 mr-3"></i>
                <div>
                  <p className="text-sm font-medium text-gray-900">Newsletter hebdomadaire</p>
                  <p className="text-xs text-gray-600">Programmée pour demain</p>
                </div>
              </div>
              <span className="text-blue-600 text-xs font-medium">NORMAL</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}