
'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { isAuthenticated } from '../../lib/auth';

export default function PortfolioEditor() {
  const [authenticated, setAuthenticated] = useState(false);
  const [activeTab, setActiveTab] = useState('allocation');
  const [portfolioConfig, setPortfolioConfig] = useState({
    allocations: [
      { id: 1, name: 'Actions', percentage: 45, value: 57395, color: '#EAB308', icon: 'ri-line-chart-line' },
      { id: 2, name: 'Obligations', percentage: 25, value: 31886, color: '#3B82F6', icon: 'ri-money-dollar-circle-line' },
      { id: 3, name: 'ETF', percentage: 20, value: 25509, color: '#10B981', icon: 'ri-fund-line' },
      { id: 4, name: 'Crypto', percentage: 7, value: 8928, color: '#8B5CF6', icon: 'ri-bit-coin-line' },
      { id: 5, name: 'Cash', percentage: 3, value: 3826, color: '#6B7280', icon: 'ri-wallet-line' }
    ],
    totalPortfolio: 127544,
    displaySettings: {
      showPercentages: true,
      showValues: true,
      showProgress: true,
      animateProgress: true,
      cardStyle: 'modern',
      chartType: 'donut'
    },
    colors: {
      primary: '#EAB308',
      secondary: '#1F2937',
      background: '#111827',
      text: '#FFFFFF',
      accent: '#3B82F6'
    }
  });
  const [editingAllocation, setEditingAllocation] = useState(null);
  const [showColorPicker, setShowColorPicker] = useState(null);
  const router = useRouter();

  // Fonction pour synchroniser automatiquement les calculs
  const synchronizePortfolio = (config) => {
    const totalValue = config.totalPortfolio;
    let syncedAllocations = [...config.allocations];

    // Recalculer toutes les valeurs basées sur les pourcentages
    syncedAllocations = syncedAllocations.map(alloc => ({ ...alloc, value: Math.round((totalValue * alloc.percentage) / 100) }));

    // Vérifier et corriger la somme totale pour les erreurs d'arrondi
    const calculatedTotal = syncedAllocations.reduce((sum, alloc) => sum + alloc.value, 0);
    const difference = totalValue - calculatedTotal;

    if (difference !== 0 && syncedAllocations.length > 0) {
      // Ajuster la plus grande allocation pour compenser l'erreur d'arrondi
      const largestIndex = syncedAllocations.reduce((maxIndex, current, index, array) => current.value > array[maxIndex].value ? index : maxIndex, 0);
      syncedAllocations[largestIndex].value += difference;
    }

    return { ...config, allocations: syncedAllocations };
  };

  useEffect(() => {
    if (!isAuthenticated()) {
      router.push('/admin/login');
      return;
    }
    setAuthenticated(true);
    loadPortfolioConfig();
  }, [router]);

  const loadPortfolioConfig = () => {
    const saved = localStorage.getItem('portfolio_config');
    if (saved) {
      const loadedConfig = { ...portfolioConfig, ...JSON.parse(saved) };
      setPortfolioConfig(synchronizePortfolio(loadedConfig));
    }
  };

  const savePortfolioConfig = () => {
    const syncedConfig = synchronizePortfolio(portfolioConfig);
    localStorage.setItem('portfolio_config', JSON.stringify(syncedConfig));
    localStorage.setItem('dashboard_portfolio_updated', Date.now().toString());
    setPortfolioConfig(syncedConfig);
    alert('Configuration sauvegardée avec succès!');
  };

  const addAllocation = () => {
    const newId = Math.max(...portfolioConfig.allocations.map(a => a.id)) + 1;
    const newAllocation = {
      id: newId,
      name: 'Nouvel Actif',
      percentage: 0,
      value: 0,
      color: '#6B7280',
      icon: 'ri-question-line'
    };
    const updatedConfig = {
      ...portfolioConfig,
      allocations: [...portfolioConfig.allocations, newAllocation]
    };
    setPortfolioConfig(synchronizePortfolio(updatedConfig));
    setEditingAllocation(newId);
  };

  const updateAllocation = (id, field, value) => {
    const updated = portfolioConfig.allocations.map(allocation => {
      if (allocation.id === id) {
        const updatedAllocation = { ...allocation, [field]: value };

        // Synchroniser automatiquement les valeurs liées
        if (field === 'percentage') {
          updatedAllocation.value = Math.round((portfolioConfig.totalPortfolio * value) / 100);
        } else if (field === 'value') {
          updatedAllocation.percentage = parseFloat(((value / portfolioConfig.totalPortfolio) * 100).toFixed(2));
        }

        return updatedAllocation;
      }
      return allocation;
    });

    const updatedConfig = { ...portfolioConfig, allocations: updated };
    setPortfolioConfig(synchronizePortfolio(updatedConfig));
  };

  const updateTotalPortfolio = (newTotal) => {
    const updatedConfig = {
      ...portfolioConfig,
      totalPortfolio: newTotal,
      allocations: portfolioConfig.allocations.map(alloc => ({ ...alloc, value: Math.round((newTotal * alloc.percentage) / 100) }))
    };
    setPortfolioConfig(synchronizePortfolio(updatedConfig));
  };

  const deleteAllocation = (id) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer cet actif ?')) {
      const updatedConfig = {
        ...portfolioConfig,
        allocations: portfolioConfig.allocations.filter(a => a.id !== id)
      };
      setPortfolioConfig(synchronizePortfolio(updatedConfig));
    }
  };

  const rebalancePortfolio = () => {
    const totalPercentage = portfolioConfig.allocations.reduce((sum, a) => sum + a.percentage, 0);
    if (totalPercentage !== 100) {
      const factor = 100 / totalPercentage;
      const rebalanced = portfolioConfig.allocations.map(allocation => ({
        ...allocation,
        percentage: parseFloat((allocation.percentage * factor).toFixed(2)),
        value: Math.round((portfolioConfig.totalPortfolio * allocation.percentage * factor) / 100)
      }));
      const updatedConfig = { ...portfolioConfig, allocations: rebalanced };
      setPortfolioConfig(synchronizePortfolio(updatedConfig));
    }
  };

  // Calculs de vérification en temps réel
  const getTotalPercentage = () => {
    return portfolioConfig.allocations.reduce((sum, a) => sum + a.percentage, 0);
  };

  const getTotalValue = () => {
    return portfolioConfig.allocations.reduce((sum, a) => sum + a.value, 0);
  };

  const getValueDiscrepancy = () => {
    return Math.abs(getTotalValue() - portfolioConfig.totalPortfolio);
  };

  const getPercentageDiscrepancy = () => {
    return Math.abs(getTotalPercentage() - 100);
  };

  const presetColors = [
    '#EAB308', '#3B82F6', '#10B981', '#8B5CF6', '#F59E0B', '#EF4444',
    '#06B6D4', '#84CC16', '#F97316', '#EC4899', '#6366F1', '#14B8A6'
  ];

  const iconOptions = [
    'ri-line-chart-line', 'ri-money-dollar-circle-line', 'ri-fund-line', 'ri-bit-coin-line',
    'ri-wallet-line', 'ri-bank-line', 'ri-home-line', 'ri-car-line', 'ri-trophy-line',
    'ri-shield-line', 'ri-plant-line', 'ri-global-line', 'ri-building-line'
  ];

  if (!authenticated) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-yellow-500 mx-auto mb-4"></div>
          <p className="text-white">Chargement de l'éditeur...</p>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'allocation', name: 'Répartition', icon: 'ri-pie-chart-line' },
    { id: 'design', name: 'Design', icon: 'ri-palette-line' },
    { id: 'preview', name: 'Aperçu', icon: 'ri-eye-line' }
  ];

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Link
              href="/admin/dashboard"
              className="flex items-center text-gray-400 hover:text-white transition-colors cursor-pointer"
            >
              <i className="ri-arrow-left-line mr-2"></i>
              Retour
            </Link>
            <h1 className="text-3xl font-bold">Éditeur de Portefeuille</h1>
          </div>
          <div className="flex space-x-4">
            <button
              onClick={rebalancePortfolio}
              className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
            >
              <i className="ri-scales-line mr-2"></i>
              Rééquilibrer
            </button>
            <button
              onClick={savePortfolioConfig}
              className="bg-yellow-500 hover:bg-yellow-600 text-black px-6 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
            >
              <i className="ri-save-line mr-2"></i>
              Sauvegarder
            </button>
          </div>
        </div>

        <div className="flex space-x-8">
          {/* Navigation */}
          <div className="w-64">
            <nav className="space-y-2">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors whitespace-nowrap cursor-pointer ${
                    activeTab === tab.id
                      ? 'bg-yellow-500 text-black'
                      : 'text-gray-400 hover:text-white hover:bg-gray-800'
                  }`}
                >
                  <i className={tab.icon}></i>
                  <span>{tab.name}</span>
                </button>
              ))}
            </nav>

            <div className="mt-8 bg-gray-900 p-4 rounded-xl border border-yellow-500/20">
              <h3 className="font-semibold mb-3">Vérification des Totaux</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">Valeur configurée:</span>
                  <span className="text-white font-medium">€{portfolioConfig.totalPortfolio.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Valeur calculée:</span>
                  <span className={`font-medium ${getValueDiscrepancy() < 1 ? 'text-green-400' : 'text-orange-400'}`}>
                    €{getTotalValue().toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Pourcentage total:</span>
                  <span className={`font-medium ${getPercentageDiscrepancy() < 0.1 ? 'text-green-400' : 'text-red-400'}`}>
                    {getTotalPercentage().toFixed(1)}%
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Nombre d'actifs:</span>
                  <span className="text-white font-medium">{portfolioConfig.allocations.length}</span>
                </div>

                {/* Alertes */}
                {getValueDiscrepancy() >= 1 && (
                  <div className="mt-3 p-2 bg-orange-500/20 rounded text-xs text-orange-300">
                    <i className="ri-error-warning-line mr-1"></i>
                    Écart de valeur: €{getValueDiscrepancy().toLocaleString()}
                  </div>
                )}

                {getPercentageDiscrepancy() >= 0.1 && (
                  <div className="mt-3 p-2 bg-red-500/20 rounded text-xs text-red-300">
                    <i className="ri-alert-line mr-1"></i>
                    Écart de %: {getPercentageDiscrepancy().toFixed(2)}%
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Contenu */}
          <div className="flex-1">
            {activeTab === 'allocation' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold">Gestion des Actifs</h2>
                  <div className="flex space-x-4">
                    <div className="flex items-center space-x-2">
                      <label className="text-sm text-gray-400">Valeur totale (€):</label>
                      <input
                        type="number"
                        value={portfolioConfig.totalPortfolio}
                        onChange={(e) => updateTotalPortfolio(parseFloat(e.target.value) || 0)}
                        className="w-32 p-2 bg-gray-800 border border-gray-700 rounded text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                    <button
                      onClick={addAllocation}
                      className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
                    >
                      <i className="ri-add-line mr-2"></i>
                      Ajouter Actif
                    </button>
                  </div>
                </div>

                <div className="grid gap-6">
                  {portfolioConfig.allocations.map((allocation) => (
                    <div key={allocation.id} className="bg-gray-900 p-6 rounded-xl border border-yellow-500/20">
                      <div className="flex items-center space-x-6">
                        <div className="flex items-center space-x-4 flex-1">
                          <div
                            className="w-12 h-12 rounded-lg flex items-center justify-center cursor-pointer"
                            style={{ backgroundColor: allocation.color + '20' }}
                            onClick={() => setShowColorPicker(allocation.id)}
                          >
                            <i className={`${allocation.icon} text-2xl`} style={{ color: allocation.color }}></i>
                          </div>

                          <div className="flex-1 space-y-2">
                            <input
                              type="text"
                              value={allocation.name}
                              onChange={(e) => updateAllocation(allocation.id, 'name', e.target.value)}
                              className="text-xl font-bold bg-transparent border-b border-transparent focus:border-yellow-500 focus:outline-none text-white w-full"
                            />

                            <div className="grid grid-cols-3 gap-4">
                              <div>
                                <label className="block text-xs text-gray-400 mb-1">Pourcentage</label>
                                <div className="flex items-center space-x-2">
                                  <input
                                    type="number"
                                    value={allocation.percentage}
                                    onChange={(e) => updateAllocation(allocation.id, 'percentage', parseFloat(e.target.value) || 0)}
                                    className="w-full p-2 bg-gray-800 border border-gray-700 rounded text-white text-sm focus:border-yellow-500 focus:outline-none"
                                    step="0.1"
                                    min="0"
                                    max="100"
                                  />
                                  <span className="text-gray-400">%</span>
                                </div>
                              </div>

                              <div>
                                <label className="block text-xs text-gray-400 mb-1">Valeur (€)</label>
                                <input
                                  type="number"
                                  value={allocation.value}
                                  onChange={(e) => updateAllocation(allocation.id, 'value', parseFloat(e.target.value) || 0)}
                                  className="w-full p-2 bg-gray-800 border border-gray-700 rounded text-white text-sm focus:border-yellow-500 focus:outline_none"
                                />
                              </div>

                              <div>
                                <label className="block text-xs text-gray-400 mb-1">Icône</label>
                                <select
                                  value={allocation.icon}
                                  onChange={(e) => updateAllocation(allocation.id, 'icon', e.target.value)}
                                  className="w-full p-2 bg-gray-800 border border-gray-700 rounded text-white text-sm focus:border-yellow-500 focus:outline-none pr-8"
                                >
                                  {iconOptions.map(icon => (
                                    <option key={icon} value={icon}>{icon.replace('ri-', '').replace('-', ' ')}</option>
                                  ))}
                                </select>
                              </div>
                            </div>

                            {/* Indicateurs de cohérence */}
                            <div className="flex justify-between text-xs text-gray-500 mt-2">
                              <div>
                                Calculé: {((allocation.value / portfolioConfig.totalPortfolio) * 100).toFixed(2)}%
                              </div>
                              <div>
                                Théorique: €{Math.round((portfolioConfig.totalPortfolio * allocation.percentage) / 100).toLocaleString()}
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="flex flex-col space-y-2">
                          <button
                            onClick={() => deleteAllocation(allocation.id)}
                            className="text-red-400 hover:text-red-300 p-2 rounded hover:bg-red-500/10 transition-colors cursor-pointer"
                          >
                            <i className="ri-delete-bin-line"></i>
                          </button>
                        </div>
                      </div>

                      {/* Color Picker */}
                      {showColorPicker === allocation.id && (
                        <div className="mt-4 p-4 bg-gray-800 rounded-lg">
                          <div className="flex items-center justify-between mb-3">
                            <span className="text-sm font-medium">Choisir une couleur</span>
                            <button
                              onClick={() => setShowColorPicker(null)}
                              className="text-gray-400 hover:text-white cursor-pointer"
                            >
                              <i className="ri-close-line"></i>
                            </button>
                          </div>
                          <div className="grid grid-cols-6 gap-2 mb-3">
                            {presetColors.map(color => (
                              <button
                                key={color}
                                onClick={() => {
                                  updateAllocation(allocation.id, 'color', color);
                                  setShowColorPicker(null);
                                }}
                                className="w-8 h-8 rounded cursor-pointer border-2 border-transparent hover:border-white"
                                style={{ backgroundColor: color }}
                              />
                            ))}
                          </div>
                          <input
                            type="color"
                            value={allocation.color}
                            onChange={(e) => updateAllocation(allocation.id, 'color', e.target.value)}
                            className="w-full h-10 rounded cursor-pointer"
                          />
                        </div>
                      )}

                      {/* Progress Bar */}
                      <div className="mt-4">
                        <div className="w-full bg-gray-800 rounded-full h-2">
                          <div
                            className="h-2 rounded-full transition-all duration-300"
                            style={{
                              width: `${allocation.percentage}%`,
                              backgroundColor: allocation.color
                            }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'design' && (
              <div className="space-y-8">
                <h2 className="text-2xl font-bold">Personnalisation du Design</h2>

                <div className="grid md:grid-cols-2 gap-8">
                  <div className="bg-gray-900 p-6 rounded-xl border border-yellow-500/20">
                    <h3 className="text-xl font-bold mb-4">Options d'Affichage</h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span>Afficher les pourcentages</span>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={portfolioConfig.displaySettings.showPercentages}
                            onChange={(e) => setPortfolioConfig({
                              ...portfolioConfig,
                              displaySettings: {
                                ...portfolioConfig.displaySettings,
                                showPercentages: e.target.checked
                              }
                            })}
                            className="sr-only peer"
                          />
                          <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-yellow-500"></div>
                        </label>
                      </div>

                      <div className="flex items-center justify-between">
                        <span>Afficher les valeurs</span>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={portfolioConfig.displaySettings.showValues}
                            onChange={(e) => setPortfolioConfig({
                              ...portfolioConfig,
                              displaySettings: {
                                ...portfolioConfig.displaySettings,
                                showValues: e.target.checked
                              }
                            })}
                            className="sr-only peer"
                          />
                          <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-yellow-500"></div>
                        </label>
                      </div>

                      <div className="flex items-center justify-between">
                        <span>Barres de progression</span>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={portfolioConfig.displaySettings.showProgress}
                            onChange={(e) => setPortfolioConfig({
                              ...portfolioConfig,
                              displaySettings: {
                                ...portfolioConfig.displaySettings,
                                showProgress: e.target.checked
                              }
                            })}
                            className="sr-only peer"
                          />
                          <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-yellow-500"></div>
                        </label>
                      </div>

                      <div className="flex items-center justify-between">
                        <span>Animations</span>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={portfolioConfig.displaySettings.animateProgress}
                            onChange={(e) => setPortfolioConfig({
                              ...portfolioConfig,
                              displaySettings: {
                                ...portfolioConfig.displaySettings,
                                animateProgress: e.target.checked
                              }
                            })}
                            className="sr-only peer"
                          />
                          <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-yellow-500"></div>
                        </label>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-900 p-6 rounded-xl border border-yellow-500/20">
                    <h3 className="text-xl font-bold mb-4">Couleurs du Thème</h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium mb-2">Couleur principale</label>
                        <div className="flex items-center space-x-3">
                          <input
                            type="color"
                            value={portfolioConfig.colors.primary}
                            onChange={(e) => setPortfolioConfig({
                              ...portfolioConfig,
                              colors: {
                                ...portfolioConfig.colors,
                                primary: e.target.value
                              }
                            })}
                            className="w-12 h-12 rounded cursor-pointer"
                          />
                          <input
                            type="text"
                            value={portfolioConfig.colors.primary}
                            onChange={(e) => setPortfolioConfig({
                              ...portfolioConfig,
                              colors: {
                                ...portfolioConfig.colors,
                                primary: e.target.value
                              }
                            })}
                            className="flex-1 p-2 bg-gray-800 border border-gray-700 rounded text-white text-sm focus:border-yellow-500 focus:outline-none"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">Couleur d'accent</label>
                        <div className="flex items-center space-x-3">
                          <input
                            type="color"
                            value={portfolioConfig.colors.accent}
                            onChange={(e) => setPortfolioConfig({
                              ...portfolioConfig,
                              colors: {
                                ...portfolioConfig.colors,
                                accent: e.target.value
                              }
                            })}
                            className="w-12 h-12 rounded cursor-pointer"
                          />
                          <input
                            type="text"
                            value={portfolioConfig.colors.accent}
                            onChange={(e) => setPortfolioConfig({
                              ...portfolioConfig,
                              colors: {
                                ...portfolioConfig.colors,
                                accent: e.target.value
                              }
                            })}
                            className="flex-1 p-2 bg-gray-800 border border-gray-700 rounded text-white text-sm focus:border-yellow-500 focus:outline-none"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">Arrière-plan</label>
                        <div className="flex items-center space-x-3">
                          <input
                            type="color"
                            value={portfolioConfig.colors.background}
                            onChange={(e) => setPortfolioConfig({
                              ...portfolioConfig,
                              colors: {
                                ...portfolioConfig.colors,
                                background: e.target.value
                              }
                            })}
                            className="w-12 h-12 rounded cursor-pointer"
                          />
                          <input
                            type="text"
                            value={portfolioConfig.colors.background}
                            onChange={(e) => setPortfolioConfig({
                              ...portfolioConfig,
                              colors: {
                                ...portfolioConfig.colors,
                                background: e.target.value
                              }
                            })}
                            className="flex-1 p-2 bg-gray-800 border border-gray-700 rounded text-white text-sm focus:border-yellow-500 focus:outline-none"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'preview' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold">Aperçu du Portefeuille</h2>

                <div
                  className="rounded-xl p-6 border"
                  style={{
                    backgroundColor: portfolioConfig.colors.background,
                    borderColor: portfolioConfig.colors.primary + '33'
                  }}
                >
                  <h3 className="text-xl font-bold mb-6" style={{ color: portfolioConfig.colors.text }}>
                    Répartition des Actifs
                  </h3>

                  <div className="space-y-4">
                    {portfolioConfig.allocations.map((allocation) => (
                      <div key={allocation.id} className="space-y-2">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center space-x-3">
                            <div
                              className="w-6 h-6 rounded flex items-center justify-center"
                              style={{ backgroundColor: allocation.color + '20' }}
                            >
                              <i className={`${allocation.icon} text-sm`} style={{ color: allocation.color }}></i>
                            </div>
                            <span style={{ color: portfolioConfig.colors.text }} className="font-medium">
                              {allocation.name}
                            </span>
                          </div>
                          <div className="flex items-center space-x-4 text-sm">
                            {portfolioConfig.displaySettings.showPercentages && (
                              <span style={{ color: portfolioConfig.colors.text + 'CC' }}>
                                {allocation.percentage}%
                              </span>
                            )}
                            {portfolioConfig.displaySettings.showValues && (
                              <span style={{ color: portfolioConfig.colors.text + 'CC' }}>
                                €{allocation.value.toLocaleString()}
                              </span>
                            )}
                          </div>
                        </div>

                        {portfolioConfig.displaySettings.showProgress && (
                          <div className="w-full bg-gray-800 rounded-full h-2">
                            <div
                              className={`h-2 rounded-full ${portfolioConfig.displaySettings.animateProgress ? 'transition-all duration-300' : ''}`}
                              style={{
                                width: `${allocation.percentage}%`,
                                backgroundColor: allocation.color
                              }}
                            />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>

                  <div className="mt-6 pt-4" style={{ borderTop: `1px solid ${portfolioConfig.colors.primary}33` }}>
                    <button
                      className="w-full py-2 rounded-lg font-medium transition-colors cursor-pointer whitespace-nowrap"
                      style={{
                        backgroundColor: portfolioConfig.colors.primary + '33',
                        color: portfolioConfig.colors.primary
                      }}
                    >
                      En savoir plus
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
