'use client';

import { useState, useEffect } from 'react';

export default function PropertiesPanel({ selectedElement, onUpdate }) {
  const [properties, setProperties] = useState({});

  useEffect(() => {
    if (selectedElement) {
      setProperties(selectedElement.properties || {});
    }
  }, [selectedElement]);

  const handlePropertyChange = (key, value) => {
    const newProperties = { ...properties, [key]: value };
    setProperties(newProperties);
    
    if (onUpdate && selectedElement) {
      onUpdate(selectedElement.id, newProperties);
    }
  };

  if (!selectedElement) {
    return (
      <div className="h-full p-4">
        <div className="text-center text-gray-400 mt-8">
          <i className="ri-cursor-line text-4xl mb-4"></i>
          <p>Sélectionnez un élément pour modifier ses propriétés</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-gray-700">
        <h2 className="text-lg font-semibold text-white mb-2">Propriétés</h2>
        <div className="flex items-center text-sm text-gray-400">
          <i className="ri-focus-3-line mr-2"></i>
          {selectedElement.type} #{selectedElement.id.slice(-6)}
        </div>
      </div>

      {/* Propriétés */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        
        {/* Propriétés communes */}
        <div className="space-y-3">
          <h3 className="text-sm font-medium text-gray-300 uppercase tracking-wide">Position & Taille</h3>
          
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs text-gray-400 mb-1">X</label>
              <input
                type="number"
                value={selectedElement.x || 0}
                onChange={(e) => handlePropertyChange('x', Number(e.target.value))}
                className="w-full bg-gray-700 border border-gray-600 rounded px-2 py-1 text-sm text-white"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Y</label>
              <input
                type="number"
                value={selectedElement.y || 0}
                onChange={(e) => handlePropertyChange('y', Number(e.target.value))}
                className="w-full bg-gray-700 border border-gray-600 rounded px-2 py-1 text-sm text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs text-gray-400 mb-1">Largeur</label>
              <input
                type="number"
                value={selectedElement.width || 0}
                onChange={(e) => handlePropertyChange('width', Number(e.target.value))}
                className="w-full bg-gray-700 border border-gray-600 rounded px-2 py-1 text-sm text-white"
              />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Hauteur</label>
              <input
                type="number"
                value={selectedElement.height || 0}
                onChange={(e) => handlePropertyChange('height', Number(e.target.value))}
                className="w-full bg-gray-700 border border-gray-600 rounded px-2 py-1 text-sm text-white"
              />
            </div>
          </div>
        </div>

        {/* Propriétés spécifiques au type */}
        {selectedElement.type === 'text' && (
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-gray-300 uppercase tracking-wide">Texte</h3>
            
            <div>
              <label className="block text-xs text-gray-400 mb-1">Contenu</label>
              <textarea
                value={properties.content || ''}
                onChange={(e) => handlePropertyChange('content', e.target.value)}
                rows={3}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-sm text-white resize-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs text-gray-400 mb-1">Taille</label>
                <select
                  value={properties.fontSize || '16px'}
                  onChange={(e) => handlePropertyChange('fontSize', e.target.value)}
                  className="w-full bg-gray-700 border border-gray-600 rounded px-2 py-1 text-sm text-white"
                >
                  <option value="12px">12px</option>
                  <option value="14px">14px</option>
                  <option value="16px">16px</option>
                  <option value="18px">18px</option>
                  <option value="20px">20px</option>
                  <option value="24px">24px</option>
                  <option value="32px">32px</option>
                  <option value="48px">48px</option>
                </select>
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1">Poids</label>
                <select
                  value={properties.fontWeight || 'normal'}
                  onChange={(e) => handlePropertyChange('fontWeight', e.target.value)}
                  className="w-full bg-gray-700 border border-gray-600 rounded px-2 py-1 text-sm text-white"
                >
                  <option value="normal">Normal</option>
                  <option value="bold">Gras</option>
                  <option value="lighter">Léger</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs text-gray-400 mb-1">Couleur</label>
              <input
                type="color"
                value={properties.color || '#000000'}
                onChange={(e) => handlePropertyChange('color', e.target.value)}
                className="w-full h-8 bg-gray-700 border border-gray-600 rounded"
              />
            </div>
          </div>
        )}

        {selectedElement.type === 'button' && (
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-gray-300 uppercase tracking-wide">Bouton</h3>
            
            <div>
              <label className="block text-xs text-gray-400 mb-1">Texte</label>
              <input
                type="text"
                value={properties.content || ''}
                onChange={(e) => handlePropertyChange('content', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-sm text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs text-gray-400 mb-1">Fond</label>
                <input
                  type="color"
                  value={properties.backgroundColor || '#3b82f6'}
                  onChange={(e) => handlePropertyChange('backgroundColor', e.target.value)}
                  className="w-full h-8 bg-gray-700 border border-gray-600 rounded"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1">Texte</label>
                <input
                  type="color"
                  value={properties.color || '#ffffff'}
                  onChange={(e) => handlePropertyChange('color', e.target.value)}
                  className="w-full h-8 bg-gray-700 border border-gray-600 rounded"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs text-gray-400 mb-1">Lien</label>
              <input
                type="url"
                value={properties.href || ''}
                onChange={(e) => handlePropertyChange('href', e.target.value)}
                placeholder="https://..."
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-sm text-white"
              />
            </div>
          </div>
        )}

        {selectedElement.type === 'image' && (
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-gray-300 uppercase tracking-wide">Image</h3>
            
            <div>
              <label className="block text-xs text-gray-400 mb-1">URL de l'image</label>
              <input
                type="url"
                value={properties.src || ''}
                onChange={(e) => handlePropertyChange('src', e.target.value)}
                placeholder="https://..."
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-sm text-white"
              />
            </div>

            <div>
              <label className="block text-xs text-gray-400 mb-1">Texte alternatif</label>
              <input
                type="text"
                value={properties.alt || ''}
                onChange={(e) => handlePropertyChange('alt', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-sm text-white"
              />
            </div>

            <div>
              <label className="block text-xs text-gray-400 mb-1">Ajustement</label>
              <select
                value={properties.objectFit || 'cover'}
                onChange={(e) => handlePropertyChange('objectFit', e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded px-2 py-1 text-sm text-white"
              >
                <option value="cover">Couvrir</option>
                <option value="contain">Contenir</option>
                <option value="fill">Remplir</option>
                <option value="scale-down">Réduire</option>
              </select>
            </div>
          </div>
        )}

        {selectedElement.type === 'section' && (
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-gray-300 uppercase tracking-wide">Section</h3>
            
            <div>
              <label className="block text-xs text-gray-400 mb-1">Couleur de fond</label>
              <input
                type="color"
                value={properties.backgroundColor || '#f9fafb'}
                onChange={(e) => handlePropertyChange('backgroundColor', e.target.value)}
                className="w-full h-8 bg-gray-700 border border-gray-600 rounded"
              />
            </div>

            <div>
              <label className="block text-xs text-gray-400 mb-1">Espacement interne</label>
              <input
                type="text"
                value={properties.padding || '16px'}
                onChange={(e) => handlePropertyChange('padding', e.target.value)}
                placeholder="16px"
                className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-sm text-white"
              />
            </div>
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="p-4 border-t border-gray-700 space-y-2">
        <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded text-sm transition-colors">
          <i className="ri-save-line mr-2"></i>
          Appliquer les modifications
        </button>
        <button className="w-full bg-red-600 hover:bg-red-700 text-white py-2 px-4 rounded text-sm transition-colors">
          <i className="ri-delete-bin-line mr-2"></i>
          Supprimer l'élément
        </button>
      </div>
    </div>
  );
}