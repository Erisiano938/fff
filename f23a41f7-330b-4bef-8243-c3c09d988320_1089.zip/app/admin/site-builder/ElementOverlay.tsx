'use client';

import { useState, useRef } from 'react';

export default function ElementOverlay({ element, onUpdate }) {
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [resizeStart, setResizeStart] = useState({ width: 0, height: 0 });
  const overlayRef = useRef(null);

  const handleMouseDown = (e, action) => {
    e.stopPropagation();
    
    if (action === 'drag') {
      setIsDragging(true);
      setDragStart({
        x: e.clientX - element.x,
        y: e.clientY - element.y
      });
    } else if (action === 'resize') {
      setIsResizing(true);
      setResizeStart({
        width: element.width,
        height: element.height,
        startX: e.clientX,
        startY: e.clientY
      });
    }
  };

  const handleMouseMove = (e) => {
    if (isDragging) {
      const newX = e.clientX - dragStart.x;
      const newY = e.clientY - dragStart.y;
      
      onUpdate({
        ...element.properties,
        x: Math.max(0, newX),
        y: Math.max(0, newY)
      });
    } else if (isResizing) {
      const deltaX = e.clientX - resizeStart.startX;
      const deltaY = e.clientY - resizeStart.startY;
      
      onUpdate({
        ...element.properties,
        width: Math.max(50, resizeStart.width + deltaX),
        height: Math.max(30, resizeStart.height + deltaY)
      });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    setIsResizing(false);
  };

  // Écouter les événements de souris sur le document
  if (typeof window !== 'undefined') {
    if (isDragging || isResizing) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    } else {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    }
  }

  return (
    <>
      {/* Outline de sélection */}
      <div 
        ref={overlayRef}
        className="absolute inset-0 border-2 border-blue-500 pointer-events-none"
        style={{
          boxShadow: '0 0 0 1px rgba(59, 130, 246, 0.3)',
        }}
      >
        {/* Poignées de redimensionnement */}
        <div className="absolute -right-1 -bottom-1 w-3 h-3 bg-blue-500 border border-white rounded-sm cursor-se-resize pointer-events-auto"
             onMouseDown={(e) => handleMouseDown(e, 'resize')}
        ></div>
        
        {/* Poignée de déplacement */}
        <div 
          className="absolute -top-8 left-0 bg-blue-500 text-white px-2 py-1 rounded text-xs font-medium cursor-move pointer-events-auto flex items-center space-x-1"
          onMouseDown={(e) => handleMouseDown(e, 'drag')}
        >
          <i className="ri-drag-move-line"></i>
          <span>{element.type}</span>
        </div>

        {/* Boutons d'action */}
        <div className="absolute -top-8 right-0 flex items-center space-x-1 pointer-events-auto">
          <button 
            className="bg-green-500 hover:bg-green-600 text-white p-1 rounded text-xs transition-colors"
            onClick={() => {
              // Dupliquer l'élément
              const newElement = {
                ...element,
                id: `element_${Date.now()}`,
                x: element.x + 20,
                y: element.y + 20
              };
              onUpdate(newElement);
            }}
          >
            <i className="ri-file-copy-line"></i>
          </button>
          
          <button 
            className="bg-red-500 hover:bg-red-600 text-white p-1 rounded text-xs transition-colors"
            onClick={() => {
              // Supprimer l'élément
              if (confirm('Supprimer cet élément ?')) {
                onUpdate(null); // Signal de suppression
              }
            }}
          >
            <i className="ri-delete-bin-line"></i>
          </button>
        </div>
      </div>

      {/* Informations de position (affichage pendant le drag) */}
      {isDragging && (
        <div className="fixed top-4 right-4 bg-gray-800 text-white px-3 py-2 rounded shadow-lg text-sm z-50">
          X: {element.x}px, Y: {element.y}px
        </div>
      )}
      
      {/* Informations de taille (affichage pendant le resize) */}
      {isResizing && (
        <div className="fixed top-4 right-4 bg-gray-800 text-white px-3 py-2 rounded shadow-lg text-sm z-50">
          {element.width}px × {element.height}px
        </div>
      )}
    </>
  );
}