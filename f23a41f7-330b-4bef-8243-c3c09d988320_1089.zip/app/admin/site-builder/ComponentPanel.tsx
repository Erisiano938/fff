'use client';

import { useState } from 'react';

const componentCategories = {
  'Texte': [
    {
      type: 'text',
      name: 'Titre',
      icon: 'ri-heading',
      defaultWidth: 300,
      defaultHeight: 40,
      defaultProperties: { content: 'Titre principal', fontSize: '24px', fontWeight: 'bold' }
    },
    {
      type: 'text',
      name: 'Paragraphe',
      icon: 'ri-text',
      defaultWidth: 400,
      defaultHeight: 80,
      defaultProperties: { content: 'Votre texte ici...', fontSize: '16px' }
    }
  ],
  'Éléments': [
    {
      type: 'button',
      name: 'Bouton',
      icon: 'ri-cursor-line',
      defaultWidth: 120,
      defaultHeight: 40,
      defaultProperties: { content: 'Cliquez ici', backgroundColor: '#3b82f6', color: '#fff' }
    },
    {
      type: 'image',
      name: 'Image',
      icon: 'ri-image-line',
      defaultWidth: 300,
      defaultHeight: 200,
      defaultProperties: { src: '', alt: 'Image' }
    }
  ],
  'Layout': [
    {
      type: 'section',
      name: 'Section',
      icon: 'ri-layout-line',
      defaultWidth: 600,
      defaultHeight: 200,
      defaultProperties: { backgroundColor: '#f9fafb', padding: '20px' }
    },
    {
      type: 'container',
      name: 'Conteneur',
      icon: 'ri-squares-line',
      defaultWidth: 500,
      defaultHeight: 300,
      defaultProperties: { backgroundColor: 'transparent', padding: '16px' }
    }
  ],
  'Médias': [
    {
      type: 'video',
      name: 'Vidéo',
      icon: 'ri-video-line',
      defaultWidth: 400,
      defaultHeight: 250,
      defaultProperties: { src: '', autoplay: false }
    },
    {
      type: 'icon',
      name: 'Icône',
      icon: 'ri-heart-line',
      defaultWidth: 50,
      defaultHeight: 50,
      defaultProperties: { iconClass: 'ri-heart-line', color: '#000', size: '24px' }
    }
  ]
};

export default function ComponentPanel() {
  const [activeCategory, setActiveCategory] = useState('Texte');

  const handleDragStart = (event, component) => {
    event.dataTransfer.setData('application/json', JSON.stringify(component));
    
    // Créer un élément fantôme personnalisé
    const dragElement = document.createElement('div');
    dragElement.className = 'bg-blue-500 text-white p-2 rounded shadow-lg';
    dragElement.textContent = component.name;
    dragElement.style.position = 'absolute';
    dragElement.style.top = '-1000px';
    document.body.appendChild(dragElement);
    event.dataTransfer.setDragImage(dragElement, 60, 20);
    
    setTimeout(() => document.body.removeChild(dragElement), 0);
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-gray-700">
        <h2 className="text-lg font-semibold text-white mb-2">Composants</h2>
        <input
          type="text"
          placeholder="Rechercher..."
          className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-sm text-white placeholder-gray-400"
        />
      </div>

      {/* Catégories */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-2">
          {Object.keys(componentCategories).map(category => (
            <div key={category} className="mb-4">
              <button
                onClick={() => setActiveCategory(activeCategory === category ? '' : category)}
                className="w-full flex items-center justify-between p-2 bg-gray-700 hover:bg-gray-600 rounded text-left transition-colors"
              >
                <span className="font-medium">{category}</span>
                <i className={`ri-arrow-${activeCategory === category ? 'up' : 'down'}-s-line`}></i>
              </button>
              
              {activeCategory === category && (
                <div className="mt-2 space-y-1">
                  {componentCategories[category].map((component, index) => (
                    <div
                      key={index}
                      draggable
                      onDragStart={(e) => handleDragStart(e, component)}
                      className="flex items-center p-3 bg-gray-750 hover:bg-gray-650 rounded cursor-move transition-colors group"
                    >
                      <div className="w-8 h-8 bg-blue-500/20 rounded flex items-center justify-center mr-3">
                        <i className={`${component.icon} text-blue-400`}></i>
                      </div>
                      <div>
                        <div className="font-medium text-sm">{component.name}</div>
                        <div className="text-xs text-gray-400">{component.type}</div>
                      </div>
                      <i className="ri-drag-move-line text-gray-500 ml-auto opacity-0 group-hover:opacity-100 transition-opacity"></i>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Actions rapides */}
      <div className="p-4 border-t border-gray-700">
        <div className="space-y-2">
          <button className="w-full bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded text-sm transition-colors">
            <i className="ri-add-line mr-2"></i>
            Composant personnalisé
          </button>
          <button className="w-full bg-gray-600 hover:bg-gray-500 text-white py-2 px-4 rounded text-sm transition-colors">
            <i className="ri-download-line mr-2"></i>
            Importer composant
          </button>
        </div>
      </div>
    </div>
  );
}