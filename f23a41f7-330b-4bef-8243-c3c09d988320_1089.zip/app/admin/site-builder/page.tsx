
'use client';

import { useState, useEffect } from 'react';
import FileExplorer from './FileExplorer';
import { FileManager, FileNode } from '../../lib/fileManager';

export default function SiteBuilder() {
  const [activeFile, setActiveFile] = useState<string>('');
  const [fileContent, setFileContent] = useState<string>('');
  const [isModified, setIsModified] = useState(false);
  const [viewMode, setViewMode] = useState<'code' | 'preview' | 'split'>('split');
  const [isSaving, setIsSaving] = useState(false);
  const [projectFiles, setProjectFiles] = useState<FileNode[]>([]);

  const fileManager = FileManager.getInstance();

  useEffect(() => {
    // Charger la structure du projet
    const files = fileManager.getProjectStructure();
    setProjectFiles(files);
    
    // Ouvrir le premier fichier par défaut
    if (files.length > 0) {
      const firstFile = findFirstFile(files);
      if (firstFile) {
        handleFileSelect(firstFile.path);
      }
    }
  }, []);

  const findFirstFile = (nodes: FileNode[]): FileNode | null => {
    for (const node of nodes) {
      if (node.type === 'file') {
        return node;
      }
      if (node.children) {
        const found = findFirstFile(node.children);
        if (found) return found;
      }
    }
    return null;
  };

  const handleFileSelect = async (filePath: string) => {
    if (isModified) {
      const shouldSave = confirm('Fichier modifié. Voulez-vous sauvegarder avant de continuer ?');
      if (shouldSave) {
        await handleSave();
      }
    }

    setActiveFile(filePath);
    try {
      const content = await fileManager.readFile(filePath);
      setFileContent(content);
      setIsModified(false);
    } catch (error) {
      console.error('Erreur lors du chargement du fichier:', error);
      setFileContent('// Erreur lors du chargement du fichier');
    }
  };

  const handleContentChange = (newContent: string) => {
    setFileContent(newContent);
    setIsModified(true);
  };

  const handleSave = async () => {
    if (!activeFile || !isModified) return;

    setIsSaving(true);
    try {
      await fileManager.writeFile(activeFile, fileContent);
      setIsModified(false);
    } catch (error) {
      console.error('Erreur lors de la sauvegarde:', error);
      alert('Erreur lors de la sauvegarde du fichier');
    }
    setIsSaving(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.ctrlKey && e.key === 's') {
      e.preventDefault();
      handleSave();
    }
  };

  const handleCreateFile = async () => {
    const fileName = prompt('Nom du nouveau fichier (avec extension):');
    if (!fileName) return;

    const filePath = `app/${fileName}`;
    try {
      await fileManager.createFile(filePath);
      // Recharger la structure du projet
      const files = fileManager.getProjectStructure();
      setProjectFiles(files);
      handleFileSelect(filePath);
    } catch (error) {
      console.error('Erreur lors de la création du fichier:', error);
      alert('Erreur lors de la création du fichier');
    }
  };

  return (
    <div className="h-screen bg-gray-900 text-white flex flex-col">
      {/* Header */}
      <div className="bg-gray-800 px-6 py-3 border-b border-gray-700 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <h1 className="text-xl font-bold">Éditeur de Code Source</h1>
          {activeFile && (
            <div className="flex items-center space-x-2 text-sm text-gray-300">
              <i className="ri-file-code-line"></i>
              <span>{activeFile}</span>
              {isModified && <span className="text-yellow-400">•</span>}
            </div>
          )}
        </div>
        <div className="flex items-center space-x-2">
          {/* Mode de vue */}
          <div className="flex bg-gray-700 rounded-lg overflow-hidden">
            <button
              onClick={() => setViewMode('code')}
              className={`px-3 py-1 text-sm ${
                viewMode === 'code' ? 'bg-blue-600' : 'hover:bg-gray-600'
              }`}
            >
              Code
            </button>
            <button
              onClick={() => setViewMode('preview')}
              className={`px-3 py-1 text-sm ${
                viewMode === 'preview' ? 'bg-blue-600' : 'hover:bg-gray-600'
              }`}
            >
              Aperçu
            </button>
            <button
              onClick={() => setViewMode('split')}
              className={`px-3 py-1 text-sm ${
                viewMode === 'split' ? 'bg-blue-600' : 'hover:bg-gray-600'
              }`}
            >
              Split
            </button>
          </div>
          
          {/* Actions */}
          <button
            onClick={handleSave}
            disabled={!isModified || isSaving}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 rounded-lg text-sm flex items-center space-x-2"
          >
            {isSaving ? (
              <i className="ri-loader-4-line animate-spin"></i>
            ) : (
              <i className="ri-save-line"></i>
            )}
            <span>Sauvegarder</span>
          </button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Explorateur de fichiers */}
        <div className="w-80 bg-gray-800 border-r border-gray-700 flex flex-col">
          <div className="p-3 border-b border-gray-700 flex items-center justify-between">
            <h3 className="font-semibold">Explorateur</h3>
            <button
              onClick={handleCreateFile}
              className="p-1 hover:bg-gray-700 rounded"
              title="Nouveau fichier"
            >
              <i className="ri-add-line text-sm"></i>
            </button>
          </div>
          <div className="flex-1 overflow-auto">
            <FileExplorer
              files={projectFiles}
              activeFile={activeFile}
              onFileSelect={handleFileSelect}
            />
          </div>
        </div>

        {/* Zone d'édition */}
        <div className="flex-1 flex">
          {/* Éditeur de code */}
          {(viewMode === 'code' || viewMode === 'split') && (
            <div className={`${viewMode === 'split' ? 'w-1/2' : 'w-full'} flex flex-col bg-gray-900`}>
              <div className="bg-gray-800 px-4 py-2 text-sm text-gray-300 border-b border-gray-700">
                Éditeur - {activeFile || 'Aucun fichier sélectionné'}
              </div>
              <div className="flex-1 relative">
                <textarea
                  value={fileContent}
                  onChange={(e) => handleContentChange(e.target.value)}
                  onKeyDown={handleKeyDown}
                  className="w-full h-full bg-gray-900 text-white font-mono text-sm p-4 resize-none outline-none"
                  placeholder="Sélectionnez un fichier pour commencer l'édition..."
                  style={{ lineHeight: '1.5' }}
                />
                {/* Indicateur de ligne */}
                <div className="absolute left-0 top-0 w-12 h-full bg-gray-800 border-r border-gray-700 pointer-events-none">
                  <div className="p-4 font-mono text-xs text-gray-500">
                    {fileContent.split('\n').map((_, i) => (
                      <div key={i} className="h-5">
                        {i + 1}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Aperçu */}
          {(viewMode === 'preview' || viewMode === 'split') && (
            <div className={`${viewMode === 'split' ? 'w-1/2' : 'w-full'} flex flex-col bg-white border-l border-gray-700`}>
              <div className="bg-gray-800 px-4 py-2 text-sm text-gray-300 border-b border-gray-700">
                Aperçu - {activeFile || 'Aucun aperçu'}
              </div>
              <div className="flex-1 overflow-auto">
                <iframe
                  src="/"
                  className="w-full h-full border-0"
                  title="Aperçu de la page"
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Barre de statut */}
      <div className="bg-gray-800 px-6 py-2 border-t border-gray-700 flex items-center justify-between text-sm text-gray-300">
        <div className="flex items-center space-x-4">
          <span>Éditeur de Code Source</span>
          {activeFile && (
            <>
              <span>•</span>
              <span>{fileManager.getFileExtension(activeFile).toUpperCase()}</span>
            </>
          )}
        </div>
        <div className="flex items-center space-x-4">
          {isModified && (
            <span className="text-yellow-400">Non sauvegardé</span>
          )}
          <span>Ctrl+S pour sauvegarder</span>
        </div>
      </div>
    </div>
  );
}
