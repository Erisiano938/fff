'use client';

import { useState, useEffect, useRef } from 'react';
import ElementOverlay from './ElementOverlay';

export default function VisualEditor({ 
  currentPage, 
  selectedElement, 
  onElementSelect, 
  onElementUpdate 
}) {
  const [pageContent, setPageContent] = useState('');
  const [elements, setElements] = useState([]);
  const [draggedElement, setDraggedElement] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const editorRef = useRef(null);

  useEffect(() => {
    loadPageContent();
  }, [currentPage]);

  const loadPageContent = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(`/api/site-builder/page-content?page=${currentPage}`);
      const data = await response.json();
      setPageContent(data.content || '');
      setElements(data.elements || []);
    } catch (error) {
      console.error('Erreur lors du chargement:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleElementClick = (element, event) => {
    event.stopPropagation();
    onElementSelect(element);
  };

  const handleDrop = (event) => {
    event.preventDefault();
    if (!draggedElement) return;

    const rect = editorRef.current.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    const newElement = {
      id: `element_${Date.now()}`,
      type: draggedElement.type,
      x,
      y,
      width: draggedElement.defaultWidth || 200,
      height: draggedElement.defaultHeight || 50,
      properties: { ...draggedElement.defaultProperties }
    };

    setElements([...elements, newElement]);
    setDraggedElement(null);
    onElementSelect(newElement);
  };

  const handleDragOver = (event) => {
    event.preventDefault();
  };

  if (isLoading) {
    return (
      <div className="w-full h-full flex items-center justify-center">
        <div className="text-gray-400">Chargement de la page...</div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full overflow-auto">
      {/* Barre d'outils */}
      <div className="absolute top-0 left-0 right-0 bg-gray-800/90 backdrop-blur-sm border-b border-gray-700 z-10">
        <div className="flex items-center justify-between px-4 py-2">
          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-400">Page: {currentPage}</span>
            <div className="flex items-center space-x-2">
              <button className="p-1 hover:bg-gray-700 rounded">
                <i className="ri-arrow-go-back-line"></i>
              </button>
              <button className="p-1 hover:bg-gray-700 rounded">
                <i className="ri-arrow-go-forward-line"></i>
              </button>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <button className="px-3 py-1 bg-gray-700 hover:bg-gray-600 rounded text-sm">
              Desktop
            </button>
            <button className="px-3 py-1 hover:bg-gray-700 rounded text-sm">
              Tablet
            </button>
            <button className="px-3 py-1 hover:bg-gray-700 rounded text-sm">
              Mobile
            </button>
          </div>
        </div>
      </div>

      {/* Zone d'édition */}
      <div 
        ref={editorRef}
        className="mt-16 min-h-full bg-white relative"
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onClick={() => onElementSelect(null)}
      >
        {/* Grille d'alignement */}
        <div className="absolute inset-0 pointer-events-none opacity-10">
          <svg width="100%" height="100%">
            <defs>
              <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#000" strokeWidth="0.5"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>

        {/* Éléments de la page */}
        {elements.map(element => (
          <div
            key={element.id}
            className="absolute cursor-pointer"
            style={{
              left: element.x,
              top: element.y,
              width: element.width,
              height: element.height,
            }}
            onClick={(e) => handleElementClick(element, e)}
          >
            <ElementRenderer element={element} />
            {selectedElement?.id === element.id && (
              <ElementOverlay 
                element={element} 
                onUpdate={(props) => onElementUpdate(element.id, props)}
              />
            )}
          </div>
        ))}

        {/* Zone de drop pour nouveaux éléments */}
        {elements.length === 0 && (
          <div className="flex items-center justify-center h-96 text-gray-400 border-2 border-dashed border-gray-300 m-8 rounded-lg">
            <div className="text-center">
              <i className="ri-drag-drop-line text-4xl mb-4"></i>
              <p>Glissez un composant ici pour commencer</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function ElementRenderer({ element }) {
  const { type, properties } = element;

  switch (type) {
    case 'text':
      return (
        <div 
          className="w-full h-full p-2 border border-gray-300 bg-white"
          style={{ 
            fontSize: properties.fontSize || '16px',
            color: properties.color || '#000',
            fontWeight: properties.fontWeight || 'normal'
          }}
        >
          {properties.content || 'Texte par défaut'}
        </div>
      );

    case 'button':
      return (
        <button
          className="w-full h-full rounded"
          style={{
            backgroundColor: properties.backgroundColor || '#3b82f6',
            color: properties.color || '#fff',
            fontSize: properties.fontSize || '14px'
          }}
        >
          {properties.content || 'Bouton'}
        </button>
      );

    case 'image':
      return (
        <div className="w-full h-full border border-gray-300 bg-gray-100 flex items-center justify-center">
          {properties.src ? (
            <img 
              src={properties.src} 
              alt={properties.alt || ''} 
              className="w-full h-full object-cover"
            />
          ) : (
            <i className="ri-image-line text-2xl text-gray-400"></i>
          )}
        </div>
      );

    case 'section':
      return (
        <div 
          className="w-full h-full border border-gray-300"
          style={{
            backgroundColor: properties.backgroundColor || '#f9fafb',
            padding: properties.padding || '16px'
          }}
        >
          <div className="text-gray-500 text-sm">Section</div>
        </div>
      );

    default:
      return (
        <div className="w-full h-full border border-gray-300 bg-gray-50 flex items-center justify-center">
          <span className="text-gray-400">{type}</span>
        </div>
      );
  }
}