'use client';

import { useState, useEffect } from 'react';

export default function PreviewFrame({ currentPage }) {
  const [previewUrl, setPreviewUrl] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Construire l'URL de prévisualisation
    const baseUrl = window.location.origin;
    const pagePath = currentPage === 'page.tsx' ? '/' : `/${currentPage.replace('/page.tsx', '')}`;
    setPreviewUrl(`${baseUrl}${pagePath}`);
    setIsLoading(false);
  }, [currentPage]);

  const handleRefresh = () => {
    setIsLoading(true);
    // Forcer le rechargement de l'iframe
    const iframe = document.getElementById('preview-iframe') as HTMLIFrameElement;
    if (iframe) {
      iframe.src = iframe.src;
    }
    setTimeout(() => setIsLoading(false), 1000);
  };

  return (
    <div className="w-full h-full bg-white relative">
      {/* Header du preview */}
      <div className="absolute top-0 left-0 right-0 bg-gray-100 border-b border-gray-300 h-12 flex items-center px-4 z-10">
        <div className="flex items-center space-x-3">
          <button
            onClick={handleRefresh}
            className="p-1 hover:bg-gray-200 rounded"
            disabled={isLoading}
          >
            <i className={`ri-refresh-line ${isLoading ? 'animate-spin' : ''}`}></i>
          </button>
          
          <div className="flex items-center bg-white border border-gray-300 rounded px-3 py-1 text-sm flex-1 max-w-md">
            <i className="ri-global-line mr-2 text-gray-400"></i>
            <span className="truncate">{previewUrl}</span>
          </div>
        </div>
        
        <div className="ml-auto flex items-center space-x-2">
          <div className="flex bg-gray-200 rounded p-1">
            <button className="px-2 py-1 bg-white rounded shadow-sm text-xs">
              <i className="ri-computer-line mr-1"></i>
              Desktop
            </button>
            <button className="px-2 py-1 hover:bg-gray-300 rounded text-xs">
              <i className="ri-tablet-line mr-1"></i>
              Tablet
            </button>
            <button className="px-2 py-1 hover:bg-gray-300 rounded text-xs">
              <i className="ri-smartphone-line mr-1"></i>
              Mobile
            </button>
          </div>
        </div>
      </div>

      {/* Contenu de prévisualisation */}
      <div className="pt-12 h-full">
        {isLoading && (
          <div className="absolute inset-0 bg-white/80 flex items-center justify-center z-20">
            <div className="text-center">
              <i className="ri-loader-4-line text-2xl animate-spin text-blue-500 mb-2"></i>
              <p className="text-gray-600">Chargement de la prévisualisation...</p>
            </div>
          </div>
        )}
        
        <iframe
          id="preview-iframe"
          src={previewUrl}
          className="w-full h-full border-0"
          title="Prévisualisation de la page"
          onLoad={() => setIsLoading(false)}
        />
      </div>
    </div>
  );
}