'use client';

import { useState, useEffect } from 'react';
import { fileManager } from '../../lib/fileManager';

export default function FileExplorer({ currentFile, onFileSelect, hasUnsavedChanges }) {
  const [fileTree, setFileTree] = useState({});
  const [expandedFolders, setExpandedFolders] = useState(new Set(['app', 'components', 'lib']));
  const [isLoading, setIsLoading] = useState(true);
  const [newFileName, setNewFileName] = useState('');
  const [showNewFileInput, setShowNewFileInput] = useState(false);

  useEffect(() => {
    loadFileTree();
  }, []);

  const loadFileTree = async () => {
    try {
      setIsLoading(true);
      const tree = await fileManager.getFileTree();
      setFileTree(tree || {});
    } catch (error) {
      console.error('Erreur lors du chargement de l\'arbre des fichiers:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleFolder = (folderPath) => {
    const newExpanded = new Set(expandedFolders);
    if (newExpanded.has(folderPath)) {
      newExpanded.delete(folderPath);
    } else {
      newExpanded.add(folderPath);
    }
    setExpandedFolders(newExpanded);
  };

  const getFileIcon = (fileName) => {
    const ext = fileName.split('.').pop()?.toLowerCase();
    switch (ext) {
      case 'tsx':
      case 'jsx':
        return 'ri-reactjs-line text-blue-400';
      case 'ts':
      case 'js':
        return 'ri-javascript-line text-yellow-400';
      case 'css':
        return 'ri-css3-line text-blue-300';
      case 'json':
        return 'ri-file-code-line text-green-400';
      case 'md':
        return 'ri-markdown-line text-gray-400';
      default:
        return 'ri-file-text-line text-gray-400';
    }
  };

  const createNewFile = async () => {
    if (!newFileName.trim()) return;
    
    try {
      const result = await fileManager.createFile(newFileName, '// Nouveau fichier\n');
      if (result.success) {
        setNewFileName('');
        setShowNewFileInput(false);
        await loadFileTree();
        onFileSelect(newFileName);
      } else {
        alert('Erreur lors de la création du fichier: ' + result.error);
      }
    } catch (error) {
      alert('Erreur lors de la création du fichier');
    }
  };

  const renderFileTree = (tree, basePath = '', level = 0) => {
    return Object.entries(tree).map(([name, node]) => {
      const fullPath = basePath ? `${basePath}/${name}` : name;
      
      if (node.type === 'folder') {
        const isExpanded = expandedFolders.has(fullPath);
        
        return (
          <div key={fullPath}>
            <div
              className="flex items-center py-1 px-2 hover:bg-gray-700 cursor-pointer rounded group"
              style={{ paddingLeft: `${level * 16 + 8}px` }}
              onClick={() => toggleFolder(fullPath)}
            >
              <i className={`ri-arrow-${isExpanded ? 'down' : 'right'}-s-line text-xs mr-1`}></i>
              <i className="ri-folder-line text-yellow-400 mr-2 text-sm"></i>
              <span className="text-sm flex-1">{name}</span>
            </div>
            
            {isExpanded && node.children && (
              <div>
                {renderFileTree(node.children, fullPath, level + 1)}
              </div>
            )}
          </div>
        );
      } else {
        const isSelected = currentFile === fullPath;
        
        return (
          <div
            key={fullPath}
            className={`flex items-center py-1 px-2 hover:bg-gray-700 cursor-pointer rounded group ${
              isSelected ? 'bg-blue-600' : ''
            }`}
            style={{ paddingLeft: `${level * 16 + 24}px` }}
            onClick={() => onFileSelect(fullPath)}
          >
            <i className={`${getFileIcon(name)} mr-2 text-sm`}></i>
            <span className="text-sm flex-1">{name}</span>
            {isSelected && hasUnsavedChanges && (
              <i className="ri-circle-fill text-orange-400 text-xs ml-1"></i>
            )}
            {isSelected && !hasUnsavedChanges && (
              <i className="ri-check-line text-green-400 text-xs ml-1"></i>
            )}
          </div>
        );
      }
    });
  };

  if (isLoading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-center">
          <i className="ri-loader-4-line animate-spin text-xl mb-2"></i>
          <p className="text-sm text-gray-400">Chargement des fichiers...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-gray-700">
        <h2 className="text-lg font-semibold text-white mb-3">Fichiers</h2>
        <div className="flex items-center space-x-2">
          <button 
            onClick={loadFileTree}
            className="p-2 bg-gray-700 hover:bg-gray-600 rounded text-xs transition-colors"
            title="Actualiser"
          >
            <i className="ri-refresh-line"></i>
          </button>
          <button 
            onClick={() => setShowNewFileInput(true)}
            className="p-2 bg-gray-700 hover:bg-gray-600 rounded text-xs transition-colors"
            title="Nouveau fichier"
          >
            <i className="ri-file-add-line"></i>
          </button>
        </div>
        
        {/* Input pour nouveau fichier */}
        {showNewFileInput && (
          <div className="mt-3 space-y-2">
            <input
              type="text"
              value={newFileName}
              onChange={(e) => setNewFileName(e.target.value)}
              placeholder="app/nouvelle-page/page.tsx"
              className="w-full bg-gray-700 border border-gray-600 rounded px-2 py-1 text-sm text-white"
              onKeyDown={(e) => {
                if (e.key === 'Enter') createNewFile();
                if (e.key === 'Escape') {
                  setShowNewFileInput(false);
                  setNewFileName('');
                }
              }}
              autoFocus
            />
            <div className="flex space-x-1">
              <button
                onClick={createNewFile}
                className="px-2 py-1 bg-green-600 hover:bg-green-700 rounded text-xs whitespace-nowrap"
              >
                Créer
              </button>
              <button
                onClick={() => {
                  setShowNewFileInput(false);
                  setNewFileName('');
                }}
                className="px-2 py-1 bg-gray-600 hover:bg-gray-700 rounded text-xs whitespace-nowrap"
              >
                Annuler
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Arbre des fichiers */}
      <div className="flex-1 overflow-y-auto p-2">
        {Object.keys(fileTree).length === 0 ? (
          <div className="text-center text-gray-400 text-sm mt-8">
            <i className="ri-folder-open-line text-2xl mb-2"></i>
            <p>Aucun fichier trouvé</p>
          </div>
        ) : (
          renderFileTree(fileTree)
        )}
      </div>

      {/* Statistiques */}
      <div className="p-4 border-t border-gray-700 text-xs text-gray-400">
        <div className="space-y-1">
          <div className="truncate">Fichier: {currentFile}</div>
          {hasUnsavedChanges && (
            <div className="text-orange-400">
              <i className="ri-alert-line mr-1"></i>
              Modifications non sauvegardées
            </div>
          )}
          <div className="text-gray-500">
            Ctrl+S pour sauvegarder
          </div>
        </div>
      </div>
    </div>
  );
}