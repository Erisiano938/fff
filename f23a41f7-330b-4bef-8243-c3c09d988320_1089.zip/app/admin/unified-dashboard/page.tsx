
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import BankingOverview from './BankingOverview';
import AgendaWorkflow from './AgendaWorkflow';

export default function UnifiedDashboard() {
  const [activeSection, setActiveSection] = useState('overview');
  const [selectedClient, setSelectedClient] = useState<any>(null);
  const [showClientModal, setShowClientModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [investmentAmount, setInvestmentAmount] = useState('');
  const [investmentSupport, setInvestmentSupport] = useState('');
  const [showAppointmentModal, setShowAppointmentModal] = useState(false);
  const [activeView, setActiveView] = useState('banking');
  const [activeClientTab, setActiveClientTab] = useState('general');
  const [showPatrimoineModal, setShowPatrimoineModal] = useState(false);
  const [showContactModal, setShowContactModal] = useState(false);
  const [contactType, setContactType] = useState('');

  const mockClients = [
    {
      id: 1,
      name: 'Sophie Martineau',
      email: 'sophie.martineau@email.com',
      phone: '+33 6 12 34 56 78',
      address: '15 rue de la Paix, 75001 Paris',
      birthDate: '1975-05-15',
      civilStatus: 'Mariée',
      matrimonialRegime: 'Communauté réduite aux acquêts',
      profession: 'Directrice Marketing',
      status: 'Premium',
      riskProfile: 'Conservateur',
      totalAssets: 285000,
      lastContact: '2024-03-10',
      kyc: 'Complet',
      mifid: 'Valide',
      objectives: 'Préparation retraite, transmission patrimoine',
      horizon: '15-20 ans',
      targetReturn: '4-6%',
      tolerance: 'Faible volatilité',
      clientNumber: 'CL-2019-0847',
      conseiller: 'Pierre Dubois',
      dateOuverture: '2019-03-15',
      derniereMAJ: '2024-03-10 14:30',
      actifs: {
        compteCourant: 12500,
        livretA: 22300,
        assuranceVie: 95000,
        pea: 45000,
        scpi: 25000,
        actions: 68000,
        obligations: 17200,
        crypto: 0,
        immobilier: 0
      },
      passifs: {
        creditImmo: { capital: 180000, restant: 125000, mensualite: 1200, echeance: '2034-03-15' },
        creditConso: { capital: 15000, restant: 8500, mensualite: 280, echeance: '2026-11-15' },
        creditPro: { capital: 0, restant: 0, mensualite: 0, echeance: '' }
      },
      accounts: [
        { type: 'Compte-titres', value: 125000, performance: '+5.2%' },
        { type: 'Assurance-vie', value: 95000, performance: '+3.8%' },
        { type: 'PEA', value: 45000, performance: '+7.1%' },
        { type: 'SCPI', value: 20000, performance: '+4.2%' }
      ],
      rdvHistorique: [
        { date: '2024-03-10', type: 'Visio', statut: 'Réalisé', objet: 'Révision portefeuille trimestrielle', conseiller: 'Pierre Dubois' },
        { date: '2024-02-28', type: 'Agence', statut: 'Réalisé', objet: 'Signature avenant assurance-vie', conseiller: 'Pierre Dubois' },
        { date: '2024-02-15', type: 'Tel', statut: 'Réalisé', objet: 'Point marché actions', conseiller: 'Pierre Dubois' },
        { date: '2024-04-15', type: 'Visio', statut: 'Programmé', objet: 'Préparation déclaration fiscale', conseiller: 'Pierre Dubois' }
      ],
      produitsSouscrits: [
        { produit: 'Assurance-vie Patrimoine+', dateSouscription: '2019-06-12', montant: '95 000 €', statut: 'Actif' },
        { produit: 'PEA Actions Europe', dateSouscription: '2020-01-08', montant: '45 000 €', statut: 'Actif' },
        { produit: 'SCPI Immobilier', dateSouscription: '2021-03-22', montant: '25 000 €', statut: 'Actif' },
        { produit: 'Compte-titres Premium', dateSouscription: '2019-03-15', montant: '68 000 €', statut: 'Actif' }
      ],
      opportunitesCommerciales: [
        { opportunite: 'PEA-PME', priorite: 'Haute', potentiel: '15 000 €', probabilite: '75%', echeance: '2024-04-30' },
        { opportunite: 'Assurance-vie enfants', priorite: 'Moyenne', potentiel: '25 000 €', probabilite: '60%', echeance: '2024-06-15' },
        { opportunite: 'Crédit travaux', priorite: 'Faible', potentiel: '50 000 €', probabilite: '30%', echeance: '2024-08-30' }
      ],
      scoreRisque: 'AAA',
      monitoring: {
        incidents: 'Aucun',
        tauxEndettement: '28%',
        capaciteResiduelle: '2 850 €/mois',
        dernierControle: '2024-03-05'
      },
      relationClient: {
        canalPrefere: 'Visio',
        satisfaction: {
          global: 9.2,
          conseil: 9.5,
          reactivite: 9.0,
          digital: 8.8,
          tarifs: 8.5
        },
        notesConseiller: 'Cliente exemplaire, très satisfaite de nos services. Souhaite développer son patrimoine immobilier à moyen terme.'
      },
      tasks: [
        { id: 1, title: 'Révision allocation actions', priority: 'Haute', due: '2024-03-20' },
        { id: 2, title: 'Préparation rapport trimestriel', priority: 'Moyenne', due: '2024-03-25' }
      ],
      interactions: [
        { date: '2024-03-10', type: 'Appel', description: 'Discussion stratégie 2024' },
        { date: '2024-02-28', type: 'Email', description: 'Envoi rapport mensuel' },
        { date: '2024-02-15', type: 'RDV', description: 'Révision portefeuille' }
      ]
    },
    {
      id: 2,
      name: 'Sophie Laurent',
      email: 'sophie.laurent@email.com',
      phone: '+33 6 87 65 43 21',
      address: '28 avenue Montaigne, 75008 Paris',
      birthDate: '1982-09-22',
      civilStatus: 'Célibataire',
      matrimonialRegime: 'N/A',
      profession: 'Avocat d\'affaires',
      status: 'Prospect',
      riskProfile: 'Modéré',
      totalAssets: 150000,
      lastContact: '2024-03-12',
      kyc: 'En cours',
      mifid: 'À réviser',
      objectives: 'Constitution patrimoine, investissement immobilier',
      horizon: '10-15 ans',
      targetReturn: '6-8%',
      tolerance: 'Volatilité modérée',
      clientNumber: 'PR-2024-0156',
      conseiller: 'Marie Durant',
      dateOuverture: '2024-02-20',
      derniereMAJ: '2024-03-12 10:15',
      actifs: {
        compteCourant: 8500,
        livretA: 22300,
        assuranceVie: 45000,
        pea: 35000,
        scpi: 0,
        actions: 39200,
        obligations: 0,
        crypto: 0,
        immobilier: 0
      },
      passifs: {
        creditImmo: { capital: 0, restant: 0, mensualite: 0, echeance: '' },
        creditConso: { capital: 12000, restant: 9200, mensualite: 320, echeance: '2026-08-20' },
        creditPro: { capital: 0, restant: 0, mensualite: 0, echeance: '' }
      },
      accounts: [
        { type: 'Compte-titres', value: 85000, performance: '+6.3%' },
        { type: 'Assurance-vie', value: 45000, performance: '+4.1%' },
        { type: 'Livret A', value: 20000, performance: '+3.0%' }
      ],
      rdvHistorique: [
        { date: '2024-03-12', type: 'Agence', statut: 'Réalisé', objet: 'Premier entretien patrimonial', conseiller: 'Marie Durant' },
        { date: '2024-03-18', type: 'Visio', statut: 'Programmé', objet: 'Finalisation dossier KYC', conseiller: 'Marie Durant' }
      ],
      produitsSouscrits: [
        { produit: 'Compte courant Premium', dateSouscription: '2024-02-20', montant: '8 500 €', statut: 'Actif' },
        { produit: 'Livret A', dateSouscription: '2024-02-20', montant: '22 300 €', statut: 'Actif' }
      ],
      opportunitesCommerciales: [
        { opportunite: 'Assurance-vie', priorite: 'Urgente', potentiel: '50 000 €', probabilite: '85%', echeance: '2024-03-25' },
        { opportunite: 'PEA', priorite: 'Haute', potentiel: '30 000 €', probabilite: '70%', echeance: '2024-04-10' }
      ],
      scoreRisque: 'AA',
      monitoring: {
        incidents: 'Aucun',
        tauxEndettement: '12%',
        capaciteResiduelle: '4 200 €/mois',
        dernierControle: '2024-03-12'
      },
      relationClient: {
        canalPrefere: 'Agence',
        satisfaction: {
          global: 8.5,
          conseil: 8.8,
          reactivite: 8.2,
          digital: 8.0,
          tarifs: 8.5
        },
        notesConseiller: 'Nouvelle cliente très prometteuse. Forte capacité d\'épargne, projet immobilier à concrétiser.'
      },
      tasks: [
        { id: 3, title: 'Finaliser dossier KYC', priority: 'Urgente', due: '2024-03-18' },
        { id: 4, title: 'Évaluation profil MiFID', priority: 'Haute', due: '2024-03-22' }
      ],
      interactions: [
        { date: '2024-03-12', type: 'RDV', description: 'Premier entretien patrimonial' },
        { date: '2024-03-08', type: 'Email', description: 'Envoi documentation KYC' }
      ]
    },
    {
      id: 3,
      name: 'Pierre Martin',
      email: 'pierre.martin@email.com',
      phone: '+33 6 11 22 33 44',
      address: '42 boulevard Haussmann, 75009 Paris',
      birthDate: '1968-12-03',
      civilStatus: 'Marié',
      matrimonialRegime: 'Séparation de biens',
      profession: 'Chef d\'entreprise',
      status: 'Patrimonial',
      riskProfile: 'Dynamique',
      totalAssets: 450000,
      lastContact: '2024-03-08',
      kyc: 'Complet',
      mifid: 'Valide',
      objectives: 'Optimisation fiscale, développement patrimoine',
      horizon: '5-10 ans',
      targetReturn: '8-12%',
      tolerance: 'Volatilité élevée acceptée',
      clientNumber: 'PT-2018-0234',
      conseiller: 'Laurent Petit',
      dateOuverture: '2018-09-12',
      derniereMAJ: '2024-03-08 16:45',
      actifs: {
        compteCourant: 25000,
        livretA: 22300,
        assuranceVie: 125000,
        pea: 75000,
        scpi: 50000,
        actions: 128000,
        obligations: 24700,
        crypto: 0,
        immobilier: 0
      },
      passifs: {
        creditImmo: { capital: 300000, restant: 185000, mensualite: 1850, echeance: '2033-09-12' },
        creditConso: { capital: 0, restant: 0, mensualite: 0, echeance: '' },
        creditPro: { capital: 150000, restant: 95000, mensualite: 2200, echeance: '2029-06-30' }
      },
      accounts: [
        { type: 'Compte-titres', value: 200000, performance: '+8.7%' },
        { type: 'PEA-PME', value: 75000, performance: '+12.3%' },
        { type: 'Assurance-vie', value: 125000, performance: '+5.9%' },
        { type: 'FCPI', value: 50000, performance: '+15.2%' }
      ],
      rdvHistorique: [
        { date: '2024-03-08', type: 'Visio', statut: 'Réalisé', objet: 'Point marché et arbitrages', conseiller: 'Laurent Petit' },
        { date: '2024-02-20', type: 'Agence', statut: 'Réalisé', objet: 'Stratégie fiscale 2024', conseiller: 'Laurent Petit' },
        { date: '2024-04-25', type: 'Tel', statut: 'Programmé', objet: 'Suivi investissements FCPI', conseiller: 'Laurent Petit' }
      ],
      produitsSouscrits: [
        { produit: 'Compte-titres Patrimoine', dateSouscription: '2018-09-12', montant: '200 000 €', statut: 'Actif' },
        { produit: 'PEA-PME', dateSouscription: '2019-01-15', montant: '75 000 €', statut: 'Actif' },
        { produit: 'FCPI Innovation', dateSouscription: '2022-06-10', montant: '50 000 €', statut: 'Actif' },
        { produit: 'Assurance-vie Multisupports', dateSouscription: '2020-03-22', montant: '125 000 €', statut: 'Actif' }
      ],
      opportunitesCommerciales: [
        { opportunite: 'FCPI 2024', priorite: 'Moyenne', potentiel: '75 000 €', probabilite: '65%', echeance: '2024-12-31' },
        { opportunite: 'Crédit lombard', priorite: 'Faible', potentiel: '100 000 €', probabilite: '40%', echeance: '2024-07-15' }
      ],
      scoreRisque: 'AA+',
      monitoring: {
        incidents: 'Aucun',
        tauxEndettement: '35%',
        capaciteResiduelle: '3 200 €/mois',
        dernierControle: '2024-03-08'
      },
      relationClient: {
        canalPrefere: 'Visio',
        satisfaction: {
          global: 9.5,
          conseil: 9.8,
          reactivite: 9.2,
          digital: 9.0,
          tarifs: 9.0
        },
        notesConseiller: 'Client haut de gamme très exigeant. Expertise financière élevée, intérêt pour produits sophistiqués.'
      },
      tasks: [
        { id: 5, title: 'Analyse opportunités Private Equity', priority: 'Moyenne', due: '2024-03-30' },
        { id: 6, title: 'Optimisation IFI 2024', priority: 'Haute', due: '2024-04-15' }
      ],
      interactions: [
        { date: '2024-03-08', type: 'Visio', description: 'Point marché et arbitrages' },
        { date: '2024-02-20', type: 'RDV', description: 'Stratégie fiscale 2024' },
        { date: '2024-02-10', type: 'Appel', description: 'Validation ordre de bourse' }
      ]
    }
  ];

  const handleFreeSlotClick = () => {
    setShowAppointmentModal(true);
  };

  const handlePatrimoineClick = (client: any) => {
    setSelectedClient(client);
    setShowPatrimoineModal(true);
  };

  const handleContactClick = (type: string, client: any) => {
    setSelectedClient(client);
    setContactType(type);
    setShowContactModal(true);
  };

  const renderClientsSection = () => (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold">Clients et CRM</h2>
          <p className="text-gray-400">Centre de commande du conseiller - Fiche client front-office bancaire</p>
        </div>
        <div className="flex items-center space-x-4">
          <button
            onClick={() => {
              setSelectedClient({
                id: 0,
                name: '',
                email: '',
                phone: '',
                address: '',
                birthDate: '',
                civilStatus: '',
                matrimonialRegime: '',
                profession: '',
                status: 'Prospect',
                riskProfile: 'Modéré',
                totalAssets: 0,
                lastContact: new Date().toISOString().split('T')[0],
                kyc: 'À compléter',
                mifid: 'À faire',
                objectives: '',
                horizon: '',
                targetReturn: '',
                tolerance: '',
                accounts: [],
                tasks: [],
                interactions: []
              });
              setShowClientModal(true);
            }}
            className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm transition-colors cursor-pointer"
          >
            <i className="ri-user-add-line mr-2"></i>
            Nouveau client
          </button>
        </div>
      </div>

      <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold text-white">Portfolio Clients</h3>
          <div className="flex items-center space-x-4">
            <input
              type="text"
              placeholder="Rechercher un client..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
            />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-500 focus:outline-none pr-8"
            >
              <option>Tous les statuts</option>
              <option>Premium</option>
              <option>Patrimonial</option>
              <option>Prospect</option>
              <option>Inactif</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {mockClients.map((client) => (
            <div key={client.id} className="bg-gray-700/30 rounded-xl p-6 border border-gray-600/50 hover:border-yellow-500/50 transition-colors">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                    <span className="text-white font-bold text-lg">{client.name.split(' ').map(n => n[0]).join('')}</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-white">{client.name}</h4>
                    <p className="text-gray-400 text-sm">{client.profession}</p>
                  </div>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${client.status === 'Premium' ? 'bg-yellow-500/20 text-yellow-400' : client.status === 'Patrimonial' ? 'bg-purple-500/20 text-purple-400' : client.status === 'Prospect' ? 'bg-blue-500/20 text-blue-400' : 'bg-gray-500/20 text-gray-400'}`}>{client.status}</span>
              </div>

              <div
                className="space-y-2 text-sm mb-4 cursor-pointer hover:bg-gray-600/20 p-2 rounded-lg transition-colors"
                onClick={() => handlePatrimoineClick(client)}
              >
                <div className="flex justify-between">
                  <span className="text-gray-400">Patrimoine:</span>
                  <span className="text-yellow-400 font-semibold">{client.totalAssets.toLocaleString()} €</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Profil risque:</span>
                  <span className="text-white">{client.riskProfile}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Dernier contact:</span>
                  <span className="text-gray-300">{new Date(client.lastContact).toLocaleDateString('fr-FR')}</span>
                </div>
              </div>

              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <span className={`w-2 h-2 rounded-full ${client.kyc === 'Complet' ? 'bg-green-500' : client.kyc === 'En cours' ? 'bg-yellow-500' : 'bg-red-500'}`}></span>
                  <span className="text-xs text-gray-400">KYC: {client.kyc}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className={`w-2 h-2 rounded-full ${client.mifid === 'Valide' ? 'bg-green-500' : client.mifid === 'À réviser' ? 'bg-yellow-500' : 'bg-red-500'}`}></span>
                  <span className="text-xs text-gray-400">MiFID: {client.mifid}</span>
                </div>
              </div>

              <div className="flex space-x-2 mb-4">
                <button
                  onClick={() => handleContactClick('call', client)}
                  className="flex-1 bg-green-600/20 hover:bg-green-600/30 text-green-400 py-2 px-3 rounded-lg text-sm transition-colors cursor-pointer"
                >
                  <i className="ri-phone-line mr-1"></i>
                  Appel
                </button>
                <button
                  onClick={() => handleContactClick('email', client)}
                  className="flex-1 bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 py-2 px-3 rounded-lg text-sm transition-colors cursor-pointer"
                >
                  <i className="ri-mail-line mr-1"></i>
                  Email
                </button>
                <button
                  onClick={() => handleContactClick('rdv', client)}
                  className="flex-1 bg-purple-600/20 hover:bg-purple-600/30 text-purple-400 py-2 px-3 rounded-lg text-sm transition-colors cursor-pointer"
                >
                  <i className="ri-calendar-line mr-1"></i>
                  RDV
                </button>
              </div>

              <button
                onClick={() => {
                  setSelectedClient(client);
                  setActiveClientTab('general');
                  setShowClientModal(true);
                }}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap"
              >
                <i className="ri-edit-line mr-2"></i>
                Ouvrir la fiche complète
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Modal Patrimoine Détaillé */}
      {showPatrimoineModal && selectedClient && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 rounded-xl max-w-6xl w-full max-h-[95vh] overflow-y-auto border border-yellow-500/20">
            <div className="flex items-center justify-between p-6 border-b border-gray-800">
              <div>
                <h3 className="text-2xl font-bold text-white flex items-center">
                  <i className="ri-pie-chart-line text-yellow-400 mr-3"></i>
                  Patrimoine Détaillé - {selectedClient.name}
                </h3>
                <p className="text-gray-400">Vue d'ensemble des actifs et passifs</p>
              </div>
              <button
                onClick={() => setShowPatrimoineModal(false)}
                className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-800 transition-colors cursor-pointer"
              >
                <i className="ri-close-line text-xl text-gray-400 hover:text-white"></i>
              </button>
            </div>

            <div className="p-6 space-y-8">
              {/* Résumé Patrimoine */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-400 mb-2">
                      {(Object.values(selectedClient.actifs || {}).reduce((a: number, b: any) => a + (typeof b === 'number' ? b : 0), 0)).toLocaleString()} €
                    </div>
                    <div className="text-gray-400">Total Actifs</div>
                  </div>
                </div>
                <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-red-400 mb-2">
                      {selectedClient.passifs ? (selectedClient.passifs.creditImmo.restant + selectedClient.passifs.creditConso.restant + selectedClient.passifs.creditPro.restant).toLocaleString() : '0'} €
                    </div>
                    <div className="text-gray-400">Total Passifs</div>
                  </div>
                </div>
                <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-yellow-400 mb-2">
                      {selectedClient.totalAssets.toLocaleString()} €
                    </div>
                    <div className="text-gray-400">Patrimoine Net</div>
                  </div>
                </div>
              </div>

              {/* Détail des Actifs */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                  <h4 className="text-xl font-bold text-white mb-6 flex items-center">
                    <i className="ri-coin-line text-green-400 mr-2"></i>
                    Répartition des Actifs
                  </h4>
                  <div className="space-y-4">
                    {selectedClient.actifs && Object.entries(selectedClient.actifs).map(([type, value]) => {
                      const typeNames: { [key: string]: string } = {
                        compteCourant: 'Compte Courant',
                        livretA: 'Livret A',
                        assuranceVie: 'Assurance-vie',
                        pea: 'PEA',
                        scpi: 'SCPI',
                        actions: 'Actions',
                        obligations: 'Obligations',
                        crypto: 'Cryptomonnaies',
                        immobilier: 'Immobilier'
                      };

                      if (typeof value === 'number' && value > 0) {
                        const total = Object.values(selectedClient.actifs).reduce((a: number, b: any) => a + (typeof b === 'number' ? b : 0), 0);
                        const percentage = ((value / total) * 100).toFixed(1);

                        return (
                          <div key={type} className="flex items-center justify-between p-3 bg-gray-700/30 rounded-lg">
                            <div className="flex items-center">
                              <div className="w-4 h-4 bg-blue-500 rounded-full mr-3"></div>
                              <span className="text-white font-medium">{typeNames[type]}</span>
                            </div>
                            <div className="text-right">
                              <div className="text-white font-semibold">{value.toLocaleString()} €</div>
                              <div className="text-gray-400 text-sm">{percentage}%</div>
                            </div>
                          </div>
                        );
                      }
                      return null;
                    })}
                  </div>
                </div>

                {/* Détail des Passifs */}
                <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                  <h4 className="text-xl font-bold text-white mb-6 flex items-center">
                    <i className="ri-bank-card-line text-red-400 mr-2"></i>
                    Crédits en Cours
                  </h4>
                  <div className="space-y-4">
                    {selectedClient.passifs && Object.entries(selectedClient.passifs).map(([type, credit]) => {
                      const typeNames: { [key: string]: string } = {
                        creditImmo: 'Crédit Immobilier',
                        creditConso: 'Crédit Consommation',
                        creditPro: 'Crédit Professionnel'
                      };

                      if (typeof credit === 'object' && credit.restant > 0) {
                        const progress = ((credit.capital - credit.restant) / credit.capital) * 100;

                        return (
                          <div key={type} className="p-4 bg-gray-700/30 rounded-lg">
                            <div className="flex items-center justify-between mb-3">
                              <span className="text-white font-medium">{typeNames[type]}</span>
                              <span className="text-red-400 font-semibold">{credit.restant.toLocaleString()} €</span>
                            </div>
                            <div className="w-full bg-gray-600 rounded-full h-2 mb-2">
                              <div
                                className="bg-red-500 h-2 rounded-full"
                                style={{ width: `${progress}%` }}
                              ></div>
                            </div>
                            <div className="flex justify-between text-sm text-gray-400">
                              <span>Mensualité: {credit.mensualite} €</span>
                              <span>Échéance: {credit.echeance}</span>
                            </div>
                          </div>
                        );
                      }
                      return null;
                    })}
                  </div>
                </div>
              </div>

              {/* Évolution Patrimoine */}
              <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                <h4 className="text-xl font-bold text-white mb-6 flex items-center">
                  <i className="ri-line-chart-line text-blue-400 mr-2"></i>
                  Évolution du Patrimoine (12 derniers mois)
                </h4>
                <div className="h-40 flex items-end space-x-2">
                  {[285000, 278000, 290000, 295000, 288000, 275000, 285000, 290000, 295000, 285000, 280000, 285000].map((value, index) => (
                    <div key={index} className="flex-1 bg-gradient-to-t from-blue-600 to-blue-400 rounded-t" style={{ height: `${(value / 300000) * 100}%` }}>
                      <div className="text-xs text-white text-center mt-1">{Math.round(value/1000)}K</div>
                    </div>
                  ))}
                </div>
                <div className="flex justify-between text-gray-400 text-sm mt-4">
                  <span>Mars 2023</span>
                  <span>Mars 2024</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal Contact */}
      {showContactModal && selectedClient && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 rounded-xl max-w-md w-full p-6 border border-yellow-500/20">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-white flex items-center">
                {contactType === 'call' && <><i className="ri-phone-line text-green-400 mr-2"></i>Appeler {selectedClient.name}</>}
                {contactType === 'email' && <><i className="ri-mail-line text-blue-400 mr-2"></i>Email à {selectedClient.name}</>}
                {contactType === 'rdv' && <><i className="ri-calendar-line text-purple-400 mr-2"></i>RDV avec {selectedClient.name}</>}
              </h3>
              <button
                onClick={() => setShowContactModal(false)}
                className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-800 transition-colors cursor-pointer"
              >
                <i className="ri-close-line text-xl text-gray-400 hover:text-white"></i>
              </button>
            </div>

            <div className="space-y-4">
              {contactType === 'call' && (
                <div className="text-center space-y-4">
                  <div className="w-20 h-20 bg-green-600/20 rounded-full flex items-center justify-center mx-auto">
                    <i className="ri-phone-line text-3xl text-green-400"></i>
                  </div>
                  <div>
                    <p className="text-white font-semibold text-lg">{selectedClient.phone}</p>
                    <p className="text-gray-400">Téléphone mobile</p>
                  </div>
                  <div className="flex space-x-3">
                    <button className="flex-1 bg-green-600 hover:bg-green-700 text-white py-3 px-4 rounded-lg transition-colors cursor-pointer">
                      <i className="ri-phone-line mr-2"></i>
                      Composer
                    </button>
                    <button className="flex-1 bg-gray-700 hover:bg-gray-600 text-white py-3 px-4 rounded-lg transition-colors cursor-pointer">
                      <i className="ri-message-line mr-2"></i>
                      SMS
                    </button>
                  </div>
                </div>
              )}

              {contactType === 'email' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-gray-400 text-sm mb-2">Destinataire</label>
                    <input
                      type="email"
                      value={selectedClient.email}
                      readOnly
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 text-sm mb-2">Objet</label>
                    <input
                      type="text"
                      placeholder="Objet de l'email..."
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-400 text-sm mb-2">Message</label>
                    <textarea
                      rows={4}
                      placeholder="Votre message..."
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-500 focus:outline-none resize-none"
                    />
                  </div>
                  <div className="flex space-x-3">
                    <button className="flex-1 bg-gray-700 hover:bg-gray-600 text-white py-2 px-4 rounded-lg transition-colors cursor-pointer">
                      Brouillon
                    </button>
                    <button className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors cursor-pointer">
                      Envoyer
                    </button>
                  </div>
                </div>
              )}

              {contactType === 'rdv' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-400 text-sm mb-2">Date</label>
                      <input
                        type="date"
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-400 text-sm mb-2">Heure</label>
                      <input
                        type="time"
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-gray-400 text-sm mb-2">Type</label>
                    <select className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-500 focus:outline-none pr-8">
                      <option>Rendez-vous présentiel</option>
                      <option>Appel téléphonique</option>
                      <option>Visioconférence</option>
                      <option>Signature documents</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-gray-400 text-sm mb-2">Objet</label>
                    <textarea
                      rows={3}
                      placeholder="Objet du rendez-vous..."
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-500 focus:outline-none resize-none"
                    />
                  </div>

                  <div className="flex space-x-3">
                    <button className="flex-1 bg-gray-700 hover:bg-gray-600 text-white py-2 px-4 rounded-lg transition-colors cursor-pointer">
                      Annuler
                    </button>
                    <button className="flex-1 bg-purple-600 hover:bg-purple-700 text-white py-2 px-4 rounded-lg transition-colors cursor-pointer">
                      Programmer
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Modal Client Complet */}
      {showClientModal && selectedClient && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 rounded-xl max-w-7xl w-full max-h-[95vh] overflow-y-auto border border-yellow-500/20">
            <div className="flex items-center justify-between p-6 border-b border-gray-800">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-xl">{selectedClient.name.split(' ').map((n: string) => n[0]).join('')}</span>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white">{selectedClient.name || 'Nouveau Client'}</h3>
                  <div className="flex items-center space-x-4 text-sm text-gray-400">
                    <span>N° Client: {selectedClient.clientNumber}</span>
                    <span>Conseiller: {selectedClient.conseiller}</span>
                    <span className={`px-2 py-1 rounded-full text-xs ${selectedClient.status === 'Premium' ? 'bg-yellow-500/20 text-yellow-400' : selectedClient.status === 'Patrimonial' ? 'bg-purple-500/20 text-purple-400' : 'bg-blue-500/20 text-blue-400'}`}>
                      {selectedClient.status}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <button
                  onClick={() => handleContactClick('call', selectedClient)}
                  className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm transition-colors cursor-pointer"
                >
                  <i className="ri-phone-line mr-2"></i>
                  Appel
                </button>
                <button
                  onClick={() => handleContactClick('rdv', selectedClient)}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm transition-colors cursor-pointer"
                >
                  <i className="ri-calendar-line mr-2"></i>
                  RDV
                </button>
                <button
                  onClick={() => handleContactClick('email', selectedClient)}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm transition-colors cursor-pointer"
                >
                  <i className="ri-mail-line mr-2"></i>
                  Email
                </button>
                <button className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-sm transition-colors cursor-pointer">
                  <i className="ri-file-pdf-line mr-2"></i>
                  Rapport PDF
                </button>
                <button
                  onClick={() => setShowClientModal(false)}
                  className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-800 transition-colors cursor-pointer"
                >
                  <i className="ri-close-line text-xl text-gray-400 hover:text-white"></i>
                </button>
              </div>
            </div>

            {/* Navigation Tabs */}
            <div className="flex space-x-1 p-6 pb-0">
              {[
                { id: 'general', label: 'Général', icon: 'ri-user-line' },
                { id: 'patrimoine', label: 'Patrimoine', icon: 'ri-pie-chart-line' },
                { id: 'commercial', label: 'Commercial', icon: 'ri-briefcase-line' },
                { id: 'risque', label: 'Gestion Risque', icon: 'ri-shield-check-line' },
                { id: 'relation', label: 'Relation Client', icon: 'ri-customer-service-line' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveClientTab(tab.id)}
                  className={`px-4 py-2 rounded-t-lg transition-colors cursor-pointer flex items-center whitespace-nowrap ${activeClientTab === tab.id ? 'bg-yellow-500/20 text-yellow-400 border-b-2 border-yellow-500' : 'text-gray-400 hover:text-white hover:bg-gray-800'}`}
                >
                  <i className={`${tab.icon} mr-2`}></i>
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="p-6">
              {activeClientTab === 'general' && (
                <div className="space-y-6">
                  {/* Informations personnelles existantes */}
                  <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                    <div className="flex items-center justify-between mb-6">
                      <h4 className="text-xl font-bold text-white flex items-center">
                        <i className="ri-user-3-line text-blue-400 mr-2"></i>
                        Informations Personnelles & Coordonnées
                      </h4>
                      <div className="flex space-x-2">
                        <button className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-sm transition-colors cursor-pointer">
                          <i className="ri-edit-line mr-1"></i>
                          Modifier
                        </button>
                        <button className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white rounded text-sm transition-colors cursor-pointer">
                          <i className="ri-refresh-line mr-1"></i>
                          Enrichir
                        </button>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-3 gap-6 mb-6">
                      <div>
                        <label className="block text-gray-400 text-sm mb-2">Nom complet *</label>
                        <input
                          type="text"
                          defaultValue={selectedClient.name}
                          className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-gray-400 text-sm mb-2">Email *</label>
                        <input
                          type="email"
                          defaultValue={selectedClient.email}
                          className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-gray-400 text-sm mb-2">Téléphone *</label>
                        <input
                          type="tel"
                          defaultValue={selectedClient.phone}
                          className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6 mb-6">
                      <div>
                        <label className="block text-gray-400 text-sm mb-2">Adresse complète</label>
                        <input
                          type="text"
                          defaultValue={selectedClient.address}
                          className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-gray-400 text-sm mb-2">Profession</label>
                        <input
                          type="text"
                          defaultValue={selectedClient.profession}
                          className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="border-t border-gray-700 pt-6">
                      <h5 className="text-lg font-semibold text-white mb-4">Profil Civil</h5>
                      <div className="grid md:grid-cols-3 gap-6">
                        <div>
                          <label className="block text-gray-400 text-sm mb-2">Date de naissance</label>
                          <input
                            type="date"
                            defaultValue={selectedClient.birthDate}
                            className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-gray-400 text-sm mb-2">Situation familiale</label>
                          <select className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none pr-8">
                            <option value={selectedClient.civilStatus}>{selectedClient.civilStatus}</option>
                            <option>Célibataire</option>
                            <option>Marié(e)</option>
                            <option>Pacsé(e)</option>
                            <option>Divorcé(e)</option>
                            <option>Veuf(ve)</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-gray-400 text-sm mb-2">Régime matrimonial</label>
                          <select className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none pr-8">
                            <option value={selectedClient.matrimonialRegime}>{selectedClient.matrimonialRegime}</option>
                            <option>Communauté réduite aux acquêts</option>
                            <option>Communauté universelle</option>
                            <option>Séparation de biens</option>
                            <option>Participation aux acquêts</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeClientTab === 'patrimoine' && (
                <div className="space-y-6">
                  {/* Même contenu que le modal patrimoine mais intégré */}
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-green-400 mb-2">
                          {selectedClient.actifs ? (Object.values(selectedClient.actifs).reduce((a: number, b: any) => a + (typeof b === 'number' ? b : 0), 0)).toLocaleString() : '0'} €
                        </div>
                        <div className="text-gray-400">Total Actifs</div>
                        <div className="w-16 h-16 mx-auto mt-4 mb-2">
                          <svg className="w-16 h-16 transform -rotate-90">
                            <circle cx="32" cy="32" r="28" stroke="#374151" strokeWidth="6" fill="transparent" />
                            <circle cx="32" cy="32" r="28" stroke="#10b981" strokeWidth="6" fill="transparent" strokeDasharray={`${2 * Math.PI * 28 * 0.85} ${2 * Math.PI * 28}`} strokeLinecap="round" />
                          </svg>
                        </div>
                      </div>
                    </div>
                    <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-red-400 mb-2">
                          {selectedClient.passifs ? (selectedClient.passifs.creditImmo.restant + selectedClient.passifs.creditConso.restant + selectedClient.passifs.creditPro.restant).toLocaleString() : '0'} €
                        </div>
                        <div className="text-gray-400">Total Passifs</div>
                        <div className="w-16 h-16 mx-auto mt-4 mb-2">
                          <svg className="w-16 h-16 transform -rotate-90">
                            <circle cx="32" cy="32" r="28" stroke="#374151" strokeWidth="6" fill="transparent" />
                            <circle cx="32" cy="32" r="28" stroke="#ef4444" strokeWidth="6" fill="transparent" strokeDasharray={`${2 * Math.PI * 28 * 0.35} ${2 * Math.PI * 28}`} strokeLinecap="round" />
                          </svg>
                        </div>
                      </div>
                    </div>
                    <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-yellow-400 mb-2">
                          {selectedClient.totalAssets.toLocaleString()} €
                        </div>
                        <div className="text-gray-400">Patrimoine Net</div>
                        <div className="w-16 h-16 mx-auto mt-4 mb-2">
                          <svg className="w-16 h-16 transform -rotate-90">
                            <circle cx="32" cy="32" r="28" stroke="#374151" strokeWidth="6" fill="transparent" />
                            <circle cx="32" cy="32" r="28" stroke="#f59e0b" strokeWidth="6" fill="transparent" strokeDasharray={`${2 * Math.PI * 28 * 0.70} ${2 * Math.PI * 28}`} strokeLinecap="round" />
                          </svg>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                      <h4 className="text-xl font-bold text-white mb-6 flex items-center">
                        <i className="ri-coin-line text-green-400 mr-2"></i>
                        Répartition des Actifs
                      </h4>
                      <div className="space-y-3">
                        {selectedClient.actifs && Object.entries(selectedClient.actifs).map(([type, value]) => {
                          const typeNames: { [key: string]: string } = {
                            compteCourant: 'Compte Courant',
                            livretA: 'Livret A',
                            assuranceVie: 'Assurance-vie',
                            pea: 'PEA',
                            scpi: 'SCPI',
                            actions: 'Actions',
                            obligations: 'Obligations',
                            crypto: 'Cryptomonnaies',
                            immobilier: 'Immobilier'
                          };

                          if (typeof value === 'number' && value > 0) {
                            const total = Object.values(selectedClient.actifs).reduce((a: number, b: any) => a + (typeof b === 'number' ? b : 0), 0);
                            const percentage = ((value / total) * 100).toFixed(1);

                            return (
                              <div key={type} className="flex items-center justify-between p-3 bg-gray-700/30 rounded-lg hover:bg-gray-700/50 transition-colors">
                                <div className="flex items-center">
                                  <div className="w-3 h-3 bg-gradient-to-r from-blue-500 to-green-500 rounded-full mr-3"></div>
                                  <span className="text-white font-medium">{typeNames[type]}</span>
                                </div>
                                <div className="text-right">
                                  <div className="text-white font-semibold">{value.toLocaleString()} €</div>
                                  <div className="text-gray-400 text-sm">{percentage}%</div>
                                </div>
                              </div>
                            );
                          }
                          return null;
                        })}
                      </div>
                    </div>

                    <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                      <h4 className="text-xl font-bold text-white mb-6 flex items-center">
                        <i className="ri-bank-card-line text-red-400 mr-2"></i>
                        Crédits en Cours
                      </h4>
                      <div className="space-y-4">
                        {selectedClient.passifs && Object.entries(selectedClient.passifs).map(([type, credit]) => {
                          const typeNames: { [key: string]: string } = {
                            creditImmo: 'Crédit Immobilier',
                            creditConso: 'Crédit Consommation',
                            creditPro: 'Crédit Professionnel'
                          };

                          if (typeof credit === 'object' && credit.restant > 0) {
                            const progress = ((credit.capital - credit.restant) / credit.capital) * 100;

                            return (
                              <div key={type} className="p-4 bg-gray-700/30 rounded-lg">
                                <div className="flex items-center justify-between mb-3">
                                  <span className="text-white font-medium">{typeNames[type]}</span>
                                  <span className="text-red-400 font-semibold">{credit.restant.toLocaleString()} €</span>
                                </div>
                                <div className="w-full bg-gray-600 rounded-full h-3 mb-2">
                                  <div
                                    className="bg-gradient-to-r from-red-600 to-red-400 h-3 rounded-full"
                                    style={{ width: `${progress}%` }}
                                  ></div>
                                </div>
                                <div className="flex justify-between text-sm text-gray-400">
                                  <span>Mensualité: {credit.mensualite} €</span>
                                  <span>Échéance: {credit.echeance}</span>
                                </div>
                                <div className="text-xs text-gray-500 mt-1">
                                  Remboursé à {progress.toFixed(1)}%
                                </div>
                              </div>
                            );
                          }
                          return null;
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeClientTab === 'commercial' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                      <h4 className="text-xl font-bold text-white mb-6 flex items-center">
                        <i className="ri-calendar-check-line text-blue-400 mr-2"></i>
                        Historique RDV
                      </h4>
                      <div className="space-y-3">
                        {selectedClient.rdvHistorique && selectedClient.rdvHistorique.map((rdv: any, index: number) => (
                          <div key={index} className={`p-3 rounded-lg border-l-4 ${rdv.statut === 'Réalisé' ? 'bg-green-500/10 border-green-500' : 'bg-blue-500/10 border-blue-500'}`}>
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-white font-medium">{rdv.date}</span>
                              <span className={`px-2 py-1 rounded-full text-xs ${rdv.statut === 'Réalisé' ? 'bg-green-500/20 text-green-400' : 'bg-blue-500/20 text-blue-400'}`}>
                                {rdv.statut}
                              </span>
                            </div>
                            <div className="text-sm text-gray-300">{rdv.objet}</div>
                            <div className="text-xs text-gray-400 mt-1">
                              <i className={`${rdv.type === 'Visio' ? 'ri-vidicon-line' : rdv.type === 'Agence' ? 'ri-building-line' : 'ri-phone-line'}`} />
                              {rdv.type} • {rdv.conseiller}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                      <h4 className="text-xl font-bold text-white mb-6 flex items-center">
                        <i className="ri-shopping-bag-line text-green-400 mr-2"></i>
                        Produits Souscrits
                      </h4>
                      <div className="space-y-3">
                        {selectedClient.produitsSouscrits && selectedClient.produitsSouscrits.map((produit: any, index: number) => (
                          <div key={index} className="p-3 bg-gray-700/30 rounded-lg">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-white font-medium">{produit.produit}</span>
                              <span className="text-green-400 font-semibold">{produit.montant}</span>
                            </div>
                            <div className="flex justify-between text-sm text-gray-400">
                              <span>Souscrit le {produit.dateSouscription}</span>
                              <span className="text-green-400">{produit.statut}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                    <h4 className="text-xl font-bold text-white mb-6 flex items-center">
                      <i className="ri-target-line text-orange-400 mr-2"></i>
                      Opportunités Cross-selling
                    </h4>
                    <div className="space-y-3">
                      {selectedClient.opportunitesCommerciales && selectedClient.opportunitesCommerciales.map((opp: any, index: number) => (
                        <div key={index} className="p-4 bg-gray-700/30 rounded-lg">
                          <div className="flex items-center justify-between mb-3">
                            <span className="text-white font-semibold">{opp.opportunite}</span>
                            <div className="flex items-center space-x-3">
                              <span className={`px-2 py-1 rounded-full text-xs ${opp.priorite === 'Urgente' ? 'bg-red-500/20 text-red-400' : opp.priorite === 'Haute' ? 'bg-orange-500/20 text-orange-400' : opp.priorite === 'Moyenne' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-gray-500/20 text-gray-400'}`}>
                                {opp.priorite}
                              </span>
                              <span className="text-green-400 font-semibold">{opp.potentiel}</span>
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-gray-400">Probabilité: </span>
                              <span className="text-white">{opp.probabilite}</span>
                            </div>
                            <div>
                              <span className="text-gray-400">Échéance: </span>
                              <span className="text-white">{opp.echeance}</span>
                            </div>
                          </div>
                          <div className="mt-3">
                            <div className="w-full bg-gray-600 rounded-full h-2">
                              <div
                                className="bg-gradient-to-r from-blue-500 to-green-500 h-2 rounded-full"
                                style={{ width: opp.probabilite }}
                              ></div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {activeClientTab === 'risque' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="bg-gray-800 rounded-xl p-6 border border-gray-700 text-center">
                      <div className="w-20 h-20 bg-green-600/20 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i className="ri-shield-check-line text-3xl text-green-400"></i>
                      </div>
                      <div className="text-2xl font-bold text-green-400 mb-2">{selectedClient.scoreRisque}</div>
                      <div className="text-gray-400">Score de Risque</div>
                      <div className="text-sm text-green-400 mt-2">Excellent</div>
                    </div>

                    <div className="bg-gray-800 rounded-xl p-6 border border-gray-700 text-center">
                      <div className="w-20 h-20 bg-blue-600/20 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i className="ri-radar-line text-3xl text-blue-400"></i>
                      </div>
                      <div className="text-2xl font-bold text-green-400 mb-2">
                        <i className="ri-check-line mr-1"></i>
                        Actif
                      </div>
                      <div className="text-gray-400">Monitoring</div>
                      <div className="text-sm text-green-400 mt-2">Temps réel</div>
                    </div>

                    <div className="bg-gray-800 rounded-xl p-6 border border-gray-700 text-center">
                      <div className="w-20 h-20 bg-yellow-600/20 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i className="ri-percent-line text-3xl text-yellow-400"></i>
                      </div>
                      <div className="text-2xl font-bold text-yellow-400 mb-2">{selectedClient.monitoring.tauxEndettement}</div>
                      <div className="text-gray-400">Taux Endettement</div>
                      <div className="text-sm text-yellow-400 mt-2">Sous seuil</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                      <h4 className="text-xl font-bold text-white mb-6 flex items-center">
                        <i className="ri-alert-line text-yellow-400 mr-2"></i>
                        Suivi des Risques
                      </h4>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between p-3 bg-green-500/10 rounded-lg border border-green-500/30">
                          <div className="flex items-center">
                            <i className="ri-check-line text-green-400 mr-3"></i>
                            <span className="text-white">Incidents de paiement</span>
                          </div>
                          <span className="text-green-400 font-semibold">{selectedClient.monitoring.incidents}</span>
                        </div>

                        <div className="flex items-center justify-between p-3 bg-blue-500/10 rounded-lg border border-blue-500/30">
                          <div className="flex items-center">
                            <i className="ri-money-euro-circle-line text-blue-400 mr-3"></i>
                            <span className="text-white">Capacité résiduelle</span>
                          </div>
                          <span className="text-blue-400 font-semibold">{selectedClient.monitoring.capaciteResiduelle}</span>
                        </div>

                        <div className="flex items-center justify-between p-3 bg-purple-500/10 rounded-lg border border-purple-500/30">
                          <div className="flex items-center">
                            <i className="ri-calendar-check-line text-purple-400 mr-3"></i>
                            <span className="text-white">Dernier contrôle</span>
                          </div>
                          <span className="text-purple-400 font-semibold">{selectedClient.monitoring.dernierControle}</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                      <h4 className="text-xl font-bold text-white mb-6 flex items-center">
                        <i className="ri-line-chart-line text-green-400 mr-2"></i>
                        Évolution Score Risque
                      </h4>
                      <div className="h-32 flex items-end space-x-2 mb-4">
                        {['AA+', 'AA+', 'AAA', 'AAA', 'AAA', 'AAA', 'AAA', 'AAA'].map((score, index) => (
                          <div key={index} className="flex-1 bg-gradient-to-t from-green-600 to-green-400 rounded-t" style={{ height: `${score === 'AAA' ? 90 : 75}%` }}></div>
                        ))}
                      </div>
                      <div className="text-center text-green-400 font-semibold">
                        Évolution positive stable
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeClientTab === 'relation' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                      <h4 className="text-xl font-bold text-white mb-6 flex items-center">
                        <i className="ri-customer-service-line text-blue-400 mr-2"></i>
                        Préférences de Contact
                      </h4>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between p-3 bg-blue-500/10 rounded-lg">
                          <div className="flex items-center">
                            <i className="ri-vidicon-line text-blue-400 mr-3"></i>
                            <span className="text-white">Canal préféré</span>
                          </div>
                          <span className="text-blue-400 font-semibold">{selectedClient.relationClient.canalPrefere}</span>
                        </div>

                        <div className="space-y-3">
                          <h5 className="text-lg font-semibold text-white">Satisfaction Client (NPS)</h5>
                          {selectedClient.relationClient.satisfaction && Object.entries(selectedClient.relationClient.satisfaction).map(([critere, note]) => (
                            <div key={critere} className="flex items-center justify-between">
                              <span className="text-gray-300 capitalize">{critere}</span>
                              <div className="flex items-center">
                                <div className="w-20 bg-gray-600 rounded-full h-2 mr-3">
                                  <div
                                    className="bg-gradient-to-r from-green-400 to-green-600 h-2 rounded-full"
                                    style={{ width: `${(note as number / 10) * 100}%` }}
                                  ></div>
                                </div>
                                <span className="text-green-400 font-bold text-sm w-8">{note}/10</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
                      <h4 className="text-xl font-bold text-white mb-6 flex items-center">
                        <i className="ri-edit-box-line text-green-400 mr-2"></i>
                        Notes Conseiller
                      </h4>
                      <div className="space-y-4">
                        <div className="bg-gray-700/30 rounded-lg p-4">
                          <div className="text-sm text-gray-400 mb-2">Note actuelle:</div>
                          <div className="text-white">{selectedClient.relationClient.notesConseiller}</div>
                        </div>

                        <div>
                          <label className="block text-gray-400 text-sm mb-2">Ajouter une note</label>
                          <textarea
                            rows={4}
                            placeholder="Nouvelle observation sur le client..."
                            className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none resize-none"
                          />
                          <div className="flex justify-end mt-2">
                            <button className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm transition-colors cursor-pointer">
                              <i className="ri-save-line mr-2"></i>
                              Sauvegarder
                            </button>
                          </div>
                        </div>

                        <div className="bg-green-500/10 rounded-lg p-4 border border-green-500/30">
                          <div className="text-sm text-green-400 mb-1">Historique des notes</div>
                          <div className="text-xs text-gray-400">
                            • 10/03/2024: Souhaite développer son épargne retraite<br />
                            • 15/02/2024: Intéressée par les SCPI<br />
                            • 28/01/2024: Cliente très satisfaite du service
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {showAppointmentModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 rounded-xl max-w-md w-full p-6 border border-yellow-500/20">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-white">Créer un rendez-vous</h3>
              <button
                onClick={() => setShowAppointmentModal(false)}
                className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-800 transition-colors cursor-pointer"
              >
                <i className="ri-close-line text-xl text-gray-400 hover:text-white"></i>
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-gray-400 text-sm mb-2">Client</label>
                <select className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-500 focus:outline-none pr-8">
                  <option>Sélectionner un client...</option>
                  {mockClients.map(client => (
                    <option key={client.id} value={client.id}>{client.name}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-gray-400 text-sm mb-2">Date</label>
                  <input
                    type="date"
                    className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-gray-400 text-sm mb-2">Heure</label>
                  <input
                    type="time"
                    className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-gray-400 text-sm mb-2">Type</label>
                <select className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-500 focus:outline-none pr-8">
                  <option>Rendez-vous présentiel</option>
                  <option>Appel téléphonique</option>
                  <option>Visioconférence</option>
                  <option>Signature documents</option>
                </select>
              </div>

              <div>
                <label className="block text-gray-400 text-sm mb-2">Objet</label>
                <textarea
                  rows={3}
                  placeholder="Objet du rendez-vous..."
                  className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-500 focus:outline-none resize-none"
                />
              </div>

              <div className="flex space-x-4 pt-4">
                <button
                  onClick={() => setShowAppointmentModal(false)}
                  className="flex-1 bg-gray-700 hover:bg-gray-600 text-white py-2 px-4 rounded-lg transition-colors cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  onClick={() => setShowAppointmentModal(false)}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-lg transition-colors cursor-pointer"
                >
                  Créer RDV
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  const renderOverviewSection = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold text-white">Tableau de Bord Banquier</h2>
          <p className="text-gray-400">Dashboard professionnel - Écran haute résolution</p>
        </div>
        <div className="flex items-center space-x-3">
          <div className="text-right">
            <div className="text-green-400 text-sm font-semibold">Dernière MAJ</div>
            <div className="text-gray-300 text-xs" suppressHydrationWarning={true}>{new Date().toLocaleTimeString('fr-FR')}</div>
          </div>
          <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm transition-colors cursor-pointer">
            <i className="ri-refresh-line mr-2"></i>
            Actualiser
          </button>
        </div>
      </div>

      {/* 1. ENCOURS SOUS GESTION */}
      <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-6 border border-gray-700 shadow-2xl">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-blue-600/20 rounded-xl flex items-center justify-center mr-4">
              <i className="ri-bank-line text-2xl text-blue-400"></i>
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">Encours Sous Gestion</h3>
              <p className="text-gray-400 text-sm">Dépôts • Épargne • Crédits</p>
            </div>
          </div>
          <div className="text-green-400 text-lg font-bold">+8.3% YTD</div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-600/50">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center">
                <i className="ri-safe-line text-green-400 mr-2"></i>
                <span className="text-gray-300 font-medium">Dépôts</span>
              </div>
              <span className="text-green-400 text-sm">+5.2%</span>
            </div>
            <div className="text-2xl font-bold text-white mb-2">127.8M €</div>
            <div className="w-full bg-gray-700 rounded-full h-3 mb-2">
              <div className="bg-green-500 h-3 rounded-full" style={{ width: '78%' }}></div>
            </div>
            <div className="text-gray-400 text-xs mt-1">Objectif: 164M € (78%)</div>
          </div>

          <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-600/50">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center">
                <i className="ri-piggy-bank-line text-blue-400 mr-2"></i>
                <span className="text-gray-300 font-medium">Épargne</span>
              </div>
              <span className="text-blue-400 text-sm">+12.1%</span>
            </div>
            <div className="text-2xl font-bold text-white mb-2">89.4M €</div>
            <div className="w-full bg-gray-700 rounded-full h-3">
              <div className="bg-blue-500 h-3 rounded-full" style={{ width: '85%' }}></div>
            </div>
            <div className="text-gray-400 text-xs mt-1">Objectif: 105M € (85%)</div>
          </div>

          <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-600/50">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center">
                <i className="ri-money-euro-circle-line text-orange-400 mr-2"></i>
                <span className="text-gray-300 font-medium">Crédits</span>
              </div>
              <span className="text-orange-400 text-sm">+3.7%</span>
            </div>
            <div className="text-2xl font-bold text-white mb-2">156.2M €</div>
            <div className="w-full bg-gray-700 rounded-full h-3">
              <div className="bg-orange-500 h-3 rounded-full" style={{ width: '92%' }}></div>
            </div>
            <div className="text-gray-400 text-xs mt-1">Objectif: 170M € (92%)</div>
          </div>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-gray-700/30 rounded-lg p-3 text-center">
            <div className="text-lg font-bold text-white">373.4M €</div>
            <div className="text-gray-400 text-sm">Total Encours</div>
          </div>
          <div className="bg-gray-700/30 rounded-lg p-3 text-center">
            <div className="text-lg font-bold text-green-400">+7.8%</div>
            <div className="text-gray-400 text-sm">Croissance</div>
          </div>
          <div className="bg-gray-700/30 rounded-lg p-3 text-center">
            <div className="text-lg font-bold text-blue-400">2,847</div>
            <div className="text-gray-400 text-sm">Clients Actifs</div>
          </div>
          <div className="bg-gray-700/30 rounded-lg p-3 text-center">
            <div className="text-lg font-bold text-purple-400">131K €</div>
            <div className="text-gray-400 text-sm">Encours Moyen</div>
          </div>
        </div>
      </div>

      {/* 2. ACTIONS RAPIDES */}
      <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-6 border border-gray-700">
        <div className="flex items-center mb-6">
          <div className="w-12 h-12 bg-purple-600/20 rounded-xl flex items-center justify-center mr-4">
            <i className="ri-flashlight-line text-2xl text-purple-400"></i>
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">Actions Rapides</h3>
            <p className="text-gray-400 text-sm">Raccourcis vers les tâches courantes</p>
          </div>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <button
            onClick={() => setActiveSection('clients')}
            className="bg-gray-700/50 hover:bg-gray-600/50 p-4 rounded-xl border border-gray-600/50 hover:border-blue-500/50 transition-all cursor-pointer"
          >
            <i className="ri-user-add-line text-2xl text-blue-400 mb-3"></i>
            <div className="text-white font-semibold">Nouveau Client</div>
            <div className="text-gray-400 text-sm">Créer une fiche</div>
          </button>

          <button
            onClick={handleFreeSlotClick}
            className="bg-gray-700/50 hover:bg-gray-600/50 p-4 rounded-xl border border-gray-600/50 hover:border-blue-500/50 transition-all cursor-pointer"
          >
            <i className="ri-calendar-line text-2xl text-blue-400 mb-3"></i>
            <div className="text-white font-semibold">RDV</div>
            <div className="text-gray-400 text-sm">Programmer</div>
          </button>

          <button className="bg-gray-700/50 hover:bg-gray-600/50 p-4 rounded-xl border border-gray-600/50 hover:border-green-500/50 transition-all cursor-pointer">
            <i className="ri-file-text-line text-2xl text-green-400 mb-3"></i>
            <div className="text-white font-semibold">Rapport</div>
            <div className="text-gray-400 text-sm">Générer PDF</div>
          </button>

          <button className="bg-gray-700/50 hover:bg-gray-600/50 p-4 rounded-xl border border-gray-600/50 hover:border-orange-500/50 transition-all cursor-pointer">
            <i className="ri-phone-line text-2xl text-orange-400 mb-3"></i>
            <div className="text-white font-semibold">Appel</div>
            <div className="text-gray-400 text-sm">Lancer</div>
          </button>
        </div>
      </div>

      {/* 3. CLIENTS PRIORITAIRES */}
      <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-6 border border-gray-700">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-red-600/20 rounded-xl flex items-center justify-center mr-4">
              <i className="ri-star-line text-2xl text-red-400"></i>
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">Clients Prioritaires</h3>
              <p className="text-gray-400 text-sm">Suivi et actions urgentes</p>
            </div>
          </div>
          <button
            onClick={() => setActiveSection('clients')}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm transition-colors cursor-pointer"
          >
            Voir tout le CRM
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {mockClients.slice(0, 3).map((client) => (
            <div key={client.id} className="bg-gray-700/30 rounded-lg p-4 border border-gray-600/50 hover:border-yellow-500/50 transition-colors">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center mr-3">
                    <span className="text-white font-bold text-sm">{client.name.split(' ').map(n => n[0]).join('')}</span>
                  </div>
                  <div>
                    <div className="text-white font-semibold">{client.name}</div>
                    <div className="text-gray-400 text-xs">{client.profession}</div>
                  </div>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${client.status === 'Premium' ? 'bg-yellow-500/20 text-yellow-400' : client.status === 'Patrimonial' ? 'bg-purple-500/20 text-purple-400' : 'bg-blue-500/20 text-blue-400'}`}>
                  {client.status}
                </span>
              </div>

              <div className="space-y-2 text-sm mb-3">
                <div className="flex justify-between">
                  <span className="text-gray-400">Patrimoine:</span>
                  <span className="text-yellow-400 font-semibold">{client.totalAssets.toLocaleString()} €</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Dernier contact:</span>
                  <span className="text-gray-300">{new Date(client.lastContact).toLocaleDateString('fr-FR')}</span>
                </div>
              </div>

              <div className="flex space-x-2">
                <button
                  onClick={() => handleContactClick('call', client)}
                  className="flex-1 bg-green-600/20 hover:bg-green-600/30 text-green-400 py-2 px-2 rounded text-xs transition-colors cursor-pointer"
                >
                  <i className="ri-phone-line mr-1"></i>Appel
                </button>
                <button
                  onClick={() => handleContactClick('rdv', client)}
                  className="flex-1 bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 py-2 px-2 rounded text-xs transition-colors cursor-pointer"
                >
                  <i className="ri-calendar-line mr-1"></i>RDV
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 4. INDICATEURS DE PERFORMANCE */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center mb-6">
            <div className="w-12 h-12 bg-green-600/20 rounded-xl flex items-center justify-center mr-4">
              <i className="ri-line-chart-line text-2xl text-green-400"></i>
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">Performance Mensuelle</h3>
              <p className="text-gray-400 text-sm">Objectifs vs Réalisé</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-gray-700/30 rounded-lg">
              <div>
                <div className="text-white font-semibold">Nouveaux clients</div>
                <div className="text-gray-400 text-sm">Objectif: 25</div>
              </div>
              <div className="text-right">
                <div className="text-green-400 font-bold text-xl">23</div>
                <div className="text-green-400 text-sm">92%</div>
              </div>
            </div>

            <div className="flex items-center justify-between p-3 bg-gray-700/30 rounded-lg">
              <div>
                <div className="text-white font-semibold">Encours collectés</div>
                <div className="text-gray-400 text-sm">Objectif: 15M €</div>
              </div>
              <div className="text-right">
                <div className="text-blue-400 font-bold text-xl">16.8M €</div>
                <div className="text-blue-400 text-sm">112%</div>
              </div>
            </div>

            <div className="flex items-center justify-between p-3 bg-gray-700/30 rounded-lg">
              <div>
                <div className="text-white font-semibold">RDV réalisés</div>
                <div className="text-gray-400 text-sm">Objectif: 180</div>
              </div>
              <div className="text-right">
                <div className="text-purple-400 font-bold text-xl">165</div>
                <div className="text-purple-400 text-sm">92%</div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-6 border border-gray-700">
          <div className="flex items-center mb-6">
            <div className="w-12 h-12 bg-yellow-600/20 rounded-xl flex items-center justify-center mr-4">
              <i className="ri-trophy-line text-2xl text-yellow-400"></i>
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">Activité Aujourd'hui</h3>
              <p className="text-gray-400 text-sm">Actions en cours</p>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center p-3 bg-blue-500/10 rounded-lg border border-blue-500/30">
              <i className="ri-calendar-check-line text-blue-400 mr-3"></i>
              <div className="flex-1">
                <div className="text-white font-semibold">6 RDV programmés</div>
                <div className="text-gray-400 text-sm">Dont 2 nouveaux prospects</div>
              </div>
            </div>

            <div className="flex items-center p-3 bg-green-500/10 rounded-lg border border-green-500/30">
              <i className="ri-phone-line text-green-400 mr-3"></i>
              <div className="flex-1">
                <div className="text-white font-semibold">12 appels à effectuer</div>
                <div className="text-gray-400 text-sm">Suivi portefeuille</div>
              </div>
            </div>

            <div className="flex items-center p-3 bg-orange-500/10 rounded-lg border border-orange-500/30">
              <i className="ri-file-text-line text-orange-400 mr-3"></i>
              <div className="flex-1">
                <div className="text-white font-semibold">4 dossiers à valider</div>
                <div className="text-gray-400 text-sm">Nouvelles ouvertures</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderAgendaSection = () => (
    <div className="h-full">
      <AgendaWorkflow />
    </div>
  );

  const renderContent = () => {
    switch (activeSection) {
      case 'overview':
        return renderOverviewSection();
      case 'agenda':
        return renderAgendaSection();
      case 'clients':
        return renderClientsSection();
      default:
        return renderOverviewSection();
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="flex">
        <div className="w-64 bg-gray-800 border-r border-gray-700 min-h-screen p-6">
          <div className="mb-8">
            <h1 className="text-2xl font-bold text-yellow-400 mb-2">Tableau de Bord Unifié</h1>
            <p className="text-gray-400 text-sm">Pilotage centralisé du conseiller</p>
          </div>

          <nav className="space-y-2">
            <button
              onClick={() => setActiveSection('overview')}
              className={`w-full text-left px-4 py-3 rounded-lg transition-colors cursor-pointer flex items-center ${activeSection === 'overview' ? 'bg-yellow-500/20 text-yellow-400' : 'text-gray-300 hover:bg-gray-700'}`}
            >
              <i className="ri-dashboard-3-line mr-3"></i>
              Vue d'ensemble
            </button>

            <button
              onClick={() => setActiveSection('agenda')}
              className={`w-full text-left px-4 py-3 rounded-lg transition-colors cursor-pointer flex items-center ${activeSection === 'agenda' ? 'bg-yellow-500/20 text-yellow-400' : 'text-gray-300 hover:bg-gray-700'}`}
            >
              <i className="ri-calendar-check-line mr-3"></i>
              Agenda et flux de travail
            </button>

            <button
              onClick={() => setActiveSection('clients')}
              className={`w-full text-left px-4 py-3 rounded-lg transition-colors cursor-pointer flex items-center ${activeSection === 'clients' ? 'bg-yellow-500/20 text-yellow-400' : 'text-gray-300 hover:bg-gray-700'}`}
            >
              <i className="ri-user-3-line mr-3"></i>
              Clients et CRM
            </button>
          </nav>
        </div>

        <div className="flex-1 p-8">
          {renderContent()}
        </div>
      </div>
    </div>
  );
}
