
'use client';

import { useState } from 'react';

export default function AgendaWorkflow() {
  const [currentView, setCurrentView] = useState('week');
  const [currentWeek, setCurrentWeek] = useState(new Date());
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [showNewAppointmentModal, setShowNewAppointmentModal] = useState(false);
  const [showPlanningModal, setShowPlanningModal] = useState(false);
  const [appointmentForm, setAppointmentForm] = useState({
    client: '',
    date: '',
    startTime: '',
    endTime: '',
    type: 'agency',
    subject: '',
    description: '',
    priority: 'normal',
    reminderEmail: true,
    reminderSMS: false
  });

  const [planningForm, setPlanningForm] = useState({
    planningType: 'recurring',
    recurrenceType: 'weekly',
    startDate: '',
    endDate: '',
    selectedDays: [],
    timeSlot: '',
    duration: '60',
    clientType: 'all',
    maxAppointments: '5',
    bufferTime: '15',
    autoConfirm: true,
    blockWeekends: true,
    notifications: true
  });

  const weekDays = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'];
  const timeSlots = Array.from({ length: 13 }, (_, i) => `${8 + i}:00`);
  const monthNames = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];

  const mockClients = [
    { id: 1, name: 'Pierre Dubois', email: 'pierre.dubois@email.com', phone: '+33 6 12 34 56 78' },
    { id: 2, name: 'Sophie Martin', email: 'sophie.martin@email.com', phone: '+33 6 87 65 43 21' },
    { id: 3, name: 'Jean Moreau', email: 'jean.moreau@email.com', phone: '+33 6 11 22 33 44' },
    { id: 4, name: 'Marie Laurent', email: 'marie.laurent@email.com', phone: '+33 6 55 66 77 88' },
    { id: 5, name: 'Paul Leroy', email: 'paul.leroy@email.com', phone: '+33 6 99 88 77 66' },
    { id: 6, name: 'Annie Petit', email: 'annie.petit@email.com', phone: '+33 6 33 44 55 66' },
    { id: 7, name: 'Michel Legrand', email: 'michel.legrand@email.com', phone: '+33 6 77 88 99 00' },
  ];

  const appointments = [
    {
      id: 1,
      day: 0,
      startTime: '09:00',
      endTime: '10:00',
      title: 'RDV M. Dubois',
      type: 'agency',
      status: 'confirmed',
      client: 'Pierre Dubois',
      subject: 'Crédit immobilier',
      icon: 'ri-building-line',
      date: new Date(2024, 11, 16) // Lundi 16 décembre 2024
    },
    {
      id: 2,
      day: 0,
      startTime: '14:30',
      endTime: '15:30',
      title: 'Visio Mme Martin',
      type: 'video',
      status: 'confirmed',
      client: 'Sophie Martin',
      subject: 'Gestion patrimoine',
      icon: 'ri-vidicon-line',
      date: new Date(2024, 11, 16)
    },
    {
      id: 3,
      day: 1,
      startTime: '10:00',
      endTime: '11:00',
      title: 'Appel client',
      type: 'phone',
      status: 'pending',
      client: 'Jean Moreau',
      subject: 'Assurance vie',
      icon: 'ri-phone-line',
      date: new Date(2024, 11, 17)
    },
    {
      id: 4,
      day: 1,
      startTime: '12:00',
      endTime: '13:30',
      title: 'Déjeuner équipe',
      type: 'lunch',
      status: 'confirmed',
      client: 'Équipe commerciale',
      subject: 'Réunion mensuelle',
      icon: 'ri-restaurant-line',
      date: new Date(2024, 11, 17)
    },
    {
      id: 5,
      day: 2,
      startTime: '11:30',
      endTime: '12:30',
      title: 'Urgence - M. Leroy',
      type: 'agency',
      status: 'urgent',
      client: 'Paul Leroy',
      subject: 'Problème découvert',
      icon: 'ri-alarm-warning-line',
      date: new Date(2024, 11, 18)
    },
    {
      id: 6,
      day: 3,
      startTime: '15:00',
      endTime: '16:00',
      title: 'Formation interne',
      type: 'personal',
      status: 'confirmed',
      client: 'Formation',
      subject: 'Nouveaux produits',
      icon: 'ri-graduation-cap-line',
      date: new Date(2024, 11, 19)
    },
    {
      id: 7,
      day: 4,
      startTime: '09:30',
      endTime: '10:30',
      title: 'RDV famille Rousseau',
      type: 'agency',
      status: 'confirmed',
      client: 'Famille Rousseau',
      subject: 'Plan épargne',
      icon: 'ri-group-line',
      date: new Date(2024, 11, 20)
    },
    // Ajout de RDV pour le mois
    {
      id: 8,
      day: 0,
      startTime: '09:00',
      endTime: '10:00',
      title: 'M. Legrand',
      type: 'agency',
      status: 'confirmed',
      client: 'Michel Legrand',
      subject: 'Ouverture compte',
      icon: 'ri-building-line',
      date: new Date(2024, 11, 23)
    },
    {
      id: 9,
      day: 2,
      startTime: '14:00',
      endTime: '15:00',
      title: 'Mme Petit',
      type: 'video',
      status: 'pending',
      client: 'Annie Petit',
      subject: 'Prêt personnel',
      icon: 'ri-vidicon-line',
      date: new Date(2024, 11, 25)
    },
    {
      id: 10,
      day: 3,
      startTime: '10:30',
      endTime: '11:30',
      title: 'Formation équipe',
      type: 'personal',
      status: 'confirmed',
      client: 'Équipe',
      subject: 'Produits 2025',
      icon: 'ri-graduation-cap-line',
      date: new Date(2024, 11, 26)
    }
  ];

  // Fonction utilitaire pour obtenir le début de la semaine (lundi)
  const getWeekStart = (date: Date) => {
    const result = new Date(date);
    const day = result.getDay();
    const diff = result.getDate() - day + (day === 0 ? -6 : 1);
    return new Date(result.setDate(diff));
  };

  // Fonction pour obtenir les rendez-vous du jour sélectionné
  const getDayAppointments = (targetDate: Date) => {
    return appointments.filter(apt =>
      apt.date.getDate() === targetDate.getDate() &&
      apt.date.getMonth() === targetDate.getMonth() &&
      apt.date.getFullYear() === targetDate.getFullYear()
    );
  };

  // Rendez-vous du jour actuel (pour la barre latérale)
  const todayAppointments = getDayAppointments(selectedDate);

  const getAppointmentStyle = (status: string) => {
    switch (status) {
      case 'confirmed': return 'bg-green-600/80 border-green-400 text-green-100';
      case 'pending': return 'bg-orange-600/80 border-orange-400 text-orange-100';
      case 'urgent': return 'bg-red-600/80 border-red-400 text-red-100 animate-pulse';
      default: return 'bg-blue-600/80 border-blue-400 text-blue-100';
    }
  };

  const getTimePosition = (time: string) => {
    const [hours, minutes] = time.split(':').map(Number);
    const totalMinutes = (hours - 8) * 60 + minutes;
    return (totalMinutes / 60) * 4; // 4rem per hour
  };

  const getDuration = (start: string, end: string) => {
    const startMinutes = getTimePosition(start);
    const endMinutes = getTimePosition(end);
    return endMinutes - startMinutes;
  };

  // Génération du calendrier mensuel
  const generateMonthCalendar = () => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const startDate = new Date(firstDay);
    startDate.setDate(startDate.getDate() - firstDay.getDay() + 1); // Commencer par lundi

    const days = [];
    const today = new Date();

    for (let i = 0; i < 42; i++) { // 6 semaines x 7 jours
      const date = new Date(startDate);
      date.setDate(startDate.getDate() + i);

      const dayAppointments = appointments.filter(apt =>
        apt.date.getDate() === date.getDate() &&
        apt.date.getMonth() === date.getMonth() &&
        apt.date.getFullYear() === date.getFullYear()
      );

      days.push({
        date,
        isCurrentMonth: date.getMonth() === month,
        isToday: date.toDateString() === today.toDateString(),
        appointments: dayAppointments
      });
    }

    return days;
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    const newMonth = new Date(currentMonth);
    if (direction === 'prev') {
      newMonth.setMonth(newMonth.getMonth() - 1);
    } else {
      newMonth.setMonth(newMonth.getMonth() + 1);
    }
    setCurrentMonth(newMonth);
  };

  // Nouvelle fonction pour ouvrir le modal de planification
  const handlePlanningClick = () => {
    setShowPlanningModal(true);
  };

  const handlePlanningFormChange = (field: string, value: string | boolean | string[]) => {
    setPlanningForm(prev => ({ ...prev, [field]: value }));
  };

  const handleDayToggle = (day: string) => {
    setPlanningForm(prev => ({
      ...prev,
      selectedDays: prev.selectedDays.includes(day)
        ? prev.selectedDays.filter(d => d !== day)
        : [...prev.selectedDays, day]
    }));
  };

  const handleSubmitPlanning = () => {
    // Validation
    if (planningForm.planningType === 'recurring' && planningForm.selectedDays.length === 0) {
      alert('Veuillez sélectionner au moins un jour de la semaine');
      return;
    }

    if (!planningForm.startDate || !planningForm.timeSlot) {
      alert('Veuillez remplir tous les champs obligatoires');
      return;
    }

    // Simulation de création du planning
    console.log('Planning créé:', planningForm);

    // Reset et fermeture
    setPlanningForm({
      planningType: 'recurring',
      recurrenceType: 'weekly',
      startDate: '',
      endDate: '',
      selectedDays: [],
      timeSlot: '',
      duration: '60',
      clientType: 'all',
      maxAppointments: '5',
      bufferTime: '15',
      autoConfirm: true,
      blockWeekends: true,
      notifications: true
    });
    setShowPlanningModal(false);

    // Notification de succès
    alert('Planning automatisé créé avec succès !');
  };

  const renderMonthView = () => {
    const monthDays = generateMonthCalendar();

    return (
      <div className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden">
        {/* En-tête du mois */}
        <div className="bg-gray-750 border-b border-gray-700 p-4 flex justify-between items-center">
          <button
            onClick={() => navigateMonth('prev')}
            className="p-2 hover:bg-gray-600 rounded-lg transition-colors"
          >
            <i className="ri-arrow-left-line text-gray-300"></i>
          </button>

          <h2 className="text-xl font-bold text-white">
            {monthNames[currentMonth.getMonth()]} {currentMonth.getFullYear()}
          </h2>

          <button
            onClick={() => navigateMonth('next')}
            className="p-2 hover:bg-gray-600 rounded-lg transition-colors"
          >
            <i className="ri-arrow-right-line text-gray-300"></i>
          </button>
        </div>

        {/* Jours de la semaine */}
        <div className="grid grid-cols-7 bg-gray-750 border-b border-gray-700">
          {weekDays.map(day => (
            <div key={day} className="p-3 text-center text-gray-300 font-medium text-sm border-r border-gray-700 last:border-r-0">
              {day.substring(0, 3)}
            </div>
          ))}
        </div>

        {/* Grille du calendrier */}
        <div className="grid grid-cols-7">
          {monthDays.map((day, index) => (
            <div
              key={index}
              className={`h-24 border-r border-b border-gray-700 last:border-r-0 p-1 ${
                !day.isCurrentMonth ? 'bg-gray-800/50' : 'bg-gray-800'
              } ${day.isToday ? 'bg-blue-600/10 border-blue-400' : ''}`}
            >
              <div className={`text-xs font-medium mb-1 ${
                !day.isCurrentMonth ? 'text-gray-500' :
                  day.isToday ? 'text-blue-400' : 'text-gray-300'
              }`}>
                {day.date.getDate()}
              </div>

              <div className="space-y-1">
                {day.appointments.slice(0, 2).map(apt => (
                  <div
                    key={apt.id}
                    className={`text-xs p-1 rounded truncate ${getAppointmentStyle(apt.status)}`}
                  >
                    <div className="flex items-center">
                      <i className={`${apt.icon} mr-1`}></i>
                      <span className="truncate">{apt.startTime} {apt.title}</span>
                    </div>
                  </div>
                ))}
                {day.appointments.length > 2 && (
                  <div className="text-xs text-gray-400 text-center">
                    +{day.appointments.length - 2} autres
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderDayView = () => {
    const dayAppointments = getDayAppointments(selectedDate);

    return (
      <div className="bg-gray-800 rounded-xl border border-gray-700">
        {/* En-tête du jour */}
        <div className="bg-gray-750 border-b border-gray-700 p-4 flex justify-between items-center">
          <h2 className="text-xl font-bold text-white">
            {weekDays[selectedDate.getDay() === 0 ? 6 : selectedDate.getDay() - 1]} {selectedDate.getDate()} {monthNames[selectedDate.getMonth()]} {selectedDate.getFullYear()}
          </h2>

          {/* Navigation pour changer de jour */}
          <div className="flex items-center space-x-2">
            <button
              onClick={() => {
                const prevDay = new Date(selectedDate);
                prevDay.setDate(prevDay.getDate() - 1);
                setSelectedDate(prevDay);
              }}
              className="p-2 hover:bg-gray-600 rounded-lg transition-colors"
            >
              <i className="ri-arrow-left-line text-gray-300"></i>
            </button>

            <button
              onClick={() => setSelectedDate(new Date())}
              className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-sm transition-colors"
            >
              Aujourd'hui
            </button>

            <button
              onClick={() => {
                const nextDay = new Date(selectedDate);
                nextDay.setDate(nextDay.getDate() + 1);
                setSelectedDate(nextDay);
              }}
              className="p-2 hover:bg-gray-600 rounded-lg transition-colors"
            >
              <i className="ri-arrow-right-line text-gray-300"></i>
            </button>
          </div>
        </div>

        {/* Vue détaillée du jour */}
        <div className="p-6">
          <div className="grid grid-cols-2 gap-6">
            {/* Colonne horaire */}
            <div className="space-y-4">
              {timeSlots.map((time) => {
                const appointment = dayAppointments.find(apt => apt.startTime === time);
                return (
                  <div key={time} className="flex items-center">
                    <div className="w-16 text-gray-400 text-sm font-medium">{time}</div>
                    <div className="flex-1 ml-4">
                      {appointment ? (
                        <div className={`p-3 rounded-lg ${getAppointmentStyle(appointment.status)} border-l-4`}>
                          <div className="flex items-center mb-2">
                            <i className={`${appointment.icon} mr-2`}></i>
                            <span className="font-semibold">{appointment.title}</span>
                          </div>
                          <p className="text-sm opacity-90">{appointment.client}</p>
                          <p className="text-xs opacity-75">{appointment.subject}</p>
                          <p className="text-xs opacity-75 mt-1">{appointment.startTime} - {appointment.endTime}</p>
                        </div>
                      ) : (
                        <div className="h-12 border-2 border-dashed border-gray-600 rounded-lg flex items-center justify-center cursor-pointer hover:border-gray-500 transition-colors"
                             onClick={handleNewAppointment}>
                          <span className="text-gray-500 text-xs">Créer un RDV</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Colonne détails */}
            <div className="space-y-4">
              <div className="bg-gray-700 rounded-lg p-4">
                <h3 className="font-semibold text-white mb-3 flex items-center">
                  <i className="ri-pie-chart-line mr-2 text-blue-400"></i>
                  Résumé du jour
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-400">{dayAppointments.filter(apt => apt.status === 'confirmed').length}</div>
                    <div className="text-xs text-gray-300">Confirmés</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-orange-400">{dayAppointments.filter(apt => apt.status === 'pending').length}</div>
                    <div className="text-xs text-gray-300">En attente</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-red-400">{dayAppointments.filter(apt => apt.status === 'urgent').length}</div>
                    <div className="text-xs text-gray-300">Urgents</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-400">{dayAppointments.length}</div>
                    <div className="text-xs text-gray-300">Total</div>
                  </div>
                </div>
              </div>

              <div className="bg-gray-700 rounded-lg p-4">
                <h3 className="font-semibold text-white mb-3 flex items-center">
                  <i className="ri-time-line mr-2 text-yellow-400"></i>
                  RDV de la journée
                </h3>
                <div className="space-y-2">
                  {dayAppointments.slice(0, 4).map(apt => (
                    <div key={apt.id} className="flex items-center p-2 bg-gray-600 rounded hover:bg-gray-500 transition-colors cursor-pointer">
                      <i className={`${apt.icon} mr-2 text-blue-400`}></i>
                      <div className="flex-1">
                        <div className="text-sm font-medium text-white">{apt.startTime} - {apt.title}</div>
                        <div className="text-xs text-gray-300">{apt.subject}</div>
                      </div>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        apt.status === 'confirmed' ? 'bg-green-600/20 text-green-400' :
                          apt.status === 'pending' ? 'bg-orange-600/20 text-orange-400' :
                            'bg-red-600/20 text-red-400'
                      }`}>
                        {apt.status === 'confirmed' ? 'OK' :
                          apt.status === 'pending' ? '...' : '!'}
                      </span>
                    </div>
                  ))}
                  {dayAppointments.length === 0 && (
                    <div className="text-center text-gray-400 py-4">
                      <i className="ri-calendar-line text-2xl mb-2 block"></i>
                      <p className="text-sm">Aucun rendez-vous ce jour</p>
                      <button
                        onClick={handleNewAppointment}
                        className="mt-2 text-xs text-blue-400 hover:text-blue-300 cursor-pointer"
                      >
                        Créer un rendez-vous
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const handleNewAppointment = () => {
    setShowNewAppointmentModal(true);
  };

  const handleFormChange = (field: string, value: string | boolean) => {
    setAppointmentForm(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmitAppointment = () => {
    // Validation simple
    if (!appointmentForm.client || !appointmentForm.date || !appointmentForm.startTime || !appointmentForm.endTime) {
      alert('Veuillez remplir tous les champs obligatoires');
      return;
    }

    // Simulation de sauvegarde
    console.log('Nouveau RDV créé:', appointmentForm);

    // Reset et fermeture
    setAppointmentForm({
      client: '',
      date: '',
      startTime: '',
      endTime: '',
      type: 'agency',
      subject: '',
      description: '',
      priority: 'normal',
      reminderEmail: true,
      reminderSMS: false
    });
    setShowNewAppointmentModal(false);

    // Notification de succès (simulée)
    alert('Rendez-vous créé avec succès !');
  };

  const getSelectedClient = () => {
    return mockClients.find(client => client.id.toString() === appointmentForm.client);
  };

  return (
    <div className="p-6 bg-gray-900 min-h-screen text-white">
      {/* En-tête de navigation */}
      <div className="mb-6 flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <h1 className="text-2xl font-bold text-white flex items-center">
            <i className="ri-calendar-check-line mr-3 text-blue-400"></i>
            Agenda & Flux de Travail
          </h1>
          <div className="flex bg-gray-800 rounded-lg p-1">
            <button
              onClick={() => setCurrentView('day')}
              className={`px-4 py-2 rounded-md transition-colors whitespace-nowrap ${
                currentView === 'day' ? 'bg-blue-600 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              Jour
            </button>
            <button
              onClick={() => setCurrentView('week')}
              className={`px-4 py-2 rounded-md transition-colors whitespace-nowrap ${
                currentView === 'week' ? 'bg-blue-600 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              Semaine
            </button>
            <button
              onClick={() => setCurrentView('month')}
              className={`px-4 py-2 rounded-md transition-colors whitespace-nowrap ${
                currentView === 'month' ? 'bg-blue-600 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              Mois
            </button>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <div className="relative">
            <i className="ri-search-line absolute left-3 top-3 text-gray-400"></i>
            <input
              type="text"
              placeholder="Rechercher un rendez-vous..."
              className="bg-gray-800 border border-gray-700 rounded-lg pl-10 pr-4 py-2 text-white placeholder-gray-400 focus:border-blue-400 focus:outline-none"
            />

          </div>

          <button className="relative p-2 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors">
            <i className="ri-notification-3-line text-white"></i>
            <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">3</span>
          </button>
        </div>
      </div>

      {/* Contenu selon la vue */}
      {currentView === 'day' && (
        <div className="grid grid-cols-12 gap-6">
          {/* Barre latérale pour la vue jour */}
          <div className="col-span-3">
            <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
              <h2 className="text-lg font-bold mb-4 text-white flex items-center">
                <i className="ri-calendar-todo-line mr-2 text-green-400"></i>
                {selectedDate.toDateString() === new Date().toDateString() ? 'Aujourd\'hui' : 'Jour sélectionné'}
              </h2>

              <div className="space-y-3">
                {todayAppointments.map((apt) => (
                  <div key={apt.id} className="bg-gray-700 rounded-lg p-4 border-l-4 border-blue-400 hover:bg-gray-600 transition-colors cursor-pointer">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center mb-1">
                          <i className={`${apt.icon} mr-2 text-blue-400`}></i>
                          <span className="font-medium text-white">{apt.startTime}</span>
                        </div>
                        <h3 className="font-semibold text-white text-sm">{apt.title}</h3>
                        <p className="text-gray-300 text-xs mt-1">{apt.subject}</p>
                      </div>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        apt.status === 'confirmed' ? 'bg-green-600/20 text-green-400' :
                          apt.status === 'pending' ? 'bg-orange-600/20 text-orange-400' :
                            'bg-red-600/20 text-red-400'
                      }`}>
                        {apt.status === 'confirmed' ? 'Confirmé' :
                          apt.status === 'pending' ? 'En attente' : 'Urgent'}
                      </span>
                    </div>
                  </div>
                ))}
                
                {todayAppointments.length === 0 && (
                  <div className="text-center text-gray-400 py-8">
                    <i className="ri-calendar-line text-4xl mb-2 block"></i>
                    <p>Aucun rendez-vous</p>
                    <button
                      onClick={handleNewAppointment}
                      className="mt-3 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm transition-colors cursor-pointer"
                    >
                      Créer un RDV
                    </button>
                  </div>
                )}
              </div>

              {/* Navigation rapide par date */}
              <div className="mt-6 pt-6 border-t border-gray-600">
                <h3 className="text-md font-semibold mb-3 text-white flex items-center">
                  <i className="ri-calendar-check-line mr-2 text-yellow-400"></i>
                  Navigation rapide
                </h3>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setSelectedDate(new Date())}
                    className="p-2 bg-gray-700 hover:bg-gray-600 rounded text-sm text-white transition-colors cursor-pointer"
                  >
                    Aujourd'hui
                  </button>
                  <button
                    onClick={() => {
                      const tomorrow = new Date();
                      tomorrow.setDate(tomorrow.getDate() + 1);
                      setSelectedDate(tomorrow);
                    }}
                    className="p-2 bg-gray-700 hover:bg-gray-600 rounded text-sm text-white transition-colors cursor-pointer"
                  >
                    Demain
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Contenu principal jour */}
          <div className="col-span-9">
            {renderDayView()}
          </div>
        </div>
      )}

      {currentView === 'month' && (
        <div className="grid grid-cols-12 gap-6">
          {/* Barre latérale pour vue mois */}
          <div className="col-span-3">
            <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
              <h2 className="text-lg font-bold mb-4 text-white flex items-center">
                <i className="ri-calendar-line mr-2 text-blue-400"></i>
                Aperçu du mois
              </h2>

              {/* Stats du mois */}
              <div className="grid grid-cols-2 gap-3 mb-6">
                <div className="bg-gray-700 rounded-lg p-3 text-center">
                  <div className="text-lg font-bold text-green-400">
                    {appointments.filter(apt => apt.status === 'confirmed' && apt.date.getMonth() === currentMonth.getMonth()).length}
                  </div>
                  <div className="text-xs text-gray-300">Confirmés</div>
                </div>
                <div className="bg-gray-700 rounded-lg p-3 text-center">
                  <div className="text-lg font-bold text-orange-400">
                    {appointments.filter(apt => apt.status === 'pending' && apt.date.getMonth() === currentMonth.getMonth()).length}
                  </div>
                  <div className="text-xs text-gray-300">En attente</div>
                </div>
                <div className="bg-gray-700 rounded-lg p-3 text-center">
                  <div className="text-lg font-bold text-red-400">
                    {appointments.filter(apt => apt.status === 'urgent' && apt.date.getMonth() === currentMonth.getMonth()).length}
                  </div>
                  <div className="text-xs text-gray-300">Urgents</div>
                </div>
                <div className="bg-gray-700 rounded-lg p-3 text-center">
                  <div className="text-lg font-bold text-blue-400">
                    {appointments.filter(apt => apt.date.getMonth() === currentMonth.getMonth()).length}
                  </div>
                  <div className="text-xs text-gray-300">Total</div>
                </div>
              </div>

              {/* Prochains RDV du mois */}
              <h3 className="text-md font-semibold mb-3 text-white">Prochains rendez-vous</h3>
              <div className="space-y-2">
                {appointments
                  .filter(apt => apt.date.getMonth() === currentMonth.getMonth())
                  .sort((a, b) => a.date.getTime() - b.date.getTime())
                  .slice(0, 5)
                  .map(apt => (
                    <div key={apt.id} className="bg-gray-700 rounded-lg p-3">
                      <div className="flex items-center mb-1">
                        <i className={`${apt.icon} mr-2 text-blue-400`}></i>
                        <span className="text-xs text-gray-300">{apt.date.getDate()}/{apt.date.getMonth() + 1}</span>
                      </div>
                      <div className="text-sm font-medium text-white">{apt.title}</div>
                      <div className="text-xs text-gray-300">{apt.startTime} - {apt.subject}</div>
                    </div>
                  ))}
              </div>
            </div>
          </div>

          {/* Vue mensuelle */}
          <div className="col-span-9">
            {renderMonthView()}
          </div>
        </div>
      )}

      {currentView === 'week' && (
        <div className="grid grid-cols-12 gap-6">
          {/* Barre latérale gauche - Rendez-vous du jour */}
          <div className="col-span-3">
            <div className="bg-gray-800 rounded-xl p-6 border border-gray-700">
              <h2 className="text-lg font-bold mb-4 text-white flex items-center">
                <i className="ri-calendar-todo-line mr-2 text-green-400"></i>
                Aujourd'hui
              </h2>

              <div className="space-y-3">
                {todayAppointments.map((apt) => (
                  <div key={apt.id} className="bg-gray-700 rounded-lg p-4 border-l-4 border-blue-400">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center mb-1">
                          <i className={`${apt.icon} mr-2 text-blue-400`}></i>
                          <span className="font-medium text-white">{apt.startTime}</span>
                        </div>
                        <h3 className="font-semibold text-white text-sm">{apt.title}</h3>
                        <p className="text-gray-300 text-xs mt-1">{apt.subject}</p>
                      </div>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        apt.status === 'confirmed' ? 'bg-green-600/20 text-green-400' :
                          apt.status === 'pending' ? 'bg-orange-600/20 text-orange-400' :
                            'bg-red-600/20 text-red-400'
                      }`}>
                        {apt.status === 'confirmed' ? 'Confirmé' :
                          apt.status === 'pending' ? 'En attente' : 'Urgent'}
                      </span>
                    </div>
                  </div>
                ))}
                {todayAppointments.length === 0 && (
                  <div className="text-center text-gray-400 py-8">
                    <i className="ri-calendar-line text-4xl mb-2"></i>
                    <p>Aucun rendez-vous aujourd'hui</p>
                  </div>
                )}
              </div>

              {/* Rappels et notifications */}
              <div className="mt-6 pt-6 border-t border-gray-600">
                <h3 className="text-md font-semibold mb-3 text-white flex items-center">
                  <i className="ri-bell-line mr-2 text-yellow-400"></i>
                  Rappels
                </h3>
                <div className="space-y-2">
                  <div className="flex items-center p-2 bg-yellow-600/10 rounded-lg">
                    <i className="ri-alarm-line text-yellow-400 mr-2"></i>
                    <span className="text-sm text-yellow-300">Appel de suivi - 15:30</span>
                  </div>
                  <div className="flex items-center p-1 bg-blue-600/10 rounded-lg">
                    <i className="ri-mail-line text-blue-400 mr-2"></i>
                    <span className="text-sm text-blue-300">Email de confirmation</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Calendrier principal */}
          <div className="col-span-9">
            <div className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden">
              {/* En-tête du calendrier */}
              <div className="bg-gray-750 border-b border-gray-700 p-4">
                <div className="grid grid-cols-8 gap-4">
                  <div className="text-center">
                    <span className="text-gray-400 text-sm font-medium">Heure</span>
                  </div>
                  {weekDays.map((day, index) => (
                    <div key={day} className="text-center">
                      <div className="text-white font-semibold">{day}</div>
                      <div className="text-gray-400 text-sm">
                        {new Date(Date.now() + (index - new Date().getDay() + 1) * 24 * 60 * 60 * 1000).getDate()}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Grille horaire */}
              <div className="relative">
                <div className="grid grid-cols-8 gap-4 p-4">
                  {/* Colonne des heures */}
                  <div className="space-y-16">
                    {timeSlots.map((time) => (
                      <div key={time} className="text-gray-400 text-sm font-medium text-right pr-2">
                        {time}
                      </div>
                    ))}
                  </div>

                  {/* Colonnes des jours */}
                  {weekDays.map((day, dayIndex) => (
                    <div key={day} className="relative">
                      {/* Lignes de séparation horaire */}
                      <div className="absolute inset-0">
                        {timeSlots.map((_, timeIndex) => (
                          <div
                            key={timeIndex}
                            className="h-16 border-b border-gray-700/50"
                            style={{ top: `${timeIndex * 4}rem` }}
                          />
                        ))}
                      </div>

                      {/* Rendez-vous */}
                      {appointments
                        .filter(apt => apt.day === dayIndex)
                        .map((apt) => (
                          <div
                            key={apt.id}
                            className={`absolute left-1 right-1 rounded-lg p-2 border-l-4 ${getAppointmentStyle(apt.status)} cursor-pointer hover:opacity-90 transition-opacity z-10`}
                            style={{
                              top: `${getTimePosition(apt.startTime)}rem`,
                              height: `${getDuration(apt.startTime, apt.endTime)}rem`,
                            }}
                          >
                            <div className="flex items-start">
                              <i className={`${apt.icon} mr-1 text-xs`}></i>
                              <div className="flex-1 min-w-0">
                                <p className="font-medium text-xs truncate">{apt.title}</p>
                                <p className="text-xs opacity-90 truncate">{apt.subject}</p>
                                <p className="text-xs opacity-75">{apt.startTime} - {apt.endTime}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Actions rapides - communes à toutes les vues */}
      <div className="mt-6 flex justify-between items-center">
        <div className="flex space-x-3">
          <button
            onClick={handleNewAppointment}
            className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors whitespace-nowrap flex items-center cursor-pointer"
          >
            <i className="ri-add-line mr-2"></i>
            Nouveau RDV
          </button>
          <button
            onClick={handlePlanningClick}
            className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg transition-colors whitespace-nowrap flex items-center cursor-pointer"
          >
            <i className="ri-calendar-event-line mr-2"></i>
            Programmer
          </button>
          <button className="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg transition-colors whitespace-nowrap flex items-center cursor-pointer">
            <i className="ri-export-line mr-2"></i>
            Exporter
          </button>
        </div>

        <div className="flex items-center space-x-2 text-sm">
          <div className="flex items-center">
            <div className="w-3 h-3 bg-green-600 rounded mr-2"></div>
            <span className="text-gray-300">Confirmé</span>
          </div>
          <div className="flex items-center ml-4">
            <div className="w-3 h-3 bg-orange-600 rounded mr-2"></div>
            <span className="text-gray-300">En attente</span>
          </div>
          <div className="flex items-center ml-4">
            <div className="w-3 h-3 bg-red-600 rounded mr-2"></div>
            <span className="text-gray-300">Urgent</span>
          </div>
        </div>
      </div>

      {/* Modal de création de RDV */}
      {showNewAppointmentModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 rounded-xl max-w-2xl w-full max-h-[95vh] overflow-y-auto border border-green-500/20 shadow-2xl">
            {/* En-tête du modal */}
            <div className="flex items-center justify-between p-6 border-b border-gray-800">
              <div>
                <h3 className="text-2xl font-bold text-white flex items-center">
                  <i className="ri-calendar-event-line text-green-400 mr-3"></i>
                  Créer un Nouveau Rendez-vous
                </h3>
                <p className="text-gray-400">Planification automatisée avec notifications</p>
              </div>
              <button
                onClick={() => setShowNewAppointmentModal(false)}
                className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-800 transition-colors cursor-pointer"
              >
                <i className="ri-close-line text-xl text-gray-400 hover:text-white"></i>
              </button>
            </div>

            <div className="p-6">
              <form onSubmit={(e) => { e.preventDefault(); handleSubmitAppointment(); }} id="new-appointment-form">
                <div className="grid lg:grid-cols-2 gap-6">
                  {/* Colonne gauche - Informations principales */}
                  <div className="space-y-4">
                    <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
                      <h4 className="text-lg font-semibold text-white mb-4 flex items-center">
                        <i className="ri-user-3-line text-blue-400 mr-2"></i>
                        Informations Client
                      </h4>

                      {/* Sélection du client */}
                      <div className="mb-4">
                        <label className="block text-gray-400 text-sm font-medium mb-2">Client *</label>
                        <select
                          name="client"
                          value={appointmentForm.client}
                          onChange={(e) => handleFormChange('client', e.target.value)}
                          className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-green-500 focus:outline-none pr-8"
                          required
                        >
                          <option value="">Sélectionner un client...</option>
                          {mockClients.map(client => (
                            <option key={client.id} value={client.id}>{client.name}</option>
                          ))}
                        </select>
                      </div>

                      {/* Informations du client sélectionné */}
                      {getSelectedClient() && (
                        <div className="bg-gray-700/50 rounded-lg p-3 border border-gray-600">
                          <div className="flex items-center mb-2">
                            <i className="ri-user-line text-blue-400 mr-2"></i>
                            <span className="text-white font-medium">{getSelectedClient()!.name}</span>
                          </div>
                          <div className="text-sm text-gray-300">
                            <div className="flex items-center mb-1">
                              <i className="ri-mail-line mr-2"></i>
                              {getSelectedClient()!.email}
                            </div>
                            <div className="flex items-center">
                              <i className="ri-phone-line mr-2"></i>
                              {getSelectedClient()!.phone}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
                      <h4 className="text-lg font-semibold text-white mb-4 flex items-center">
                        <i className="ri-calendar-2-line text-green-400 mr-2"></i>
                        Date & Heure
                      </h4>

                      {/* Date */}
                      <div className="mb-4">
                        <label className="block text-gray-400 text-sm font-medium mb-2">Date du RDV *</label>
                        <input
                          type="date"
                          name="date"
                          value={appointmentForm.date}
                          onChange={(e) => handleFormChange('date', e.target.value)}
                          min={new Date().toISOString().split('T')[0]}
                          className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-green-500 focus:outline-none"
                          required
                        />
                      </div>

                      {/* Heures */}
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-gray-400 text-sm font-medium mb-2">Heure début *</label>
                          <input
                            type="time"
                            name="startTime"
                            value={appointmentForm.startTime}
                            onChange={(e) => handleFormChange('startTime', e.target.value)}
                            className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-green-500 focus:outline-none"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-gray-400 text-sm font-medium mb-2">Heure fin *</label>
                          <input
                            type="time"
                            name="endTime"
                            value={appointmentForm.endTime}
                            onChange={(e) => handleFormChange('endTime', e.target.value)}
                            className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-green-500 focus:outline-none"
                            required
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Colonne droite - Détails et options */}
                  <div className="space-y-4">
                    <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
                      <h4 className="text-lg font-semibold text-white mb-4 flex items-center">
                        <i className="ri-settings-3-line text-yellow-400 mr-2"></i>
                        Type & Détails
                      </h4>

                      {/* Type de RDV */}
                      <div className="mb-4">
                        <label className="block text-gray-400 text-sm font-medium mb-2">Type de rendez-vous</label>
                        <select
                          name="type"
                          value={appointmentForm.type}
                          onChange={(e) => handleFormChange('type', e.target.value)}
                          className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-green-500 focus:outline-none pr-8"
                        >
                          <option value="agency">Rendez-vous en agence</option>
                          <option value="video">Visioconférence</option>
                          <option value="phone">Appel téléphonique</option>
                          <option value="home">Visite à domicile</option>
                          <option value="signature">Signature documents</option>
                        </select>
                      </div>

                      {/* Objet */}
                      <div className="mb-4">
                        <label className="block text-gray-400 text-sm font-medium mb-2">Objet du RDV</label>
                        <input
                          type="text"
                          name="subject"
                          value={appointmentForm.subject}
                          onChange={(e) => handleFormChange('subject', e.target.value)}
                          placeholder="Ex: Ouverture compte, Crédit immobilier..."
                          className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:border-green-500 focus:outline-none"
                          maxLength={100}
                        />
                      </div>

                      {/* Priorité */}
                      <div className="mb-4">
                        <label className="block text-gray-400 text-sm font-medium mb-2">Priorité</label>
                        <select
                          name="priority"
                          value={appointmentForm.priority}
                          onChange={(e) => handleFormChange('priority', e.target.value)}
                          className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-green-500 focus:outline-none pr-8"
                        >
                          <option value="normal">Normale</option>
                          <option value="high">Élevée</option>
                          <option value="urgent">Urgente</option>
                        </select>
                      </div>
                    </div>

                    <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
                      <h4 className="text-lg font-semibold text-white mb-4 flex items-center">
                        <i className="ri-notification-3-line text-purple-400 mr-2"></i>
                        Notifications
                      </h4>

                      {/* Options de rappel */}
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <i className="ri-mail-line text-blue-400 mr-2"></i>
                            <span className="text-white">Email de confirmation</span>
                          </div>
                          <input
                            type="checkbox"
                            name="reminderEmail"
                            checked={appointmentForm.reminderEmail}
                            onChange={(e) => handleFormChange('reminderEmail', e.target.checked)}
                            className="w-5 h-5 text-green-600 bg-gray-700 border-gray-600 rounded focus:ring-green-500"
                          />
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <i className="ri-message-3-line text-green-400 mr-2"></i>
                            <span className="text-white">SMS de rappel</span>
                          </div>
                          <input
                            type="checkbox"
                            name="reminderSMS"
                            checked={appointmentForm.reminderSMS}
                            onChange={(e) => handleFormChange('reminderSMS', e.target.checked)}
                            className="w-5 h-5 text-green-600 bg-gray-700 border-gray-600 rounded focus:ring-green-500"
                          />
                        </div>
                      </div>

                      {/* Timing des rappels */}
                      <div className="mt-4 p-3 bg-gray-700/50 rounded-lg">
                        <div className="text-sm text-gray-300">
                          <div className="flex items-center mb-1">
                            <i className="ri-time-line text-yellow-400 mr-2"></i>
                            <span>Rappels automatiques :</span>
                          </div>
                          <ul className="text-xs text-gray-400 ml-6 space-y-1">
                            <li>• 24h avant le RDV</li>
                            <li>• 2h avant le RDV</li>
                            <li>• Confirmation instantanée</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Description */}
                <div className="mt-6 bg-gray-800 rounded-lg p-4 border border-gray-700">
                  <label className="block text-gray-400 text-sm font-medium mb-2">
                    <i className="ri-file-text-line mr-2"></i>
                    Notes et détails supplémentaires
                  </label>
                  <textarea
                    name="description"
                    value={appointmentForm.description}
                    onChange={(e) => handleFormChange('description', e.target.value)}
                    rows={4}
                    placeholder="Documents à préparer, points à aborder, informations importantes..."
                    className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:border-green-500 focus:outline-none resize-none"
                    maxLength={500}
                  />
                  <div className="text-xs text-gray-400 mt-1">
                    {appointmentForm.description.length}/500 caractères
                  </div>
                </div>

                {/* Actions */}
                <div className="flex justify-between items-center mt-8 pt-6 border-t border-gray-700">
                  <button
                    type="button"
                    onClick={() => setShowNewAppointmentModal(false)}
                    className="px-6 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors cursor-pointer"
                  >
                    <i className="ri-close-line mr-2"></i>
                    Annuler
                  </button>

                  <div className="flex space-x-3">
                    <button
                      type="button"
                      onClick={() => {
                        handleSubmitAppointment();
                        // Simulation d'envoi de l'invitation
                        setTimeout(() => {
                          alert('Invitation envoyée au client !');
                        }, 1000);
                      }}
                      className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                    >
                      <i className="ri-send-plane-line mr-2"></i>
                      Créer & Envoyer
                    </button>

                    <button
                      type="submit"
                      className="px-6 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                    >
                      <i className="ri-save-line mr-2"></i>
                      Créer RDV
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Nouveau Modal de Planification Avancé */}
      {showPlanningModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 rounded-xl max-w-4xl w-full max-h-[95vh] overflow-y-auto border border-blue-500/20 shadow-2xl">
            {/* En-tête du modal */}
            <div className="flex items-center justify-between p-6 border-b border-gray-800">
              <div>
                <h3 className="text-2xl font-bold text-white flex items-center">
                  <i className="ri-calendar-event-line text-blue-400 mr-3"></i>
                  Planification Automatisée Avancée
                </h3>
                <p className="text-gray-400">Créer des créneaux récurrents et optimiser votre planning</p>
              </div>
              <button
                onClick={() => setShowPlanningModal(false)}
                className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-800 transition-colors cursor-pointer"
              >
                <i className="ri-close-line text-xl text-gray-400 hover:text-white"></i>
              </button>
            </div>

            <div className="p-6">
              <form onSubmit={(e) => { e.preventDefault(); handleSubmitPlanning(); }} id="planning-form">
                <div className="grid lg:grid-cols-2 gap-8">
                  {/* Colonne gauche - Configuration de base */}
                  <div className="space-y-6">
                    <div className="bg-gray-800 rounded-lg p-5 border border-gray-700">
                      <h4 className="text-lg font-semibold text-white mb-4 flex items-center">
                        <i className="ri-settings-4-line text-blue-400 mr-2"></i>
                        Configuration de Planning
                      </h4>

                      {/* Type de planification */}
                      <div className="mb-4">
                        <label className="block text-gray-400 text-sm font-medium mb-3">Type de planification</label>
                        <div className="grid grid-cols-2 gap-3">
                          <button
                            type="button"
                            onClick={() => handlePlanningFormChange('planningType', 'recurring')}
                            className={`p-3 rounded-lg border transition-colors text-sm ${
                              planningForm.planningType === 'recurring'
                                ? 'bg-blue-600/20 border-blue-500 text-blue-300'
                                : 'bg-gray-700 border-gray-600 text-gray-300 hover:border-gray-500'
                            }`}
                          >
                            <i className="ri-repeat-line mb-1 block"></i>
                            Récurrent
                          </button>
                          <button
                            type="button"
                            onClick={() => handlePlanningFormChange('planningType', 'template')}
                            className={`p-3 rounded-lg border transition-colors text-sm ${
                              planningForm.planningType === 'template'
                                ? 'bg-blue-600/20 border-blue-500 text-blue-300'
                                : 'bg-gray-700 border-gray-600 text-gray-300 hover:border-gray-500'
                            }`}
                          >
                            <i className="ri-file-copy-line mb-1 block"></i>
                            Template
                          </button>
                        </div>
                      </div>

                      {/* Récurrence si récurrent */}
                      {planningForm.planningType === 'recurring' && (
                        <div className="mb-4">
                          <label className="block text-gray-400 text-sm font-medium mb-2">Fréquence</label>
                          <select
                            value={planningForm.recurrenceType}
                            onChange={(e) => handlePlanningFormChange('recurrenceType', e.target.value)}
                            className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none pr-8"
                          >
                            <option value="weekly">Hebdomadaire</option>
                            <option value="biweekly">Bi-hebdomadaire</option>
                            <option value="monthly">Mensuel</option>
                            <option value="custom">Personnalisé</option>
                          </select>
                        </div>
                      )}

                      {/* Période */}
                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div>
                          <label className="block text-gray-400 text-sm font-medium mb-2">Date de début *</label>
                          <input
                            type="date"
                            value={planningForm.startDate}
                            onChange={(e) => handlePlanningFormChange('startDate', e.target.value)}
                            min={new Date().toISOString().split('T')[0]}
                            className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-gray-400 text-sm font-medium mb-2">Date de fin</label>
                          <input
                            type="date"
                            value={planningForm.endDate}
                            onChange={(e) => handlePlanningFormChange('endDate', e.target.value)}
                            min={planningForm.startDate}
                            className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                          />
                        </div>
                      </div>

                      {/* Jours de la semaine pour récurrent */}
                      {planningForm.planningType === 'recurring' && (
                        <div className="mb-4">
                          <label className="block text-gray-400 text-sm font-medium mb-3">Jours de la semaine *</label>
                          <div className="grid grid-cols-4 gap-2">
                            {[ 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche' ].map(day => (
                              <button
                                key={day}
                                type="button"
                                onClick={() => handleDayToggle(day)}
                                className={`p-2 rounded-lg text-xs font-medium transition-colors ${
                                  planningForm.selectedDays.includes(day)
                                    ? 'bg-blue-600 text-white'
                                    : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                                }`}
                              >
                                {day.substring(0, 3)}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="bg-gray-800 rounded-lg p-5 border border-gray-700">
                      <h4 className="text-lg font-semibold text-white mb-4 flex items-center">
                        <i className="ri-time-line text-green-400 mr-2"></i>
                        Créneaux Horaires
                      </h4>

                      {/* Créneau principal */}
                      <div className="mb-4">
                        <label className="block text-gray-400 text-sm font-medium mb-2">Heure de début *</label>
                        <input
                          type="time"
                          value={planningForm.timeSlot}
                          onChange={(e) => handlePlanningFormChange('timeSlot', e.target.value)}
                          className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                          required
                        />
                      </div>

                      {/* Durée et buffer */}
                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div>
                          <label className="block text-gray-400 text-sm font-medium mb-2">Durée (min)</label>
                          <select
                            value={planningForm.duration}
                            onChange={(e) => handlePlanningFormChange('duration', e.target.value)}
                            className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none pr-8"
                          >
                            <option value="30">30 min</option>
                            <option value="45">45 min</option>
                            <option value="60">1 heure</option>
                            <option value="90">1h30</option>
                            <option value="120">2 heures</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-gray-400 text-sm font-medium mb-2">Temps de battement</label>
                          <select
                            value={planningForm.bufferTime}
                            onChange={(e) => handlePlanningFormChange('bufferTime', e.target.value)}
                            className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none pr-8"
                          >
                            <option value="0">Aucun</option>
                            <option value="15">15 min</option>
                            <option value="30">30 min</option>
                          </select>
                        </div>
                      </div>

                      {/* Nombre maximum de RDV */}
                      <div>
                        <label className="block text-gray-400 text-sm font-medium mb-2">Nombre max de RDV par jour</label>
                        <input
                          type="number"
                          min="1"
                          max="20"
                          value={planningForm.maxAppointments}
                          onChange={(e) => handlePlanningFormChange('maxAppointments', e.target.value)}
                          className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Colonne droite - Options avancées */}
                  <div className="space-y-6">
                    <div className="bg-gray-800 rounded-lg p-5 border border-gray-700">
                      <h4 className="text-lg font-semibold text-white mb-4 flex items-center">
                        <i className="ri-user-settings-line text-yellow-400 mr-2"></i>
                        Règles et Restrictions
                      </h4>

                      {/* Type de clients */}
                      <div className="mb-4">
                        <label className="block text-gray-400 text-sm font-medium mb-2">Type de clients autorisés</label>
                        <select
                          value={planningForm.clientType}
                          onChange={(e) => handlePlanningFormChange('clientType', e.target.value)}
                          className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white focus:border-blue-500 focus:outline-none pr-8"
                        >
                          <option value="all">Tous les clients</option>
                          <option value="vip">Clients VIP uniquement</option>
                          <option value="new">Nouveaux clients</option>
                          <option value="existing">Clients existants</option>
                          <option value="corporate">Entreprises</option>
                        </select>
                      </div>

                      {/* Options de blocage */}
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <i className="ri-calendar-close-line text-orange-400 mr-2"></i>
                            <span className="text-white">Bloquer les week-ends</span>
                          </div>
                          <input
                            type="checkbox"
                            checked={planningForm.blockWeekends}
                            onChange={(e) => handlePlanningFormChange('blockWeekends', e.target.checked)}
                            className="w-5 h-5 text-blue-600 bg-gray-700 border-gray-600 rounded focus:ring-blue-500"
                          />
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <i className="ri-check-double-line text-green-400 mr-2"></i>
                            <span className="text-white">Confirmation automatique</span>
                          </div>
                          <input
                            type="checkbox"
                            checked={planningForm.autoConfirm}
                            onChange={(e) => handlePlanningFormChange('autoConfirm', e.target.checked)}
                            className="w-5 h-5 text-blue-600 bg-gray-700 border-gray-600 rounded focus:ring-blue-500"
                          />
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <i className="ri-notification-badge-line text-purple-400 mr-2"></i>
                            <span className="text-white">Notifications automatiques</span>
                          </div>
                          <input
                            type="checkbox"
                            checked={planningForm.notifications}
                            onChange={(e) => handlePlanningFormChange('notifications', e.target.checked)}
                            className="w-5 h-5 text-blue-600 bg-gray-700 border-gray-600 rounded focus:ring-blue-500"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="bg-gray-800 rounded-lg p-5 border border-gray-700">
                      <h4 className="text-lg font-semibold text-white mb-4 flex items-center">
                        <i className="ri-bar-chart-box-line text-purple-400 mr-2"></i>
                        Aperçu de la Planification
                      </h4>

                      {/* Statistiques prévisionnelles */}
                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div className="bg-gray-700/50 rounded-lg p-3 text-center">
                          <div className="text-xl font-bold text-blue-400">
                            {planningForm.selectedDays.length * 4}
                          </div>
                          <div className="text-xs text-gray-300">Créneaux/semaine</div>
                        </div>
                        <div className="bg-gray-700/50 rounded-lg p-3 text-center">
                          <div className="text-xl font-bold text-green-400">
                            {Math.floor(parseInt(planningForm.duration) / 60) || 0}h{parseInt(planningForm.duration) % 60 || '00'}
                          </div>
                          <div className="text-xs text-gray-300">Durée RDV</div>
                        </div>
                        <div className="bg-gray-700/50 rounded-lg p-3 text-center">
                          <div className="text-xl font-bold text-yellow-400">
                            {planningForm.maxAppointments}
                          </div>
                          <div className="text-xs text-gray-300">Max/jour</div>
                        </div>
                        <div className="bg-gray-700/50 rounded-lg p-3 text-center">
                          <div className="text-xl font-bold text-purple-400">
                            {planningForm.bufferTime}min
                          </div>
                          <div className="text-xs text-gray-300">Battement</div>
                        </div>
                      </div>

                      {/* Preview des jours sélectionnés */}
                      {planningForm.selectedDays.length > 0 && (
                        <div>
                          <div className="text-sm text-gray-300 mb-2">Jours actifs :</div>
                          <div className="flex flex-wrap gap-1">
                            {planningForm.selectedDays.map(day => (
                              <span key={day} className="px-2 py-1 bg-blue-600/20 text-blue-300 rounded text-xs">
                                {day.substring(0, 3)}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Heure de début si définie */}
                      {planningForm.timeSlot && (
                        <div className="mt-3 p-2 bg-gray-700/30 rounded text-center">
                          <span className="text-sm text-gray-300">Début à </span>
                          <span className="text-white font-semibold">{planningForm.timeSlot}</span>
                        </div>
                      )}
                    </div>

                    <div className="bg-gray-800 rounded-lg p-5 border border-gray-700">
                      <h4 className="text-lg font-semibold text-white mb-4 flex items-center">
                        <i className="ri-lightbulb-line text-yellow-400 mr-2"></i>
                        Suggestions Intelligentes
                      </h4>

                      <div className="space-y-3">
                        <div className="flex items-start p-3 bg-blue-600/10 rounded-lg border border-blue-500/20">
                          <i className="ri-information-line text-blue-400 mr-2 mt-0.5"></i>
                          <div>
                            <div className="text-sm font-medium text-blue-300">Optimisation automatique</div>
                            <div className="text-xs text-gray-300">Les créneaux seront répartis selon votre historique</div>
                          </div>
                        </div>

                        <div className="flex items-start p-3 bg-green-600/10 rounded-lg border border-green-500/20">
                          <i className="ri-calendar-check-line text-green-400 mr-2 mt-0.5"></i>
                          <div>
                            <div className="text-sm font-medium text-green-300">Éviter les conflits</div>
                            <div className="text-xs text-gray-300">Vérification automatique des disponibilités</div>
                          </div>
                        </div>

                        <div className="flex items-start p-3 bg-purple-600/10 rounded-lg border border-purple-500/20">
                          <i className="ri-mail-send-line text-purple-400 mr-2 mt-0.5"></i>
                          <div>
                            <div className="text-sm font-medium text-purple-300">Communications auto</div>
                            <div className="text-xs text-gray-300">Invitations et rappels programmés</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex justify-between items-center mt-8 pt-6 border-t border-gray-700">
                  <button
                    type="button"
                    onClick={() => setShowPlanningModal(false)}
                    className="px-6 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors cursor-pointer"
                  >
                    <i className="ri-close-line mr-2"></i>
                    Annuler
                  </button>

                  <div className="flex space-x-3">
                    <button
                      type="button"
                      onClick={() => {
                        // Preview avant validation
                        alert('Preview : ' + JSON.stringify(planningForm, null, 2));
                      }}
                      className="px-6 py-3 bg-gray-600 hover:bg-gray-500 text-white rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                    >
                      <i className="ri-eye-line mr-2"></i>
                      Prévisualiser
                    </button>

                    <button
                      type="submit"
                      className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                    >
                      <i className="ri-save-line mr-2"></i>
                      Créer Planning
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
