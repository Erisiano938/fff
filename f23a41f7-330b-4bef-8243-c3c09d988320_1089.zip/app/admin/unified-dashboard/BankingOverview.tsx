'use client';

import React from 'react';

export default function BankingOverview() {
  return (
    <div className="p-6 bg-gradient-to-br from-gray-900 to-gray-800 min-h-screen text-white">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Tableau de Bord Banquier</h1>
        <p className="text-gray-300">Vue d'ensemble des performances et indicateurs clés</p>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Encours Sous Gestion */}
        <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
          <div className="flex items-center mb-4">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-bank-line text-blue-400 text-xl"></i>
            </div>
            <h3 className="text-xl font-semibold ml-3 text-white">Encours Sous Gestion</h3>
          </div>
          
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Dépôts</span>
              <div className="text-right">
                <div className="text-2xl font-bold text-green-400">127.8M €</div>
                <div className="text-green-400 text-sm">+5.2%</div>
              </div>
            </div>
            
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div className="bg-green-400 h-2 rounded-full" style={{width: '78%'}}></div>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Épargne</span>
              <div className="text-right">
                <div className="text-2xl font-bold text-blue-400">89.4M €</div>
                <div className="text-blue-400 text-sm">+12.1%</div>
              </div>
            </div>
            
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div className="bg-blue-400 h-2 rounded-full" style={{width: '65%'}}></div>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Crédits</span>
              <div className="text-right">
                <div className="text-2xl font-bold text-purple-400">156.2M €</div>
                <div className="text-purple-400 text-sm">+3.7%</div>
              </div>
            </div>
            
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div className="bg-purple-400 h-2 rounded-full" style={{width: '92%'}}></div>
            </div>
          </div>
        </div>

        {/* Objectifs Commerciaux */}
        <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
          <div className="flex items-center mb-4">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-target-line text-orange-400 text-xl"></i>
            </div>
            <h3 className="text-xl font-semibold ml-3 text-white">Objectifs Commerciaux</h3>
          </div>
          
          <div className="space-y-4">
            <div className="text-center">
              <div className="text-4xl font-bold text-orange-400 mb-2">87%</div>
              <div className="text-gray-300 text-sm">Taux de réalisation</div>
              <div className="w-full bg-gray-700 rounded-full h-3 mt-2">
                <div className="bg-orange-400 h-3 rounded-full" style={{width: '87%'}}></div>
              </div>
            </div>
            
            <div className="border-t border-gray-700 pt-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-300">Nouveaux clients</span>
                <span className="text-2xl font-bold text-green-400">47</span>
              </div>
              <div className="text-sm text-gray-400">Ce mois : +18%</div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-gray-300">Comptes épargne</span>
                <span className="text-green-400">23</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-300">Crédits immobiliers</span>
                <span className="text-blue-400">12</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-300">Assurances vie</span>
                <span className="text-purple-400">18</span>
              </div>
            </div>
          </div>
        </div>

        {/* Gestion du Risque */}
        <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
          <div className="flex items-center mb-4">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-shield-check-line text-red-400 text-xl"></i>
            </div>
            <h3 className="text-xl font-semibold ml-3 text-white">Gestion du Risque</h3>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-300">Taux de défaut</span>
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-green-400 mr-2"></div>
                <span className="text-green-400 font-bold">0.23%</span>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-gray-300">Encours surveillés</span>
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-yellow-400 mr-2"></div>
                <span className="text-yellow-400 font-bold">4.2M €</span>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-gray-300">Alertes actives</span>
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-red-400 mr-2 animate-pulse"></div>
                <span className="text-red-400 font-bold">3</span>
              </div>
            </div>
            
            <div className="border-t border-gray-700 pt-4">
              <div className="text-sm text-gray-300 mb-2">Exposition par secteur</div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Immobilier</span>
                  <span className="text-green-400">Faible</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">PME/ETI</span>
                  <span className="text-yellow-400">Modéré</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Particuliers</span>
                  <span className="text-green-400">Faible</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Performance Financière */}
        <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
          <div className="flex items-center mb-4">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-line-chart-line text-green-400 text-xl"></i>
            </div>
            <h3 className="text-xl font-semibold ml-3 text-white">Performance Financière</h3>
          </div>
          
          <div className="space-y-4">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-400 mb-1">4.2M €</div>
              <div className="text-sm text-gray-300">Produit Net Bancaire</div>
              <div className="w-20 h-20 mx-auto mt-3 relative">
                <div className="w-full h-full rounded-full border-4 border-gray-700"></div>
                <div className="absolute inset-0 rounded-full border-4 border-green-400 border-t-transparent" style={{transform: 'rotate(306deg)'}}></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-sm font-bold text-green-400">85%</span>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4 border-t border-gray-700 pt-4">
              <div className="text-center">
                <div className="text-xl font-bold text-blue-400">68.4%</div>
                <div className="text-xs text-gray-300">Marge nette</div>
              </div>
              <div className="text-center">
                <div className="text-xl font-bold text-purple-400">15.8%</div>
                <div className="text-xs text-gray-300">ROE</div>
              </div>
            </div>
            
            <div className="text-center">
              <div className="text-lg font-bold text-yellow-400">1.8%</div>
              <div className="text-xs text-gray-300">ROA</div>
            </div>
          </div>
        </div>

        {/* Satisfaction Client */}
        <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
          <div className="flex items-center mb-4">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-customer-service-2-line text-blue-400 text-xl"></i>
            </div>
            <h3 className="text-xl font-semibold ml-3 text-white">Satisfaction Client</h3>
          </div>
          
          <div className="space-y-4">
            <div className="text-center">
              <div className="text-4xl font-bold text-green-400 mb-1">+67</div>
              <div className="text-sm text-gray-300">Net Promoter Score</div>
              <div className="text-xs text-green-400 mt-1">Excellent</div>
            </div>
            
            <div className="border-t border-gray-700 pt-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-6 h-6 flex items-center justify-center">
                    <i className="ri-error-warning-line text-orange-400"></i>
                  </div>
                  <span className="text-gray-300 ml-2 text-sm">Réclamations</span>
                </div>
                <div className="text-right">
                  <div className="text-orange-400 font-bold">3</div>
                  <div className="text-xs text-gray-400">0.1% portefeuille</div>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-6 h-6 flex items-center justify-center">
                    <i className="ri-smartphone-line text-blue-400"></i>
                  </div>
                  <span className="text-gray-300 ml-2 text-sm">Adoption digital</span>
                </div>
                <span className="text-blue-400 font-bold">89%</span>
              </div>
              
              <div className="text-xs text-gray-400 mt-3">
                Canaux préférés: App mobile (45%), Web (31%), Agence (24%)
              </div>
            </div>
          </div>
        </div>

        {/* Ressources & Productivité */}
        <div className="bg-gray-800 border border-gray-700 rounded-xl p-6">
          <div className="flex items-center mb-4">
            <div className="w-8 h-8 flex items-center justify-center">
              <i className="ri-team-line text-purple-400 text-xl"></i>
            </div>
            <h3 className="text-xl font-semibold ml-3 text-white">Ressources</h3>
          </div>
          
          <div className="space-y-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-400 mb-1">8</div>
              <div className="text-sm text-gray-300">Conseillers actifs</div>
            </div>
            
            <div className="border-t border-gray-700 pt-4">
              <div className="text-sm text-gray-300 mb-3">Top Performers</div>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-400">Marie Laurent</span>
                  <span className="text-green-400 text-sm font-bold">+15%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-400">Pierre Dubois</span>
                  <span className="text-blue-400 text-sm font-bold">+12%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-400">Sophie Martin</span>
                  <span className="text-purple-400 text-sm font-bold">+9%</span>
                </div>
              </div>
            </div>
            
            <div className="border-t border-gray-700 pt-4">
              <div className="text-center">
                <div className="text-xl font-bold text-blue-400 mb-1">2,847</div>
                <div className="text-xs text-gray-300">Clients au total</div>
              </div>
              
              <div className="mt-3 text-xs text-gray-400">
                Répartition: Particuliers (78%), Professionnels (15%), Entreprises (7%)
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Stats Bar */}
      <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-gray-800 border border-gray-700 rounded-lg p-4 text-center">
          <div className="w-8 h-8 flex items-center justify-center mx-auto mb-2">
            <i className="ri-funds-line text-green-400 text-xl"></i>
          </div>
          <div className="text-lg font-bold text-green-400">373.4M €</div>
          <div className="text-xs text-gray-300">Total Actifs</div>
        </div>
        
        <div className="bg-gray-800 border border-gray-700 rounded-lg p-4 text-center">
          <div className="w-8 h-8 flex items-center justify-center mx-auto mb-2">
            <i className="ri-user-add-line text-blue-400 text-xl"></i>
          </div>
          <div className="text-lg font-bold text-blue-400">+142</div>
          <div className="text-xs text-gray-300">Nouveaux clients 3M</div>
        </div>
        
        <div className="bg-gray-800 border border-gray-700 rounded-lg p-4 text-center">
          <div className="w-8 h-8 flex items-center justify-center mx-auto mb-2">
            <i className="ri-trophy-line text-yellow-400 text-xl"></i>
          </div>
          <div className="text-lg font-bold text-yellow-400">96.8%</div>
          <div className="text-xs text-gray-300">Taux satisfaction</div>
        </div>
        
        <div className="bg-gray-800 border border-gray-700 rounded-lg p-4 text-center">
          <div className="w-8 h-8 flex items-center justify-center mx-auto mb-2">
            <i className="ri-pulse-line text-red-400 text-xl"></i>
          </div>
          <div className="text-lg font-bold text-red-400">Real-time</div>
          <div className="text-xs text-gray-300">Données live</div>
        </div>
      </div>
    </div>
  );
}