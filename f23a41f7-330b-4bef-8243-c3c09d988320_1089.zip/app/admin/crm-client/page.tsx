import ClientProfile from './ClientProfile';

export default function CRMClientPage() {
  return <ClientProfile />;
}