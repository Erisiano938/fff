'use client';
import { useState } from 'react';

export default function ClientProfile() {
  const [activeTab, setActiveTab] = useState('profil');
  const [showContactModal, setShowContactModal] = useState(false);
  const [showMeetingModal, setShowMeetingModal] = useState(false);

  const clientData = {
    id: 'CLI-2024-001547',
    firstName: 'Sophie',
    lastName: 'Martineau',
    segment: 'Premium',
    status: 'Patrimonial',
    totalAssets: '2 450 000',
    riskScore: 'AAA',
    nps: 9.2,
    joinDate: '15/03/2019',
    lastContact: '08/01/2024',
    advisor: 'Thomas Dubois',
    phone: '+33 6 42 18 75 93',
    email: 'sophie.martineau@email.com',
    address: '125 Avenue des Champs-Élysées, 75008 Paris'
  };

  const patrimoineData = {
    actifs: {
      comptesCourants: 185000,
      epargneReglementee: 122000,
      assuranceVie: 890000,
      pea: 245000,
      scpi: 320000,
      actionsDiverses: 180000,
      obligations: 95000,
      cryptomonnaies: 25000
    },
    passifs: {
      creditImmobilier: 285000,
      creditConso: 18000,
      creditProfessionnel: 0
    }
  };

  const commercialData = {
    rendezvous: [
      { date: '08/01/2024', type: 'Visio', sujet: 'Révision portefeuille annuelle', statut: 'Réalisé' },
      { date: '15/12/2023', type: 'Agence', sujet: 'Souscription SCPI', statut: 'Réalisé' },
      { date: '22/11/2023', type: 'Téléphone', sujet: 'Suivi marché actions', statut: 'Réalisé' },
      { date: '18/01/2024', type: 'Agence', sujet: 'Optimisation fiscale 2024', statut: 'Programmé' }
    ],
    produits: [
      { nom: 'Compte Premium', type: 'Bancaire', souscrit: '2019', statut: 'Actif' },
      { nom: 'Assurance Vie Patrimoine', type: 'Épargne', souscrit: '2019', statut: 'Actif' },
      { nom: 'PEA Premium', type: 'Bourse', souscrit: '2020', statut: 'Actif' },
      { nom: 'SCPI Diversifiées', type: 'Immobilier', souscrit: '2023', statut: 'Actif' },
      { nom: 'Crédit Immobilier', type: 'Crédit', souscrit: '2019', statut: 'En cours' }
    ],
    opportunites: [
      { produit: 'PER Entreprise', priorite: 'Haute', potentiel: '50 000 €', probabilite: '85%' },
      { produit: 'Assurance Prévoyance', priorite: 'Moyenne', potentiel: '15 000 €', probabilite: '60%' },
      { produit: 'Compte Joint', priorite: 'Faible', potentiel: '5 000 €', probabilite: '30%' }
    ]
  };

  const totalActifs = Object.values(patrimoineData.actifs).reduce((sum, val) => sum + val, 0);
  const totalPassifs = Object.values(patrimoineData.passifs).reduce((sum, val) => sum + val, 0);
  const patrimoineNet = totalActifs - totalPassifs;

  const renderProfil = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-800/50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
            <i className="ri-user-line mr-2 text-blue-400"></i>
            Informations personnelles
          </h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-400">Nom complet:</span>
              <span className="text-white">{clientData.firstName} {clientData.lastName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Numéro client:</span>
              <span className="text-blue-400 font-mono">{clientData.id}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Segment:</span>
              <span className="text-yellow-400 font-semibold">{clientData.segment}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Statut:</span>
              <span className="text-green-400">{clientData.status}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Client depuis:</span>
              <span className="text-white">{clientData.joinDate}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Conseiller:</span>
              <span className="text-white">{clientData.advisor}</span>
            </div>
          </div>
        </div>

        <div className="bg-gray-800/50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
            <i className="ri-contacts-line mr-2 text-green-400"></i>
            Contact
          </h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-400">Téléphone:</span>
              <span className="text-white">{clientData.phone}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Email:</span>
              <span className="text-blue-400">{clientData.email}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Adresse:</span>
              <span className="text-white text-right max-w-xs">{clientData.address}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Dernier contact:</span>
              <span className="text-white">{clientData.lastContact}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-gradient-to-r from-blue-600/20 to-blue-800/20 rounded-lg p-6 border border-blue-500/20">
          <h4 className="text-blue-400 font-semibold mb-2">Patrimoine Total</h4>
          <p className="text-2xl font-bold text-white">{clientData.totalAssets} €</p>
          <p className="text-sm text-gray-400 mt-1">Patrimoine net: {patrimoineNet.toLocaleString()} €</p>
        </div>

        <div className="bg-gradient-to-r from-green-600/20 to-green-800/20 rounded-lg p-6 border border-green-500/20">
          <h4 className="text-green-400 font-semibold mb-2">Score de Risque</h4>
          <p className="text-2xl font-bold text-white">{clientData.riskScore}</p>
          <p className="text-sm text-gray-400 mt-1">Excellent profil</p>
        </div>

        <div className="bg-gradient-to-r from-purple-600/20 to-purple-800/20 rounded-lg p-6 border border-purple-500/20">
          <h4 className="text-purple-400 font-semibold mb-2">Satisfaction NPS</h4>
          <p className="text-2xl font-bold text-white">{clientData.nps}/10</p>
          <p className="text-sm text-gray-400 mt-1">Client promoteur</p>
        </div>
      </div>
    </div>
  );

  const renderPatrimoine = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-800/50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
            <i className="ri-wallet-line mr-2 text-green-400"></i>
            Actifs - {totalActifs.toLocaleString()} €
          </h3>
          <div className="space-y-3">
            {Object.entries(patrimoineData.actifs).map(([key, value]) => (
              <div key={key} className="flex justify-between items-center">
                <span className="text-gray-400 capitalize">{key.replace(/([A-Z])/g, ' $1')}</span>
                <div className="text-right">
                  <span className="text-white font-semibold">{value.toLocaleString()} €</span>
                  <div className="w-20 bg-gray-700 rounded-full h-1 mt-1">
                    <div 
                      className="bg-green-400 h-1 rounded-full" 
                      style={{ width: `${(value / totalActifs) * 100}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gray-800/50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
            <i className="ri-bank-card-line mr-2 text-red-400"></i>
            Passifs - {totalPassifs.toLocaleString()} €
          </h3>
          <div className="space-y-3">
            {Object.entries(patrimoineData.passifs).map(([key, value]) => (
              <div key={key} className="flex justify-between items-center">
                <span className="text-gray-400 capitalize">{key.replace(/([A-Z])/g, ' $1')}</span>
                <div className="text-right">
                  <span className="text-white font-semibold">{value.toLocaleString()} €</span>
                  {value > 0 && (
                    <div className="w-20 bg-gray-700 rounded-full h-1 mt-1">
                      <div 
                        className="bg-red-400 h-1 rounded-full" 
                        style={{ width: `${(value / totalPassifs) * 100}%` }}
                      ></div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-gray-800/50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
          <i className="ri-pie-chart-line mr-2 text-blue-400"></i>
          Répartition du patrimoine
        </h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-2">
              <span className="text-white font-bold">{Math.round((patrimoineData.actifs.assuranceVie / totalActifs) * 100)}%</span>
            </div>
            <p className="text-sm text-gray-400">Assurance Vie</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-2">
              <span className="text-white font-bold">{Math.round((patrimoineData.actifs.scpi / totalActifs) * 100)}%</span>
            </div>
            <p className="text-sm text-gray-400">SCPI</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-2">
              <span className="text-white font-bold">{Math.round((patrimoineData.actifs.pea / totalActifs) * 100)}%</span>
            </div>
            <p className="text-sm text-gray-400">PEA</p>
          </div>
          <div className="text-center">
            <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mx-auto mb-2">
              <span className="text-white font-bold">{Math.round(((patrimoineData.actifs.comptesCourants + patrimoineData.actifs.epargneReglementee) / totalActifs) * 100)}%</span>
            </div>
            <p className="text-sm text-gray-400">Liquidités</p>
          </div>
        </div>
      </div>
    </div>
  );

  const renderCommercial = () => (
    <div className="space-y-6">
      <div className="bg-gray-800/50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
          <i className="ri-calendar-line mr-2 text-blue-400"></i>
          Historique des rendez-vous
        </h3>
        <div className="space-y-3">
          {commercialData.rendezvous.map((rdv, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-700/50 rounded">
              <div className="flex items-center space-x-3">
                <div className={`w-3 h-3 rounded-full ${rdv.statut === 'Réalisé' ? 'bg-green-400' : 'bg-yellow-400'}`}></div>
                <div>
                  <p className="text-white font-medium">{rdv.sujet}</p>
                  <p className="text-sm text-gray-400">{rdv.date} - {rdv.type}</p>
                </div>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                rdv.statut === 'Réalisé' ? 'bg-green-600/20 text-green-400' : 'bg-yellow-600/20 text-yellow-400'
              }`}>
                {rdv.statut}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-gray-800/50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
          <i className="ri-shopping-bag-line mr-2 text-green-400"></i>
          Produits souscrits
        </h3>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {commercialData.produits.map((produit, index) => (
            <div key={index} className="p-4 bg-gray-700/50 rounded-lg">
              <div className="flex justify-between items-start mb-2">
                <h4 className="text-white font-medium">{produit.nom}</h4>
                <span className={`px-2 py-1 rounded-full text-xs ${
                  produit.statut === 'Actif' ? 'bg-green-600/20 text-green-400' : 'bg-blue-600/20 text-blue-400'
                }`}>
                  {produit.statut}
                </span>
              </div>
              <p className="text-sm text-gray-400">{produit.type} - Souscrit en {produit.souscrit}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-gray-800/50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
          <i className="ri-target-line mr-2 text-purple-400"></i>
          Opportunités de développement
        </h3>
        <div className="space-y-3">
          {commercialData.opportunites.map((opp, index) => (
            <div key={index} className="p-4 bg-gray-700/50 rounded-lg">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="text-white font-medium">{opp.produit}</h4>
                  <p className="text-sm text-gray-400">Potentiel: {opp.potentiel}</p>
                </div>
                <div className="text-right">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    opp.priorite === 'Haute' ? 'bg-red-600/20 text-red-400' :
                    opp.priorite === 'Moyenne' ? 'bg-yellow-600/20 text-yellow-400' :
                    'bg-gray-600/20 text-gray-400'
                  }`}>
                    {opp.priorite}
                  </span>
                  <p className="text-sm text-gray-400 mt-1">{opp.probabilite}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderRisque = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-gradient-to-r from-green-600/20 to-green-800/20 rounded-lg p-6 border border-green-500/20">
          <h4 className="text-green-400 font-semibold mb-2">Score Global</h4>
          <p className="text-3xl font-bold text-white">AAA</p>
          <p className="text-sm text-gray-400 mt-1">Excellent</p>
        </div>

        <div className="bg-gradient-to-r from-blue-600/20 to-blue-800/20 rounded-lg p-6 border border-blue-500/20">
          <h4 className="text-blue-400 font-semibold mb-2">Taux d'endettement</h4>
          <p className="text-3xl font-bold text-white">12%</p>
          <p className="text-sm text-gray-400 mt-1">Très faible</p>
        </div>

        <div className="bg-gradient-to-r from-purple-600/20 to-purple-800/20 rounded-lg p-6 border border-purple-500/20">
          <h4 className="text-purple-400 font-semibold mb-2">Capacité résiduelle</h4>
          <p className="text-3xl font-bold text-white">450K€</p>
          <p className="text-sm text-gray-400 mt-1">Disponible</p>
        </div>
      </div>

      <div className="bg-gray-800/50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
          <i className="ri-shield-check-line mr-2 text-green-400"></i>
          Monitoring en temps réel
        </h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 bg-green-600/10 border border-green-500/20 rounded">
            <div className="flex items-center space-x-3">
              <i className="ri-checkbox-circle-line text-green-400 text-xl"></i>
              <span className="text-white">Paiements à jour</span>
            </div>
            <span className="text-green-400 font-semibold">OK</span>
          </div>
          
          <div className="flex items-center justify-between p-3 bg-green-600/10 border border-green-500/20 rounded">
            <div className="flex items-center space-x-3">
              <i className="ri-checkbox-circle-line text-green-400 text-xl"></i>
              <span className="text-white">Limites respectées</span>
            </div>
            <span className="text-green-400 font-semibold">OK</span>
          </div>
          
          <div className="flex items-center justify-between p-3 bg-green-600/10 border border-green-500/20 rounded">
            <div className="flex items-center space-x-3">
              <i className="ri-checkbox-circle-line text-green-400 text-xl"></i>
              <span className="text-white">Documents à jour</span>
            </div>
            <span className="text-green-400 font-semibold">OK</span>
          </div>
        </div>
      </div>

      <div className="bg-gray-800/50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
          <i className="ri-history-line mr-2 text-yellow-400"></i>
          Historique des incidents
        </h3>
        <div className="text-center py-8">
          <i className="ri-shield-check-line text-green-400 text-4xl mb-4"></i>
          <p className="text-gray-400">Aucun incident signalé</p>
          <p className="text-sm text-green-400 mt-2">Client exemplaire depuis 5 ans</p>
        </div>
      </div>
    </div>
  );

  const renderRelation = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-800/50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
            <i className="ri-phone-line mr-2 text-blue-400"></i>
            Canaux privilégiés
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-blue-600/10 border border-blue-500/20 rounded">
              <div className="flex items-center space-x-3">
                <i className="ri-vidicon-line text-blue-400"></i>
                <span className="text-white">Visioconférence</span>
              </div>
              <span className="text-blue-400 font-semibold">Préféré</span>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-gray-700/50 rounded">
              <div className="flex items-center space-x-3">
                <i className="ri-building-line text-gray-400"></i>
                <span className="text-white">Agence physique</span>
              </div>
              <span className="text-gray-400">Occasionnel</span>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-gray-700/50 rounded">
              <div className="flex items-center space-x-3">
                <i className="ri-smartphone-line text-gray-400"></i>
                <span className="text-white">Application mobile</span>
              </div>
              <span className="text-gray-400">Quotidien</span>
            </div>
          </div>
        </div>

        <div className="bg-gray-800/50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
            <i className="ri-heart-line mr-2 text-purple-400"></i>
            Satisfaction détaillée
          </h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Conseil</span>
              <div className="flex items-center space-x-2">
                <div className="w-20 bg-gray-700 rounded-full h-2">
                  <div className="bg-green-400 h-2 rounded-full" style={{ width: '95%' }}></div>
                </div>
                <span className="text-white font-semibold">9.5</span>
              </div>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Réactivité</span>
              <div className="flex items-center space-x-2">
                <div className="w-20 bg-gray-700 rounded-full h-2">
                  <div className="bg-green-400 h-2 rounded-full" style={{ width: '90%' }}></div>
                </div>
                <span className="text-white font-semibold">9.0</span>
              </div>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Produits</span>
              <div className="flex items-center space-x-2">
                <div className="w-20 bg-gray-700 rounded-full h-2">
                  <div className="bg-green-400 h-2 rounded-full" style={{ width: '92%' }}></div>
                </div>
                <span className="text-white font-semibold">9.2</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-gray-800/50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
          <i className="ri-chat-3-line mr-2 text-green-400"></i>
          Notes et commentaires
        </h3>
        <div className="space-y-4">
          <div className="p-4 bg-gray-700/50 rounded-lg">
            <div className="flex justify-between items-start mb-2">
              <span className="text-sm text-gray-400">08/01/2024 - Thomas Dubois</span>
              <span className="text-xs text-blue-400">Important</span>
            </div>
            <p className="text-white">Cliente très satisfaite de la performance de son portefeuille. Intéressée par l'optimisation fiscale via PER entreprise. À recontacter fin janvier pour proposition détaillée.</p>
          </div>
          
          <div className="p-4 bg-gray-700/50 rounded-lg">
            <div className="flex justify-between items-start mb-2">
              <span className="text-sm text-gray-400">15/12/2023 - Thomas Dubois</span>
              <span className="text-xs text-green-400">Suivi</span>
            </div>
            <p className="text-white">Souscription SCPI réalisée pour 200K€. Cliente ravie du conseil et de l'accompagnement. Excellente relation de confiance établie.</p>
          </div>
        </div>
        
        <div className="mt-6">
          <textarea
            className="w-full bg-gray-700/50 border border-gray-600 rounded-lg p-3 text-white placeholder-gray-400 focus:border-blue-400 focus:outline-none"
            rows={3}
            placeholder="Ajouter une nouvelle note..."
          ></textarea>
          <button className="mt-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium">
            Enregistrer la note
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-7xl mx-auto">
        <div className="bg-gray-900/50 rounded-xl p-8">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center space-x-6">
              <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                <span className="text-2xl font-bold text-white">SM</span>
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white">{clientData.firstName} {clientData.lastName}</h1>
                <div className="flex items-center space-x-4 mt-2">
                  <span className="px-3 py-1 bg-yellow-600/20 text-yellow-400 rounded-full text-sm font-medium">
                    {clientData.segment}
                  </span>
                  <span className="px-3 py-1 bg-green-600/20 text-green-400 rounded-full text-sm font-medium">
                    {clientData.status}
                  </span>
                  <span className="text-gray-400 text-sm">{clientData.id}</span>
                </div>
              </div>
            </div>
            
            <div className="flex space-x-3">
              <button 
                onClick={() => setShowContactModal(true)}
                className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg flex items-center space-x-2 whitespace-nowrap"
              >
                <i className="ri-phone-line"></i>
                <span>Appeler</span>
              </button>
              <button 
                onClick={() => setShowMeetingModal(true)}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg flex items-center space-x-2 whitespace-nowrap"
              >
                <i className="ri-calendar-line"></i>
                <span>RDV</span>
              </button>
              <button className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg flex items-center space-x-2 whitespace-nowrap">
                <i className="ri-mail-line"></i>
                <span>Email</span>
              </button>
              <button className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg flex items-center space-x-2 whitespace-nowrap">
                <i className="ri-file-pdf-line"></i>
                <span>Rapport PDF</span>
              </button>
            </div>
          </div>

          <div className="flex space-x-1 mb-8 bg-gray-800/50 p-1 rounded-lg">
            {[
              { id: 'profil', label: 'Profil', icon: 'ri-user-line' },
              { id: 'patrimoine', label: 'Patrimoine', icon: 'ri-wallet-line' },
              { id: 'commercial', label: 'Commercial', icon: 'ri-briefcase-line' },
              { id: 'risque', label: 'Risque', icon: 'ri-shield-line' },
              { id: 'relation', label: 'Relation', icon: 'ri-heart-line' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 px-4 py-3 rounded-md flex items-center justify-center space-x-2 font-medium transition-all whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-400 hover:text-white hover:bg-gray-700/50'
                }`}
              >
                <i className={tab.icon}></i>
                <span>{tab.label}</span>
              </button>
            ))}
          </div>

          {activeTab === 'profil' && renderProfil()}
          {activeTab === 'patrimoine' && renderPatrimoine()}
          {activeTab === 'commercial' && renderCommercial()}
          {activeTab === 'risque' && renderRisque()}
          {activeTab === 'relation' && renderRelation()}
        </div>
      </div>

      {showContactModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-gray-900 rounded-lg p-6 w-96">
            <h3 className="text-lg font-semibold text-white mb-4">Contacter le client</h3>
            <div className="space-y-3">
              <button className="w-full p-3 bg-green-600 hover:bg-green-700 text-white rounded-lg flex items-center space-x-3">
                <i className="ri-phone-line"></i>
                <span>Appel téléphonique</span>
              </button>
              <button className="w-full p-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg flex items-center space-x-3">
                <i className="ri-vidicon-line"></i>
                <span>Visioconférence</span>
              </button>
              <button className="w-full p-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg flex items-center space-x-3">
                <i className="ri-mail-line"></i>
                <span>Envoyer un email</span>
              </button>
            </div>
            <button 
              onClick={() => setShowContactModal(false)}
              className="mt-4 w-full p-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg"
            >
              Annuler
            </button>
          </div>
        </div>
      )}

      {showMeetingModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-gray-900 rounded-lg p-6 w-96">
            <h3 className="text-lg font-semibold text-white mb-4">Programmer un rendez-vous</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-400 mb-1">Date</label>
                <input type="date" className="w-full p-2 bg-gray-800 border border-gray-600 rounded text-white" />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">Heure</label>
                <input type="time" className="w-full p-2 bg-gray-800 border border-gray-600 rounded text-white" />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">Sujet</label>
                <input type="text" placeholder="Objet du rendez-vous" className="w-full p-2 bg-gray-800 border border-gray-600 rounded text-white" />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-1">Type</label>
                <select className="w-full p-2 bg-gray-800 border border-gray-600 rounded text-white pr-8">
                  <option>Visioconférence</option>
                  <option>Agence</option>
                  <option>Téléphone</option>
                </select>
              </div>
            </div>
            <div className="flex space-x-3 mt-6">
              <button className="flex-1 p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg">
                Programmer
              </button>
              <button 
                onClick={() => setShowMeetingModal(false)}
                className="flex-1 p-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg"
              >
                Annuler
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}