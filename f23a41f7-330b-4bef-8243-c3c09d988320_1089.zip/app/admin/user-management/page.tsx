
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import AdminPasswordPrompt from '../../components/AdminPasswordPrompt';

interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  role: 'admin' | 'conseiller' | 'dev' | 'audit' | 'support' | 'client';
  status: 'active' | 'inactive' | 'pending' | 'suspended';
  lastLogin: string;
  createdAt: string;
  permissions: string[];
  kycStatus: 'pending' | 'verified' | 'rejected';
  complianceNotes: string;
  password?: string;
  tempPassword?: string;
}

export default function UserManagementPage() {
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState<User[]>([]);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [newUser, setNewUser] = useState({
    firstName: '',
    lastName: '',
    email: '',
    role: 'client' as User['role'],
    status: 'active' as User['status'],
    tempPassword: ''
  });
  const [passwordData, setPasswordData] = useState({
    newPassword: '',
    confirmPassword: '',
    generatePassword: false,
    sendByEmail: true
  });
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [showAdminAuth, setShowAdminAuth] = useState(false);
  const router = useRouter();

  useEffect(() => {
    // Accès direct sans authentification
    loadUsers();
  }, []);

  const loadUsers = () => {
    try {
      const storedUsers = localStorage.getItem('cmv_users');
      if (storedUsers) {
        setUsers(JSON.parse(storedUsers));
      } else {
        const defaultUsers: User[] = [
          {
            id: '1',
            firstName: 'Jean',
            lastName: 'Administrateur',
            email: 'admin@cmv.fr',
            role: 'admin',
            status: 'active',
            lastLogin: '2024-12-13 14:30',
            createdAt: '2024-01-15',
            permissions: ['all'],
            kycStatus: 'verified',
            complianceNotes: 'Administrateur principal - Accès complet'
          },
          {
            id: '2',
            firstName: 'Marie',
            lastName: 'Conseillère',
            email: 'conseiller@cmv.fr',
            role: 'conseiller',
            status: 'active',
            lastLogin: '2024-12-13 10:15',
            createdAt: '2024-02-20',
            permissions: ['client-management', 'portfolio', 'reports'],
            kycStatus: 'verified',
            complianceNotes: 'Conseillère patrimoniale certifiée AMF'
          },
          {
            id: '3',
            firstName: 'Pierre',
            lastName: 'Développeur',
            email: 'dev@cmv.fr',
            role: 'support',
            status: 'active',
            lastLogin: '2024-12-12 16:45',
            createdAt: '2024-03-10',
            permissions: ['code', 'deploy', 'logs'],
            kycStatus: 'verified',
            complianceNotes: 'Développeur principal - Accès technique autorisé'
          },
          {
            id: '4',
            firstName: 'Sophie',
            lastName: 'Auditrice',
            email: 'audit@cmv.fr',
            role: 'audit',
            status: 'active',
            lastLogin: '2024-12-13 09:20',
            createdAt: '2024-04-05',
            permissions: ['audit', 'compliance', 'reports'],
            kycStatus: 'verified',
            complianceNotes: 'Auditrice ACPR - Contrôle conformité'
          },
          {
            id: '5',
            firstName: 'Thomas',
            lastName: 'Support',
            email: 'support@cmv.fr',
            role: 'support',
            status: 'active',
            lastLogin: '2024-12-13 11:30',
            createdAt: '2024-05-12',
            permissions: ['tickets', 'docs', 'client-help'],
            kycStatus: 'verified',
            complianceNotes: 'Support technique - Assistance clients'
          },
          {
            id: '6',
            firstName: 'Claire',
            lastName: 'Martin',
            email: 'claire.martin@email.com',
            role: 'client',
            status: 'active',
            lastLogin: '2024-12-13 08:30',
            createdAt: '2024-11-15',
            permissions: ['dashboard', 'portfolio'],
            kycStatus: 'verified',
            complianceNotes: 'Cliente premium - KYC complet validé'
          }
        ];
        setUsers(defaultUsers);
        localStorage.setItem('cmv_users', JSON.stringify(defaultUsers));
      }
    } catch (error) {
      console.error('Erreur lors du chargement des utilisateurs:', error);
    }
  };

  const generateRandomPassword = () => {
    const length = 12;
    const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
    let password = "";
    for (let i = 0; i < length; i++) {
      password += charset.charAt(Math.floor(Math.random() * charset.length));
    }
    return password;
  };

  const handleCreateUser = () => {
    if (!newUser.firstName || !newUser.lastName || !newUser.email) {
      alert('Veuillez remplir tous les champs requis');
      return;
    }

    if (!newUser.tempPassword) {
      alert('Veuillez définir un mot de passe temporaire');
      return;
    }

    try {
      const user: User = {
        id: Date.now().toString(),
        ...newUser,
        lastLogin: 'Jamais connecté',
        createdAt: new Date().toISOString().split('T')[0],
        permissions: getDefaultPermissions(newUser.role),
        kycStatus: 'pending',
        complianceNotes: 'Nouvel utilisateur - Vérification KYC requise',
        password: newUser.tempPassword
      };

      const updatedUsers = [...users, user];
      setUsers(updatedUsers);
      localStorage.setItem('cmv_users', JSON.stringify(updatedUsers));

      setShowCreateModal(false);
      setNewUser({
        firstName: '',
        lastName: '',
        email: '',
        role: 'client',
        status: 'active',
        tempPassword: ''
      });

      alert(`Utilisateur créé avec succès !\nEmail: ${newUser.email}\nMot de passe temporaire: ${newUser.tempPassword}`);
    } catch (error) {
      console.error('Erreur lors de la création:', error);
      alert('Erreur lors de la création de l\'utilisateur');
    }
  };

  const handlePasswordChange = () => {
    if (!selectedUser) return;

    if (passwordData.generatePassword) {
      const newPassword = generateRandomPassword();
      setPasswordData({ ...passwordData, newPassword, confirmPassword: newPassword });
      return;
    }

    if (!passwordData.newPassword || !passwordData.confirmPassword) {
      alert('Veuillez remplir tous les champs');
      return;
    }

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      alert('Les mots de passe ne correspondent pas');
      return;
    }

    if (passwordData.newPassword.length < 8) {
      alert('Le mot de passe doit contenir au moins 8 caractères');
      return;
    }

    try {
      const updatedUsers = users.map(user =>
        user.id === selectedUser.id 
          ? { ...user, password: passwordData.newPassword }
          : user
      );
      setUsers(updatedUsers);
      localStorage.setItem('cmv_users', JSON.stringify(updatedUsers));

      setShowPasswordModal(false);
      setPasswordData({
        newPassword: '',
        confirmPassword: '',
        generatePassword: false,
        sendByEmail: true
      });

      alert(passwordData.generatePassword 
        ? `Nouveau mot de passe généré: ${passwordData.newPassword}` 
        : 'Mot de passe modifié avec succès !');
    } catch (error) {
      console.error('Erreur lors de la modification:', error);
      alert('Erreur lors de la modification du mot de passe');
    }
  };

  const handleEditUser = (user: User) => {
    setSelectedUser({ ...user });
    setShowEditModal(true);
  };

  const handlePasswordEdit = (user: User) => {
    setSelectedUser(user);
    setPasswordData({
      newPassword: '',
      confirmPassword: '',
      generatePassword: false,
      sendByEmail: true
    });
    setShowPasswordModal(true);
  };

  const handleUpdateUser = () => {
    if (!selectedUser) return;

    try {
      const updatedUsers = users.map(user =>
        user.id === selectedUser.id ? selectedUser : user
      );
      setUsers(updatedUsers);
      localStorage.setItem('cmv_users', JSON.stringify(updatedUsers));

      setShowEditModal(false);
      setSelectedUser(null);
      alert('Utilisateur modifié avec succès !');
    } catch (error) {
      console.error('Erreur lors de la modification:', error);
      alert('Erreur lors de la modification de l\'utilisateur');
    }
  };

  const handleDeleteUser = (userId: string) => {
    const userToDelete = users.find(u => u.id === userId);
    if (!userToDelete) return;

    if (confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur ?')) {
      try {
        const updatedUsers = users.filter(user => user.id !== userId);
        setUsers(updatedUsers);
        localStorage.setItem('cmv_users', JSON.stringify(updatedUsers));

        alert('Utilisateur supprimé avec succès !');
      } catch (error) {
        console.error('Erreur lors de la suppression:', error);
        alert('Erreur lors de la suppression de l\'utilisateur');
      }
    }
  };

  const handleLogout = () => {
    router.push('/');
  };

  const getDefaultPermissions = (role: User['role']): string[] => {
    switch (role) {
      case 'admin':
        return ['all'];
      case 'conseiller':
        return ['client-management', 'portfolio', 'reports', 'academy'];
      case 'dev':
        return ['code', 'deploy', 'logs', 'staging'];
      case 'audit':
        return ['audit', 'compliance', 'reports'];
      case 'support':
        return ['tickets', 'docs', 'client-help'];
      case 'client':
        return ['dashboard', 'portfolio', 'academy'];
      default:
        return ['dashboard'];
    }
  };

  const getRoleBadgeColor = (role: User['role']) => {
    switch (role) {
      case 'admin':
        return 'bg-red-500/20 text-red-400';
      case 'conseiller':
        return 'bg-blue-500/20 text-blue-400';
      case 'dev':
        return 'bg-purple-500/20 text-purple-400';
      case 'audit':
        return 'bg-green-500/20 text-green-400';
      case 'support':
        return 'bg-orange-500/20 text-orange-400';
      case 'client':
        return 'bg-yellow-500/20 text-yellow-400';
      default:
        return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getStatusBadgeColor = (status: User['status']) => {
    switch (status) {
      case 'active':
        return 'bg-green-500/20 text-green-400';
      case 'inactive':
        return 'bg-red-500/20 text-red-400';
      case 'pending':
        return 'bg-yellow-500/20 text-yellow-400';
      case 'suspended':
        return 'bg-gray-500/20 text-gray-400';
      default:
        return 'bg-gray-500/20 text-gray-400';
    }
  };

  const handleAdminAuthSuccess = () => {
    setShowAdminAuth(false);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header unifié avec le dashboard */}
      <header className="bg-gray-900 border-b border-yellow-500/30 sticky top-0 z-10">
        <div className="px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-6">
              <Link href="/" className="text-2xl font-bold text-yellow-400 font-['Pacifico']">
                logo
              </Link>
              <div className="h-8 w-px bg-gray-700"></div>
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
                  Gestion des Utilisateurs
                </h1>
                <p className="text-xs text-gray-400">Administration des comptes et rôles</p>
              </div>
              <div className="px-3 py-1 rounded-full text-xs font-bold bg-green-500/20 text-green-400 flex items-center space-x-1">
                <i className="ri-shield-check-line"></i>
                <span>Accès Direct</span>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <div className="text-sm font-medium text-white">Administrateur</div>
                <div className="text-xs text-gray-400">
                  Connecté • {new Date().toLocaleDateString('fr-FR')}
                </div>
              </div>
              <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center">
                <i className="ri-user-line text-black text-lg"></i>
              </div>
              <Link
                href="/admin/dashboard"
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors text-sm font-medium whitespace-nowrap cursor-pointer"
              >
                <i className="ri-arrow-left-line mr-2"></i>
                Retour
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Sidebar unifié */}
      <div className="flex">
        <div className="w-72 bg-gray-900 min-h-screen border-r border-gray-800">
          <div className="p-6">
            <h2 className="text-lg font-bold text-yellow-400 mb-6">Centre de Contrôle</h2>
            
            <nav className="space-y-2">
              <Link
                href="/admin/dashboard"
                className="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-400 hover:text-yellow-400 hover:bg-gray-800 transition-all cursor-pointer"
              >
                <i className="ri-dashboard-3-line text-xl"></i>
                <span>Tableau de Bord</span>
              </Link>
              
              <div className="flex items-center space-x-3 px-4 py-3 rounded-lg bg-yellow-500/20 text-yellow-400 font-medium">
                <i className="ri-user-settings-line text-xl"></i>
                <span>Gestion Utilisateurs</span>
              </div>
              
              {[
                { 
                  title: 'Gestion Académie', 
                  href: '/admin/academy-manager', 
                  icon: 'ri-graduation-cap-line'
                },
                { 
                  title: 'Dashboard Unifié', 
                  href: '/admin/unified-dashboard', 
                  icon: 'ri-layout-grid-line'
                },
                { 
                  title: 'Gestion Indicateurs', 
                  href: '/admin/indicators-manager', 
                  icon: 'ri-line-chart-line'
                },
                { 
                  title: 'Constructeur Site', 
                  href: '/admin/site-builder', 
                  icon: 'ri-building-line'
                },
                { 
                  title: "Codes d'Accès", 
                  href: '/admin/access-codes', 
                  icon: 'ri-key-line'
                },
                { 
                  title: 'Gestion Contenu', 
                  href: '/admin/create-blog', 
                  icon: 'ri-file-text-line'
                },
                { 
                  title: 'Paiements', 
                  href: '/admin/payment-history', 
                  icon: 'ri-bank-card-line'
                },
                { 
                  title: 'Paramètres', 
                  href: '/admin/settings', 
                  icon: 'ri-settings-3-line'
                }
              ].map((item, index) => (
                <Link
                  key={index}
                  href={item.href}
                  className="flex items-center space-x-3 px-4 py-3 rounded-lg text-gray-400 hover:text-yellow-400 hover:bg-gray-800 transition-all cursor-pointer"
                >
                  <i className={`${item.icon} text-xl`}></i>
                  <span>{item.title}</span>
                </Link>
              ))}
            </nav>
          </div>
        </div>

        {/* Contenu principal */}
        <div className="flex-1 p-8">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-3xl font-bold mb-2 bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
                Gestion des Utilisateurs
              </h2>
              <p className="text-gray-400">Créez et gérez les accès utilisateurs avec contrôle des permissions</p>
            </div>
            <button
              onClick={() => setShowCreateModal(true)}
              className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-medium transition-colors cursor-pointer whitespace-nowrap flex items-center"
            >
              <i className="ri-user-add-line mr-2"></i>
              Nouvel Utilisateur
            </button>
          </div>

          {/* Statistiques */}
          <div className="grid grid-cols-1 md:grid-cols-6 gap-4 mb-8">
            {[
              { label: 'Total', count: users.length, icon: 'ri-group-line', color: 'blue' },
              { label: 'Administrateurs', count: users.filter(u => u.role === 'admin').length, icon: 'ri-shield-user-line', color: 'red' },
              { label: 'Conseillers', count: users.filter(u => u.role === 'conseiller').length, icon: 'ri-user-star-line', color: 'blue' },
              { label: 'Développeurs', count: users.filter(u => u.role === 'dev').length, icon: 'ri-code-line', color: 'purple' },
              { label: 'Soutien', count: users.filter(u => u.role === 'support').length, icon: 'ri-customer-service-line', color: 'orange' },
              { label: 'Clients', count: users.filter(u => u.role === 'client').length, icon: 'ri-user-line', color: 'yellow' }
            ].map((stat, index) => (
              <div key={index} className="bg-gray-900 rounded-lg p-4 border border-gray-800">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">{stat.label}</p>
                    <p className={`text-2xl font-bold text-${stat.color}-400`}>{stat.count}</p>
                  </div>
                  <div className="w-8 h-8 flex items-center justify-center">
                    <i className={`${stat.icon} text-${stat.color}-400 text-2xl`}></i>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Liste des utilisateurs */}
          <div className="bg-gray-900 rounded-lg border border-gray-800 overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-800 bg-gray-800/50">
              <h3 className="text-xl font-semibold text-white">Liste des Utilisateurs ({users.length})</h3>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-800">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Utilisateur
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Rôle
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Statut
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      KYC
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Dernière Connexion
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-800">
                  {users.map((user) => (
                    <tr key={user.id} className="hover:bg-gray-800/50 transition-colors">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center text-black font-bold text-sm">
                            {user.firstName[0]}{user.lastName[0]}
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-white">
                              {user.firstName} {user.lastName}
                            </div>
                            <div className="text-sm text-gray-400">{user.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${getRoleBadgeColor(user.role)}`}>
                          {user.role.toUpperCase()}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${getStatusBadgeColor(user.status)}`}>
                          {user.status === 'active' ? 'Actif' : 
                           user.status === 'inactive' ? 'Inactif' : 
                           user.status === 'pending' ? 'En attente' : 'Suspendu'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${
                            user.kycStatus === 'verified' ? 'bg-green-500/20 text-green-400' : 
                            user.kycStatus === 'pending' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-red-500/20 text-red-400'
                          }`}
                        >
                          {user.kycStatus === 'verified' ? 'Vérifié' : 
                           user.kycStatus === 'pending' ? 'En attente' : 'Rejeté'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-400">
                        {user.lastLogin}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex space-x-3">
                          <button
                            onClick={() => handleEditUser(user)}
                            className="text-blue-400 hover:text-blue-300 cursor-pointer transition-colors"
                            title="Modifier utilisateur"
                          >
                            <i className="ri-edit-line text-lg"></i>
                          </button>
                          <button
                            onClick={() => handlePasswordEdit(user)}
                            className="text-purple-400 hover:text-purple-300 cursor-pointer transition-colors"
                            title="Modifier mot de passe"
                          >
                            <i className="ri-lock-password-line text-lg"></i>
                          </button>
                          <button
                            className="text-green-400 hover:text-green-300 cursor-pointer transition-colors"
                            title="Voir conformité"
                          >
                            <i className="ri-shield-check-line text-lg"></i>
                          </button>
                          {user.role !== 'admin' && (
                            <button
                              onClick={() => handleDeleteUser(user.id)}
                              className="text-red-400 hover:text-red-300 cursor-pointer transition-colors"
                              title="Supprimer utilisateur"
                            >
                              <i className="ri-delete-bin-line text-lg"></i>
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Modal Création d'utilisateur */}
          {showCreateModal && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
              <div className="bg-gray-900 rounded-lg p-6 w-full max-w-md mx-4 border border-gray-800">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-white">Créer un Utilisateur</h3>
                  <button
                    onClick={() => setShowCreateModal(false)}
                    className="text-gray-400 hover:text-white cursor-pointer"
                  >
                    <i className="ri-close-line text-xl"></i>
                  </button>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2 text-gray-300">Prénom *</label>
                    <input
                      type="text"
                      value={newUser.firstName}
                      onChange={(e) => setNewUser({ ...newUser, firstName: e.target.value })}
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-500 focus:outline-none"
                      placeholder="Entrez le prénom"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2 text-gray-300">Nom *</label>
                    <input
                      type="text"
                      value={newUser.lastName}
                      onChange={(e) => setNewUser({ ...newUser, lastName: e.target.value })}
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-500 focus:outline-none"
                      placeholder="Entrez le nom"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2 text-gray-300">Email *</label>
                    <input
                      type="email"
                      value={newUser.email}
                      onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-500 focus:outline-none"
                      placeholder="exemple@email.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2 text-gray-300">Rôle</label>
                    <select
                      value={newUser.role}
                      onChange={(e) => setNewUser({ ...newUser, role: e.target.value as User['role'] })}
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-500 focus:outline-none pr-8"
                    >
                      <option value="client">Client</option>
                      <option value="conseiller">Conseiller</option>
                      <option value="support">Support</option>
                      <option value="audit">Audit</option>
                      <option value="dev">Développeur</option>
                      <option value="admin">Administrateur</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2 text-gray-300">Mot de passe temporaire *</label>
                    <div className="flex space-x-2">
                      <input
                        type="text"
                        value={newUser.tempPassword}
                        onChange={(e) => setNewUser({ ...newUser, tempPassword: e.target.value })}
                        className="flex-1 px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-500 focus:outline-none"
                        placeholder="Mot de passe temporaire"
                      />
                      <button
                        type="button"
                        onClick={() => setNewUser({ ...newUser, tempPassword: generateRandomPassword() })}
                        className="px-4 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                        title="Générer un mot de passe"
                      >
                        <i className="ri-refresh-line"></i>
                      </button>
                    </div>
                  </div>
                </div>
                
                <div className="flex space-x-3 mt-8">
                  <button
                    onClick={() => setShowCreateModal(false)}
                    className="flex-1 px-4 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-lg font-medium transition-colors cursor-pointer"
                  >
                    Annuler
                  </button>
                  <button
                    onClick={handleCreateUser}
                    className="flex-1 px-4 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-medium transition-colors cursor-pointer"
                  >
                    Créer
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Modal Modification d'utilisateur */}
          {showEditModal && selectedUser && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
              <div className="bg-gray-900 rounded-lg p-6 w-full max-w-lg mx-4 max-h-[90vh] overflow-y-auto border border-gray-800">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-white">Modifier l'Utilisateur</h3>
                  <button
                    onClick={() => setShowEditModal(false)}
                    className="text-gray-400 hover:text-white cursor-pointer"
                  >
                    <i className="ri-close-line text-xl"></i>
                  </button>
                </div>

                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium mb-2 text-gray-300">Prénom</label>
                      <input
                        type="text"
                        value={selectedUser.firstName}
                        onChange={(e) => setSelectedUser({ ...selectedUser, firstName: e.target.value })}
                        className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2 text-gray-300">Nom</label>
                      <input
                        type="text"
                        value={selectedUser.lastName}
                        onChange={(e) => setSelectedUser({ ...selectedUser, lastName: e.target.value })}
                        className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-2 text-gray-300">Email</label>
                    <input
                      type="email"
                      value={selectedUser.email}
                      onChange={(e) => setSelectedUser({ ...selectedUser, email: e.target.value })}
                      className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white focus:border-yellow-500 focus:outline-none"
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium mb-2 text-gray-300">Rôle</label>
                      <select
                        value={selectedUser.role}
                        onChange={(e) => {
                          const role = e.target.value as User['role'];
                          setSelectedUser({
                            ...selectedUser,
                            role,
                            permissions: getDefaultPermissions(role)
                          });
                        }}
                        className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white focus:border-yellow-500 focus:outline-none pr-8"
                      >
                        <option value="client">Client</option>
                        <option value="conseiller">Conseiller</option>
                        <option value="support">Support</option>
                        <option value="audit">Audit</option>
                        <option value="dev">Développeur</option>
                        <option value="admin">Administrateur</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2 text-gray-300">Statut</label>
                      <select
                        value={selectedUser.status}
                        onChange={(e) => setSelectedUser({ ...selectedUser, status: e.target.value as User['status'] })}
                        className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white focus:border-yellow-500 focus:outline-none pr-8"
                      >
                        <option value="active">Actif</option>
                        <option value="pending">En attente</option>
                        <option value="inactive">Inactif</option>
                        <option value="suspended">Suspendu</option>
                      </select>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-2 text-gray-300">Notes de conformité</label>
                    <textarea
                      value={selectedUser.complianceNotes}
                      onChange={(e) => setSelectedUser({ ...selectedUser, complianceNotes: e.target.value })}
                      className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded text-white focus:border-yellow-500 focus:outline-none resize-none"
                      rows={3}
                      placeholder="Notes de conformité..."
                    />
                  </div>
                </div>
                
                <div className="flex space-x-3 mt-6">
                  <button
                    onClick={() => setShowEditModal(false)}
                    className="flex-1 px-4 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-lg font-medium transition-colors cursor-pointer"
                  >
                    Annuler
                  </button>
                  <button
                    onClick={handleUpdateUser}
                    className="flex-1 px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors cursor-pointer"
                  >
                    Sauvegarder
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Modal Modification de mot de passe */}
          {showPasswordModal && selectedUser && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
              <div className="bg-gray-900 rounded-lg p-6 w-full max-w-md mx-4 border border-gray-800">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold text-white">Modifier le Mot de Passe</h3>
                  <button
                    onClick={() => setShowPasswordModal(false)}
                    className="text-gray-400 hover:text-white cursor-pointer"
                  >
                    <i className="ri-close-line text-xl"></i>
                  </button>
                </div>

                <div className="mb-4 p-4 bg-gray-800 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center text-black font-bold text-sm">
                      {selectedUser.firstName[0]}{selectedUser.lastName[0]}
                    </div>
                    <div>
                      <div className="text-white font-medium">{selectedUser.firstName} {selectedUser.lastName}</div>
                      <div className="text-gray-400 text-sm">{selectedUser.email}</div>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-center space-x-3 p-3 bg-gray-800 rounded-lg">
                    <input
                      type="checkbox"
                      id="generatePassword"
                      checked={passwordData.generatePassword}
                      onChange={(e) => setPasswordData({ ...passwordData, generatePassword: e.target.checked })}
                      className="w-4 h-4 text-yellow-500 border-gray-600 rounded focus:ring-yellow-500"
                    />
                    <label htmlFor="generatePassword" className="text-gray-300 text-sm cursor-pointer">
                      Générer un mot de passe automatiquement
                    </label>
                  </div>

                  {!passwordData.generatePassword && (
                    <>
                      <div>
                        <label className="block text-sm font-medium mb-2 text-gray-300">Nouveau mot de passe</label>
                        <input
                          type="password"
                          value={passwordData.newPassword}
                          onChange={(e) => setPasswordData({ ...passwordData, newPassword: e.target.value })}
                          className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-500 focus:outline-none"
                          placeholder="Minimum 8 caractères"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2 text-gray-300">Confirmer le mot de passe</label>
                        <input
                          type="password"
                          value={passwordData.confirmPassword}
                          onChange={(e) => setPasswordData({ ...passwordData, confirmPassword: e.target.value })}
                          className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-yellow-500 focus:outline-none"
                          placeholder="Répétez le mot de passe"
                        />
                      </div>
                    </>
                  )}

                  {passwordData.generatePassword && passwordData.newPassword && (
                    <div className="p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
                      <div className="text-yellow-400 font-medium mb-2">Mot de passe généré :</div>
                      <div className="text-white font-mono bg-gray-800 p-2 rounded text-sm break-all">
                        {passwordData.newPassword}
                      </div>
                    </div>
                  )}

                  <div className="flex items-center space-x-3 p-3 bg-gray-800 rounded-lg">
                    <input
                      type="checkbox"
                      id="sendByEmail"
                      checked={passwordData.sendByEmail}
                      onChange={(e) => setPasswordData({ ...passwordData, sendByEmail: e.target.checked })}
                      className="w-4 h-4 text-yellow-500 border-gray-600 rounded focus:ring-yellow-500"
                    />
                    <label htmlFor="sendByEmail" className="text-gray-300 text-sm cursor-pointer">
                      Envoyer le nouveau mot de passe par email
                    </label>
                  </div>
                </div>
                
                <div className="flex space-x-3 mt-8">
                  <button
                    onClick={() => setShowPasswordModal(false)}
                    className="flex-1 px-4 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-lg font-medium transition-colors cursor-pointer"
                  >
                    Annuler
                  </button>
                  <button
                    onClick={handlePasswordChange}
                    className="flex-1 px-4 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg font-medium transition-colors cursor-pointer"
                  >
                    {passwordData.generatePassword ? 'Générer' : 'Modifier'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Modal d'authentification administrateur */}
          <AdminPasswordPrompt
            isOpen={showAdminAuth}
            onClose={() => setShowAdminAuth(false)}
            onSuccess={handleAdminAuthSuccess}
            adminEmail={currentUser?.email || 'admin@cmv.fr'}
          />
        </div>
      </div>
    </div>
  );
}
