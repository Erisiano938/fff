'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { getPlans, savePlan, updatePlan, deletePlan, getPaymentSettings, updatePaymentSettings, type Plan, type PaymentPageSettings } from '../../lib/plansStorage';

export default function PlansManager() {
  const [authenticated, setAuthenticated] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [activeTab, setActiveTab] = useState('plans');
  const [plans, setPlans] = useState<Plan[]>([]);
  const [settings, setSettings] = useState<PaymentPageSettings | null>(null);
  const [editingPlan, setEditingPlan] = useState<Plan | null>(null);
  const [showPlanModal, setShowPlanModal] = useState(false);
  const [newFeature, setNewFeature] = useState('');
  const [customProperties, setCustomProperties] = useState<{[key: string]: any}>({});
  const router = useRouter();

  // Vérification d'authentification unifiée
  const isAuthenticated = () => {
    const adminUser = localStorage.getItem('cmv_admin_user');
    const adminAuth = localStorage.getItem('adminAuth');
    return !!(adminUser || adminAuth);
  };

  useEffect(() => {
    if (!isAuthenticated()) {
      router.push('/admin/login');
      return;
    }

    // Charger les données utilisateur
    try {
      const adminUser = localStorage.getItem('cmv_admin_user');
      const adminAuth = localStorage.getItem('adminAuth');
      
      let userData = null;
      if (adminUser) {
        userData = JSON.parse(adminUser);
      } else {
        userData = {
          email: 'admin@cmv.fr',
          name: 'Administrateur',
          role: 'admin'
        };
      }
      
      setUser(userData);
      setAuthenticated(true);
    } catch (error) {
      console.error('Erreur authentification:', error);
      router.push('/admin/login');
      return;
    }

    loadData();
  }, [router]);

  const loadData = () => {
    setPlans(getPlans());
    setSettings(getPaymentSettings());
  };

  const handleLogout = () => {
    localStorage.removeItem('cmv_admin_user');
    localStorage.removeItem('adminAuth');
    router.push('/admin/login');
  };

  const handleSavePlan = () => {
    if (!editingPlan) return;

    const planWithCustomProps = {
      ...editingPlan,
      ...customProperties
    };

    if (editingPlan.id && editingPlan.id !== 'new') {
      updatePlan(editingPlan.id, planWithCustomProps);
    } else {
      const { id, createdAt, updatedAt, ...planData } = planWithCustomProps;
      savePlan(planData);
    }

    loadData();
    setShowPlanModal(false);
    setEditingPlan(null);
    setCustomProperties({ });
  };

  const handleDeletePlan = (id: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce forfait ?')) {
      deletePlan(id);
      loadData();
    }
  };

  const handleAddPlan = () => {
    const newPlan: Plan = {
      id: 'new',
      name: 'Nouveau Forfait',
      price: '99€',
      period: '/mois',
      features: ['Nouvelle fonctionnalité'],
      popular: false,
      color: '#3B82F6',
      icon: 'ri-star-line',
      description: 'Description du nouveau forfait',
      order: plans.length + 1,
      active: true,
      buttonText: 'Choisir ce plan',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    setEditingPlan(newPlan);
    setCustomProperties({ });
    setShowPlanModal(true);
  };

  const handleEditPlan = (plan: Plan) => {
    const standardProps = [ 'id', 'name', 'price', 'period', 'features', 'popular', 'color', 'icon', 'description', 'order', 'active', 'buttonText', 'badge', 'createdAt', 'updatedAt' ];
    const customProps: {[key: string]: any} = { };

    Object.keys(plan).forEach(key => {
      if (!standardProps.includes(key)) {
        customProps[key] = (plan as any)[key];
      }
    });

    setEditingPlan({ ...plan });
    setCustomProperties(customProps);
    setShowPlanModal(true);
  };

  const addFeature = () => {
    if (!newFeature.trim() || !editingPlan) return;

    setEditingPlan({
      ...editingPlan,
      features: [...editingPlan.features, newFeature.trim()]
    });
    setNewFeature('');
  };

  const removeFeature = (index: number) => {
    if (!editingPlan) return;

    setEditingPlan({
      ...editingPlan,
      features: editingPlan.features.filter((_, i) => i !== index)
    });
  };

  const updateFeature = (index: number, value: string) => {
    if (!editingPlan) return;

    const updatedFeatures = [...editingPlan.features];
    updatedFeatures[index] = value;
    setEditingPlan({
      ...editingPlan,
      features: updatedFeatures
    });
  };

  const addCustomProperty = () => {
    const key = prompt('Nom de la nouvelle propriété:');
    if (key && key.trim()) {
      setCustomProperties({
        ...customProperties,
        [key.trim()]: ''
      });
    }
  };

  const updateCustomProperty = (key: string, value: any) => {
    setCustomProperties({
      ...customProperties,
      [key]: value
    });
  };

  const removeCustomProperty = (key: string) => {
    const updated = { ...customProperties };
    delete updated[key];
    setCustomProperties(updated);
  };

  const renderCustomPropertyInput = (key: string, value: any) => {
    if (typeof value === 'boolean') {
      return (
        <input
          type="checkbox"
          checked={value}
          onChange={(e) => updateCustomProperty(key, e.target.checked)}
          className="w-4 h-4 bg-gray-800 border border-gray-700 rounded focus:ring-yellow-500"
        />
      );
    } else if (typeof value === 'number') {
      return (
        <input
          type="number"
          value={value}
          onChange={(e) => updateCustomProperty(key, parseFloat(e.target.value) || 0)}
          className="flex-1 p-2 bg-gray-700 border border-gray-600 rounded text-white text-sm focus:border-yellow-500 focus:outline-none"
        />
      );
    } else if (typeof value === 'string' && value.length > 50) {
      return (
        <textarea
          value={value}
          onChange={(e) => updateCustomProperty(key, e.target.value)}
          rows={3}
          className="flex-1 p-2 bg-gray-700 border border-gray-600 rounded text-white text-sm focus:border-yellow-500 focus:outline-none resize-none"
        />
      );
    } else {
      return (
        <input
          type="text"
          value={value}
          onChange={(e) => updateCustomProperty(key, e.target.value)}
          className="flex-1 p-2 bg-gray-700 border border-gray-600 rounded text-white text-sm focus:border-yellow-500 focus:outline-none"
        />
      );
    }
  };

  const handleSaveSettings = () => {
    if (settings) {
      updatePaymentSettings(settings);
      alert('Paramètres sauvegardés avec succès !');
    }
  };

  const addSecurityFeature = () => {
    if (!settings) return;

    setSettings({
      ...settings,
      securityFeatures: [
        ...settings.securityFeatures,
        { text: 'Nouvelle fonctionnalité', icon: 'ri-shield-line' }
      ]
    });
  };

  const removeSecurityFeature = (index: number) => {
    if (!settings) return;

    setSettings({
      ...settings,
      securityFeatures: settings.securityFeatures.filter((_, i) => i !== index)
    });
  };

  const exportConfiguration = () => {
    const config = {
      plans: plans,
      settings: settings,
      timestamp: new Date().toISOString()
    };

    const dataStr = JSON.stringify(config, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `forfaits-config-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const importConfiguration = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const config = JSON.parse(e.target?.result as string);
        if (config.plans && Array.isArray(config.plans)) {
          config.plans.forEach((plan: any) => {
            if (plan.id && plan.id !== 'new') {
              updatePlan(plan.id, plan);
            } else {
              const { id, createdAt, updatedAt, ...planData } = plan;
              savePlan(planData);
            }
          });
        }
        if (config.settings) {
          updatePaymentSettings(config.settings);
        }
        loadData();
        alert('Configuration importée avec succès !');
      } catch (error) {
        alert('Erreur lors de l\'import du fichier de configuration');
        console.error('Import error:', error);
      }
    };
    reader.readAsText(file);
    event.target.value = '';
  };

  const iconOptions = [
    'ri-user-line', 'ri-vip-crown-line', 'ri-vip-diamond-line', 'ri-star-line',
    'ri-trophy-line', 'ri-rocket-line', 'ri-shield-star-line', 'ri-medal-line',
    'ri-award-line', 'ri-gem-line', 'ri-fire-line', 'ri-flashlight-line'
  ];

  const colorPresets = [
    '#3B82F6', '#EAB308', '#8B5CF6', '#10B981', '#F59E0B', '#EF4444',
    '#06B6D4', '#84CC16', '#F97316', '#EC4899', '#6366F1', '#14B8A6'
  ];

  if (!authenticated) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-yellow-500 mx-auto mb-4"></div>
          <p className="text-white">Chargement de la gestion des forfaits...</p>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'plans', name: 'Forfaits', icon: 'ri-price-tag-3-line' },
    { id: 'settings', name: 'Paramètres Page', icon: 'ri-settings-3-line' },
    { id: 'advanced', name: 'Avancé', icon: 'ri-code-line' },
    { id: 'preview', name: 'Aperçu', icon: 'ri-eye-line' }
  ];

  return (
    <>
      <div className="min-h-screen bg-black text-white">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center space-x-4">
              <Link 
                href="/admin/dashboard"
                className="flex items-center text-gray-400 hover:text-white transition-colors cursor-pointer"
              >
                <i className="ri-arrow-left-line mr-2"></i>
                Retour
              </Link>
              <h1 className="text-3xl font-bold">Gestion des Forfaits</h1>
            </div>
            <div className="flex space-x-4">
              <Link 
                href="/payment"
                target="_blank"
                className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
              >
                <i className="ri-external-link-line mr-2"></i>
                Voir la Page
              </Link>
              {activeTab === 'settings' && (
                <button 
                  onClick={handleSaveSettings}
                  className="bg-yellow-500 hover:bg-yellow-600 text-black px-6 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
                >
                  <i className="ri-save-line mr-2"></i>
                  Sauvegarder
                </button>
              )}
            </div>
          </div>

          <div className="flex space-x-8">
            {/* Navigation */}
            <div className="w-64">
              <nav className="space-y-2">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors whitespace-nowrap cursor-pointer ${ 
                      activeTab === tab.id 
                        ? 'bg-yellow-500 text-black' 
                        : 'text-gray-400 hover:text-white hover:bg-gray-800'
                    }`}
                  >
                    <i className={tab.icon}></i>
                    <span>{tab.name}</span>
                  </button>
                ))}
              </nav>

              <div className="mt-8 bg-gray-900 p-4 rounded-xl border border-yellow-500/20">
                <h3 className="font-semibold mb-3">Statistiques</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Forfaits actifs:</span>
                    <span className="text-white font-medium">{plans.filter(p => p.active).length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Total forfaits:</span>
                    <span className="text-white font-medium">{plans.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Populaires:</span>
                    <span className="text-white font-medium">{plans.filter(p => p.popular).length}</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 bg-gray-900 p-4 rounded-xl border border-yellow-500/20">
                <h3 className="font-semibold mb-3">Actions Rapides</h3>
                <div className="space-y-2">
                  <button
                    onClick={exportConfiguration}
                    className="w-full text-left text-sm text-gray-400 hover:text-white p-2 rounded hover:bg-gray-800 transition-colors cursor-pointer"
                  >
                    <i className="ri-download-line mr-2"></i>
                    Exporter Config
                  </button>
                  <label className="w-full text-left text-sm text-gray-400 hover:text-white p-2 rounded hover:bg-gray-800 transition-colors cursor-pointer block">
                    <i className="ri-upload-line mr-2"></i>
                    Importer Config
                    <input
                      type="file"
                      accept=".json"
                      onChange={importConfiguration}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>
            </div>

            {/* Contenu */}
            <div className="flex-1">
              {activeTab === 'plans' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h2 className="text-2xl font-bold">Gestion des Forfaits</h2>
                    <button 
                      onClick={handleAddPlan}
                      className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
                    >
                      <i className="ri-add-line mr-2"></i>
                      Nouveau Forfait
                    </button>
                  </div>

                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {plans.map((plan) => (
                      <div key={plan.id} className="bg-gray-900 p-6 rounded-xl border border-yellow-500/20 relative">
                        {plan.popular && (
                          <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                            <span className="bg-yellow-500 text-black px-3 py-1 rounded-full text-xs font-bold">
                              {plan.badge || 'POPULAIRE'}
                            </span>
                          </div>
                        )}                        
                        <div className="flex items-center space-x-3 mb-4">
                          <div 
                            className="w-12 h-12 rounded-lg flex items-center justify-center"
                            style={{ backgroundColor: plan.color + '20' }}
                          >
                            <i className={`${plan.icon} text-2xl`} style={{ color: plan.color }}></i>
                          </div>
                          <div className="flex-1">
                            <h3 className="text-xl font-bold">{plan.name}</h3>
                            <p className="text-gray-400 text-sm">{plan.description}</p>
                          </div>
                        </div>

                        <div className="mb-4">
                          <div className="flex items-center">
                            <span className="text-3xl font-bold" style={{ color: plan.color }}>
                              {plan.price}
                            </span>
                            <span className="text-gray-400 ml-1">{plan.period}</span>
                          </div>
                        </div>

                        <div className="mb-4">
                          <h4 className="font-semibold mb-2">Fonctionnalités:</h4>
                          <ul className="space-y-1 text-sm">
                            {plan.features.slice(0, 3).map((feature, index) => (
                              <li key={index} className="flex items-center text-gray-300">
                                <i className="ri-check-line text-green-400 mr-2 text-sm"></i>
                                {feature}
                              </li>
                            ))}
                            {plan.features.length > 3 && (
                              <li className="text-gray-400 text-xs">
                                +{plan.features.length - 3} autres fonctionnalités
                              </li>
                            )}
                          </ul>
                        </div>

                        <div className="flex items-center justify-between mb-4">
                          <span className={`px-2 py-1 rounded text-xs font-semibold ${ 
                            plan.active 
                              ? 'bg-green-500/20 text-green-400' 
                              : 'bg-gray-500/20 text-gray-400'
                          }`}>
                            {plan.active ? 'Actif' : 'Inactif'}
                          </span>
                          <span className="text-xs text-gray-400">
                            Ordre: {plan.order}
                          </span>
                        </div>

                        {/* Affichage des propriétés personnalisées */}
                        {Object.keys(plan).filter(key => ![ 'id', 'name', 'price', 'period', 'features', 'popular', 'color', 'icon', 'description', 'order', 'active', 'buttonText', 'badge', 'createdAt', 'updatedAt'].includes(key)).length > 0 && (
                          <div className="mb-4 p-2 bg-gray-800 rounded text-xs">
                            <div className="text-gray-400 mb-1">Propriétés personnalisées:</div>
                            {Object.keys(plan).filter(key => ![ 'id', 'name', 'price', 'period', 'features', 'popular', 'color', 'icon', 'description', 'order', 'active', 'buttonText', 'badge', 'createdAt', 'updatedAt'].includes(key)).slice(0, 2).map(key => (
                              <div key={key} className="text-gray-300">
                                {key}: {String((plan as any)[key]).slice(0, 20)}...
                              </div>
                            ))}
                          </div>
                        )}

                        <div className="flex space-x-2">
                          <button
                            onClick={() => handleEditPlan(plan)}
                            className="flex-1 bg-blue-500 hover:bg-blue-600 text-white py-2 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap"
                          >
                            <i className="ri-edit-line mr-2"></i>
                            Modifier
                          </button>
                          <button
                            onClick={() => handleDeletePlan(plan.id)}
                            className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-semibold transition-colors cursor-pointer"
                          >
                            <i className="ri-delete-bin-line"></i>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === 'advanced' && (
                <div className="space-y-8">
                  <h2 className="text-2xl font-bold">Configuration Avancée</h2>

                  <div className="bg-gray-900 p-6 rounded-xl border border-yellow-500/20">
                    <h3 className="text-xl font-bold mb-4">Éditeur JSON</h3>
                    <p className="text-gray-400 mb-4">Modifiez directement la configuration JSON des forfaits pour un contrôle total.</p>

                    <textarea
                      value={JSON.stringify({ plans, settings }, null, 2)}
                      onChange={(e) => {
                        try {
                          const parsed = JSON.parse(e.target.value);
                          if (parsed.plans && Array.isArray(parsed.plans)) {
                            setPlans(parsed.plans);
                          }
                          if (parsed.settings) {
                            setSettings(parsed.settings);
                          }
                        } catch (error) {
                          // Ignorer les erreurs de parsing pendant la saisie
                        }
                      }}
                      className="w-full h-96 p-4 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm font-mono focus:border-yellow-500 focus:outline-none resize-none"
                      style={{ fontSize: '12px', lineHeight: '1.4' }}
                    />

                    <div className="flex justify-between items-center mt-4">
                      <span className="text-sm text-gray-400">
                        Modification en temps réel - Sauvegardez vos changements
                      </span>
                      <div className="flex space-x-2">
                        <button
                          onClick={() => {
                            try {
                              JSON.parse(JSON.stringify({ plans, settings }));
                              alert('Format JSON valide ✓');
                            } catch (error) {
                              alert('Format JSON invalide ✗');
                            }
                          }}
                          className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap"
                        >
                          <i className="ri-check-line mr-2"></i>
                          Valider JSON
                        </button>
                        <button
                          onClick={() => {
                            plans.forEach(plan => {
                              if (plan.id && plan.id !== 'new') {
                                updatePlan(plan.id, plan);
                              }
                            });
                            if (settings) {
                              updatePaymentSettings(settings);
                            }
                            alert('Configuration sauvegardée !');
                          }}
                          className="bg-yellow-500 hover:bg-yellow-600 text-black px-4 py-2 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap"
                        >
                          <i className="ri-save-line mr-2"></i>
                          Sauvegarder Tout
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-900 p-6 rounded-xl border border-yellow-500/20">
                    <h3 className="text-xl font-bold mb-4">Outils de Développement</h3>

                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <h4 className="font-semibold">Actions en Lot</h4>
                        <div className="space-y-2">
                          <button
                            onClick={() => {
                              const updatedPlans = plans.map(plan => ({ ...plan, active: true }));
                              setPlans(updatedPlans);
                            }}
                            className="w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap"
                          >
                            Activer Tous les Forfaits
                          </button>
                          <button
                            onClick={() => {
                              const updatedPlans = plans.map(plan => ({ ...plan, active: false }));
                              setPlans(updatedPlans);
                            }}
                            className="w-full bg-red-600 hover:bg-red-700 text-white py-2 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap"
                          >
                            Désactiver Tous les Forfaits
                          </button>
                          <button
                            onClick={() => {
                              const updatedPlans = plans.map(plan => ({ ...plan, popular: false }));
                              setPlans(updatedPlans);
                            }}
                            className="w-full bg-gray-600 hover:bg-gray-700 text-white py-2 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap"
                          >
                            Supprimer Badges Populaires
                          </button>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <h4 className="font-semibold">Génération Automatique</h4>
                        <div className="space-y-2">
                          <button
                            onClick={() => {
                              const colors = colorPresets;
                              const updatedPlans = plans.map((plan, index) => ({
                                ...plan,
                                color: colors[index % colors.length],
                                order: index + 1
                              }));
                              setPlans(updatedPlans);
                            }}
                            className="w-full bg-purple-600 hover:bg-purple-700 text-white py-2 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap"
                          >
                            Auto-Couleurs & Ordre
                          </button>
                          <button
                            onClick={() => {
                              const icons = iconOptions;
                              const updatedPlans = plans.map((plan, index) => ({
                                ...plan,
                                icon: icons[index % icons.length]
                              }));
                              setPlans(updatedPlans);
                            }}
                            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-2 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap"
                          >
                            Auto-Icônes
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'preview' && settings && (
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold">Aperçu de la Page de Paiement</h2>

                  <div 
                    className="rounded-xl p-8 min-h-screen"
                    style={{ backgroundColor: settings.backgroundColor, color: settings.textColor }}
                  >
                    <div className="max-w-4xl mx-auto">
                      <div className="text-center mb-12">
                        <h1 className="text-4xl font-bold mb-4">
                          {settings.title.split(' ').map((word, index) => 
                            word.toLowerCase() === settings.headerText.toLowerCase() ? (
                              <span key={index} style={{ color: settings.accentColor }}>{word} </span>
                            ) : (
                              word + ' '
                            )
                          )}
                        </h1>
                        <p className="text-xl opacity-75 max-w-2xl mx-auto">
                          {settings.subtitle}
                        </p>
                      </div>

                      <div className="grid md:grid-cols-3 gap-6 mb-12">
                        {plans.filter(p => p.active).map((plan) => (
                          <div
                            key={plan.id}
                            className={`relative p-6 rounded-2xl border-2 transition-all ${ 
                              plan.popular ? 'ring-2' : ''
                            }`}
                            style={{ 
                              borderColor: plan.popular ? settings.accentColor : '#374151',
                              backgroundColor: plan.popular ? settings.accentColor + '10' : '#1F2937',
                              ringColor: plan.popular ? settings.accentColor + '50' : 'transparent'
                            }}
                          >
                            {plan.popular && plan.badge && (
                              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                                <span 
                                  className="px-4 py-1 rounded-full text-sm font-bold"
                                  style={{ backgroundColor: settings.accentColor, color: settings.backgroundColor }}
                                >
                                  {plan.badge}
                                </span>
                              </div>
                            )}                            
                            <div className="text-center mb-6">
                              <div className="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center"
                                   style={{ backgroundColor: plan.color + '20' }}
                              >
                                <i className={`${plan.icon} text-3xl`} style={{ color: plan.color }}></i>
                              </div>
                              <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                              <div className="flex items-center justify-center">
                                <span className="text-4xl font-bold" style={{ color: settings.accentColor }}>
                                  {plan.price}
                                </span>
                                <span className="opacity-75 ml-1">{plan.period}</span>
                              </div>
                              <p className="text-sm opacity-75 mt-2">{plan.description}</p>
                            </div>

                            <ul className="space-y-2 mb-6">
                              {plan.features.map((feature, index) => (
                                <li key={index} className="flex items-center opacity-90">
                                  <i className="ri-check-line mr-3 text-lg" style={{ color: settings.accentColor }}></i>
                                  {feature}
                                </li>
                              ))}
                            </ul>

                            <button 
                              className="w-full py-3 rounded-lg font-bold transition-colors whitespace-nowrap"
                              style={{ 
                                backgroundColor: plan.popular ? settings.accentColor : 'transparent',
                                color: plan.popular ? settings.backgroundColor : settings.accentColor,
                                border: `2px solid ${settings.accentColor}`
                              }}
                            >
                              {plan.buttonText}
                            </button>
                          </div>
                        ))}
                      </div>

                      <div className="text-center">
                        <div className="inline-flex items-center space-x-8 px-8 py-4 rounded-xl"
                             style={{ backgroundColor: '#1F2937' }}
                        >
                          {settings.securityFeatures.map((feature, index) => (
                            <div key={index} className="flex items-center space-x-2">
                              <i className={feature.icon} style={{ color: settings.accentColor }}></i>
                              <span className="opacity-75">{feature.text}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Modal de modification des forfaits */}
      {showPlanModal && editingPlan && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-900 rounded-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto border border-yellow-500/20">
            <div className="flex items-center justify-between p-6 border-b border-gray-800">
              <h3 className="text-2xl font-bold text-white flex items-center">
                <i className="ri-price-tag-3-line text-yellow-400 mr-3"></i>
                {editingPlan.id === 'new' ? 'Nouveau Forfait' : 'Modifier le Forfait'}
              </h3>
              <button
                onClick={() => setShowPlanModal(false)}
                className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-800 transition-colors cursor-pointer"
              >
                <i className="ri-close-line text-xl text-gray-400 hover:text-white"></i>
              </button>
            </div>

            <div className="p-6 space-y-8">
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <h4 className="text-lg font-semibold text-yellow-400">Informations de Base</h4>

                  <div>
                    <label className="block text-gray-400 text-sm mb-2">Nom du forfait</label>
                    <input
                      type="text"
                      value={editingPlan.name}
                      onChange={(e) => setEditingPlan({ ...editingPlan, name: e.target.value })}
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-400 text-sm mb-2">Prix</label>
                      <input
                        type="text"
                        value={editingPlan.price}
                        onChange={(e) => setEditingPlan({ ...editingPlan, price: e.target.value })}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-400 text-sm mb-2">Période</label>
                      <input
                        type="text"
                        value={editingPlan.period}
                        onChange={(e) => setEditingPlan({ ...editingPlan, period: e.target.value })}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-gray-400 text-sm mb-2">Description</label>
                    <textarea
                      value={editingPlan.description}
                      onChange={(e) => setEditingPlan({ ...editingPlan, description: e.target.value })}
                      rows={4}
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none resize-none"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-400 text-sm mb-2">Texte du bouton</label>
                    <input
                      type="text"
                      value={editingPlan.buttonText}
                      onChange={(e) => setEditingPlan({ ...editingPlan, buttonText: e.target.value })}
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="text-lg font-semibold text-yellow-400">Apparence & Comportement</h4>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-gray-400 text-sm mb-2">Ordre d'affichage</label>
                      <input
                        type="number"
                        value={editingPlan.order}
                        onChange={(e) => setEditingPlan({ ...editingPlan, order: parseInt(e.target.value) || 1 })}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-gray-400 text-sm mb-2">Badge (si populaire)</label>
                      <input
                        type="text"
                        value={editingPlan.badge || ''}
                        onChange={(e) => setEditingPlan({ ...editingPlan, badge: e.target.value })}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                        placeholder="POPULAIRE"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-gray-400 text-sm mb-2">Icône</label>
                    <select
                      value={editingPlan.icon}
                      onChange={(e) => setEditingPlan({ ...editingPlan, icon: e.target.value })}
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none pr-8"
                    >
                      {iconOptions.map(icon => (
                        <option key={icon} value={icon}>{icon.replace('ri-', '').replace('-', ' ')}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-gray-400 text-sm mb-2">Couleur</label>
                    <div className="flex items-center space-x-3 mb-3">
                      <input
                        type="color"
                        value={editingPlan.color}
                        onChange={(e) => setEditingPlan({ ...editingPlan, color: e.target.value })}
                        className="w-12 h-12 rounded cursor-pointer"
                      />
                      <input
                        type="text"
                        value={editingPlan.color}
                        onChange={(e) => setEditingPlan({ ...editingPlan, color: e.target.value })}
                        className="flex-1 p-2 bg-gray-800 border border-gray-700 rounded text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                    <div className="grid grid-cols-6 gap-2">
                      {colorPresets.map(color => (
                        <button
                          key={color}
                          onClick={() => setEditingPlan({ ...editingPlan, color })}
                          className="w-8 h-8 rounded cursor-pointer border-2 border-transparent hover:border-white"
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <input
                        type="checkbox"
                        id="popular"
                        checked={editingPlan.popular}
                        onChange={(e) => setEditingPlan({ ...editingPlan, popular: e.target.checked })}
                        className="w-4 h-4 bg-gray-800 border border-gray-700 rounded focus:ring-yellow-500"
                      />
                      <label htmlFor="popular" className="text-gray-400 text-sm">Forfait populaire</label>
                    </div>

                    <div className="flex items-center space-x-3">
                      <input
                        type="checkbox"
                        id="active"
                        checked={editingPlan.active}
                        onChange={(e) => setEditingPlan({ ...editingPlan, active: e.target.checked })}
                        className="w-4 h-4 bg-gray-800 border border-gray-700 rounded focus:ring-yellow-500"
                      />
                      <label htmlFor="active" className="text-gray-400 text-sm">Forfait actif</label>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-gray-800 p-6 rounded-lg">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-lg font-semibold text-gray-200">Fonctionnalités</h4>
                  <div className="flex items-center space-x-2">
                    <input
                      type="text"
                      value={newFeature}
                      onChange={(e) => setNewFeature(e.target.value)}
                      placeholder="Nouvelle fonctionnalité..."
                      className="px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white text-sm focus:border-yellow-500 focus:outline-none"
                      onKeyPress={(e) => e.key === 'Enter' && addFeature()}
                    />
                    <button
                      onClick={addFeature}
                      className="bg-green-500 hover:bg-green-600 text-white px-3 py-2 rounded font-semibold transition-colors cursor-pointer whitespace-nowrap"
                    >
                      <i className="ri-add-line"></i>
                    </button>
                  </div>
                </div>

                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {editingPlan.features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-3 p-3 bg-gray-700 rounded">
                      <i className="ri-drag-move-line text-gray-400 cursor-move"></i>
                      <input
                        type="text"
                        value={feature}
                        onChange={(e) => updateFeature(index, e.target.value)}
                        className="flex-1 p-2 bg-gray-600 border border-gray-500 rounded text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                      <button
                        onClick={() => removeFeature(index)}
                        className="text-red-400 hover:text-red-300 p-1 cursor-pointer"
                      >
                        <i className="ri-delete-bin-line"></i>
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Section Propriétés Personnalisées */}
              <div className="bg-gray-800 p-6 rounded-lg">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-lg font-semibold text-gray-200">Propriétés Personnalisées</h4>
                  <button
                    onClick={addCustomProperty}
                    className="bg-purple-500 hover:bg-purple-600 text-white px-3 py-2 rounded font-semibold transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-add-line mr-1"></i>
                    Ajouter Propriété
                  </button>
                </div>

                <div className="space-y-3 max-h-64 overflow-y-auto">
                  {Object.entries(customProperties).map(([key, value]) => (
                    <div key={key} className="flex items-center space-x-3 p-3 bg-gray-700 rounded">
                      <div className="w-32">
                        <input
                          type="text"
                          value={key}
                          onChange={(e) => {
                            const newKey = e.target.value;
                            const updated = { ...customProperties };
                            delete updated[key];
                            updated[newKey] = value;
                            setCustomProperties(updated);
                          }}
                          className="w-full p-2 bg-gray-600 border border-gray-500 rounded text-white text-sm focus:border-yellow-500 focus:outline-none"
                          placeholder="Nom propriété"
                        />
                      </div>
                      <div className="flex-1">
                        {renderCustomPropertyInput(key, value)}
                      </div>
                      <div className="flex items-center space-x-2">
                        <select
                          value={typeof value}
                          onChange={(e) => {
                            let newValue: any = value;
                            switch (e.target.value) {
                              case 'boolean':
                                newValue = Boolean(value);
                                break;
                              case 'number':
                                newValue = Number(value) || 0;
                                break;
                              case 'string':
                                newValue = String(value);
                                break;
                            }
                            updateCustomProperty(key, newValue);
                          }}
                          className="p-2 bg-gray-600 border border-gray-500 rounded text-white text-xs focus:border-yellow-500 focus:outline-none pr-8"
                        >
                          <option value="string">Texte</option>
                          <option value="number">Nombre</option>
                          <option value="boolean">Booléen</option>
                        </select>
                        <button
                          onClick={() => removeCustomProperty(key)}
                          className="text-red-400 hover:text-red-300 p-1 cursor-pointer"
                        >
                          <i className="ri-delete-bin-line"></i>
                        </button>
                      </div>
                    </div>
                  ))}

                  {Object.keys(customProperties).length === 0 && (
                    <div className="text-center text-gray-400 py-8">
                      <i className="ri-settings-3-line text-4xl mb-2 block"></i>
                      <p>Aucune propriété personnalisée</p>
                      <p className="text-sm">Ajoutez des propriétés pour étendre les fonctionnalités</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex space-x-4 pt-6 border-t border-gray-700">
                <button
                  onClick={() => setShowPlanModal(false)}
                  className="flex-1 bg-gray-700 hover:bg-gray-600 text-white py-3 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap"
                >
                  Annuler
                </button>
                <button
                  onClick={handleSavePlan}
                  className="flex-1 bg-yellow-500 hover:bg-yellow-400 text-black py-3 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-save-line mr-2"></i>
                  {editingPlan.id === 'new' ? 'Créer le Forfait' : 'Sauvegarder'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}