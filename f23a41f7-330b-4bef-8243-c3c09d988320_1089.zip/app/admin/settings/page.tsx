
'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function AdminSettings() {
  const [activeTab, setActiveTab] = useState('general');
  const [settings, setSettings] = useState({
    siteName: 'CMV Finance',
    siteDescription: 'Plateforme de trading et formation financière',
    contactEmail: 'contact@cmvfinance.com',
    theme: 'dark',
    language: 'fr',
    enableRegistration: true,
    enableComments: true,
    maintenanceMode: false,
    analyticsCode: '',
    seoTitle: 'CMV Finance - Trading & Formation',
    seoDescription: 'Maîtrisez le trading avec nos formations, analyses et outils professionnels',
    socialFacebook: '',
    socialTwitter: '',
    socialLinkedin: '',
    socialYoutube: ''
  });

  const [siteTexts, setSiteTexts] = useState({
    // Page d'accueil
    heroTitle: "cmv l'art de fructifier et protéger votre avenir financier",
    heroSubtitle: 'Conseil en Gestion de Patrimoine & Trading',
    heroDescription:
      "Nous accompagnons nos clients dans l'optimisation de leur patrimoine financier grâce à une expertise reconnue en investissement et une approche personnalisée de la gestion de portefeuille.",
    heroButtonPrimary: 'Prendre Rendez-vous',
    heroButtonSecondary: 'Nos Services',

    // Section Features
    featuresTitle: 'Fonctionnalités',
    featuresHighlight: 'Principales',
    featuresDescription:
      'Découvrez tous nos outils financiers conçus pour optimiser vos investissements et améliorer vos performances',

    // Features individuelles
    feature1Title: 'Gestion de Patrimoine',
    feature1Description:
      'Suivez vos investissements en temps réel avec des analyses détaillées et des simulateurs avancés.',
    feature2Title: "Académie de Trading",
    feature2Description:
      "Apprenez le trading et l'investissement avec nos formations complètes et interactives.",
    feature3Title: "Marketplace d'Indicateurs",
    feature3Description:
      "Découvrez et achetez les meilleurs indicateurs TradingView créés par notre communauté.",
    feature4Title: 'Formation interactive et simulateurs "ludo-éducatifs"',
    feature4Description:
      'Modules gamifiés pour comprendre la Bourse, les crypto-actifs ou l\'immobilier locatif via des cas pratiques. Quiz, challenges et certification interne pour valider vos connaissances.',

    // Navigation
    navDashboard: 'Dashboard',
    navTrading: 'Trading',
    navAcademy: 'Académie',
    navIndicators: 'Indicateurs',
    navAllocation: 'Allocation',
    navOpportunities: 'Opportunités',
    navContact: 'Contact',

    // Boutons généraux
    btnLogin: 'Connexion',
    btnRegister: 'Inscription',
    btnDiscover: 'Découvrir',
    btnLearnMore: 'En savoir plus',
    btnGetStarted: 'Commencer',

    // Footer
    footerDescription:
      'Plateforme complète de trading et formation financière pour optimiser votre patrimoine.',
    footerQuickLinks: 'Liens Rapides',
    footerServices: 'Services',
    footerSupport: 'Support',
    footerRights: 'Tous droits réservés',

    // Messages communs
    loading: 'Chargement...',
    comingSoon: 'Bientôt disponible',
    error: "Une erreur s'est produite",
    success: 'Opération réussie',

    // Academy
    academyTitle: 'Académie de Trading',
    academyDescription: 'Maîtrisez les marchés financiers avec nos formations complètes',

    // Dashboard
    dashboardTitle: 'Tableau de Bord',
    dashboardWelcome: 'Bienvenue sur votre dashboard',

    // Trading
    tradingTitle: 'Plateforme de Trading',
    tradingDescription: 'Tradez en toute confiance avec nos outils professionnels'
  });

  const router = useRouter();

  useEffect(() => {
    // Accès direct sans authentification
    loadSettings();
    loadSiteTexts();
  }, []);

  const loadSettings = () => {
    const savedSettings = localStorage.getItem('cmv_site_settings');
    if (savedSettings) {
      setSettings({ ...settings, ...JSON.parse(savedSettings) });
    }
  };

  const loadSiteTexts = () => {
    const savedTexts = localStorage.getItem('cmv_site_texts');
    if (savedTexts) {
      setSiteTexts({ ...siteTexts, ...JSON.parse(savedTexts) });
    }
  };

  const saveSiteTexts = (texts: any) => {
    localStorage.setItem('cmv_site_texts', JSON.stringify(texts));

    // Trigger event to notify components
    const event = new CustomEvent('siteTextsUpdated', {
      detail: texts
    });
    window.dispatchEvent(event);
  };

  const saveSettings = () => {
    localStorage.setItem('cmv_site_settings', JSON.stringify(settings));
    saveSiteTexts(siteTexts);
    alert('Paramètres sauvegardés avec succès!');
  };

  const handleTextChange = (key: string, value: string) => {
    const newTexts = { ...siteTexts, [key]: value };
    setSiteTexts(newTexts);
    saveSiteTexts(newTexts);
  };

  const tabs = [
    { id: 'general', name: 'Général', icon: 'ri-settings-line' },
    { id: 'texts', name: 'Gestion des Textes', icon: 'ri-file-text-line' },
    { id: 'seo', name: 'SEO', icon: 'ri-search-line' },
    { id: 'social', name: 'Réseaux Sociaux', icon: 'ri-share-line' },
    { id: 'advanced', name: 'Avancé', icon: 'ri-code-line' },
    { id: 'backup', name: 'Sauvegarde', icon: 'ri-database-line' }
  ];

  return (
    <div className="min-h-screen bg-black text-white pb-16">
      <header className="bg-gray-900 border-b border-yellow-500/30 sticky top-0 z-10">
        <div className="px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-6">
              <Link href="/" className="text-2xl font-bold text-yellow-400 font-['Pacifico']">
                logo
              </Link>
              <div className="h-8 w-px bg-gray-700"></div>
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
                  Paramètres du Site
                </h1>
                <p className="text-xs text-gray-400">Configuration et personnalisation</p>
              </div>
              <div className="px-3 py-1 rounded-full text-xs font-bold bg-green-500/20 text-green-400 flex items-center space-x-1">
                <i className="ri-shield-check-line"></i>
                <span>Accès Direct</span>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <Link
                href="/admin/dashboard"
                className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-lg transition-colors text-sm font-medium whitespace-nowrap"
              >
                <i className="ri-arrow-left-line mr-2"></i>
                Retour Dashboard
              </Link>
              <button
                onClick={saveSettings}
                className="bg-yellow-500 hover:bg-yellow-600 text-black px-6 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
              >
                <i className="ri-save-line mr-2"></i>
                Sauvegarder Tout
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row space-y-6 lg:space-y-0 lg:space-x-8">
          {/* Navigation - Responsive */}
          <div className="lg:w-64">
            <nav className="space-y-2">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg font-medium transition-colors whitespace-nowrap cursor-pointer ${
                    activeTab === tab.id
                      ? 'bg-yellow-500 text-black'
                      : 'text-gray-400 hover:text-white hover:bg-gray-800'
                  }`}
                >
                  <i className={tab.icon}></i>
                  <span>{tab.name}</span>
                </button>
              ))}
            </nav>
          </div>

          {/* Contenu principal avec scroll */}
          <div className="flex-1 max-h-[calc(100vh-12rem)] overflow-y-auto pr-2">
            {activeTab === 'general' && (
              <div className="bg-gray-900 p-6 lg:p-8 rounded-xl border border-yellow-500/20 mb-8">
                <h2 className="text-2xl font-bold mb-6">Configuration Générale</h2>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium mb-2">Nom du Site</label>
                    <input
                      type="text"
                      value={settings.siteName}
                      onChange={(e) => setSettings({ ...settings, siteName: e.target.value })}
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Email de Contact</label>
                    <input
                      type="email"
                      value={settings.contactEmail}
                      onChange={(e) => setSettings({ ...settings, contactEmail: e.target.value })}
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium mb-2">Description du Site</label>
                    <textarea
                      value={settings.siteDescription}
                      onChange={(e) => setSettings({ ...settings, siteDescription: e.target.value })}
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none resize-none"
                      rows={3}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Thème</label>
                    <select
                      value={settings.theme}
                      onChange={(e) => setSettings({ ...settings, theme: e.target.value })}
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none pr-8"
                    >
                      <option value="dark">Sombre</option>
                      <option value="light">Clair</option>
                      <option value="auto">Automatique</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Langue</label>
                    <select
                      value={settings.language}
                      onChange={(e) => setSettings({ ...settings, language: e.target.value })}
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none pr-8"
                    >
                      <option value="fr">Français</option>
                      <option value="en">English</option>
                      <option value="es">Español</option>
                    </select>
                  </div>
                </div>

                <div className="mt-8">
                  <h3 className="text-lg font-bold mb-6">Options du Site</h3>
                  <div className="space-y-6">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
                      <div>
                        <div className="font-medium">Inscription Ouverte</div>
                        <div className="text-sm text-gray-400">Permettre aux nouveaux utilisateurs de s'inscrire</div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={settings.enableRegistration}
                          onChange={(e) => setSettings({ ...settings, enableRegistration: e.target.checked })}
                          className="sr-only peer"
                        />
                        <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-yellow-500"></div>
                      </label>
                    </div>
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
                      <div>
                        <div className="font-medium">Commentaires</div>
                        <div className="text-sm text-gray-400">Activer les commentaires sur les articles</div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={settings.enableComments}
                          onChange={(e) => setSettings({ ...settings, enableComments: e.target.checked })}
                          className="sr-only peer"
                        />
                        <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-yellow-500"></div>
                      </label>
                    </div>
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
                      <div>
                        <div className="font-medium">Mode Maintenance</div>
                        <div className="text-sm text-gray-400">Mettre le site en maintenance</div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input
                          type="checkbox"
                          checked={settings.maintenanceMode}
                          onChange={(e) => setSettings({ ...settings, maintenanceMode: e.target.checked })}
                          className="sr-only peer"
                        />
                        <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-yellow-500"></div>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'texts' && (
              <div className="space-y-8">
                {/* Page d'accueil */}
                <div className="bg-gray-900 p-6 lg:p-8 rounded-xl border border-yellow-500/20">
                  <h2 className="text-2xl font-bold mb-6">Page d'Accueil</h2>
                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Titre Principal (Hero)</label>
                      <input
                        type="text"
                        value={siteTexts.heroTitle}
                        onChange={(e) => handleTextChange('heroTitle', e.target.value)}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Sous-titre</label>
                      <input
                        type="text"
                        value={siteTexts.heroSubtitle}
                        onChange={(e) => handleTextChange('heroSubtitle', e.target.value)}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Description</label>
                      <textarea
                        value={siteTexts.heroDescription}
                        onChange={(e) => handleTextChange('heroDescription', e.target.value)}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none resize-none"
                        rows={4}
                      />
                    </div>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-2">Bouton Principal</label>
                        <input
                          type="text"
                          value={siteTexts.heroButtonPrimary}
                          onChange={(e) => handleTextChange('heroButtonPrimary', e.target.value)}
                          className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">Bouton Secondaire</label>
                        <input
                          type="text"
                          value={siteTexts.heroButtonSecondary}
                          onChange={(e) => handleTextChange('heroButtonSecondary', e.target.value)}
                          className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Section Fonctionnalités */}
                <div className="bg-gray-900 p-6 lg:p-8 rounded-xl border border-yellow-500/20">
                  <h2 className="text-2xl font-bold mb-6">Section Fonctionnalités</h2>
                  <div className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-2">Titre</label>
                        <input
                          type="text"
                          value={siteTexts.featuresTitle}
                          onChange={(e) => handleTextChange('featuresTitle', e.target.value)}
                          className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-2">Mot en Surbrillance</label>
                        <input
                          type="text"
                          value={siteTexts.featuresHighlight}
                          onChange={(e) => handleTextChange('featuresHighlight', e.target.value)}
                          className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Description</label>
                      <textarea
                        value={siteTexts.featuresDescription}
                        onChange={(e) => handleTextChange('featuresDescription', e.target.value)}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none resize-none"
                        rows={3}
                      />
                    </div>
                  </div>
                </div>

                {/* Fonctionnalités individuelles */}
                <div className="bg-gray-900 p-6 lg:p-8 rounded-xl border border-yellow-500/20">
                  <h2 className="text-2xl font-bold mb-6">Fonctionnalités Individuelles</h2>
                  <div className="space-y-8">
                    {[1, 2, 3, 4].map((num) => (
                      <div key={num} className="bg-gray-800 p-6 rounded-lg">
                        <h3 className="text-lg font-semibold mb-4">Fonctionnalité {num}</h3>
                        <div className="space-y-4">
                          <div>
                            <label className="block text-sm font-medium mb-2">Titre</label>
                            <input
                              type="text"
                              value={siteTexts[`feature${num}Title`]}
                              onChange={(e) => handleTextChange(`feature${num}Title`, e.target.value)}
                              className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium mb-2">Description</label>
                            <textarea
                              value={siteTexts[`feature${num}Description`]}
                              onChange={(e) => handleTextChange(`feature${num}Description`, e.target.value)}
                              className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none resize-none"
                              rows={3}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Navigation */}
                <div className="bg-gray-900 p-6 lg:p-8 rounded-xl border border-yellow-500/20">
                  <h2 className="text-2xl font-bold mb-6">Navigation</h2>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Dashboard</label>
                      <input
                        type="text"
                        value={siteTexts.navDashboard}
                        onChange={(e) => handleTextChange('navDashboard', e.target.value)}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Trading</label>
                      <input
                        type="text"
                        value={siteTexts.navTrading}
                        onChange={(e) => handleTextChange('navTrading', e.target.value)}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Académie</label>
                      <input
                        type="text"
                        value={siteTexts.navAcademy}
                        onChange={(e) => handleTextChange('navAcademy', e.target.value)}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Indicateurs</label>
                      <input
                        type="text"
                        value={siteTexts.navIndicators}
                        onChange={(e) => handleTextChange('navIndicators', e.target.value)}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Allocation</label>
                      <input
                        type="text"
                        value={siteTexts.navAllocation}
                        onChange={(e) => handleTextChange('navAllocation', e.target.value)}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Opportunités</label>
                      <input
                        type="text"
                        value={siteTexts.navOpportunities}
                        onChange={(e) => handleTextChange('navOpportunities', e.target.value)}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Contact</label>
                      <input
                        type="text"
                        value={siteTexts.navContact}
                        onChange={(e) => handleTextChange('navContact', e.target.value)}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* Boutons communs */}
                <div className="bg-gray-900 p-6 lg:p-8 rounded-xl border border-yellow-500/20">
                  <h2 className="text-2xl font-bold mb-6">Boutons Communs</h2>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Connexion</label>
                      <input
                        type="text"
                        value={siteTexts.btnLogin}
                        onChange={(e) => handleTextChange('btnLogin', e.target.value)}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Inscription</label>
                      <input
                        type="text"
                        value={siteTexts.btnRegister}
                        onChange={(e) => handleTextChange('btnRegister', e.target.value)}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Découvrir</label>
                      <input
                        type="text"
                        value={siteTexts.btnDiscover}
                        onChange={(e) => handleTextChange('btnDiscover', e.target.value)}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">En savoir plus</label>
                      <input
                        type="text"
                        value={siteTexts.btnLearnMore}
                        onChange={(e) => handleTextChange('btnLearnMore', e.target.value)}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Commencer</label>
                      <input
                        type="text"
                        value={siteTexts.btnGetStarted}
                        onChange={(e) => handleTextChange('btnGetStarted', e.target.value)}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* Messages système */}
                <div className="bg-gray-900 p-6 lg:p-8 rounded-xl border border-yellow-500/20">
                  <h2 className="text-2xl font-bold mb-6">Messages Système</h2>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium mb-2">Chargement</label>
                      <input
                        type="text"
                        value={siteTexts.loading}
                        onChange={(e) => handleTextChange('loading', e.target.value)}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Bientôt disponible</label>
                      <input
                        type="text"
                        value={siteTexts.comingSoon}
                        onChange={(e) => handleTextChange('comingSoon', e.target.value)}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Erreur</label>
                      <input
                        type="text"
                        value={siteTexts.error}
                        onChange={(e) => handleTextChange('error', e.target.value)}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Succès</label>
                      <input
                        type="text"
                        value={siteTexts.success}
                        onChange={(e) => handleTextChange('success', e.target.value)}
                        className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'seo' && (
              <div className="bg-gray-900 p-6 lg:p-8 rounded-xl border border-yellow-500/20 mb-8">
                <h2 className="text-2xl font-bold mb-6">Configuration SEO</h2>
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium mb-2">Titre SEO</label>
                    <input
                      type="text"
                      value={settings.seoTitle}
                      onChange={(e) => setSettings({ ...settings, seoTitle: e.target.value })}
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      placeholder="Titre qui apparaît dans les résultats de recherche"
                    />
                    <div className="text-xs text-gray-400 mt-1">{settings.seoTitle.length}/60 caractères</div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Description SEO</label>
                    <textarea
                      value={settings.seoDescription}
                      onChange={(e) => setSettings({ ...settings, seoDescription: e.target.value })}
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none resize-none"
                      rows={3}
                      maxLength={160}
                      placeholder="Description qui apparaît dans les résultats de recherche"
                    />
                    <div className="text-xs text-gray-400 mt-1">{settings.seoDescription.length}/160 caractères</div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Code Google Analytics</label>
                    <input
                      type="text"
                      value={settings.analyticsCode}
                      onChange={(e) => setSettings({ ...settings, analyticsCode: e.target.value })}
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      placeholder="G-XXXXXXXXXX"
                    />
                  </div>

                  <div className="bg-gray-800 p-6 rounded-lg">
                    <h3 className="font-semibold mb-4">Aperçu Google</h3>
                    <div className="bg-white text-black p-4 rounded">
                      <div className="text-blue-600 text-lg">{settings.seoTitle}</div>
                      <div className="text-green-600 text-sm">https://cmvfinance.com</div>
                      <div className="text-gray-600 text-sm mt-1">{settings.seoDescription}</div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'social' && (
              <div className="bg-gray-900 p-6 lg:p-8 rounded-xl border border-yellow-500/20 mb-8">
                <h2 className="text-2xl font-bold mb-6">Réseaux Sociaux</h2>
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      <i className="ri-facebook-fill text-blue-500 mr-2"></i>
                      Facebook
                    </label>
                    <input
                      type="url"
                      value={settings.socialFacebook}
                      onChange={(e) => setSettings({ ...settings, socialFacebook: e.target.value })}
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      placeholder="https://facebook.com/cmvfinance"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      <i className="ri-twitter-fill text-blue-400 mr-2"></i>
                      Twitter
                    </label>
                    <input
                      type="url"
                      value={settings.socialTwitter}
                      onChange={(e) => setSettings({ ...settings, socialTwitter: e.target.value })}
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      placeholder="https://twitter.com/cmvfinance"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      <i className="ri-linkedin-fill text-blue-600 mr-2"></i>
                      LinkedIn
                    </label>
                    <input
                      type="url"
                      value={settings.socialLinkedin}
                      onChange={(e) => setSettings({ ...settings, socialLinkedin: e.target.value })}
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      placeholder="https://linkedin.com/company/cmvfinance"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      <i className="ri-youtube-fill text-red-500 mr-2"></i>
                      YouTube
                    </label>
                    <input
                      type="url"
                      value={settings.socialYoutube}
                      onChange={(e) => setSettings({ ...settings, socialYoutube: e.target.value })}
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none"
                      placeholder="https://youtube.com/@cmvfinance"
                    />
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'advanced' && (
              <div className="bg-gray-900 p-6 lg:p-8 rounded-xl border border-yellow-500/20 mb-8">
                <h2 className="text-2xl font-bold mb-6">Paramètres Avancés</h2>
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium mb-2">Code CSS Personnalisé</label>
                    <textarea
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none resize-none font-mono"
                      rows={8}
                      placeholder="/* Votre CSS personnalisé */"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Scripts Personnalisés (Head)</label>
                    <textarea
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none resize-none font-mono"
                      rows={6}
                      placeholder="<script><!-- Votre code JavaScript --></script>"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Scripts Personnalisés (Body)</label>
                    <textarea
                      className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white text-sm focus:border-yellow-500 focus:outline-none resize-none font-mono"
                      rows={6}
                      placeholder="<script><!-- Votre code JavaScript --></script>"
                    />
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'backup' && (
              <div className="bg-gray-900 p-6 lg:p-8 rounded-xl border border-yellow-500/20 mb-8">
                <h2 className="text-2xl font-bold mb-6">Sauvegarde et Restauration</h2>
                <div className="space-y-6">
                  <div className="bg-gray-800 p-6 rounded-lg">
                    <h3 className="font-semibold mb-4">Créer une Sauvegarde</h3>
                    <p className="text-gray-400 mb-4">Exportez tous vos contenus, paramètres et données utilisateurs.</p>
                    <button className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer">
                      <i className="ri-download-line mr-2"></i>
                      Télécharger Sauvegarde
                    </button>
                  </div>

                  <div className="bg-gray-800 p-6 rounded-lg">
                    <h3 className="font-semibold mb-4">Restaurer une Sauvegarde</h3>
                    <p className="text-gray-400 mb-4">Importez une sauvegarde précédente pour restaurer votre site.</p>
                    <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-4">
                      <input type="file" accept=".json,.zip" className="hidden" id="backup-upload" />
                      <label htmlFor="backup-upload" className="bg-yellow-500 hover:bg-yellow-600 text-black px-6 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer">
                        <i className="ri-upload-line mr-2"></i>
                        Choisir Fichier
                      </label>
                      <button className="bg-red-500 hover:bg-red-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer">
                        <i className="ri-refresh-line mr-2"></i>
                        Restaurer
                      </button>
                    </div>
                  </div>

                  <div className="bg-gray-800 p-6 rounded-lg">
                    <h3 className="font-semibold mb-4">Sauvegardes Automatiques</h3>
                    <div className="space-y-3">
                      {[{ date: '2024-01-15 14:30', size: '2.3 MB', type: 'Complète' }, { date: '2024-01-14 14:30', size: '2.1 MB', type: 'Complète' }, { date: '2024-01-13 14:30', size: '1.9 MB', type: 'Complète' }].map((backup, index) => (
                        <div key={index} className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0 py-3 border-b border-gray-700 last:border-b-0">
                          <div>
                            <div className="font-medium">{backup.date}</div>
                            <div className="text-sm text-gray-400">{backup.type} - {backup.size}</div>
                          </div>
                          <div className="flex space-x-2">
                            <button className="text-blue-400 hover:text-blue-300 p-2 hover:bg-gray-700 rounded cursor-pointer">
                              <i className="ri-download-line"></i>
                            </button>
                            <button className="text-green-400 hover:text-green-300 p-2 hover:bg-gray-700 rounded cursor-pointer">
                              <i className="ri-refresh-line"></i>
                            </button>
                            <button className="text-red-400 hover:text-red-300 p-2 hover:bg-gray-700 rounded cursor-pointer">
                              <i className="ri-delete-bin-line"></i>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
