
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

interface AccessCode {
  id: string;
  code: string;
  type: 'Premium' | 'Pro' | 'Ultimate';
  isUsed: boolean;
  createdAt: string;
  usedAt?: string;
  usedBy?: string;
}

export default function AccessCodesManager() {
  const router = useRouter();
  const [accessCodes, setAccessCodes] = useState<AccessCode[]>([
    {
      id: '1',
      code: 'PREMIUM2024-ABC123',
      type: 'Premium',
      isUsed: false,
      createdAt: '2024-01-15'
    },
    {
      id: '2',
      code: 'PRO2024-XYZ789',
      type: 'Pro',
      isUsed: true,
      createdAt: '2024-01-10',
      usedAt: '2024-01-12',
      usedBy: 'john.doe@email.com'
    },
    {
      id: '3',
      code: 'ULTIMATE2024-DEF456',
      type: 'Ultimate',
      isUsed: false,
      createdAt: '2024-01-20'
    }
  ]);

  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newCodeData, setNewCodeData] = useState({
    type: 'Premium' as 'Premium' | 'Pro' | 'Ultimate',
    quantity: 1
  });

  const generateAccessCode = (type: string) => {
    const prefix = type.toUpperCase();
    const randomCode = Math.random().toString(36).substring(2, 8).toUpperCase();
    return `${prefix}2024-${randomCode}`;
  };

  const handleCreateCodes = () => {
    const newCodes: AccessCode[] = [];
    for (let i = 0; i < newCodeData.quantity; i++) {
      newCodes.push({
        id: Date.now().toString() + i,
        code: generateAccessCode(newCodeData.type),
        type: newCodeData.type,
        isUsed: false,
        createdAt: new Date().toISOString().split('T')[0]
      });
    }
    setAccessCodes([...newCodes, ...accessCodes]);
    setShowCreateForm(false);
    setNewCodeData({ type: 'Premium', quantity: 1 });
  };

  const handleDeleteCode = (id: string) => {
    setAccessCodes(accessCodes.filter(code => code.id !== id));
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'Premium': return 'bg-blue-100 text-blue-800';
      case 'Pro': return 'bg-purple-100 text-purple-800';
      case 'Ultimate': return 'bg-gold-100 text-gold-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <Link href="/admin/dashboard" className="text-blue-600 hover:text-blue-800">
                <i className="ri-arrow-left-line text-xl"></i>
              </Link>
              <h1 className="text-2xl font-bold text-gray-900">Codes d'Accès</h1>
            </div>
            <button
              onClick={() => setShowCreateForm(true)}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center space-x-2"
            >
              <i className="ri-add-line"></i>
              <span>Créer des codes</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="flex items-center">
              <div className="p-2 bg-blue-100 rounded-lg">
                <i className="ri-ticket-line text-blue-600 text-xl"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Codes</p>
                <p className="text-2xl font-semibold text-gray-900">{accessCodes.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="flex items-center">
              <div className="p-2 bg-green-100 rounded-lg">
                <i className="ri-check-line text-green-600 text-xl"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Codes Utilisés</p>
                <p className="text-2xl font-semibold text-gray-900">
                  {accessCodes.filter(code => code.isUsed).length}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="flex items-center">
              <div className="p-2 bg-orange-100 rounded-lg">
                <i className="ri-time-line text-orange-600 text-xl"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Codes Disponibles</p>
                <p className="text-2xl font-semibold text-gray-900">
                  {accessCodes.filter(code => !code.isUsed).length}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="flex items-center">
              <div className="p-2 bg-purple-100 rounded-lg">
                <i className="ri-vip-crown-line text-purple-600 text-xl"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Codes Ultimate</p>
                <p className="text-2xl font-semibold text-gray-900">
                  {accessCodes.filter(code => code.type === 'Ultimate').length}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Access Codes Table */}
        <div className="bg-white rounded-lg shadow-sm">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Liste des Codes d'Accès</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Code
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Type
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Statut
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Créé le
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Utilisé par
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {accessCodes.map((code) => (
                  <tr key={code.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <code className="bg-gray-100 px-2 py-1 rounded text-sm font-mono">
                          {code.code}
                        </code>
                        <button
                          onClick={() => navigator.clipboard.writeText(code.code)}
                          className="ml-2 text-gray-400 hover:text-gray-600"
                        >
                          <i className="ri-file-copy-line"></i>
                        </button>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getTypeColor(code.type)}`}>
                        {code.type}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        code.isUsed ? 'bg-green-100 text-green-800' : 'bg-orange-100 text-orange-800'
                      }`}>
                        {code.isUsed ? 'Utilisé' : 'Disponible'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {code.createdAt}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {code.usedBy || '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <button
                        onClick={() => handleDeleteCode(code.id)}
                        className="text-red-600 hover:text-red-800"
                      >
                        <i className="ri-delete-bin-line"></i>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Create Form Modal */}
      {showCreateForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Créer des Codes d'Accès</h3>
              <button
                onClick={() => setShowCreateForm(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Type de Plan
                </label>
                <select
                  value={newCodeData.type}
                  onChange={(e) => setNewCodeData({...newCodeData, type: e.target.value as any})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Premium">Premium</option>
                  <option value="Pro">Pro</option>
                  <option value="Ultimate">Ultimate</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Quantité
                </label>
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={newCodeData.quantity}
                  onChange={(e) => setNewCodeData({...newCodeData, quantity: parseInt(e.target.value)})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="flex justify-end space-x-3 mt-6">
              <button
                onClick={() => setShowCreateForm(false)}
                className="px-4 py-2 text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200"
              >
                Annuler
              </button>
              <button
                onClick={handleCreateCodes}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Créer les codes
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
