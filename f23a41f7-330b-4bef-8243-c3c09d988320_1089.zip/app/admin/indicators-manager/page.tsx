
'use client';

import { useState } from 'react';
import Link from 'next/link';

interface Indicator {
  id: string;
  name: string;
  description: string;
  category: 'Technical' | 'Fundamental' | 'Sentiment' | 'Economic';
  price: number;
  status: 'active' | 'inactive' | 'pending';
  downloads: number;
  rating: number;
  author: string;
  createdAt: string;
}

export default function IndicatorsManager() {
  const [indicators, setIndicators] = useState<Indicator[]>([
    {
      id: '1',
      name: 'RSI Avancé',
      description: 'Indicateur RSI avec signaux d\'achat/vente optimisés',
      category: 'Technical',
      price: 29.99,
      status: 'active',
      downloads: 1247,
      rating: 4.8,
      author: 'TradingPro',
      createdAt: '2024-01-15'
    },
    {
      id: '2',
      name: 'MACD Personnalisé',
      description: 'MACD avec alertes et configurations avancées',
      category: 'Technical',
      price: 19.99,
      status: 'active',
      downloads: 892,
      rating: 4.6,
      author: 'AlgoTrader',
      createdAt: '2024-01-10'
    },
    {
      id: '3',
      name: 'Sentiment Market',
      description: 'Analyse du sentiment du marché en temps réel',
      category: 'Sentiment',
      price: 49.99,
      status: 'pending',
      downloads: 0,
      rating: 0,
      author: 'DataAnalyst',
      createdAt: '2024-01-20'
    }
  ]);

  const [showCreateForm, setShowCreateForm] = useState(false);
  const [selectedIndicator, setSelectedIndicator] = useState<Indicator | null>(null);
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'inactive': return 'bg-red-100 text-red-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Technical': return 'bg-blue-100 text-blue-800';
      case 'Fundamental': return 'bg-purple-100 text-purple-800';
      case 'Sentiment': return 'bg-orange-100 text-orange-800';
      case 'Economic': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const updateStatus = (id: string, newStatus: 'active' | 'inactive' | 'pending') => {
    setIndicators(indicators.map(indicator => 
      indicator.id === id ? { ...indicator, status: newStatus } : indicator
    ));
  };

  const deleteIndicator = (id: string) => {
    setIndicators(indicators.filter(indicator => indicator.id !== id));
    if (selectedIndicator?.id === id) {
      setSelectedIndicator(null);
    }
  };

  const filteredIndicators = indicators.filter(indicator => {
    if (filterCategory !== 'all' && indicator.category !== filterCategory) return false;
    if (filterStatus !== 'all' && indicator.status !== filterStatus) return false;
    return true;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <Link href="/admin/dashboard" className="text-blue-600 hover:text-blue-800">
                <i className="ri-arrow-left-line text-xl"></i>
              </Link>
              <h1 className="text-2xl font-bold text-gray-900">Gestion des Indicateurs</h1>
            </div>
            <div className="flex items-center space-x-4">
              <select
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">Toutes les catégories</option>
                <option value="Technical">Technique</option>
                <option value="Fundamental">Fondamental</option>
                <option value="Sentiment">Sentiment</option>
                <option value="Economic">Économique</option>
              </select>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">Tous les statuts</option>
                <option value="active">Actif</option>
                <option value="inactive">Inactif</option>
                <option value="pending">En attente</option>
              </select>
              <button
                onClick={() => setShowCreateForm(true)}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center space-x-2"
              >
                <i className="ri-add-line"></i>
                <span>Nouvel indicateur</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="flex items-center">
              <div className="p-2 bg-blue-100 rounded-lg">
                <i className="ri-line-chart-line text-blue-600 text-xl"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Indicateurs</p>
                <p className="text-2xl font-semibold text-gray-900">{indicators.length}</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="flex items-center">
              <div className="p-2 bg-green-100 rounded-lg">
                <i className="ri-check-line text-green-600 text-xl"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Actifs</p>
                <p className="text-2xl font-semibold text-gray-900">
                  {indicators.filter(i => i.status === 'active').length}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="flex items-center">
              <div className="p-2 bg-orange-100 rounded-lg">
                <i className="ri-download-line text-orange-600 text-xl"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Téléchargements</p>
                <p className="text-2xl font-semibold text-gray-900">
                  {indicators.reduce((sum, i) => sum + i.downloads, 0)}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="flex items-center">
              <div className="p-2 bg-purple-100 rounded-lg">
                <i className="ri-money-dollar-circle-line text-purple-600 text-xl"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Revenus Potentiels</p>
                <p className="text-2xl font-semibold text-gray-900">
                  {indicators.reduce((sum, i) => sum + (i.downloads * i.price), 0).toFixed(0)}€
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Indicators Table */}
        <div className="bg-white rounded-lg shadow-sm">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">
              Indicateurs ({filteredIndicators.length})
            </h2>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Indicateur
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Catégorie
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Prix
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Statut
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Téléchargements
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Note
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredIndicators.map((indicator) => (
                  <tr key={indicator.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm font-medium text-gray-900">{indicator.name}</div>
                        <div className="text-sm text-gray-500">{indicator.description}</div>
                        <div className="text-xs text-gray-400">Par {indicator.author}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getCategoryColor(indicator.category)}`}>
                        {indicator.category}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {indicator.price}€
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(indicator.status)}`}>
                        {indicator.status === 'active' ? 'Actif' : 
                         indicator.status === 'inactive' ? 'Inactif' : 'En attente'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {indicator.downloads.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {indicator.rating > 0 ? (
                        <div className="flex items-center">
                          <span className="text-sm text-gray-900">{indicator.rating}</span>
                          <i className="ri-star-fill text-yellow-400 ml-1"></i>
                        </div>
                      ) : (
                        <span className="text-sm text-gray-500">-</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => setSelectedIndicator(indicator)}
                          className="text-blue-600 hover:text-blue-800"
                        >
                          <i className="ri-edit-line"></i>
                        </button>
                        <button
                          onClick={() => updateStatus(indicator.id, 
                            indicator.status === 'active' ? 'inactive' : 'active')}
                          className="text-green-600 hover:text-green-800"
                        >
                          <i className={indicator.status === 'active' ? 'ri-pause-line' : 'ri-play-line'}></i>
                        </button>
                        <button
                          onClick={() => deleteIndicator(indicator.id)}
                          className="text-red-600 hover:text-red-800"
                        >
                          <i className="ri-delete-bin-line"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Create/Edit Form Modal */}
      {(showCreateForm || selectedIndicator) && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">
                {selectedIndicator ? 'Modifier l\'indicateur' : 'Créer un nouvel indicateur'}
              </h3>
              <button
                onClick={() => {
                  setShowCreateForm(false);
                  setSelectedIndicator(null);
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nom de l'indicateur
                </label>
                <input
                  type="text"
                  defaultValue={selectedIndicator?.name || ''}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Ex: RSI Avancé"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Description
                </label>
                <textarea
                  rows={3}
                  defaultValue={selectedIndicator?.description || ''}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Description de l'indicateur..."
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Catégorie
                  </label>
                  <select
                    defaultValue={selectedIndicator?.category || 'Technical'}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="Technical">Technique</option>
                    <option value="Fundamental">Fondamental</option>
                    <option value="Sentiment">Sentiment</option>
                    <option value="Economic">Économique</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Prix (€)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    defaultValue={selectedIndicator?.price || ''}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="29.99"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Auteur
                </label>
                <input
                  type="text"
                  defaultValue={selectedIndicator?.author || ''}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Nom de l'auteur"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Fichier de l'indicateur
                </label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                  <i className="ri-upload-cloud-line text-3xl text-gray-400 mb-2"></i>
                  <p className="text-sm text-gray-600">
                    Glissez-déposez votre fichier ici ou cliquez pour parcourir
                  </p>
                  <input type="file" accept=".ex4,.mq4,.ex5,.mq5" className="hidden" />
                </div>
              </div>
            </div>

            <div className="flex justify-end space-x-3 mt-6">
              <button
                onClick={() => {
                  setShowCreateForm(false);
                  setSelectedIndicator(null);
                }}
                className="px-4 py-2 text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200"
              >
                Annuler
              </button>
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                {selectedIndicator ? 'Mettre à jour' : 'Créer'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
