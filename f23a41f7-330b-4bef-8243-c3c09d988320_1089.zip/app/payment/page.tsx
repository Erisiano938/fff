'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { getPlans, getPaymentSettings, type Plan, type PaymentPageSettings } from '../lib/plansStorage';

export default function PaymentPage() {
  const [plans, setPlans] = useState<Plan[]>([]);
  const [settings, setSettings] = useState<PaymentPageSettings | null>(null);
  const [selectedPlan, setSelectedPlan] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [formData, setFormData] = useState({
    email: '',
    firstName: '',
    lastName: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    billingAddress: '',
    city: '',
    postalCode: '',
    country: 'France'
  });
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    const loadedPlans = getPlans().filter(plan => plan.active);
    const loadedSettings = getPaymentSettings();
    
    setPlans(loadedPlans);
    setSettings(loadedSettings);
    
    // Sélectionner automatiquement le plan populaire ou le premier
    const popularPlan = loadedPlans.find(p => p.popular);
    if (popularPlan) {
      setSelectedPlan(popularPlan.id);
    } else if (loadedPlans.length > 0) {
      setSelectedPlan(loadedPlans[0].id);
    }
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    
    // Simulation du processus de paiement
    setTimeout(() => {
      setIsProcessing(false);
      alert('Paiement réussi ! Vous allez recevoir vos accès par email.');
    }, 3000);
  };

  const selectedPlanData = plans.find(plan => plan.id === selectedPlan);

  if (!settings) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-yellow-500 mx-auto mb-4"></div>
          <p className="text-white">Chargement...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen text-white" style={{ backgroundColor: settings.backgroundColor }}>
      <Header />
      
      <div className="pt-20 pb-16">
        <div className="container mx-auto px-6">
          <div className="max-w-6xl mx-auto">
            {/* Header */}
            <div className="text-center mb-12">
              <Link href="/academy" className="inline-flex items-center hover:opacity-75 mb-6 transition-colors cursor-pointer" style={{ color: settings.accentColor }}>
                <i className="ri-arrow-left-line mr-2"></i>
                Retour à l'Académie
              </Link>
              <h1 className="text-4xl font-bold mb-4" style={{ color: settings.textColor }}>
                {settings.title.split(' ').map((word, index) => 
                  word.toLowerCase() === settings.headerText.toLowerCase() ? (
                    <span key={index} style={{ color: settings.accentColor }}>{word} </span>
                  ) : (
                    <span key={index} style={{ color: settings.textColor }}>{word} </span>
                  )
                )}
              </h1>
              <p className="text-xl max-w-2xl mx-auto" style={{ color: settings.textColor + 'CC' }}>
                {settings.subtitle}
              </p>
            </div>

            <div className="grid lg:grid-cols-3 gap-8 mb-12">
              {plans.map((plan) => (
                <div
                  key={plan.id}
                  onClick={() => setSelectedPlan(plan.id)}
                  className={`relative p-8 rounded-2xl border-2 cursor-pointer transition-all hover:scale-105 ${
                    selectedPlan === plan.id
                      ? 'ring-2'
                      : 'hover:border-opacity-50'
                  }`}
                  style={{ 
                    borderColor: selectedPlan === plan.id ? settings.accentColor : '#374151',
                    backgroundColor: selectedPlan === plan.id ? settings.accentColor + '10' : '#1F2937',
                    ringColor: selectedPlan === plan.id ? settings.accentColor + '50' : 'transparent'
                  }}
                >
                  {plan.popular && plan.badge && (
                    <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                      <span 
                        className="px-4 py-1 rounded-full text-sm font-bold"
                        style={{ backgroundColor: settings.accentColor, color: settings.backgroundColor }}
                      >
                        {plan.badge}
                      </span>
                    </div>
                  )}
                  
                  <div className="text-center mb-6">
                    <div className="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center"
                         style={{ backgroundColor: plan.color + '20' }}>
                      <i className={`${plan.icon} text-3xl`} style={{ color: plan.color }}></i>
                    </div>
                    <h3 className="text-2xl font-bold mb-2" style={{ color: settings.textColor }}>{plan.name}</h3>
                    <div className="flex items-center justify-center">
                      <span className="text-4xl font-bold" style={{ color: settings.accentColor }}>
                        {plan.price}
                      </span>
                      <span style={{ color: settings.textColor + 'AA' }} className="ml-1">{plan.period}</span>
                    </div>
                    <p className="text-sm mt-2" style={{ color: settings.textColor + 'CC' }}>{plan.description}</p>
                  </div>

                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-center" style={{ color: settings.textColor + 'DD' }}>
                        <i className="ri-check-line mr-3 text-lg" style={{ color: settings.accentColor }}></i>
                        {feature}
                      </li>
                    ))}
                  </ul>

                  <div className="w-8 h-8 border-2 rounded-full flex items-center justify-center mx-auto"
                       style={{ borderColor: settings.accentColor }}>
                    {selectedPlan === plan.id && (
                      <div className="w-4 h-4 rounded-full" style={{ backgroundColor: settings.accentColor }}></div>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Payment Form */}
            <div className="max-w-2xl mx-auto">
              <div className="bg-gray-900 rounded-2xl p-8 border border-gray-800">
                <h2 className="text-2xl font-bold text-white mb-6">Informations de Paiement</h2>
                
                {/* Plan Summary */}
                {selectedPlanData && (
                  <div className="border rounded-xl p-4 mb-6" style={{ backgroundColor: settings.accentColor + '10', borderColor: settings.accentColor + '20' }}>
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-lg font-bold text-white">{selectedPlanData.name}</h3>
                        <p className="text-gray-400">Facturation mensuelle</p>
                      </div>
                      <div className="text-2xl font-bold" style={{ color: settings.accentColor }}>
                        {selectedPlanData.price}{selectedPlanData.period}
                      </div>
                    </div>
                  </div>
                )}

                {/* Payment Method */}
                <div className="mb-6">
                  <label className="block text-white font-semibold mb-3">Méthode de Paiement</label>
                  <div className="flex space-x-4">
                    <button
                      onClick={() => setPaymentMethod('card')}
                      className={`flex items-center space-x-2 px-4 py-3 rounded-lg border-2 transition-all cursor-pointer ${
                        paymentMethod === 'card'
                          ? 'border-yellow-500 bg-yellow-500/10'
                          : 'border-gray-700 hover:border-gray-600'
                      }`}
                    >
                      <i className="ri-bank-card-line text-xl"></i>
                      <span>Carte Bancaire</span>
                    </button>
                    <button
                      onClick={() => setPaymentMethod('paypal')}
                      className={`flex items-center space-x-2 px-4 py-3 rounded-lg border-2 transition-all cursor-pointer ${
                        paymentMethod === 'paypal'
                          ? 'border-yellow-500 bg-yellow-500/10'
                          : 'border-gray-700 hover:border-gray-600'
                      }`}
                    >
                      <i className="ri-paypal-line text-xl"></i>
                      <span>PayPal</span>
                    </button>
                  </div>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Personal Info */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-white font-semibold mb-2">Prénom</label>
                      <input
                        type="text"
                        name="firstName"
                        value={formData.firstName}
                        onChange={handleInputChange}
                        required
                        className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:border-yellow-500 focus:outline-none text-white placeholder-gray-400"
                        placeholder="John"
                      />
                    </div>
                    <div>
                      <label className="block text-white font-semibold mb-2">Nom</label>
                      <input
                        type="text"
                        name="lastName"
                        value={formData.lastName}
                        onChange={handleInputChange}
                        required
                        className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:border-yellow-500 focus:outline-none text-white placeholder-gray-400"
                        placeholder="Doe"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-white font-semibold mb-2">Email</label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:border-yellow-500 focus:outline-none text-white placeholder-gray-400"
                      placeholder="john@example.com"
                    />
                  </div>

                  {paymentMethod === 'card' && (
                    <>
                      <div>
                        <label className="block text-white font-semibold mb-2">Numéro de Carte</label>
                        <input
                          type="text"
                          name="cardNumber"
                          value={formData.cardNumber}
                          onChange={handleInputChange}
                          required
                          placeholder="1234 5678 9012 3456"
                          className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:border-yellow-500 focus:outline-none text-white placeholder-gray-400"
                        />
                      </div>

                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-white font-semibold mb-2">Date d'Expiration</label>
                          <input
                            type="text"
                            name="expiryDate"
                            value={formData.expiryDate}
                            onChange={handleInputChange}
                            required
                            placeholder="MM/AA"
                            className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:border-yellow-500 focus:outline-none text-white placeholder-gray-400"
                          />
                        </div>
                        <div>
                          <label className="block text-white font-semibold mb-2">Code CVV</label>
                          <input
                            type="text"
                            name="cvv"
                            value={formData.cvv}
                            onChange={handleInputChange}
                            required
                            placeholder="123"
                            className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:border-yellow-500 focus:outline-none text-white placeholder-gray-400"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-white font-semibold mb-2">Adresse de Facturation</label>
                        <input
                          type="text"
                          name="billingAddress"
                          value={formData.billingAddress}
                          onChange={handleInputChange}
                          required
                          className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:border-yellow-500 focus:outline-none text-white placeholder-gray-400"
                          placeholder="123 Rue de la Paix"
                        />
                      </div>

                      <div className="grid md:grid-cols-3 gap-4">
                        <div>
                          <label className="block text-white font-semibold mb-2">Ville</label>
                          <input
                            type="text"
                            name="city"
                            value={formData.city}
                            onChange={handleInputChange}
                            required
                            className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:border-yellow-500 focus:outline-none text-white placeholder-gray-400"
                            placeholder="Paris"
                          />
                        </div>
                        <div>
                          <label className="block text-white font-semibold mb-2">Code Postal</label>
                          <input
                            type="text"
                            name="postalCode"
                            value={formData.postalCode}
                            onChange={handleInputChange}
                            required
                            className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:border-yellow-500 focus:outline-none text-white placeholder-gray-400"
                            placeholder="75001"
                          />
                        </div>
                        <div>
                          <label className="block text-white font-semibold mb-2">Pays</label>
                          <select
                            name="country"
                            value={formData.country}
                            onChange={handleInputChange}
                            className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:border-yellow-500 focus:outline-none text-white pr-8"
                          >
                            <option value="France">France</option>
                            <option value="Belgique">Belgique</option>
                            <option value="Suisse">Suisse</option>
                            <option value="Canada">Canada</option>
                          </select>
                        </div>
                      </div>
                    </>
                  )}

                  {/* Terms */}
                  <div className="flex items-start space-x-3">
                    <input
                      type="checkbox"
                      id="terms"
                      required
                      className="mt-1 w-4 h-4 bg-gray-800 border border-gray-700 rounded focus:ring-yellow-500"
                    />
                    <label htmlFor="terms" className="text-gray-300 text-sm">
                      J'accepte les{' '}
                      <Link href="/terms" className="hover:opacity-75 cursor-pointer" style={{ color: settings.accentColor }}>
                        conditions d'utilisation
                      </Link>{' '}
                      et la{' '}
                      <Link href="/privacy" className="hover:opacity-75 cursor-pointer" style={{ color: settings.accentColor }}>
                        politique de confidentialité
                      </Link>
                    </label>
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isProcessing}
                    className="w-full font-bold py-4 rounded-lg transition-colors flex items-center justify-center space-x-2 whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed"
                    style={{ 
                      backgroundColor: isProcessing ? '#6B7280' : settings.accentColor,
                      color: settings.backgroundColor
                    }}
                  >
                    {isProcessing ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2" style={{ borderColor: settings.backgroundColor }}></div>
                        <span>Traitement en cours...</span>
                      </>
                    ) : (
                      <>
                        <i className="ri-secure-payment-line text-xl"></i>
                        <span>Finaliser le Paiement - {selectedPlanData?.price}</span>
                      </>
                    )}
                  </button>

                  <div className="text-center">
                    <p className="text-gray-400 text-sm flex items-center justify-center space-x-2">
                      <i className="ri-shield-check-line text-green-400"></i>
                      <span>Paiement sécurisé SSL - Données protégées</span>
                    </p>
                  </div>
                </form>
              </div>
            </div>

            {/* Security Banner */}
            <div className="mt-12 bg-gray-900 rounded-xl p-6 border border-gray-800">
              <div className="flex items-center justify-center space-x-8">
                {settings.securityFeatures.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-2 text-gray-400">
                    <i className={feature.icon} style={{ color: settings.accentColor }}></i>
                    <span>{feature.text}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}