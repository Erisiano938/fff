
// Improved error handling utility for network requests and API calls

export interface ErrorInfo {
  message: string;
  code?: string;
  timestamp: number;
  url?: string;
}

export class NetworkErrorHandler {
  private static errors: ErrorInfo[] = [];

  static logError(error: Error | any, url?: string): void {
    // Safely extract error information
    const errorMessage = error?.message || error?.toString() || 'Unknown error';
    const errorCode = error?.name || error?.code || 'UnknownError';

    const errorInfo: ErrorInfo = {
      message: errorMessage,
      code: errorCode,
      timestamp: Date.now(),
      url
    };

    this.errors.push(errorInfo);
    
    // Only log non-empty errors
    if (errorMessage && errorMessage !== '{}') {
      console.error('🚨 Network Error Details:', {
        message: errorMessage,
        code: errorCode,
        url: url || 'N/A',
        timestamp: new Date(errorInfo.timestamp).toISOString()
      });
    }

    // Keep only last 50 errors
    if (this.errors.length > 50) {
      this.errors = this.errors.slice(-50);
    }
  }

  static getRecentErrors(): ErrorInfo[] {
    return [...this.errors].reverse();
  }

  static clearErrors(): void {
    this.errors = [];
  }

  // Improved retry mechanism with better error handling
  static async retryFetch(
    url: string, 
    options: RequestInit = {}, 
    maxRetries: number = 2,
    delay: number = 1000
  ): Promise<Response> {
    let lastError: Error | null = null;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        console.log(`🔄 Fetch attempt ${attempt}/${maxRetries} for:`, url);
        
        // Create abort controller for timeout
        const controller = new AbortController();
        const timeoutId = setTimeout(() => {
          controller.abort();
          console.warn(`⏰ Request timeout after 8 seconds for attempt ${attempt}`);
        }, 8000);

        const response = await fetch(url, {
          ...options,
          signal: controller.signal
        });

        clearTimeout(timeoutId);

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        console.log(`✅ Fetch successful on attempt ${attempt}`);
        return response;

      } catch (error) {
        lastError = error as Error;
        
        // Log specific error types
        if (error instanceof Error) {
          if (error.name === 'AbortError') {
            console.warn(`⏰ Request timeout on attempt ${attempt}`);
          } else if (error.message.includes('fetch')) {
            console.warn(`🌐 Network error on attempt ${attempt}:`, error.message);
          } else {
            console.warn(`❌ Request failed on attempt ${attempt}:`, error.message);
          }
        }

        if (attempt < maxRetries) {
          console.log(`⏳ Waiting ${delay}ms before retry...`);
          await new Promise(resolve => setTimeout(resolve, delay));
          delay = Math.min(delay * 1.5, 5000); // Progressive backoff, max 5s
        }
      }
    }

    // Log the final error only if it has meaningful content
    if (lastError && lastError.message && lastError.message !== '{}') {
      this.logError(lastError, url);
    }
    
    throw lastError || new Error('All retry attempts failed');
  }

  // Safe fetch with simplified error handling
  static async safeFetch(
    url: string,
    options: RequestInit = {},
    timeoutMs: number = 5000
  ): Promise<Response | null> {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

      const response = await fetch(url, {
        ...options,
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        console.warn(`⚠️ HTTP ${response.status} for ${url}`);
        return null;
      }

      return response;
    } catch (error) {
      if (error instanceof Error && error.name !== 'AbortError') {
        console.warn(`🌐 Network request failed for ${url}:`, error.message);
      }
      return null;
    }
  }

  // Safe image loading with fallback
  static createSafeImageUrl(
    baseUrl: string, 
    fallbackUrl?: string
  ): Promise<string> {
    return new Promise((resolve) => {
      if (typeof window === 'undefined') {
        resolve(baseUrl);
        return;
      }

      const img = new Image();
      
      img.onload = () => {
        console.log('✅ Image loaded successfully:', baseUrl);
        resolve(baseUrl);
      };
      
      img.onerror = () => {
        console.warn('⚠️ Image failed to load:', baseUrl);
        if (fallbackUrl) {
          console.log('🔄 Using fallback image:', fallbackUrl);
          resolve(fallbackUrl);
        } else {
          // Use a minimal SVG placeholder
          const placeholder = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjI1MCIgdmlld0JveD0iMCAwIDQwMCAyNTAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSI0MDAiIGhlaWdodD0iMjUwIiBmaWxsPSIjRjNGNEY2Ii8+CjxyZWN0IHg9IjE1MCIgeT0iMTAwIiB3aWR0aD0iMTAwIiBoZWlnaHQ9IjUwIiBmaWxsPSIjMzc0MUY0IiByeD0iOCIvPgo8dGV4dCB4PSIyMDAiIHk9IjEzMCIgZmlsbD0iI0ZGRkZGRiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjE0Ij5JbWFnZTwvdGV4dD4KPC9zdmc+';
          resolve(placeholder);
        }
      };
      
      img.src = baseUrl;
    });
  }
}

// Improved global error handler
if (typeof window !== 'undefined') {
  window.addEventListener('unhandledrejection', (event) => {
    // Only handle meaningful fetch errors
    if (event.reason && 
        typeof event.reason === 'object' && 
        event.reason.message && 
        event.reason.message !== '{}' &&
        (event.reason.message.includes('fetch') || event.reason.message.includes('network'))) {
      
      NetworkErrorHandler.logError(event.reason);
      console.log('🔧 Network connectivity issue detected');
    }
  });

  // Handle window errors as well
  window.addEventListener('error', (event) => {
    if (event.error && event.error.message && event.error.message.includes('fetch')) {
      NetworkErrorHandler.logError(event.error, event.filename);
    }
  });
}
