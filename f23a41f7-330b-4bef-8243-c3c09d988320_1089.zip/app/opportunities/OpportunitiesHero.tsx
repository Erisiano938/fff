'use client';

export default function OpportunitiesHero() {
  return (
    <section className="bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900 py-20 relative overflow-hidden">
      <div className="absolute inset-0 bg-black/20"></div>
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Détecteur d' <span className="text-yellow-400">Opportunités</span> Sectorielles
          </h1>
          <p className="text-xl text-gray-200 mb-8">
            Identifiez les secteurs en croissance avant les autres grâce à notre analyse avancée des signaux faibles du marché
          </p>
          <div className="flex flex-wrap justify-center gap-6 text-white">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-yellow-500/20 rounded-full flex items-center justify-center">
                <i className="ri-search-line text-yellow-400"></i>
              </div>
              <span className="font-medium">Appels d'Offres</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-yellow-500/20 rounded-full flex items-center justify-center">
                <i className="ri-lightbulb-line text-yellow-400"></i>
              </div>
              <span className="font-medium">Brevets</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-yellow-500/20 rounded-full flex items-center justify-center">
                <i className="ri-user-star-line text-yellow-400"></i>
              </div>
              <span className="font-medium">Mouvements RH</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}