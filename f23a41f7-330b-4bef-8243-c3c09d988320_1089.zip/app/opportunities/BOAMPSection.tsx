
'use client';

import { useState, useEffect, useMemo, useCallback } from 'react';

interface BOAMPRecord {
  fields: {
    numero_avis: string;
    titre: string;
    date_publication: string;
    datelimitereponse?: string;
    datefindiffusion?: string;
    descripteur_code?: string;
    type_marche?: string;
    code_departement?: string;
    organisme_nom?: string;
    montant_marche?: number;
    lieu_execution?: string;
  };
}

// Fonction utilitaire déplacée en dehors du composant
const getDaysRemaining = (dateString?: string) => {
  if (!dateString) return null;
  const today = new Date();
  const deadline = new Date(dateString);
  const diffTime = deadline.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
};

// Fonction de formatage déplacée en dehors du composant
const formatDate = (dateString: string) => {
  if (!dateString) return 'Non spécifiée';
  return new Date(dateString).toLocaleDateString('fr-FR');
};

// Données de démonstration
const mockData = [
  {
    fields: {
      numero_avis: 'AO-2025-HYD-001',
      titre: 'Fourniture et installation de stations hydrogène vert pour flotte de transport public',
      date_publication: '2025-01-15',
      datelimitereponse: '2025-08-15',
      datefindiffusion: '2025-08-15',
      organisme_nom: 'Métropole de Lyon',
      code_departement: '69',
      type_marche: 'Fournitures et services',
      montant_marche: 15000000,
      lieu_execution: 'Lyon, Rhône-Alpes'
    }
  },
  {
    fields: {
      numero_avis: 'AO-2025-IA-002',
      titre: 'Développement d\'une plateforme IA pour l\'optimisation des services publics numériques',
      date_publication: '2025-01-16',
      datelimitereponse: '2025-08-20',
      datefindiffusion: '2025-08-20',
      organisme_nom: 'Ville de Paris',
      code_departement: '75',
      type_marche: 'Services informatiques',
      montant_marche: 8500000,
      lieu_execution: 'Paris, Île-de-France'
    }
  },
  {
    fields: {
      numero_avis: 'AO-2025-CYBER-003',
      titre: 'Audit de cybersécurité et mise en conformité RGPD pour administrations territoriales',
      date_publication: '2025-01-17',
      datelimitereponse: '2025-08-25',
      datefindiffusion: '2025-08-25',
      organisme_nom: 'Région Nouvelle-Aquitaine',
      code_departement: '33',
      type_marche: 'Services de conseil',
      montant_marche: 3200000,
      lieu_execution: 'Bordeaux, Nouvelle-Aquitaine'
    }
  }
];

export default function BOAMPSection() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('');
  const [selectedType, setSelectedType] = useState('');
  const [boampData, setBOAMPData] = useState<BOAMPRecord[]>(mockData);
  const [filteredData, setFilteredOpportunities] = useState<BOAMPRecord[]>(mockData);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Mémorisation des données de fallback pour éviter les recalculs
  const fallbackData = useMemo(() => mockData, []);

  // Mémorisation de la fonction de fetch pour éviter les re-créations
  const fetchBOAMPData = useCallback(async () => {
    try {
      setError(null);
      setIsLoading(true);

      const baseUrl = 'https://boamp-datadila.opendatasoft.com/api/records/1.0/search';
      const today = new Date().toISOString().slice(0, 10);

      const params = new URLSearchParams({
        dataset: 'boamp',
        rows: '15',
        sort: '-fields.date_publication',
        lang: 'fr',
        facet: 'fields.type_marche',
        facet: 'fields.code_departement'
      });

      if (searchTerm) {
        params.set('q', searchTerm);
      }

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);

      const response = await fetch(`${baseUrl}?${params.toString()}`, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`API BOAMP indisponible (${response.status})`);
      }

      const data = await response.json();

      if (data.records && Array.isArray(data.records)) {
        const openRecords = data.records
          .filter(record => {
            const limitDate = record.fields.date_limite_reponse;
            return limitDate && limitDate >= today;
          })
          .slice(0, 12)
          .map(record => ({
            fields: {
              numero_avis: record.fields.numero_avis || 'N/A',
              titre: record.fields.titre || 'Titre non disponible',
              date_publication: record.fields.date_publication || '',
              datelimitereponse: record.fields.date_limite_reponse || '',
              datefindiffusion: record.fields.date_fin_diffusion || '',
              organisme_nom: record.fields.organisme_nom || '',
              code_departement: record.fields.code_departement || '',
              type_marche: record.fields.type_marche || '',
              montant_marche: record.fields.montant_marche || 0,
              lieu_execution: record.fields.lieu_execution || ''
            }
          }));

        setBOAMPData(openRecords);
      } else {
        throw new Error('Format de données inattendu');
      }
    } catch (err) {
      setBOAMPData(fallbackData);
      
      if (err instanceof Error) {
        if (err.name === 'AbortError') {
          setError('Timeout: Données de démonstration affichées.');
        } else if (err.message.includes('Failed to fetch')) {
          setError('Problème de réseau. Données de démonstration affichées.');
        } else {
          setError('API temporairement indisponible. Données de démonstration affichées.');
        }
      } else {
        setError('API temporairement indisponible. Données de démonstration affichées.');
      }
    } finally {
      setIsLoading(false);
    }
  }, [searchTerm, fallbackData]);

  // Chargement initial uniquement
  useEffect(() => {
    fetchBOAMPData();
  }, [fetchBOAMPData]);

  // Mémorisation des données filtrées pour éviter les recalculs
  useEffect(() => {
    const filtered = boampData.filter(record => {
      const matchSearch = !searchTerm ||
        record.fields.titre?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        record.fields.organisme_nom?.toLowerCase().includes(searchTerm.toLowerCase());

      const matchDepartment = !selectedDepartment ||
        record.fields.code_departement === selectedDepartment;

      const matchType = !selectedType ||
        record.fields.type_marche === selectedType;

      return matchSearch && matchDepartment && matchType;
    });
    setFilteredOpportunities(filtered);
  }, [boampData, searchTerm, selectedDepartment, selectedType]);

  // Mémorisation des listes uniques
  const uniqueDepartments = useMemo(() => {
    return Array.from(
      new Set(boampData.map(record => record.fields.code_departement).filter(Boolean))
    ).sort();
  }, [boampData]);

  const uniqueTypes = useMemo(() => {
    return Array.from(
      new Set(boampData.map(record => record.fields.type_marche).filter(Boolean))
    ).sort();
  }, [boampData]);

  // Mémorisation des statistiques pour éviter les recalculs
  const statistics = useMemo(() => {
    const urgentCount = filteredData.filter(record => {
      const days = getDaysRemaining(record.fields.datelimitereponse || record.fields.datefindiffusion);
      return days !== null && days <= 7;
    }).length;

    const highAmountCount = filteredData.filter(record => 
      record.fields.montant_marche && record.fields.montant_marche > 100000
    ).length;

    return {
      urgent: urgentCount,
      highAmount: highAmountCount,
      departments: uniqueDepartments.length,
      types: uniqueTypes.length
    };
  }, [filteredData, uniqueDepartments, uniqueTypes]);

  // Mémorisation de la fonction d'export
  const exportToCSV = useCallback(() => {
    if (filteredData.length === 0) return;

    const headers = [
      'Numéro d\'avis',
      'Titre',
      'Date de publication',
      'Date limite de réponse',
      'Organisme',
      'Département',
      'Type de marché',
      'Montant',
      'Lieu d\'exécution'
    ];

    const csvData = filteredData.map(record => [
      record.fields.numero_avis || '',
      `"${(record.fields.titre || '').replace(/"/g, '""')}"`,
      record.fields.date_publication || '',
      record.fields.datelimitereponse || '',
      `"${(record.fields.organisme_nom || '').replace(/"/g, '""')}"`,
      record.fields.code_departement || '',
      record.fields.type_marche || '',
      record.fields.montant_marche || '',
      `"${(record.fields.lieu_execution || '').replace(/"/g, '""')}"`,
    ]);

    const csv = [headers, ...csvData].map(row => row.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `boamp_appels_offres_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
  }, [filteredData]);

  // Mémorisation de la fonction de copie
  const copyToClipboard = useCallback((record: BOAMPRecord) => {
    const info = `Appel d'offres: ${record.fields.titre}\nN°: ${record.fields.numero_avis}\nOrganisme: ${record.fields.organisme_nom || 'N/A'}\nDate limite: ${formatDate(record.fields.datelimitereponse || record.fields.datefindiffusion || '')}\nLien: https://www.boamp.fr/index.php/avis/detail/${encodeURIComponent(record.fields.numero_avis || '')}`;
    navigator.clipboard.writeText(info).then(() => {
      alert('Informations copiées !');
    });
  }, []);

  if (isLoading) {
    return (
      <div className="bg-gray-900 rounded-xl p-8 border border-yellow-500/20">
        <div className="text-center">
          <div className="w-12 h-12 border-2 border-yellow-500/30 border-t-yellow-500 rounded-full animate-spin mx-auto mb-4"></div>
          <h3 className="text-xl font-bold text-white mb-2">Chargement des appels d'offres</h3>
          <p className="text-gray-400">Récupération des données BOAMP...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header avec statistiques */}
      <div className="bg-gradient-to-r from-blue-900/20 to-purple-900/20 rounded-2xl p-6 border border-blue-500/20">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
          <div>
            <h2 className="text-3xl font-bold text-white mb-3 flex items-center">
              <i className="ri-file-list-3-line mr-3 text-blue-400"></i>
              Appels d'Offres Publics
            </h2>
            <div className="flex flex-wrap items-center gap-4 text-sm">
              <span className="px-3 py-1 bg-green-500/20 text-green-400 rounded-full font-medium">
                <i className="ri-check-line mr-1"></i>
                3 appels d'offres ouverts
              </span>
              <span className="text-gray-400">sur 3 total</span>
              {error && (
                <span className="flex items-center text-orange-400 bg-orange-500/10 px-3 py-1 rounded-full">
                  <i className="ri-information-line mr-2"></i>
                  {error}
                </span>
              )}
            </div>
          </div>
          <div className="flex flex-wrap gap-3">
            <button 
              onClick={fetchBOAMPData}
              className="flex items-center px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl transition-all duration-300 shadow-lg hover:shadow-blue-500/25 cursor-pointer whitespace-nowrap"
            >
              <i className="ri-refresh-line mr-2"></i>
              Actualiser
            </button>
            <button 
              onClick={exportToCSV}
              className="flex items-center px-6 py-3 bg-green-600 hover:bg-green-700 text-white rounded-xl transition-all duration-300 shadow-lg hover:shadow-green-500/25 cursor-pointer whitespace-nowrap"
            >
              <i className="ri-download-line mr-2"></i>
              Export CSV
            </button>
          </div>
        </div>
      </div>

      {/* Filtres améliorés */}
      <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-700/50">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
          <i className="ri-filter-3-line mr-2 text-blue-400"></i>
          Filtres de recherche
        </h3>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div>
            <label className="block text-white font-medium mb-3">
              <i className="ri-search-line mr-2 text-gray-400"></i>
              Recherche
            </label>
            <input
              type="text"
              placeholder="Titre, organisme, mots-clés..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full p-4 bg-gray-900/80 border border-gray-600 rounded-xl text-white placeholder-gray-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 focus:outline-none transition-all duration-300"
            />
          </div>
          <div>
            <label className="block text-white font-medium mb-3">
              <i className="ri-map-pin-line mr-2 text-gray-400"></i>
              Département
            </label>
            <select
              value={selectedDepartment}
              onChange={(e) => setSelectedDepartment(e.target.value)}
              className="w-full p-4 bg-gray-900/80 border border-gray-600 rounded-xl text-white focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 focus:outline-none transition-all duration-300 pr-8"
            >
              <option value="">Tous les départements</option>
              {uniqueDepartments.map(dept => (
                <option key={dept} value={dept}>{dept}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-white font-medium mb-3">
              <i className="ri-briefcase-line mr-2 text-gray-400"></i>
              Type de marché
            </label>
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="w-full p-4 bg-gray-900/80 border border-gray-600 rounded-xl text-white focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 focus:outline-none transition-all duration-300 pr-8"
            >
              <option value="">Tous les types</option>
              {uniqueTypes.map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Statistiques visuellement améliorées */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-blue-900/40 to-blue-800/20 rounded-xl p-6 border border-blue-500/30 hover:border-blue-400/50 transition-all duration-300">
          <div className="flex items-center justify-between mb-2">
            <div className="text-3xl font-bold text-blue-400">{statistics.urgent}</div>
            <i className="ri-alarm-warning-line text-2xl text-blue-400"></i>
          </div>
          <div className="text-sm text-gray-300 font-medium">Urgents (≤7j)</div>
          <div className="w-full bg-blue-900/30 rounded-full h-2 mt-3">
            <div 
              className="bg-blue-400 h-2 rounded-full" 
              style={{ width: `${(statistics.urgent / filteredData.length) * 100}%` }}
            ></div>
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-green-900/40 to-green-800/20 rounded-xl p-6 border border-green-500/30 hover:border-green-400/50 transition-all duration-300">
          <div className="flex items-center justify-between mb-2">
            <div className="text-3xl font-bold text-green-400">{statistics.highAmount}</div>
            <i className="ri-money-euro-circle-line text-2xl text-green-400"></i>
          </div>
          <div className="text-sm text-gray-300 font-medium">Montant &gt;100k€</div>
          <div className="w-full bg-green-900/30 rounded-full h-2 mt-3">
            <div 
              className="bg-green-400 h-2 rounded-full" 
              style={{ width: `${(statistics.highAmount / filteredData.length) * 100}%` }}
            ></div>
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-purple-900/40 to-purple-800/20 rounded-xl p-6 border border-purple-500/30 hover:border-purple-400/50 transition-all duration-300">
          <div className="flex items-center justify-between mb-2">
            <div className="text-3xl font-bold text-purple-400">{statistics.departments}</div>
            <i className="ri-map-2-line text-2xl text-purple-400"></i>
          </div>
          <div className="text-sm text-gray-300 font-medium">Départements</div>
          <div className="w-full bg-purple-900/30 rounded-full h-2 mt-3">
            <div className="bg-purple-400 h-2 rounded-full w-full"></div>
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-yellow-900/40 to-yellow-800/20 rounded-xl p-6 border border-yellow-500/30 hover:border-yellow-400/50 transition-all duration-300">
          <div className="flex items-center justify-between mb-2">
            <div className="text-3xl font-bold text-yellow-400">{statistics.types}</div>
            <i className="ri-folder-line text-2xl text-yellow-400"></i>
          </div>
          <div className="text-sm text-gray-300 font-medium">Types de marchés</div>
          <div className="w-full bg-yellow-900/30 rounded-full h-2 mt-3">
            <div className="bg-yellow-400 h-2 rounded-full w-full"></div>
          </div>
        </div>
      </div>

      {/* Liste des appels d'offres avec design premium */}
      <div className="space-y-6">
        {filteredData.map((opportunity, index) => {
          const daysRemaining = getDaysRemaining(
            opportunity.fields.datelimitereponse || opportunity.fields.datefindiffusion
          );
          
          return (
            <div
              key={`${opportunity.fields.numero_avis}-${index}`}
              className="group bg-gradient-to-r from-gray-900/80 to-gray-800/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700/50 hover:border-red-500/50 transition-all duration-500 hover:shadow-2xl hover:shadow-red-500/10 hover:-translate-y-1"
            >
              <div className="flex flex-col xl:flex-row gap-8">
                {/* Contenu principal */}
                <div className="flex-1 space-y-6">
                  {/* En-tête avec badge urgent */}
                  <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
                    <h3 className="text-xl font-bold text-white leading-tight group-hover:text-blue-400 transition-colors duration-300">
                      {opportunity.fields.titre}
                    </h3>
                    <div className="flex items-center gap-3">
                      {daysRemaining !== null && daysRemaining <= 7 && (
                        <span className="flex items-center px-4 py-2 bg-gradient-to-r from-red-500/20 to-red-600/20 text-red-400 rounded-full text-sm font-semibold border border-red-500/30 whitespace-nowrap">
                          <i className="ri-alarm-warning-line mr-2"></i>
                          URGENT
                        </span>
                      )}
                      <span className="text-xs text-gray-400 bg-gray-800 px-3 py-1 rounded-full">
                        #{opportunity.fields.numero_avis}
                      </span>
                    </div>
                  </div>

                  {/* Informations principales dans une grille */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-6 bg-gray-800/30 rounded-xl border border-gray-700/30">
                    <div className="space-y-2">
                      <div className="flex items-center text-gray-400 text-sm">
                        <i className="ri-calendar-line mr-2"></i>
                        Publication
                      </div>
                      <div className="text-white font-semibold">
                        {formatDate(opportunity.fields.date_publication)}
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center text-gray-400 text-sm">
                        <i className="ri-time-line mr-2"></i>
                        Date limite
                      </div>
                      <div className="flex items-center">
                        <span className="font-semibold text-red-400">
                          {formatDate(opportunity.fields.datelimitereponse || opportunity.fields.datefindiffusion || '')}
                        </span>
                        {daysRemaining !== null && daysRemaining < 0 && (
                          <span className="ml-3 text-xs text-red-300 bg-red-500/10 px-2 py-1 rounded">
                            (Expiré)
                          </span>
                        )}
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center text-gray-400 text-sm">
                        <i className="ri-money-euro-circle-line mr-2"></i>
                        Montant estimé
                      </div>
                      <div className="text-2xl font-bold text-green-400">
                        {opportunity.fields.montant_marche 
                          ? `${opportunity.fields.montant_marche.toLocaleString()} €`
                          : 'Non spécifié'}
                      </div>
                    </div>
                  </div>

                  {/* Organisme et détails */}
                  <div className="flex flex-col sm:flex-row gap-6 p-4 bg-gray-800/20 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center">
                        <i className="ri-building-line text-blue-400 text-xl"></i>
                      </div>
                      <div>
                        <div className="text-gray-400 text-sm">Organisme</div>
                        <div className="text-white font-semibold">{opportunity.fields.organisme_nom || 'Non spécifié'}</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-purple-500/20 rounded-full flex items-center justify-center">
                        <i className="ri-folder-line text-purple-400 text-xl"></i>
                      </div>
                      <div>
                        <div className="text-gray-400 text-sm">Type de marché</div>
                        <div className="text-white font-semibold">{opportunity.fields.type_marche || 'Non spécifié'}</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-yellow-500/20 rounded-full flex items-center justify-center">
                        <i className="ri-map-pin-line text-yellow-400 text-xl"></i>
                      </div>
                      <div>
                        <div className="text-gray-400 text-sm">Lieu d'exécution</div>
                        <div className="text-white font-semibold">{opportunity.fields.lieu_execution || 'Non spécifié'}</div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Actions avec design amélioré */}
                <div className="xl:w-48 flex xl:flex-col gap-3">
                  <a
                    href={`https://www.boamp.fr/index.php/avis/detail/${encodeURIComponent(opportunity.fields.numero_avis)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 xl:flex-none flex items-center justify-center px-6 py-4 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white rounded-xl transition-all duration-300 cursor-pointer whitespace-nowrap font-semibold shadow-lg hover:shadow-blue-500/25 hover:scale-105"
                  >
                    <i className="ri-external-link-line mr-2"></i>
                    Consulter
                  </a>
                  
                  <button 
                    onClick={() => copyToClipboard(opportunity)}
                    className="flex-1 xl:flex-none flex items-center justify-center px-6 py-4 bg-gray-700 hover:bg-gray-600 text-white rounded-xl transition-all duration-300 cursor-pointer whitespace-nowrap font-semibold shadow-lg hover:shadow-gray-500/25"
                  >
                    <i className="ri-file-copy-line mr-2"></i>
                    Copier info
                  </button>
                  
                  <button className="flex-1 xl:flex-none flex items-center justify-center px-6 py-4 bg-green-600 hover:bg-green-700 text-white rounded-xl transition-all duration-300 cursor-pointer whitespace-nowrap font-semibold shadow-lg hover:shadow-green-500/25">
                    <i className="ri-bookmark-line mr-2"></i>
                    Sauvegarder
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Pagination */}
      <div className="flex justify-center items-center space-x-4 pt-8">
        <button className="flex items-center px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-lg transition-colors cursor-pointer">
          <i className="ri-arrow-left-line mr-2"></i>
          Précédent
        </button>
        <div className="flex space-x-2">
          <button className="w-10 h-10 bg-blue-600 text-white rounded-lg font-semibold">1</button>
          <button className="w-10 h-10 bg-gray-800 hover:bg-gray-700 text-white rounded-lg transition-colors cursor-pointer">2</button>
          <button className="w-10 h-10 bg-gray-800 hover:bg-gray-700 text-white rounded-lg transition-colors cursor-pointer">3</button>
        </div>
        <button className="flex items-center px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white rounded-lg transition-colors cursor-pointer">
          Suivant
          <i className="ri-arrow-right-line ml-2"></i>
        </button>
      </div>
    </div>
  );
}
