
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Opportunités d\'Investissement',
  description: 'Découvrez les meilleures opportunités d\'investissement : appels d\'offres BOAMP, brevets innovants, analyses sectorielles et dirigeants performants.',
  keywords: 'opportunités investissement, BOAMP, appels offres, brevets, analyses sectorielles, investissement innovation, marchés publics',
  openGraph: {
    title: 'Opportunités d\'Investissement | CMV Finance',
    description: 'Identifiez les meilleures opportunités d\'investissement avec notre analyse approfondie des marchés.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Opportunités d\'Investissement | CMV Finance',
    description: 'Identifiez les meilleures opportunités d\'investissement avec notre analyse approfondie des marchés.',
  },
};

export default function OpportunitiesLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Service",
            "name": "Opportunités d'Investissement CMV",
            "description": "Service d'identification et d'analyse des opportunités d'investissement",
            "url": `${process.env.NEXT_PUBLIC_SITE_URL}/opportunities`,
            "provider": {
              "@type": "Organization",
              "name": "CMV Finance",
              "url": process.env.NEXT_PUBLIC_SITE_URL
            },
            "serviceType": "Investment Research",
            "hasOfferCatalog": {
              "@type": "OfferCatalog",
              "name": "Services d'Analyse",
              "itemListElement": [
                {
                  "@type": "Offer",
                  "itemOffered": {
                    "@type": "Service",
                    "name": "Veille BOAMP",
                    "description": "Surveillance des appels d'offres publics français"
                  }
                },
                {
                  "@type": "Offer",
                  "itemOffered": {
                    "@type": "Service",
                    "name": "Analyse Brevets",
                    "description": "Identification des innovations et brevets prometteurs"
                  }
                },
                {
                  "@type": "Offer",
                  "itemOffered": {
                    "@type": "Service",
                    "name": "Analyses Sectorielles",
                    "description": "Études approfondies des secteurs d'activité"
                  }
                }
              ]
            }
          })
        }}
      />
      {children}
    </>
  );
}
