'use client';

import Header from '../components/Header';
import Footer from '../components/Footer';
import OpportunitiesHero from './OpportunitiesHero';
import SectorAnalysis from './SectorAnalysis';
import BOAMPSection from './BOAMPSection';
import PatentsSection from './PatentsSection';
import ExecutivesSection from './ExecutivesSection';

export default function OpportunitiesPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <OpportunitiesHero />
      <SectorAnalysis />
      <BOAMPSection />
      <PatentsSection />
      <ExecutivesSection />
      <Footer />
    </div>
  );
}