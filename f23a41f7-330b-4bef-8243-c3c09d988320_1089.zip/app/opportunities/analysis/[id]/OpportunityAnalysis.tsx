
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

interface OpportunityData {
  id: string;
  reference: string;
  title: string;
  authority: string;
  sector: string;
  budget: number;
  deadline: string;
  location: string;
  type: string;
  procedure: string;
  description: string;
  requirements: string[];
  criteria: {
    technical: number;
    financial: number;
    experience: number;
  };
  competitors: {
    estimated: number;
    majorPlayers: string[];
  };
  riskLevel: 'low' | 'medium' | 'high';
  successProbability: number;
}

export default function OpportunityAnalysis({ opportunityId }: { opportunityId: string }) {
  const [opportunity, setOpportunity] = useState<OpportunityData | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    fetchOpportunityData();
  }, [opportunityId]);

  const fetchOpportunityData = () => {
    setLoading(true);
    
    // Données de démonstration basées sur l'ID
    const mockData: { [key: string]: OpportunityData } = {
      'boamp-001': {
        id: 'boamp-001',
        reference: 'AO-2025-HYD-001',
        title: 'Fourniture et installation de stations hydrogène vert pour flotte de transport public',
        authority: 'Métropole de Lyon',
        sector: 'Hydrogène vert',
        budget: 15000000,
        deadline: '2025-08-15',
        location: 'Lyon, Rhône-Alpes',
        type: 'Fournitures et services',
        procedure: 'Appel d\'offres ouvert',
        description: 'La Métropole de Lyon lance un appel d\'offres majeur pour équiper sa flotte de transport public avec des stations de recharge à hydrogène vert. Ce projet s\'inscrit dans la stratégie de décarbonation des transports publics et vise à positionner Lyon comme référence européenne en matière de mobilité propre.',
        requirements: [
          'Certification ISO 14001 et 45001 obligatoire',
          'Expérience minimale de 5 ans dans l\'hydrogène industriel',
          'Capacité de production de 200kg H2/jour minimum par station',
          'Garantie constructeur de 10 ans sur les équipements',
          'Personnel certifié ATEX pour la manipulation d\'hydrogène',
          'Solutions de monitoring temps réel avec API dédiée'
        ],
        criteria: {
          technical: 60,
          financial: 25,
          experience: 15
        },
        competitors: {
          estimated: 8,
          majorPlayers: ['Air Liquide', 'McPhy Energy', 'Linde Gas', 'Plastic Omnium']
        },
        riskLevel: 'medium',
        successProbability: 65
      },
      'boamp-002': {
        id: 'boamp-002',
        reference: 'AO-2025-IA-002',
        title: 'Développement d\'une plateforme IA pour l\'optimisation des services publics numériques',
        authority: 'Ville de Paris',
        sector: 'Intelligence Artificielle',
        budget: 8500000,
        deadline: '2025-08-20',
        location: 'Paris, Île-de-France',
        type: 'Services informatiques',
        procedure: 'Procédure négociée',
        description: 'La Ville de Paris souhaite développer une plateforme d\'intelligence artificielle pour optimiser la gestion des services publics numériques. Cette solution doit intégrer machine learning, NLP et vision par ordinateur pour améliorer l\'expérience citoyenne.',
        requirements: [
          'Expertise en IA générative et modèles de langage (LLM)',
          'Conformité RGPD et sécurité renforcée',
          'Architecture cloud-native et scalable',
          'Interface multilingue (français, anglais, arabe)',
          'Intégration avec les systèmes existants de la ville',
          'Formation des équipes municipales incluse'
        ],
        criteria: {
          technical: 70,
          financial: 20,
          experience: 10
        },
        competitors: {
          estimated: 12,
          majorPlayers: ['Capgemini', 'Atos', 'Orange Business', 'IBM France']
        },
        riskLevel: 'high',
        successProbability: 45
      },
      'boamp-003': {
        id: 'boamp-003',
        reference: 'AO-2025-CYBER-003',
        title: 'Audit de cybersécurité et mise en conformité RGPD pour administrations territoriales',
        authority: 'Région Nouvelle-Aquitaine',
        sector: 'Cybersécurité',
        budget: 3200000,
        deadline: '2025-08-25',
        location: 'Bordeaux, Nouvelle-Aquitaine',
        type: 'Services de conseil',
        procedure: 'Appel d\'offres restreint',
        description: 'Audit complet de cybersécurité couvrant 150 sites administratifs de la région. Mission incluant tests d\'intrusion, formation du personnel, mise en conformité RGPD et déploiement d\'un SOC régional.',
        requirements: [
          'Certifications CISSP, CISA ou CISM obligatoires',
          'Agrément sécurité nationale si applicable',
          'Expérience prouvée en administration publique',
          'Outils de pentest certifiés et à jour',
          'Équipe dédiée de 15 consultants minimum',
          'Méthodologie EBIOS Risk Manager'
        ],
        criteria: {
          technical: 50,
          financial: 30,
          experience: 20
        },
        competitors: {
          estimated: 6,
          majorPlayers: ['Thales', 'Orange Cyberdefense', 'Wavestone', 'PwC']
        },
        riskLevel: 'low',
        successProbability: 75
      }
    };

    setOpportunity(mockData[opportunityId] || null);
    setLoading(false);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'currency',
      currency: 'EUR',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  const getDaysRemaining = (deadline: string) => {
    const deadlineDate = new Date(deadline);
    const now = new Date();
    const diffTime = deadlineDate.getTime() - now.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-green-600 bg-green-100';
      case 'medium': return 'text-orange-600 bg-orange-100';
      case 'high': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getRiskLabel = (risk: string) => {
    switch (risk) {
      case 'low': return 'Risque Faible';
      case 'medium': return 'Risque Modéré';
      case 'high': return 'Risque Élevé';
      default: return 'Non évalué';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">Chargement de l'analyse...</p>
        </div>
      </div>
    );
  }

  if (!opportunity) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <i className="ri-file-search-line text-6xl text-gray-400 mb-4"></i>
          <h2 className="text-2xl font-bold text-gray-600 mb-2">Opportunité non trouvée</h2>
          <p className="text-gray-500 mb-6">L'analyse demandée n'est pas disponible</p>
          <Link href="/opportunities" className="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors cursor-pointer">
            Retour aux opportunités
          </Link>
        </div>
      </div>
    );
  }

  const daysRemaining = getDaysRemaining(opportunity.deadline);
  const isUrgent = daysRemaining < 15;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link href="/opportunities" className="flex items-center text-gray-600 hover:text-blue-600 transition-colors cursor-pointer">
              <i className="ri-arrow-left-line text-xl mr-2"></i>
              Retour aux opportunités
            </Link>
            <div className="flex items-center space-x-3">
              <span className="px-3 py-1 bg-blue-100 text-blue-800 text-sm font-medium rounded-full">
                {opportunity.reference}
              </span>
              <span className={`px-3 py-1 text-sm font-medium rounded-full ${getRiskColor(opportunity.riskLevel)}`}>
                {getRiskLabel(opportunity.riskLevel)}
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-8">
        {/* En-tête de l'opportunité */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <h1 className="text-3xl font-bold text-gray-800 mb-4">
                {opportunity.title}
              </h1>
              <div className="flex flex-wrap items-center gap-4 mb-6">
                <div className="flex items-center text-gray-600">
                  <i className="ri-building-line mr-2"></i>
                  {opportunity.authority}
                </div>
                <div className="flex items-center text-gray-600">
                  <i className="ri-map-pin-line mr-2"></i>
                  {opportunity.location}
                </div>
                <div className="flex items-center text-gray-600">
                  <i className="ri-price-tag-3-line mr-2"></i>
                  {opportunity.sector}
                </div>
              </div>
              <p className="text-gray-700 leading-relaxed">
                {opportunity.description}
              </p>
            </div>
            
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-6">
                <h3 className="font-bold text-gray-800 mb-4">Informations Clés</h3>
                <div className="space-y-3">
                  <div>
                    <div className="text-sm text-gray-500">Budget</div>
                    <div className="text-2xl font-bold text-blue-600">
                      {formatCurrency(opportunity.budget)}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Date limite</div>
                    <div className="font-medium text-gray-800">
                      {formatDate(opportunity.deadline)}
                    </div>
                    <div className={`text-sm ${isUrgent ? 'text-orange-600' : 'text-gray-500'}`}>
                      {daysRemaining} jours restants
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Probabilité de succès</div>
                    <div className="flex items-center space-x-2">
                      <div className="flex-1 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-500 h-2 rounded-full"
                          style={{ width: `${opportunity.successProbability}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-medium text-gray-800">
                        {opportunity.successProbability}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation des onglets */}
        <div className="bg-white rounded-xl shadow-lg mb-8">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-8">
              {[
                { id: 'overview', label: 'Vue d\'ensemble', icon: 'ri-dashboard-line' },
                { id: 'requirements', label: 'Exigences', icon: 'ri-list-check-line' },
                { id: 'competition', label: 'Concurrence', icon: 'ri-team-line' },
                { id: 'strategy', label: 'Stratégie', icon: 'ri-lightbulb-line' },
                { id: 'timeline', label: 'Calendrier', icon: 'ri-calendar-line' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 py-4 px-2 border-b-2 font-medium text-sm transition-colors cursor-pointer ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <i className={tab.icon}></i>
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>

          <div className="p-8">
            {/* Onglet Vue d'ensemble */}
            {activeTab === 'overview' && (
              <div className="space-y-8">
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">Critères d'évaluation</h3>
                  <div className="grid md:grid-cols-3 gap-6">
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-gray-600">Technique</span>
                        <span className="font-bold text-gray-800">{opportunity.criteria.technical}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-500 h-2 rounded-full"
                          style={{ width: `${opportunity.criteria.technical}%` }}
                        ></div>
                      </div>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-gray-600">Financier</span>
                        <span className="font-bold text-gray-800">{opportunity.criteria.financial}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-green-500 h-2 rounded-full"
                          style={{ width: `${opportunity.criteria.financial}%` }}
                        ></div>
                      </div>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-gray-600">Expérience</span>
                        <span className="font-bold text-gray-800">{opportunity.criteria.experience}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-purple-500 h-2 rounded-full"
                          style={{ width: `${opportunity.criteria.experience}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">Analyse SWOT</h3>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="bg-green-50 rounded-lg p-6">
                      <h4 className="font-bold text-green-800 mb-3 flex items-center">
                        <i className="ri-thumb-up-line mr-2"></i>
                        Forces
                      </h4>
                      <ul className="space-y-2 text-green-700">
                        <li>• Budget conséquent avec marge de négociation</li>
                        <li>• Secteur en forte croissance réglementaire</li>
                        <li>• Référence prestigieuse pour le portefeuille</li>
                        <li>• Critères techniques favorisant l'innovation</li>
                      </ul>
                    </div>
                    <div className="bg-red-50 rounded-lg p-6">
                      <h4 className="font-bold text-red-800 mb-3 flex items-center">
                        <i className="ri-thumb-down-line mr-2"></i>
                        Faiblesses
                      </h4>
                      <ul className="space-y-2 text-red-700">
                        <li>• Délai de réponse serré</li>
                        <li>• Concurrence de grands groupes établis</li>
                        <li>• Exigences de certification élevées</li>
                        <li>• Complexité technique importante</li>
                      </ul>
                    </div>
                    <div className="bg-blue-50 rounded-lg p-6">
                      <h4 className="font-bold text-blue-800 mb-3 flex items-center">
                        <i className="ri-lightbulb-line mr-2"></i>
                        Opportunités
                      </h4>
                      <ul className="space-y-2 text-blue-700">
                        <li>• Partenariats stratégiques possibles</li>
                        <li>• Extension vers d'autres régions</li>
                        <li>• Développement de solutions propriétaires</li>
                        <li>• Positionnement sur marché émergent</li>
                      </ul>
                    </div>
                    <div className="bg-orange-50 rounded-lg p-6">
                      <h4 className="font-bold text-orange-800 mb-3 flex items-center">
                        <i className="ri-alert-line mr-2"></i>
                        Menaces
                      </h4>
                      <ul className="space-y-2 text-orange-700">
                        <li>• Évolution rapide des technologies</li>
                        <li>• Changements réglementaires</li>
                        <li>• Pression sur les prix</li>
                        <li>• Risques de retards techniques</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Onglet Exigences */}
            {activeTab === 'requirements' && (
              <div>
                <h3 className="text-xl font-bold text-gray-800 mb-6">Exigences détaillées</h3>
                <div className="space-y-4">
                  {opportunity.requirements.map((req, index) => (
                    <div key={index} className="flex items-start space-x-3 p-4 bg-gray-50 rounded-lg">
                      <div className="w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center text-sm font-medium">
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <p className="text-gray-800">{req}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                          Obligatoire
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-8 bg-yellow-50 border border-yellow-200 rounded-lg p-6">
                  <h4 className="font-bold text-yellow-800 mb-3 flex items-center">
                    <i className="ri-warning-line mr-2"></i>
                    Points d'attention majeurs
                  </h4>
                  <ul className="space-y-2 text-yellow-700">
                    <li>• Vérifier la compatibilité avec les normes européennes EN 17127</li>
                    <li>• Prévoir les coûts de formation et certification du personnel</li>
                    <li>• Anticiper les délais d'obtention des agréments sécurité</li>
                    <li>• Valider la disponibilité des composants critiques</li>
                  </ul>
                </div>
              </div>
            )}

            {/* Onglet Concurrence */}
            {activeTab === 'competition' && (
              <div className="space-y-8">
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-4">Analyse concurrentielle</h3>
                  <div className="bg-gray-50 rounded-lg p-6 mb-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <div className="text-sm text-gray-500 mb-1">Nombre de concurrents estimé</div>
                        <div className="text-3xl font-bold text-blue-600">
                          {opportunity.competitors.estimated}
                        </div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-500 mb-1">Niveau de concurrence</div>
                        <div className="text-lg font-medium text-orange-600">
                          {opportunity.competitors.estimated > 10 ? 'Très élevé' : 
                           opportunity.competitors.estimated > 6 ? 'Élevé' : 'Modéré'}
                        </div>
                      </div>
                    </div>
                  </div>

                  <h4 className="font-bold text-gray-800 mb-4">Concurrents majeurs identifiés</h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    {opportunity.competitors.majorPlayers.map((competitor, index) => (
                      <div key={index} className="bg-white border rounded-lg p-4 shadow-sm">
                        <div className="flex items-center justify-between">
                          <span className="font-medium text-gray-800">{competitor}</span>
                          <span className={`px-2 py-1 text-xs rounded-full ${
                            index === 0 ? 'bg-red-100 text-red-800' : 
                            index === 1 ? 'bg-orange-100 text-orange-800' : 
                            'bg-yellow-100 text-yellow-800'
                          }`}>
                            {index === 0 ? 'Menace haute' : 
                             index === 1 ? 'Menace moyenne' : 'Concurrent'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                  <h4 className="font-bold text-blue-800 mb-3">Stratégie de différenciation recommandée</h4>
                  <ul className="space-y-2 text-blue-700">
                    <li>• Mettre en avant l'innovation technologique et R&D</li>
                    <li>• Proposer des garanties étendues et maintenance prédictive</li>
                    <li>• Valoriser l'expertise locale et proximité client</li>
                    <li>• Offrir des services de formation et accompagnement</li>
                  </ul>
                </div>
              </div>
            )}

            {/* Onglet Stratégie */}
            {activeTab === 'strategy' && (
              <div className="space-y-8">
                <div>
                  <h3 className="text-xl font-bold text-gray-800 mb-6">Plan d'action recommandé</h3>
                  
                  <div className="space-y-6">
                    <div className="bg-green-50 border-l-4 border-green-500 p-6">
                      <h4 className="font-bold text-green-800 mb-3">Phase 1 : Préparation (Semaine 1-2)</h4>
                      <ul className="space-y-2 text-green-700">
                        <li>• Constituer l'équipe projet dédiée</li>
                        <li>• Auditer les certifications et agréments</li>
                        <li>• Identifier les partenaires techniques stratégiques</li>
                        <li>• Analyser en détail le cahier des charges</li>
                      </ul>
                    </div>

                    <div className="bg-blue-50 border-l-4 border-blue-500 p-6">
                      <h4 className="font-bold text-blue-800 mb-3">Phase 2 : Développement (Semaine 3-4)</h4>
                      <ul className="space-y-2 text-blue-700">
                        <li>• Conception technique détaillée</li>
                        <li>• Chiffrage précis et optimisation budgétaire</li>
                        <li>• Négociation avec fournisseurs clés</li>
                        <li>• Préparation des éléments différenciants</li>
                      </ul>
                    </div>

                    <div className="bg-purple-50 border-l-4 border-purple-500 p-6">
                      <h4 className="font-bold text-purple-800 mb-3">Phase 3 : Finalisation (Semaine 5-6)</h4>
                      <ul className="space-y-2 text-purple-700">
                        <li>• Rédaction de la réponse technique</li>
                        <li>• Validation juridique et conformité</li>
                        <li>• Préparation de la soutenance</li>
                        <li>• Dépôt de l'offre et suivi</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
                  <h4 className="font-bold text-yellow-800 mb-3 flex items-center">
                    <i className="ri-money-euro-circle-line mr-2"></i>
                    Recommandations budgétaires
                  </h4>
                  <div className="grid md:grid-cols-3 gap-4 text-yellow-700">
                    <div>
                      <div className="font-medium">Préparation offre</div>
                      <div className="text-sm">15-25k€</div>
                    </div>
                    <div>
                      <div className="font-medium">Partenariats</div>
                      <div className="text-sm">Budget négocié</div>
                    </div>
                    <div>
                      <div className="font-medium">Certifications</div>
                      <div className="text-sm">10-15k€</div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Onglet Calendrier */}
            {activeTab === 'timeline' && (
              <div>
                <h3 className="text-xl font-bold text-gray-800 mb-6">Planning détaillé</h3>
                <div className="space-y-4">
                  {[
                    { date: '15 Juillet', task: 'Publication de l\'appel d\'offres', status: 'completed' },
                    { date: '22 Juillet', task: 'Date limite pour questions écrites', status: 'upcoming' },
                    { date: '29 Juillet', task: 'Réponses aux questions publiées', status: 'upcoming' },
                    { date: '10 Août', task: 'Visite technique obligatoire', status: 'upcoming' },
                    { date: '15 Août', task: 'Date limite de remise des offres', status: 'deadline' },
                    { date: '30 Août', task: 'Ouverture des plis', status: 'future' },
                    { date: '15 Sept', task: 'Notification du marché', status: 'future' }
                  ].map((item, index) => (
                    <div key={index} className={`flex items-center space-x-4 p-4 rounded-lg ${
                      item.status === 'completed' ? 'bg-green-50' :
                      item.status === 'deadline' ? 'bg-red-50' :
                      item.status === 'upcoming' ? 'bg-blue-50' : 'bg-gray-50'
                    }`}>
                      <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                        item.status === 'completed' ? 'bg-green-500 text-white' :
                        item.status === 'deadline' ? 'bg-red-500 text-white' :
                        item.status === 'upcoming' ? 'bg-blue-500 text-white' : 'bg-gray-400 text-white'
                      }`}>
                        {item.status === 'completed' ? (
                          <i className="ri-check-line"></i>
                        ) : item.status === 'deadline' ? (
                          <i className="ri-alarm-warning-line"></i>
                        ) : (
                          <i className="ri-calendar-line"></i>
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="font-medium text-gray-800">{item.task}</div>
                        <div className="text-sm text-gray-600">{item.date}</div>
                      </div>
                      <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                        item.status === 'completed' ? 'bg-green-100 text-green-800' :
                        item.status === 'deadline' ? 'bg-red-100 text-red-800' :
                        item.status === 'upcoming' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {item.status === 'completed' ? 'Terminé' :
                         item.status === 'deadline' ? 'URGENT' :
                         item.status === 'upcoming' ? 'À venir' : 'Futur'}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-8 bg-red-50 border border-red-200 rounded-lg p-6">
                  <h4 className="font-bold text-red-800 mb-3 flex items-center">
                    <i className="ri-time-line mr-2"></i>
                    Échéances critiques
                  </h4>
                  <div className="text-red-700">
                    <p className="mb-2">
                      <strong>Plus que {daysRemaining} jours</strong> pour finaliser et déposer votre offre.
                    </p>
                    <p className="text-sm">
                      Recommandation : Déposer l'offre 48h avant la date limite pour éviter tout risque technique.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Actions */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div>
              <h3 className="font-bold text-gray-800 mb-2">Prêt à soumissionner ?</h3>
              <p className="text-gray-600">Toutes les informations pour préparer votre offre</p>
            </div>
            <div className="flex space-x-4">
              <button className="px-6 py-3 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors cursor-pointer whitespace-nowrap">
                <i className="ri-download-line mr-2"></i>
                Télécharger l'analyse
              </button>
              <button className="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors cursor-pointer whitespace-nowrap">
                <i className="ri-external-link-line mr-2"></i>
                Accéder à l'appel d'offres
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
