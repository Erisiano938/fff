
import OpportunityAnalysis from './OpportunityAnalysis';

export async function generateStaticParams() {
  return [
    { id: 'boamp-001' },
    { id: 'boamp-002' },
    { id: 'boamp-003' },
    { id: 'boamp-004' },
    { id: 'boamp-005' },
    { id: '5e7c3891aa7fb1a8a5ed57cc1aeaa96f5f7844cd' },
    { id: 'demo-1' },
    { id: 'demo-2' },
    { id: 'demo-3' },
    { id: 'demo-4' },
    { id: 'demo-5' },
    { id: 'demo-6' },
    { id: 'default' },
    { id: 'sample' },
    { id: 'test-opportunity' },
    { id: 'ao-2025-001' },
    { id: 'ao-2025-002' },
    { id: 'ao-2025-003' },
    { id: 'marche-public-001' },
    { id: 'marche-public-002' },
    { id: 'test_001' },
    { id: 'test_002' },
    { id: 'test_003' },
    { id: 'fallback_001' },
    { id: 'test002' },
    { id: 'opportunity-001' },
    { id: 'opportunity-002' }
  ];
}

export default function AnalysisPage({ params }: { params: { id: string } }) {
  return <OpportunityAnalysis opportunityId={params.id} />;
}
