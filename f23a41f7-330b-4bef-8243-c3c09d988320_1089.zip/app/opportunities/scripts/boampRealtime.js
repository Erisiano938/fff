
// fetchBOAMP_withStack.js
const axios = require('axios');

const API_URL = 'https://boamp-datadila.opendatasoft.com/api/explore/v2.1/catalog/datasets/boamp/records';

async function getOpenAnnouncements(limit = 10) {
  const today = new Date().toISOString().split('T')[0];
  const params = {
    limit,
    offset: 0,
    order_by: '-fields.date_publication',
    select: 'fields.numero_avis,fields.titre,fields.date_publication,fields.date_limite_reponse',
    where: `fields.date_limite_reponse >= '${today}'`
  };

  const res = await axios.get(API_URL, { params, timeout: 5000 });
  return res.data.records.map(rec => {
    const { numero_avis, titre, date_publication, date_limite_reponse } = rec.fields;
    const url = `https://www.boamp.fr/index.php/avis/detail/${encodeURIComponent(numero_avis)}`;
    return { numero_avis, titre, date_publication, date_limite_reponse, url };
  });
}

(async () => {
  try {
    const annonces = await getOpenAnnouncements(5);
    annonces.forEach(a => {
      console.log(
        `[${a.date_publication}] ${a.numero_avis} – ${a.titre}\n` +
        `   Limite : ${a.date_limite_reponse}\n` +
        `   Détail 👉 ${a.url}\n`
      );
    });
  } catch (err) {
    console.error('Erreur API BOAMP :', err.message);
    console.error(err.stack);  // << Affiche le call stack complet
  }
})();
