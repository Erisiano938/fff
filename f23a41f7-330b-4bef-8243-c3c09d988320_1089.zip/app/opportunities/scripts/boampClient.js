
// boampRealtimeV2.js
// Client JavaScript utilisant l'Explore API v2.1 pour récupérer les avis BOAMP ouverts

import fetch from 'node-fetch'; // ou global fetch en navigateur

const API_URL =
  'https://boamp-datadila.opendatasoft.com/api/explore/v2.1' +
  '/catalog/datasets/boamp%40boamp-datadila/records';
const SITE_URL = 'https://www.boamp.fr/index.php/avis/detail';

/**
 * Récupère les derniers avis BOAMP ouverts (date_limite ≥ aujourd'hui)
 * @param {number} limit Nombre max d'avis
 * @param {string} term Terme optionnel de recherche (plein-texte)
 * @returns {Promise<Array<{id,title,pubDate,limitDate,url}>>}
 */
export async function fetchOpenBOAMP({ limit = 10, term = '' } = {}) {
  const today = new Date().toISOString().slice(0, 10);
  const qp = new URLSearchParams({
    limit: limit.toString(),
    offset: '0',
    order_by: '-fields.date_publication',
    select: [
      'fields.numero_avis',
      'fields.titre',
      'fields.date_publication',
      'fields.date_limite_reponse'
    ].join(',')
  });
  if (term) qp.set('where', `fields.titre ILIKE '%${term}%' AND fields.date_limite_reponse>='${today}'`);
  else qp.set('where', `fields.date_limite_reponse>='${today}'`);

  const res = await fetch(`${API_URL}?${qp}`, { timeout: 5000 });
  if (!res.ok) throw new Error(`BOAMP API HTTP ${res.status}`);
  const { records } = await res.json();

  return (records || []).map(r => {
    const f = r.fields;
    return {
      id: f.numero_avis,
      title: f.titre,
      pubDate: f.date_publication,
      limitDate: f.date_limite_reponse,
      url: `${SITE_URL}/${encodeURIComponent(f.numero_avis)}`
    };
  });
}

// Exemple minimal pour IA "ready"
(async () => {
  const avis = await fetchOpenBOAMP({ limit: 5 });
  console.log(JSON.stringify(avis, null, 2));
})();
