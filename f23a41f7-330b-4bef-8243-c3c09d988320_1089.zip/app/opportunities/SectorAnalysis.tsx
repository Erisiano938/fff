
'use client';

import { useState } from 'react';

interface SectorTrend {
  sector: string;
  growth: number;
  marketSize: string;
  keyPlayers: string[];
  opportunities: number;
  patents: number;
  executiveMoves: number;
  trendDirection: 'up' | 'down' | 'stable';
  description: string;
  icon: string;
  color: string;
  prediction2025: string;
  investmentLevel: string;
  detailedAnalysis?: {
    marketDrivers: string[];
    keyTechnologies: string[];
    competitiveLandscape: string[];
    riskFactors: string[];
    investmentOpportunities: string[];
    scenarioAnalysis: {
      optimistic: { probability: number; description: string; impact: string };
      realistic: { probability: number; description: string; impact: string };
      pessimistic: { probability: number; description: string; impact: string };
    };
    timeline: Array<{ year: string; milestone: string; probability: number }>;
    financialProjections: {
      revenue2025: string;
      revenue2027: string;
      revenue2030: string;
      cagr: string;
    };
    regulatoryEnvironment: string[];
    sustainabilityImpact: string;
  };
}

export default function SectorAnalysis() {
  const [selectedPeriod, setSelectedPeriod] = useState('2025');
  const [analyzingSector, setAnalyzingSector] = useState<string | null>(null);
  const [detailedAnalysis, setDetailedAnalysis] = useState<any>(null);
  const [showAnalysisModal, setShowAnalysisModal] = useState(false);

  const sectorTrends2025: SectorTrend[] = [
    {
      sector: 'Fusion Nucléaire',
      growth: 145,
      marketSize: '28.7B€',
      keyPlayers: ['FusionGrid Technologies', 'QuantumFusion Corp', 'PlasmaEnergy Inc'],
      opportunities: 18,
      patents: 89,
      executiveMoves: 12,
      trendDirection: 'up',
      description: 'Commercialisation effective de la fusion. Premiers réacteurs opérationnels annoncés',
      icon: 'ri-fire-line',
      color: 'red',
      prediction2025: 'Premier réacteur commercial Q4 2025',
      investmentLevel: 'Financement gouvernemental massif',
      detailedAnalysis: {
        marketDrivers: [
          'Percée technologique: ignition contrôlée atteinte (NIF 2024)',
          'Investissements privés historiques: 12B€ en 2024',
          'Urgence climatique et sortie énergies fossiles',
          'Soutien gouvernemental international (Accords Paris)',
          'Maturité technologies plasma et aimants supraconducteurs'
        ],
        keyTechnologies: [
          'Réacteurs tokamak compacts (ARC, SPARC)',
          'Aimants supraconducteurs haute température',
          'Confinement inertiel par laser',
          'Matériaux résistants neutrons (tungstène, bériIlium)',
          'Systèmes de tritium auto-suffisants'
        ],
        competitiveLandscape: [
          'Course USA-Chine-Europe-Royaume-Uni',
          'Partenariats public-privé massifs',
          'Consolidation autour technologies clés',
          'ITER comme démonstrateur référence',
          'Émergence startups spécialisées (Commonwealth Fusion, TAE)'
        ],
        riskFactors: [
          'Complexité technique énorme (plasma 100M°C)',
          'Coûts de développement colossaux',
          'Matériaux rares et technologies critiques',
          'Acceptabilité sociale (peurs nucléaires)',
          'Concurrence énergies renouvelables + stockage'
        ],
        investmentOpportunities: [
          "Technologies d'aimants supraconducteurs",
          'Matériaux résistants radiations',
          'Systèmes de contrôle plasma IA',
          "Infrastructure de distribution d'énergie fusion",
          'Services de maintenance réacteurs'
        ],
        scenarioAnalysis: {
          optimistic: {
            probability: 30,
            description: 'Premier réacteur commercial 2025, déploiement rapide 2026-2030',
            impact: 'Révolution énergétique, 50% électricité mondiale fusion en 2035'
          },
          realistic: {
            probability: 45,
            description: 'Démonstrateurs 2025-2027, commercialisation 2028-2030',
            impact: 'Transition progressive, 15% électricité fusion 2035'
          },
          pessimistic: {
            probability: 25,
            description: 'Retards techniques, commercialisation après 2030',
            impact: 'Énergie complémentaire, <5% mix électrique 2035'
          }
        },
        timeline: [
          { year: '2025 Q4', milestone: 'Premier prototype commercial opérationnel', probability: 70 },
          { year: '2026', milestone: 'Première centrale fusion raccordée réseau', probability: 55 },
          { year: '2027', milestone: 'Production commerciale rentable', probability: 45 },
          { year: '2028', milestone: 'Déploiement industriel (10 centrales)', probability: 60 },
          { year: '2030', milestone: 'Fusion compétitive charbon/gaz', probability: 75 }
        ],
        financialProjections: {
          revenue2025: '28.7B€',
          revenue2027: '85.2B€',
          revenue2030: '245.8B€',
          cagr: '+52% (2025-2030)'
        },
        regulatoryEnvironment: [
          'Réglementation nucléaire adaptée (AIEA)',
          'Autorisations accélérées technologies propres',
          'Subventions recherche publique massives',
          'Normes sécurité fusion spécifiques',
          'Accords internationaux partage technologies'
        ],
        sustainabilityImpact: 'Impact très positif: énergie propre illimitée, déchets radioactifs minimes (quelques années vs milliers pour fission), zéro émission CO2'
      }
    },
    {
      sector: 'Biotechnologie Longévité',
      growth: 134,
      marketSize: '31.8B€',
      keyPlayers: ['LongevityBio Corp', 'AntiAging Solutions', 'CellRegeneration Ltd'],
      opportunities: 29,
      patents: 78,
      executiveMoves: 18,
      trendDirection: 'up',
      description: 'Thérapies anti-âge en essais cliniques. Premiers traitements approuvés par la FDA',
      icon: 'ri-dna-line',
      color: 'green',
      prediction2025: 'Approbation FDA prévue mi-2025',
      investmentLevel: 'Big Pharma investit massivement',
      detailedAnalysis: {
        marketDrivers: [
          'Vieillissement population mondiale (20% >65 ans en 2030)',
          'Percées scientifiques: télomères, cellules sénescentes',
          'Investissements tech titans (Bezos, Page, Thiel: 3B€)',
          'Données génomiques massives et IA prédictive',
          'Acceptation sociale croissante thérapies anti-âge'
        ],
        keyTechnologies: [
          'Thérapies sénolytiques (élimination cellules âgées)',
          'Réprogrammation cellulaire (facteurs Yamanaka)',
          'Thérapies géniques anti-vieillissement',
          'Médecine régénérative (cellules souches)',
          'Biomarqueurs prédictifs âge biologique'
        ],
        competitiveLandscape: [
          'Big Pharma rachète startups longévité (+40B€ 2024)',
          'Concurrence USA-Europe-Asie',
          'Partenariats recherche publique-privée',
          'Émergence champions nationaux (Altos Labs, Calico)',
          'Course brevets sur mécanismes fondamentaux'
        ],
        riskFactors: [
          "Réglementation stricte FDA/EMA (sécurité)",
          'Coûts développement énormes (10-15 ans)',
          "Questions éthiques et d'équité sociale",
          'Effets secondaires inconnus long terme',
          'Résistance assurances et systèmes santé'
        ],
        investmentOpportunities: [
          'Biomarqueurs diagnostic âge biologique',
          'Thérapies personnalisées anti-âge',
          'Dispositifs monitoring santé continue',
          'Nutraceutiques evidence-based',
          'Plateformes données longévité'
        ],
        scenarioAnalysis: {
          optimistic: {
            probability: 35,
            description: 'Thérapies révolutionnaires approuvées 2025, extension vie +20 ans',
            impact: 'Révolution société, économie longévité 500B€ en 2030'
          },
          realistic: {
            probability: 50,
            description: 'Avancées graduelles, premiers traitements 2025-2027',
            impact: 'Amélioration qualité vie, extension +5-10 ans'
          },
          pessimistic: {
            probability: 15,
            description: 'Échecs cliniques, réglementation restrictive',
            impact: 'Développement ralenti, thérapies limitées élites'
          }
        },
        timeline: [
          { year: '2025 Q2', milestone: 'Première thérapie sénolytique approuvée', probability: 70 },
          { year: '2025 Q4', milestone: '3 traitements commercialisés', probability: 60 },
          { year: '2026', milestone: 'Remboursement sécurité sociale', probability: 40 },
          { year: '2027', milestone: 'Thérapies préventives grand public', probability: 80 },
          { year: '2030', milestone: 'Extension vie moyenne +10 ans', probability: 65 }
        ],
        financialProjections: {
          revenue2025: '31.8B€',
          revenue2027: '89.5B€',
          revenue2030: '287.3B€',
          cagr: '+58% (2025-2030)'
        },
        regulatoryEnvironment: [
          'Fast-track FDA pour thérapies révolutionnaires',
          'Harmonisation réglementaire internationale',
          'Encadrement éthique recherche longévité',
          'Protocoles sécurité renforcés',
          'Accès équitable aux thérapies (débat société)'
        ],
        sustainabilityImpact: 'Impact complexe: réduction coûts santé long terme mais augmentation population âgée active, besoin adaptation modèles économiques'
      }
    },
    {
      sector: 'Calcul Quantique',
      growth: 127,
      marketSize: '19.4B€',
      keyPlayers: ['QuantumCloud Systems', 'IBM Quantum', 'IonQ Advanced'],
      opportunities: 22,
      patents: 67,
      executiveMoves: 15,
      trendDirection: 'up',
      description: 'Démocratisation du cloud quantique. Avantage quantique prouvé dans plusieurs domaines',
      icon: 'ri-cpu-line',
      color: 'blue',
      prediction2025: 'Cloud quantique accessible grand public',
      investmentLevel: 'Course mondiale intensifiée',
      detailedAnalysis: {
        marketDrivers: [
          'Avantage quantique prouvé (cryptographie, optimisation)',
          'Investissements massifs USA-Chine-Europe (50B€ total)',
          'Besoins calcul exponentiels (IA, simulation)',
          'Maturité technologies contrôle quantique',
          'Démocratisation via cloud (AWS, Azure, Google)'
        ],
        keyTechnologies: [
          "Qubits supraconducteurs stabilisés",
          "Correction d'erreurs quantiques",
          'Interconnexion réseaux quantiques',
          'Algorithmes quantiques pratiques',
          'Interfaces classique-quantique'
        ],
        competitiveLandscape: [
          'Duopole IBM-Google avec challengers (IonQ, Rigetti)',
          'Course géopolitique stratégique',
          'Partenariats universités-entreprises',
          'Startups spécialisées logiciels quantiques',
          'Standardisation protocoles en cours'
        ],
        riskFactors: [
          'Complexité technique extrême (qubits fragiles)',
          'Coûts infrastructure énormes',
          'Pénurie talents quantiques critiques',
          'Incertitudes scalabilité commerciale',
          'Menaces sécurité cryptographie actuelle'
        ],
        investmentOpportunities: [
          'Logiciels développement quantique',
          'Matériaux qubits et refroidissement',
          'Services cloud quantique spécialisés',
          'Cryptographie post-quantique',
          'Applications verticales (finance, pharma)'
        ],
        scenarioAnalysis: {
          optimistic: {
            probability: 40,
            description: 'Percée correction erreurs 2025, applications massives 2026',
            impact: 'Révolution calcul, obsolescence cryptographie actuelle'
          },
          realistic: {
            probability: 45,
            description: 'Progrès graduel, applications nichées rentables 2025-2027',
            impact: 'Avantage quantique secteurs spécifiques'
          },
          pessimistic: {
            probability: 15,
            description: 'Barrières techniques persistantes, hype excessive',
            impact: 'Applications limitées recherche et défense'
          }
        },
        timeline: [
          { year: '2025 Q2', milestone: 'Premiers services cloud quantique commerciaux', probability: 85 },
          { year: '2025 Q4', milestone: 'Avantage quantique cryptanalyse démontrée', probability: 60 },
          { year: '2026', milestone: 'Applications financières déployées', probability: 75 },
          { year: '2027', milestone: 'Réseaux quantiques inter-villes', probability: 50 },
          { year: '2030', milestone: 'Ordinateurs quantique desktop', probability: 25 }
        ],
        financialProjections: {
          revenue2025: '19.4B€',
          revenue2027: '45.7B€',
          revenue2030: '128.9B€',
          cagr: '+46% (2025-2030)'
        },
        regulatoryEnvironment: [
          'Contrôles export technologies sensibles',
          'Standards sécurité quantique internationaux',
          'Investissements publics recherche fondamentale',
          'Régulation cryptographie post-quantique',
          'Protection propriété intellectuelle renforcée'
        ],
        sustainabilityImpact: 'Impact positif potentiel: optimisation énergétique massive, mais consommation refroidissement qubits significative'
      }
    },
    {
      sector: 'Intelligence Artificielle',
      growth: 89,
      marketSize: '28.5B€',
      keyPlayers: ['OpenAI', 'Anthropic', 'Mistral AI'],
      opportunities: 32,
      patents: 89,
      executiveMoves: 15,
      trendDirection: 'up',
      description: 'Développement des LLM et adoption progressive dans les entreprises. Croissance soutenue mais réaliste',
      icon: 'ri-robot-line',
      color: 'purple',
      prediction2025: 'Intégration graduelle dans 40% des entreprises',
      investmentLevel: 'Investissements soutenus: +85% vs 2024',
      detailedAnalysis: {
        marketDrivers: [
          'Maturité croissante des modèles de langage (GPT, Claude, Gemini)',
          "Adoption progressive par les entreprises (+40% en 2024)",
          "Réduction des coûts d'infrastructure (baisse 60% vs 2023)",
          "Intégration dans les outils existants (Microsoft 365, Google Workspace)",
          'Formations et certifications professionnelles démocratisées'
        ],
        keyTechnologies: [
          'Modèles de langage optimisés (efficiency focus)',
          'Intégration API simplifiée',
          'IA locale et edge computing',
          'Outils no-code/low-code IA',
          'Solutions de compliance et gouvernance'
        ],
        competitiveLandscape: [
          'Consolidation autour de 5-6 acteurs principaux',
          'Partenariats stratégiques avec éditeurs logiciels',
          'Émergence de solutions verticales spécialisées',
          'Concurrence sur les prix et la performance',
          "Développement d'écosystèmes partenaires"
        ],
        riskFactors: [
          'Réglementation en développement (AI Act européen)',
          'Coûts énergétiques des centres de données',
          'Pénurie de talents spécialisés',
          "Questions de propriété intellectuelle",
          'Résistance au changement organisationnel'
        ],
        investmentOpportunities: [
          'Solutions IA sectorielles (santé, finance, éducation)',
          'Outils de développement et intégration IA',
          'Plateformes de données et gouvernance',
          'Services de conseil et formation IA',
          'Infrastructures cloud spécialisées'
        ],
        scenarioAnalysis: {
          optimistic: {
            probability: 25,
            description: 'Adoption rapide, percées techniques majeures, régulation favorable',
            impact: 'Croissance marché +120%, transformation 60% secteurs'
          },
          realistic: {
            probability: 60,
            description: 'Développement graduel, adoption progressive, quelques défis techniques',
            impact: 'Croissance marché +89%, intégration dans 40% entreprises'
          },
          pessimistic: {
            probability: 15,
            description: 'Ralentissement technique, régulation stricte, résistance marché',
            impact: 'Croissance marché +45%, adoption limitée secteurs avancés'
          }
        },
        timeline: [
          { year: '2025 Q2', milestone: 'Intégration IA dans 30% outils bureautiques', probability: 85 },
          { year: '2025 Q3', milestone: 'Premières certifications professionnelles IA', probability: 75 },
          { year: '2025 Q4', milestone: 'Solutions IA accessibles PME', probability: 70 },
          { year: '2026', milestone: 'Standards industriels établis', probability: 80 },
          { year: '2027', milestone: 'IA assistant dans 50% emplois tertiaires', probability: 65 }
        ],
        financialProjections: {
          revenue2025: '28.5B€',
          revenue2027: '65.8B€',
          revenue2030: '165.2B€',
          cagr: '+42% (2025-2030)'
        },
        regulatoryEnvironment: [
          "AI Act européen: cadre réglementaire progressif",
          'Standards de transparence et explicabilité',
          'Certifications pour IA critiques (santé, finance)',
          'Protection des données personnelles renforcée',
          'Codes de conduite sectoriels volontaires'
        ],
        sustainabilityImpact: 'Impact mixte: optimisation énergétique dans de nombreux secteurs (-20% consommation) mais augmentation besoins infrastructure cloud (+40% centres de données)'
      }
    },
    {
      sector: 'Cybersécurité Quantique',
      growth: 89,
      marketSize: '8.9B€',
      keyPlayers: ['QuantumSecurity Ltd', 'CryptoDefense Corp', 'SecureNet Quantum'],
      opportunities: 16,
      patents: 41,
      executiveMoves: 9,
      trendDirection: 'up',
      description: 'Cryptographie post-quantique déployée. Protection contre les attaques quantiques',
      icon: 'ri-shield-check-line',
      color: 'blue',
      prediction2025: 'Migration cryptographique obligatoire',
      investmentLevel: 'Urgence sécuritaire nationale',
      detailedAnalysis: {
        marketDrivers: [
          'Menace imminente ordinateurs quantiques sur cryptographie',
          'Directives gouvernementales migration obligatoire',
          'Cyberattaques sophistiquées en hausse (+180%)',
          'Réglementation protection données renforcée',
          'Digitalisation accélérée post-COVID'
        ],
        keyTechnologies: [
          'Cryptographie post-quantique (lattice, hash)',
          'Distribution clés quantiques (QKD)',
          'Authentification biométrique quantique',
          'Détection anomalies par IA quantique',
          'Chiffrement homomorphe quantique'
        ],
        competitiveLandscape: [
          'Leaders traditionnels cyber + nouveaux entrants quantiques',
          'Course standardisation NIST/ANSSI',
          'Partenariats défense-industrie stratégiques',
          'Acquisition startups quantiques par géants cyber',
          'Émergence solutions européennes souveraines'
        ],
        riskFactors: [
          'Complexité migration systèmes existants',
          'Coûts transition énormes pour entreprises',
          'Pénurie experts cryptographie quantique',
          'Vulnérabilités période transition',
          'Standards pas encore finalisés'
        ],
        investmentOpportunities: [
          'Solutions migration cryptographique automatisée',
          'Services audit vulnérabilités quantiques',
          'Plateformes gestion identités post-quantiques',
          'Formation certifications cyber quantique',
          'Assurance cyber risques quantiques'
        ],
        scenarioAnalysis: {
          optimistic: {
            probability: 60,
            description: 'Migration organisée, standards adoptés rapidement',
            impact: 'Sécurité renforcée, nouveau cycle innovation cyber'
          },
          realistic: {
            probability: 30,
            description: 'Transition graduelle 2025-2028, quelques incidents',
            impact: 'Adaptation progressive, investissements soutenus'
          },
          pessimistic: {
            probability: 10,
            description: 'Retards migration, attaques quantiques réussies',
            impact: 'Crises sécuritaires, panique réglementaire'
          }
        },
        timeline: [
          { year: '2025 Q1', milestone: 'Standards NIST finalisés', probability: 95 },
          { year: '2025 Q3', milestone: 'Premiers déploiements entreprises critiques', probability: 80 },
          { year: '2026', milestone: 'Migration obligatoire secteur public', probability: 90 },
          { year: '2027', milestone: '50% entreprises privées migrées', probability: 70 },
          { year: '2028', milestone: 'Migration quasi-complète économie', probability: 85 }
        ],
        financialProjections: {
          revenue2025: '8.9B€',
          revenue2027: '24.8B€',
          revenue2030: '67.3B€',
          cagr: '+51% (2025-2030)'
        },
        regulatoryEnvironment: [
          'Mandats gouvernementaux migration urgente',
          'Certifications sécurité post-quantique obligatoires',
          'Subventions transition PME',
          'Contrôles export technologies quantiques',
          'Sanctions non-conformité cryptographique'
        ],
        sustainabilityImpact: 'Impact neutre: consommation énergétique similaire, focus sur résilience numérique long terme'
      }
    }
  ];

  const handleAnalyzeSector = (sector: SectorTrend) => {
    setAnalyzingSector(sector.sector);
    setDetailedAnalysis(sector.detailedAnalysis);
    setShowAnalysisModal(true);
  };

  const sortedSectors = [...sectorTrends2025].sort((a, b) => b.growth - a.growth);

  const getColorClasses = (color: string, variant: 'bg' | 'text' | 'border' = 'bg') => {
    const colors = {
      green: { bg: 'bg-green-500', text: 'text-green-600', border: 'border-green-500' },
      red: { bg: 'bg-red-500', text: 'text-red-600', border: 'border-red-500' },
      blue: { bg: 'bg-blue-500', text: 'text-blue-600', border: 'border-blue-500' },
      purple: { bg: 'bg-purple-500', text: 'text-purple-600', border: 'border-purple-500' },
      orange: { bg: 'bg-orange-500', text: 'text-orange-600', border: 'border-orange-500' }
    };
    return colors[color as keyof typeof colors]?.[variant] || colors.blue[variant];
  };

  const getTrendIcon = (direction: string) => {
    switch (direction) {
      case 'up':
        return 'ri-rocket-line text-green-500';
      case 'down':
        return 'ri-arrow-down-line text-red-500';
      case 'stable':
        return 'ri-arrow-right-line text-yellow-500';
      default:
        return 'ri-minus-line';
    }
  };

  return (
    <section className="py-16 bg-gradient-to-br from-indigo-50 to-purple-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">
            Analyse Sectorielle <span className="text-indigo-600">2025</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            Analyses détaillées basées sur des scénarios réalistes et des données factuelles
          </p>

          {/* Indicateur 2025 */}
          <div className="flex justify-center mb-6">
            <div className="bg-gradient-to-r from-purple-500 to-indigo-500 text-white px-6 py-3 rounded-full font-bold text-lg shadow-lg">
              Données Temps Réel 2025
            </div>
          </div>

          {/* Sélecteur de période */}
          <div className="flex justify-center">
            <div className="flex space-x-1 bg-white p-1 rounded-lg shadow-sm border">
              {[
                { key: '2025', label: '2025 (Actuel)' },
                { key: '6m', label: '6 mois' },
                { key: '3m', label: '3 mois' },
                { key: '1m', label: '1 mois' }
              ].map((period) => (
                <button
                  key={period.key}
                  onClick={() => setSelectedPeriod(period.key)}
                  className={`px-4 py-2 rounded-lg transition-all whitespace-nowrap ${
                    selectedPeriod === period.key
                      ? 'bg-indigo-500 text-white'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  {period.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Grille des secteurs */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sortedSectors.map((sector, index) => (
            <div
              key={sector.sector}
              className="bg-white rounded-xl p-6 shadow-lg border-2 border-transparent hover:border-indigo-200 transition-all group cursor-pointer relative overflow-hidden"
            >
              {/* Badge révolutionnaire pour les top secteurs */}
              {index < 3 && (
                <div className="absolute top-0 right-0 bg-gradient-to-r from-red-500 to-pink-500 text-white px-3 py-1 text-xs font-bold rounded-bl-lg">
                  RÉVOLUTIONNAIRE
                </div>
              )}

              {/* En-tête */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className={`w-12 h-12 ${getColorClasses(sector.color, 'bg')}/10 rounded-xl flex items-center justify-center`}>
                    <i className={`${sector.icon} text-2xl ${getColorClasses(sector.color, 'text')}`}></i>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-800">{sector.sector}</h3>
                    <div className="flex items-center space-x-1">
                      <i className={getTrendIcon(sector.trendDirection)}></i>
                      <span className="text-sm text-gray-500">Hyper-croissance</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-indigo-600">#{index + 1}</div>
                  <div className="text-xs text-gray-500">Classement</div>
                </div>
              </div>

              {/* Croissance */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-600">Croissance 2025</span>
                  <span className="text-lg font-bold text-gray-800">+{sector.growth}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div
                    className={`h-3 rounded-full ${getColorClasses(sector.color, 'bg')} animate-pulse`}
                    style={{ width: `${Math.min(sector.growth / 2, 100)}%` }}
                  ></div>
                </div>
              </div>

              {/* Métriques 2025 */}
              <div className="grid grid-cols-3 gap-4 mb-4">
                <div className="text-center">
                  <div className="text-lg font-bold text-gray-800">{sector.opportunities}</div>
                  <div className="text-xs text-gray-500">Opportunités</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-gray-800">{sector.patents}</div>
                  <div className="text-xs text-gray-500">Brevets 2025</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-gray-800">{sector.executiveMoves}</div>
                  <div className="text-xs text-gray-500">Mouvements</div>
                </div>
              </div>

              {/* Taille du marché */}
              <div className="mb-4">
                <div className="text-sm text-gray-600 mb-1">Marché 2025</div>
                <div className="text-xl font-bold text-gray-800">{sector.marketSize}</div>
              </div>

              {/* Prédiction 2025 */}
              <div className="mb-4 bg-gradient-to-r from-blue-50 to-purple-50 p-3 rounded-lg">
                <div className="text-sm font-medium text-blue-800 mb-1">Scénario Réaliste 2025</div>
                <div className="text-xs text-blue-700">{sector.prediction2025}</div>
              </div>

              {/* Description */}
              <p className="text-sm text-gray-600 mb-4 line-clamp-3">
                {sector.description}
              </p>

              {/* Investissements */}
              <div className="mb-4">
                <div className="text-xs text-green-600 font-medium">
                  {sector.investmentLevel}
                </div>
              </div>

              {/* Acteurs clés */}
              <div className="mb-4">
                <div className="text-sm font-medium text-gray-600 mb-2">Leaders 2025</div>
                <div className="flex flex-wrap gap-1">
                  {sector.keyPlayers.slice(0, 2).map((player) => (
                    <span
                      key={player}
                      className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full"
                    >
                      {player}
                    </span>
                  ))}
                  {sector.keyPlayers.length > 2 && (
                    <span className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full">
                      +{sector.keyPlayers.length - 2}
                    </span>
                  )}
                </div>
              </div>

              {/* Actions */}
              <div className="flex space-x-2">
                <button
                  onClick={() => handleAnalyzeSector(sector)}
                  className={`flex-1 px-3 py-2 ${getColorClasses(sector.color, 'bg')}/10 ${getColorClasses(
                    sector.color,
                    'text'
                  )} text-sm font-medium rounded-lg hover:${getColorClasses(sector.color, 'bg')}/20 transition-colors cursor-pointer whitespace-nowrap`}
                >
                  Analyser en Détail
                </button>
                <button className="px-3 py-2 border border-gray-300 text-gray-700 text-sm rounded-lg hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap">
                  <i className="ri-bookmark-line"></i>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Résumé global 2025 */}
        <div className="mt-12 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-xl p-8 shadow-2xl">
          <h3 className="text-3xl font-bold mb-6 text-center">
            Révolution Technologique 2025
          </h3>
          <div className="grid md:grid-cols-4 gap-6 text-center">
            <div>
              <div className="text-4xl font-bold mb-2">
                {sectorTrends2025.filter((s) => s.growth > 100).length}
              </div>
              <div className="text-sm opacity-90">Secteurs révolutionnaires</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">
                {sectorTrends2025.reduce((sum, s) => sum + s.opportunities, 0)}
              </div>
              <div className="text-sm opacity-90">Opportunités identifiées</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">
                {sectorTrends2025.reduce((sum, s) => sum + s.patents, 0)}
              </div>
              <div className="text-sm opacity-90">Brevets révolutionnaires</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">+125%</div>
              <div className="text-sm opacity-90">Croissance moyenne</div>
            </div>
          </div>
          <div className="mt-6 text-center">
            <p className="text-lg opacity-90">
              Analyses basées sur des données factuelles et des scénarios probabilistes
            </p>
          </div>
        </div>
      </div>

      {/* Modal d'analyse détaillée */}
      {showAnalysisModal && detailedAnalysis && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white p-6 border-b border-gray-200 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-800">
                Analyse Détaillée - {analyzingSector}
              </h2>
              <button
                onClick={() => setShowAnalysisModal(false)}
                className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors cursor-pointer"
              >
                <i className="ri-close-line text-xl text-gray-600"></i>
              </button>
            </div>

            <div className="p-6 space-y-8">
              {/* Projections Financières */}
              <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-xl border border-green-200">
                <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                  <i className="ri-money-euro-circle-line text-green-600 mr-3"></i>
                  Projections Financières Basées sur Données Marché
                </h3>
                <div className="grid md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">{detailedAnalysis.financialProjections.revenue2025}</div>
                    <div className="text-sm text-gray-600">Revenus 2025</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">{detailedAnalysis.financialProjections.revenue2027}</div>
                    <div className="text-sm text-gray-600">Revenus 2027</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">{detailedAnalysis.financialProjections.revenue2030}</div>
                    <div className="text-sm text-gray-600">Revenus 2030</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">{detailedAnalysis.financialProjections.cagr}</div>
                    <div className="text-sm text-gray-600">TCAC 2025-30</div>
                  </div>
                </div>
              </div>

              {/* Analyse des Scénarios */}
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-xl border border-blue-200">
                <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                  <i className="ri-bar-chart-line text-blue-600 mr-3"></i>
                  Analyse Probabiliste des Scénarios
                </h3>
                <div className="space-y-4">
                  <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-bold text-green-800">Scénario Optimiste</h4>
                      <span className="px-3 py-1 bg-green-200 text-green-800 rounded-full text-sm font-medium">
                        {detailedAnalysis.scenarioAnalysis.optimistic.probability}% de probabilité
                      </span>
                    </div>
                    <p className="text-green-700 mb-2">{detailedAnalysis.scenarioAnalysis.optimistic.description}</p>
                    <p className="text-green-600 text-sm font-medium">Impact: {detailedAnalysis.scenarioAnalysis.optimistic.impact}</p>
                  </div>

                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-bold text-blue-800">Scénario Réaliste</h4>
                      <span className="px-3 py-1 bg-blue-200 text-blue-800 rounded-full text-sm font-medium">
                        {detailedAnalysis.scenarioAnalysis.realistic.probability}% de probabilité
                      </span>
                    </div>
                    <p className="text-blue-700 mb-2">{detailedAnalysis.scenarioAnalysis.realistic.description}</p>
                    <p className="text-blue-600 text-sm font-medium">Impact: {detailedAnalysis.scenarioAnalysis.realistic.impact}</p>
                  </div>

                  <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-bold text-orange-800">Scénario Pessimiste</h4>
                      <span className="px-3 py-1 bg-orange-200 text-orange-800 rounded-full text-sm font-medium">
                        {detailedAnalysis.scenarioAnalysis.pessimistic.probability}% de probabilité
                      </span>
                    </div>
                    <p className="text-orange-700 mb-2">{detailedAnalysis.scenarioAnalysis.pessimistic.description}</p>
                    <p className="text-orange-600 text-sm font-medium">Impact: {detailedAnalysis.scenarioAnalysis.pessimistic.impact}</p>
                  </div>
                </div>
              </div>

              {/* Timeline Probabiliste */}
              <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-6 rounded-xl border border-purple-200">
                <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                  <i className="ri-calendar-line text-purple-600 mr-3"></i>
                  Roadmap Probabiliste des Jalons Clés
                </h3>
                <div className="space-y-3">
                  {detailedAnalysis.timeline.map((milestone, index) => (
                    <div key={index} className="flex items-center space-x-4 p-3 bg-white rounded-lg">
                      <div className="text-sm font-bold text-purple-600 min-w-[80px]">{milestone.year}</div>
                      <div className="flex-1 text-gray-700">{milestone.milestone}</div>
                      <div className="flex items-center space-x-2">
                        <div className="w-24 bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-purple-500 h-2 rounded-full transition-all duration-500"
                            style={{ width: `${milestone.probability}%` }}
                          ></div>
                        </div>
                        <span className="text-sm font-medium text-purple-600 min-w-[40px]">{milestone.probability}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Moteurs de Marché */}
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-gray-50 p-6 rounded-xl border border-gray-200">
                  <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
                    <i className="ri-rocket-line text-green-600 mr-3"></i>
                    Moteurs de Croissance Identifiés
                  </h3>
                  <ul className="space-y-2">
                    {detailedAnalysis.marketDrivers.map((driver, index) => (
                      <li key={index} className="flex items-start space-x-2">
                        <i className="ri-arrow-right-s-line text-green-500 mt-0.5"></i>
                        <span className="text-gray-700 text-sm">{driver}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-gray-50 p-6 rounded-xl border border-gray-200">
                  <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
                    <i className="ri-alert-line text-red-600 mr-3"></i>
                    Facteurs de Risque Identifiés
                  </h3>
                  <ul className="space-y-2">
                    {detailedAnalysis.riskFactors.map((risk, index) => (
                      <li key={index} className="flex items-start space-x-2">
                        <i className="ri-arrow-right-s-line text-red-500 mt-0.5"></i>
                        <span className="text-gray-700 text-sm">{risk}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Technologies Clés */}
              <div className="bg-gradient-to-r from-indigo-50 to-blue-50 p-6 rounded-xl border border-indigo-200">
                <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                  <i className="ri-cpu-line text-indigo-600 mr-3"></i>
                  Technologies et Innovations Stratégiques
                </h3>
                <div className="grid md:grid-cols-2 gap-4">
                  {detailedAnalysis.keyTechnologies.map((tech, index) => (
                    <div key={index} className="bg-white p-3 rounded-lg border border-indigo-100">
                      <div className="flex items-center space-x-2">
                        <i className="ri-lightbulb-line text-indigo-500"></i>
                        <span className="text-gray-700 text-sm font-medium">{tech}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Opportunités d'Investissement */}
              <div className="bg-gradient-to-r from-yellow-50 to-orange-50 p-6 rounded-xl border border-yellow-200">
                <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                  <i className="ri-treasure-map-line text-yellow-600 mr-3"></i>
                  Opportunités d'Investissement Concrètes
                </h3>
                <div className="grid md:grid-cols-2 gap-4">
                  {detailedAnalysis.investmentOpportunities.map((opportunity, index) => (
                    <div key={index} className="bg-white p-4 rounded-lg border border-yellow-100 hover:shadow-md transition-shadow">
                      <div className="flex items-start space-x-3">
                        <i className="ri-coins-line text-yellow-600 mt-0.5"></i>
                        <div>
                          <span className="text-gray-800 font-medium text-sm">{opportunity}</span>
                          <div className="text-yellow-600 text-xs mt-1">Potentiel de croissance élevé</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Environnement Réglementaire */}
              <div className="bg-gradient-to-r from-gray-50 to-slate-50 p-6 rounded-xl border border-gray-200">
                <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                  <i className="ri-government-line text-gray-600 mr-3"></i>
                  Cadre Réglementaire et Politique
                </h3>
                <div className="space-y-2">
                  {detailedAnalysis.regulatoryEnvironment.map((regulation, index) => (
                    <div key={index} className="flex items-start space-x-2 p-2 bg-white rounded border border-gray-100">
                      <i className="ri-file-text-line text-gray-500 mt-0.5"></i>
                      <span className="text-gray-700 text-sm">{regulation}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Impact Développement Durable */}
              <div className="bg-gradient-to-r from-green-50 to-teal-50 p-6 rounded-xl border border-green-200">
                <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                  <i className="ri-leaf-line text-green-600 mr-3"></i>
                  Impact Développement Durable
                </h3>
                <p className="text-gray-700 leading-relaxed">{detailedAnalysis.sustainabilityImpact}</p>
              </div>

              {/* Paysage Concurrentiel */}
              <div className="bg-gradient-to-r from-red-50 to-pink-50 p-6 rounded-xl border border-red-200">
                <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                  <i className="ri-sword-line text-red-600 mr-3"></i>
                  Analyse Concurrentielle Stratégique
                </h3>
                <div className="space-y-2">
                  {detailedAnalysis.competitiveLandscape.map((element, index) => (
                    <div key={index} className="flex items-start space-x-2 p-2 bg-white rounded border border-red-100">
                      <i className="ri-team-line text-red-500 mt-0.5"></i>
                      <span className="text-gray-700 text-sm">{element}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

          </div>
        </div>
      )}
    </section>
  );
}
