'use client';

import { useState, useEffect } from 'react';

interface BOAMPRecord {
  fields: {
    numero_avis: string;
    titre: string;
    date_publication: string;
    datelimitereponse?: string;
    datefindiffusion?: string;
    descripteur_code?: string;
    type_marche?: string;
    code_departement?: string;
    organisme_nom?: string;
    montant_marche?: number;
    lieu_execution?: string;
    url_boamp: string;
    isNew?: boolean;
  };
}

interface BOAMPData {
  lastUpdate: string;
  lastDate: string;
  totalProcessed: number;
  records: BOAMPRecord[];
}

const BOAMPRealtime = () => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [activeFilter, setActiveFilter] = useState('tous');

  const fetchBOAMPData = async () => {
    try {
      setLoading(true);
      setError(null);

      const today = new Date().toISOString().split('T')[0];

      // Appel API BOAMP officielle avec logique enrichie
      const response = await fetch(
        `https://boamp-datadila.opendatasoft.com/api/explore/v2.1/catalog/datasets/boamp/records?` +
        new URLSearchParams({
          limit: '50',
          order_by: 'fields.datelimitereponse',
          select: [
            'fields.numero_avis',
            'fields.titre',
            'fields.date_publication',
            'fields.datelimitereponse',
            'fields.datefindiffusion',
            'fields.organisme_nom',
            'fields.code_departement',
            'fields.type_marche',
            'fields.montant_marche'
          ].join(','),
          where: `(fields.datelimitereponse >= "${today}" OR (fields.datelimitereponse IS NULL AND fields.datefindiffusion >= "${today}"))`
        })
      );

      if (!response.ok) {
        throw new Error(`Erreur API BOAMP: ${response.status}`);
      }

      const apiData = await response.json();

      // Transformer et enrichir les données
      const enriched = apiData.records.map((r: any) => {
        const deadline = r.fields.datelimitereponse || r.fields.datefindiffusion;
        const daysRemaining = deadline
          ? Math.ceil((new Date(deadline).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))
          : null;

        const publicationDate = new Date(r.fields.date_publication);
        const now = new Date();
        const diffHours = (now.getTime() - publicationDate.getTime()) / (1000 * 60 * 60);

        return {
          numero: r.fields.numero_avis,
          titre: r.fields.titre,
          publication: r.fields.date_publication,
          deadline: deadline || 'Non spécifiée',
          jours_restants: daysRemaining,
          organisme: r.fields.organisme_nom || 'N/A',
          departement: r.fields.code_departement || 'N/A',
          type: r.fields.type_marche || 'N/A',
          montant: r.fields.montant_marche || 'Non précisé',
          url: `https://www.boamp.fr/avis/${r.fields.numero_avis}`,
          isNew: diffHours <= 24
        };
      });

      // Trier par deadline et garder les plus urgents
      const sorted = enriched
        .filter(r => r.jours_restants !== null && r.jours_restants >= 0)
        .sort((a, b) => (a.jours_restants || 9999) - (b.jours_restants || 9999));

      setData({
        lastUpdate: new Date().toISOString(),
        total: sorted.length,
        records: sorted
      });
      setLastUpdate(new Date());

    } catch (err: any) {
      console.error('Erreur BOAMP:', err);
      setError(err.message || 'Erreur lors du chargement des données BOAMP');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBOAMPData();
  }, []);

  const getFilteredRecords = () => {
    if (!data?.records) return [];
    
    switch (activeFilter) {
      case 'nouveaux':
        return data.records.filter((record: any) => record.isNew);
      case 'urgents':
        return data.records.filter((record: any) => record.jours_restants !== null && record.jours_restants <= 3);
      case 'semaine':
        return data.records.filter((record: any) => record.jours_restants !== null && record.jours_restants <= 7);
      default:
        return data.records;
    }
  };

  const getUrgencyColor = (jours: number | null) => {
    if (jours === null) return 'text-gray-500';
    if (jours <= 3) return 'text-red-600';
    if (jours <= 7) return 'text-orange-600';
    return 'text-green-600';
  };

  const getUrgencyBg = (jours: number | null) => {
    if (jours === null) return 'bg-gray-100';
    if (jours <= 3) return 'bg-red-50 border-red-200';
    if (jours <= 7) return 'bg-orange-50 border-orange-200';
    return 'bg-green-50 border-green-200';
  };

  const filteredRecords = getFilteredRecords();

  // Calcul des compteurs pour les filtres
  const counters = {
    tous: data?.records?.length || 0,
    nouveaux: data?.records?.filter((r: any) => r.isNew).length || 0,
    urgents: data?.records?.filter((r: any) => r.jours_restants !== null && r.jours_restants <= 3).length || 0,
    semaine: data?.records?.filter((r: any) => r.jours_restants !== null && r.jours_restants <= 7).length || 0
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-xl font-bold text-gray-900 mb-2">
            Appels d'Offres BOAMP - Temps Réel
          </h3>
          <p className="text-sm text-gray-600">
            Dernière mise à jour: {lastUpdate ? lastUpdate.toLocaleTimeString('fr-FR') : 'Jamais'}
          </p>
        </div>
        <button
          onClick={fetchBOAMPData}
          disabled={loading}
          className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 whitespace-nowrap"
        >
          <i className={`ri-refresh-line ${loading ? 'animate-spin' : ''}`}></i>
          <span>Actualiser</span>
        </button>
      </div>

      {/* Filtres avec compteurs */}
      <div className="flex flex-wrap gap-2 mb-6">
        {[
          { key: 'tous', label: 'Tous', count: counters.tous },
          { key: 'nouveaux', label: 'Nouveaux', count: counters.nouveaux },
          { key: 'urgents', label: 'Urgents', count: counters.urgents },
          { key: 'semaine', label: 'Cette semaine', count: counters.semaine }
        ].map(filter => (
          <button
            key={filter.key}
            onClick={() => setActiveFilter(filter.key)}
            className={`flex items-center space-x-2 px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${
              activeFilter === filter.key
                ? 'bg-blue-100 text-blue-700 border border-blue-200'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <span>{filter.label}</span>
            <span className={`px-2 py-0.5 rounded-full text-xs ${
              activeFilter === filter.key ? 'bg-blue-200' : 'bg-gray-200'
            }`}>
              {filter.count}
            </span>
          </button>
        ))}
      </div>

      {loading && (
        <div className="flex items-center justify-center py-12">
          <div className="flex items-center space-x-3">
            <i className="ri-loader-4-line text-2xl animate-spin text-blue-600"></i>
            <span className="text-gray-600">Chargement des opportunités BOAMP...</span>
          </div>
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
          <div className="flex items-center space-x-2">
            <i className="ri-error-warning-line text-red-600"></i>
            <span className="text-red-800 font-medium">Erreur:</span>
            <span className="text-red-700">{error}</span>
          </div>
        </div>
      )}

      {!loading && !error && filteredRecords.length === 0 && (
        <div className="text-center py-12">
          <i className="ri-file-search-line text-4xl text-gray-400 mb-4"></i>
          <p className="text-gray-600">Aucun appel d'offres trouvé pour ce filtre.</p>
        </div>
      )}

      {!loading && !error && filteredRecords.length > 0 && (
        <div className="space-y-4">
          {filteredRecords.map((record: any, index: number) => (
            <div 
              key={record.numero} 
              className={`border rounded-lg p-4 transition-all hover:shadow-md ${getUrgencyBg(record.jours_restants)}`}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h4 className="font-semibold text-gray-900 flex-1">
                      {record.titre}
                    </h4>
                    <div className="flex items-center space-x-2">
                      {record.isNew && (
                        <span className="px-2 py-1 bg-green-100 text-green-800 text-xs font-medium rounded-full whitespace-nowrap">
                          NOUVEAU
                        </span>
                      )}
                      {record.jours_restants !== null && (
                        <span className={`px-2 py-1 text-xs font-medium rounded-full whitespace-nowrap ${getUrgencyColor(record.jours_restants)} ${
                          record.jours_restants <= 3 ? 'bg-red-100' : 
                          record.jours_restants <= 7 ? 'bg-orange-100' : 'bg-green-100'
                        }`}>
                          {record.jours_restants === 0 ? 'AUJOURD\'HUI' : 
                           record.jours_restants === 1 ? 'DEMAIN' : 
                           `${record.jours_restants} jours`}
                        </span>
                      )}
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm text-gray-600 mb-3">
                    <div>
                      <span className="font-medium text-gray-700">Organisme:</span>
                      <br />{record.organisme}
                    </div>
                    <div>
                      <span className="font-medium text-gray-700">Département:</span>
                      <br />{record.departement}
                    </div>
                    <div>
                      <span className="font-medium text-gray-700">Type:</span>
                      <br />{record.type}
                    </div>
                    <div>
                      <span className="font-medium text-gray-700">Montant:</span>
                      <br />{record.montant}
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="text-sm text-gray-500">
                      <span className="font-medium">Publication:</span> {new Date(record.publication).toLocaleDateString('fr-FR')}
                      {record.deadline !== 'Non spécifiée' && (
                        <>
                          <span className="mx-2">•</span>
                          <span className="font-medium">Échéance:</span> {new Date(record.deadline).toLocaleDateString('fr-FR')}
                        </>
                      )}
                    </div>
                    <a
                      href={record.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm whitespace-nowrap"
                    >
                      <span>Voir l'avis</span>
                      <i className="ri-external-link-line"></i>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {!loading && !error && data && (
        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center justify-between text-sm text-gray-600">
            <span>Total des opportunités actives: {data.total}</span>
            <span>Prochaine actualisation automatique dans 30 minutes</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default function BOAMPRealtime() {
  const [boampData, setBOAMPData] = useState<BOAMPData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isLive, setIsLive] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedFilters, setSelectedFilters] = useState({
    departement: '',
    type_marche: '',
    montant_min: '',
    search: ''
  });

  // Simuler la récupération des données temps réel
  const fetchRealtimeData = async () => {
    try {
      setLoading(true);
      const today = new Date().toISOString().split('T')[0];

      const response = await fetch(
        `https://boamp-datadila.opendatasoft.com/api/explore/v2.1/catalog/datasets/boamp/records?` +
        new URLSearchParams({
          limit: '50',
          order_by: 'fields.datelimitereponse',
          select: [
            'fields.numero_avis',
            'fields.titre',
            'fields.date_publication',
            'fields.datelimitereponse',
            'fields.datefindiffusion',
            'fields.organisme_nom',
            'fields.code_departement',
            'fields.type_marche',
            'fields.montant_marche'
          ].join(','),
          where: `(fields.datelimitereponse >= "${today}" OR (fields.datelimitereponse IS NULL AND fields.datefindiffusion >= "${today}"))`
        })
      );

      if (!response.ok) {
        throw new Error(`Erreur API BOAMP: ${response.status}`);
      }

      const data = await response.json();

      const enrichedData = {
        ...data,
        records: data.records.map((record: any) => {
          const publicationDate = new Date(record.fields.date_publication);
          const now = new Date();
          const diffHours = (now.getTime() - publicationDate.getTime()) / (1000 * 60 * 60);

          const deadline = record.fields.datelimitereponse || record.fields.datefindiffusion;
          const daysRemaining = deadline
            ? Math.ceil((new Date(deadline).getTime() - now.getTime()) / (1000 * 60 * 60 * 24))
            : null;

          return {
            ...record,
            fields: {
              ...record.fields,
              url_boamp: `https://www.boamp.fr/avis/${record.fields.numero_avis}`,
              isNew: diffHours <= 24,
              daysRemaining
            }
          };
        })
      };

      setBOAMPData(enrichedData);
      setLastUpdate(new Date());
      setError(null);
    } catch (err) {
      console.error('Erreur lors de la récupération des données BOAMP:', err);
      setError(err instanceof Error ? err.message : 'Erreur inconnue');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRealtimeData();
    
    // Actualisation automatique toutes les 30 secondes quand le mode live est activé
    let interval: NodeJS.Timeout;
    if (isLive) {
      interval = setInterval(fetchRealtimeData, 30000);
    }
    
    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [isLive]);

  const filteredRecords = boampData?.records.filter(record => {
    const { departement, type_marche, montant_min, search } = selectedFilters;
    
    if (departement && record.fields.code_departement !== departement) return false;
    if (type_marche && record.fields.type_marche !== type_marche) return false;
    if (montant_min && (!record.fields.montant_marche || record.fields.montant_marche < parseInt(montant_min))) return false;
    if (search && !record.fields.titre.toLowerCase().includes(search.toLowerCase())) return false;
    
    return true;
  }) || [];

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: '2-digit', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getDaysRemaining = (dateString?: string) => {
    if (!dateString) return null;
    const today = new Date();
    const deadline = new Date(dateString);
    const diffTime = deadline.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const exportToCSV = () => {
    if (!filteredRecords.length) return;
    
    const headers = ['Numéro', 'Titre', 'Date publication', 'Date limite', 'Organisme', 'Département', 'Type marché', 'Montant', 'Lien'];
    const csvData = filteredRecords.map(record => [
      record.fields.numero_avis,
      `"${record.fields.titre.replace(/"/g, '""')}"`,
      record.fields.date_publication,
      record.fields.datelimitereponse || record.fields.datefindiffusion || '',
      `"${(record.fields.organisme_nom || '').replace(/"/g, '""')}"`,
      record.fields.code_departement || '',
      record.fields.type_marche || '',
      record.fields.montant_marche || '',
      record.fields.url_boamp
    ]);
    
    const csv = [headers, ...csvData].map(row => row.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `boamp_realtime_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  if (isLoading) {
    return (
      <div className="bg-gray-900 rounded-xl p-8 border border-yellow-500/20">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-yellow-500/30 border-t-yellow-500 rounded-full animate-spin mx-auto mb-4"></div>
          <h3 className="text-xl font-bold text-white mb-2">Chargement des avis BOAMP</h3>
          <p className="text-gray-400">Récupération des derniers appels d'offres...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-gray-900 rounded-xl p-8 border border-red-500/20">
        <div className="text-center">
          <i className="ri-error-warning-line text-4xl text-red-400 mb-4"></i>
          <h3 className="text-xl font-bold text-white mb-2">Erreur de connexion</h3>
          <p className="text-gray-400 mb-4">{error}</p>
          <button
            onClick={fetchRealtimeData}
            className="px-6 py-3 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-refresh-line mr-2"></i>
            Réessayer
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* En-tête avec statut temps réel */}
      <div className="bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-xl p-6 border border-green-500/30">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center">
              <i className="ri-live-line text-2xl text-green-400"></i>
            </div>
            <div>
              <h3 className="text-2xl font-bold text-white">BOAMP Temps Réel</h3>
              <p className="text-gray-300">Monitoring des appels d'offres publics</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <div className="text-sm text-gray-400">Dernière mise à jour</div>
              <div className="text-white font-medium">
                {boampData?.lastUpdate ? formatDate(boampData.lastUpdate) : 'N/A'}
              </div>
            </div>
            
            <button
              onClick={() => setIsLive(!isLive)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-all cursor-pointer whitespace-nowrap ${
                isLive 
                  ? 'bg-green-500 text-white' 
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              <div className={`w-2 h-2 rounded-full ${isLive ? 'bg-white animate-pulse' : 'bg-gray-500'}`}></div>
              <span>{isLive ? 'Live ON' : 'Live OFF'}</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-black/20 rounded-lg p-4">
            <div className="text-2xl font-bold text-green-400">{filteredRecords.length}</div>
            <div className="text-sm text-gray-400">Avis ouverts</div>
          </div>
          <div className="bg-black/20 rounded-lg p-4">
            <div className="text-2xl font-bold text-blue-400">{boampData?.totalProcessed || 0}</div>
            <div className="text-sm text-gray-400">Total traités</div>
          </div>
          <div className="bg-black/20 rounded-lg p-4">
            <div className="text-2xl font-bold text-yellow-400">
              {filteredRecords.filter(r => {
                const days = getDaysRemaining(r.fields.datelimitereponse || r.fields.datefindiffusion);
                return days !== null && days <= 7;
              }).length}
            </div>
            <div className="text-sm text-gray-400">Urgents (≤7j)</div>
          </div>
          <div className="bg-black/20 rounded-lg p-4">
            <div className="text-2xl font-bold text-purple-400">
              {filteredRecords.filter(r => r.fields.isNew).length}
            </div>
            <div className="text-sm text-gray-400">Nouveaux aujourd'hui</div>
          </div>
        </div>
      </div>

      {/* Filtres */}
      <div className="bg-gray-900 rounded-xl p-6 border border-yellow-500/20">
        <h4 className="text-lg font-bold text-white mb-4">Filtres de recherche</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <input
            type="text"
            placeholder="Rechercher dans les titres..."
            value={selectedFilters.search}
            onChange={(e) => setSelectedFilters({...selectedFilters, search: e.target.value})}
            className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:border-blue-500 focus:outline-none"
          />
          
          <select
            value={selectedFilters.departement}
            onChange={(e) => setSelectedFilters({...selectedFilters, departement: e.target.value})}
            className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-blue-500 focus:outline-none pr-8"
          >
            <option value="">Tous les départements</option>
            {Array.from(new Set(boampData?.records.map(r => r.fields.code_departement).filter(Boolean)))
              .sort()
              .map(dept => (
                <option key={dept} value={dept}>{dept}</option>
              ))}
          </select>
          
          <select
            value={selectedFilters.type_marche}
            onChange={(e) => setSelectedFilters({...selectedFilters, type_marche: e.target.value})}
            className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:border-blue-500 focus:outline-none pr-8"
          >
            <option value="">Tous les types</option>
            {Array.from(new Set(boampData?.records.map(r => r.fields.type_marche).filter(Boolean)))
              .sort()
              .map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
          </select>
          
          <input
            type="number"
            placeholder="Montant minimum €"
            value={selectedFilters.montant_min}
            onChange={(e) => setSelectedFilters({...selectedFilters, montant_min: e.target.value})}
            className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:border-blue-500 focus:outline-none"
          />
        </div>

        <div className="flex justify-between items-center mt-4">
          <div className="text-gray-400 text-sm">
            {filteredRecords.length} avis affichés sur {boampData?.records.length || 0} total
          </div>
          
          <div className="flex space-x-2">
            <button
              onClick={() => setSelectedFilters({departement: '', type_marche: '', montant_min: '', search: ''})}
              className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-close-line mr-1"></i>
              Effacer
            </button>
            <button
              onClick={exportToCSV}
              className="px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-download-line mr-1"></i>
              Export CSV
            </button>
          </div>
        </div>
      </div>

      {/* Liste des avis */}
      <div className="space-y-4">
        {filteredRecords.length === 0 ? (
          <div className="bg-gray-900 rounded-xl p-8 border border-gray-700 text-center">
            <i className="ri-search-line text-4xl text-gray-500 mb-4"></i>
            <h3 className="text-xl font-bold text-white mb-2">Aucun avis trouvé</h3>
            <p className="text-gray-400">Modifiez vos critères de recherche pour voir plus de résultats</p>
          </div>
        ) : (
          filteredRecords.map((record, index) => {
            const fields = record.fields;
            const urgencyLevel = fields.daysRemaining <= 3 ? 'urgent' : fields.daysRemaining <= 7 ? 'warning' : 'normal';
            
            return (
              <div 
                key={fields.numero_avis} 
                className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
              >
                <div className="flex justify-between items-start mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-semibold text-gray-900 text-sm leading-tight">
                        {fields.titre}
                      </h3>
                      {fields.isNew && (
                        <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs font-medium rounded-full whitespace-nowrap">
                          NOUVEAU
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-gray-600 mb-2">{fields.organisme_nom}</p>
                  </div>
                  
                  <div className="flex flex-col items-end gap-1">
                    {fields.daysRemaining !== null && (
                      <span className={`px-2 py-1 text-xs font-medium rounded-full whitespace-nowrap ${
                        urgencyLevel === 'urgent' ? 'bg-red-100 text-red-800' :
                        urgencyLevel === 'warning' ? 'bg-orange-100 text-orange-800' :
                        'bg-green-100 text-green-800'
                      }`}>
                        {fields.daysRemaining} jour{fields.daysRemaining !== 1 ? 's' : ''}
                      </span>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 text-xs text-gray-600 mb-4">
                  <div>
                    <span className="font-medium">Département:</span> {fields.code_departement || 'N/A'}
                  </div>
                  <div>
                    <span className="font-medium">Type:</span> {fields.type_marche || 'N/A'}
                  </div>
                  <div>
                    <span className="font-medium">Montant:</span> {fields.montant_marche || 'Non précisé'}
                  </div>
                  <div>
                    <span className="font-medium">Échéance:</span> {
                      fields.datelimitereponse || fields.datefindiffusion ? 
                      new Date(fields.datelimitereponse || fields.datefindiffusion).toLocaleDateString('fr-FR') : 
                      'Non spécifiée'
                    }
                  </div>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-xs text-gray-500">
                    Publié le {new Date(fields.date_publication).toLocaleDateString('fr-FR')}
                  </span>
                  {fields.url_boamp && (
                    <a 
                      href={fields.url_boamp}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 px-3 py-1 bg-blue-600 text-white text-xs font-medium rounded hover:bg-blue-700 transition-colors whitespace-nowrap cursor-pointer"
                    >
                      <i className="ri-external-link-line"></i>
                      Voir l'avis
                    </a>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Instructions d'installation */}
      <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-xl p-6 border border-blue-500/20">
        <h4 className="text-lg font-bold text-white mb-4 flex items-center">
          <i className="ri-terminal-line text-blue-400 mr-2"></i>
          Monitoring Automatique
        </h4>
        
        <p className="text-gray-300 mb-4">
          Pour activer le monitoring temps réel automatique des avis BOAMP, lancez le script Node.js :
        </p>

        <div className="bg-black/30 rounded-lg p-4 font-mono text-sm space-y-2">
          <div className="text-green-400"># Installation des dépendances</div>
          <div className="text-white">cd app/opportunities/scripts && npm install</div>
          
          <div className="text-green-400 mt-4"># Lancement du monitoring</div>
          <div className="text-white">npm start</div>
          
          <div className="text-green-400 mt-4"># Ou en mode développement avec auto-restart</div>
          <div className="text-white">npm run dev</div>
        </div>

        <div className="mt-4 text-sm text-gray-400">
          <p><strong>Fonctionnalités du script :</strong></p>
          <ul className="list-disc list-inside mt-2 space-y-1">
            <li>Vérification automatique toutes les 30 secondes</li>
            <li>Filtrage des avis encore ouverts uniquement</li>
            <li>Logs détaillés avec timestamps</li>
            <li>Sauvegarde JSON pour intégration web</li>
            <li>Nettoyage automatique des avis expirés</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
