
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function FormationInteractivePage() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showQuiz, setShowQuiz] = useState(false);
  const [currentQuiz, setCurrentQuiz] = useState(null);

  const categories = [
    { id: 'all', name: 'Tous', icon: 'ri-apps-line' },
    { id: 'bourse', name: 'Bourse', icon: 'ri-line-chart-line' },
    { id: 'crypto', name: 'Crypto', icon: 'ri-currency-line' },
    { id: 'immobilier', name: 'Immobilier', icon: 'ri-building-line' },
    { id: 'fiscalite', name: 'Fiscalité', icon: 'ri-calculator-line' }
  ];

  const complexQuizzes = {
    bourse: {
      title: 'Quiz Bourse - Niveau Expert',
      totalQuestions: 50,
      questions: [
        {
          question: 'Dans un contexte de volatilité accrue, quelle stratégie d\'arbitrage utilisant les options pourrait permettre de capturer la convergence des prix entre le marché comptant et le marché à terme d\'un indice boursier ?',
          options: [
            'Straddle long avec delta-hedge dynamique',
            'Butterfly spread avec ajustement gamma',
            'Arbitrage de volatilité par collar synthétique',
            'Calendar spread avec roulement des échéances'
          ],
          correct: 0
        },
        {
          question: 'Comment l\'effet de levier financier d\'une entreprise influence-t-il le beta de son action dans le modèle CAPM, et quelle correction appliquer lors d\'une analyse sectorielle ?',
          options: [
            'Beta unlevered = Beta levered / (1 + (1-Tax) × D/E)',
            'Beta levered = Beta unlevered × (1 + (1-Tax) × D/E)',
            'Beta ajusté = Beta × (1 + Covariance(Dette, Marché))',
            'Beta sectoriel = Moyenne pondérée des betas individuels'
          ],
          correct: 1
        },
        {
          question: 'En microstructure des marchés, quel impact a la fragmentation sur la formation des prix et comment l\'algorithme TWAP peut-il être optimisé dans ce contexte ?',
          options: [
            'Réduction du spread bid-ask par arbitrage inter-marchés',
            'Augmentation des coûts de transaction due à la recherche de liquidité',
            'Amélioration de la découverte des prix par agrégation',
            'Neutralité sur la volatilité intraday'
          ],
          correct: 1
        },
        {
          question: 'Dans une stratégie de momentum cross-sectoriel, comment intégrer les corrélations dynamiques et l\'asymétrie des rendements pour optimiser l\'allocation ?',
          options: [
            'Utilisation de modèles GARCH multivariés avec copules',
            'Application du modèle Black-Litterman modifié',
            'Optimisation de Markowitz avec contraintes de VaR',
            'Allocation par parité de risque ajustée'
          ],
          correct: 0
        },
        {
          question: 'Comment calculer la duration effective d\'une obligation convertible dans un environnement de taux variables et de volatilité du sous-jacent ?',
          options: [
            'Duration = Duration pure + Duration equity × Delta',
            'Duration modifiée + Convexité × Gamma × Volatilité²',
            'Duration hybride = Poids obligataire × Duration + Poids equity × Beta',
            'Duration effective par différences finies sur la courbe des taux'
          ],
          correct: 3
        },
        {
          question: 'En trading haute fréquence, quelle technique permet de détecter et exploiter les anomalies de micro-structure tout en gérant le risque d\'inventory ?',
          options: [
            'Algorithmes de market making avec optimal inventory control',
            'Détection de patterns par machine learning non-supervisé',
            'Arbitrage statistique avec mean-reversion models',
            'Exploitation des latences réseau par colocation'
          ],
          correct: 0
        },
        {
          question: 'Comment évaluer le risque de modèle dans un portefeuille multi-stratégies utilisant des dérivés exotiques ?',
          options: [
            'Backtesting avec bootstrap et stress scenarios',
            'Validation croisée par modèles alternatifs',
            'Monte Carlo avec paramètres incertains',
            'Toutes les approches précédentes combinées'
          ],
          correct: 3
        },
        {
          question: 'Dans l\'analyse du credit spread, comment intégrer les effets de liquidité et de flight-to-quality lors de crises systémiques ?',
          options: [
            'Modèle de Merton étendu avec prime de liquidité',
            'Spread = Credit Risk + Liquidity Premium + Systematic Risk',
            'Utilisation de CDS comme proxy du risque de crédit pur',
            'Modélisation par chaînes de Markov à régimes multiples'
          ],
          correct: 1
        },
        {
          question: 'Comment optimiser une stratégie de carry trade en intégrant les forward premia et les risques de change non-linéaires ?',
          options: [
            'Hedging par options exotiques avec barrières',
            'Modèle de déséquilibre avec mean-reversion',
            'Carry ajusté du skew de volatilité implicite',
            'Optimisation dynamique avec contraintes de drawdown'
          ],
          correct: 2
        },
        {
          question: 'En gestion alternative, comment mesurer l\'alpha réel d\'un hedge fund après ajustement des biais de survivance et de sélection ?',
          options: [
            'Alpha de Jensen avec benchmark adaptatif',
            'Modèle à 7 facteurs de Fung et Hsieh',
            'Bootstrap avec correction de Holm-Bonferroni',
            'Analyse par composantes principales sur les stratégies'
          ],
          correct: 1
        },
        {
          question: 'Dans un contexte de QE (Quantitative Easing), comment anticiper l\'impact sur la structure par terme des taux et ajuster les stratégies obligataires ?',
          options: [
            'Modèle de Nelson-Siegel avec facteur QE',
            'Analyse des flux de portefeuille par duration bucket',
            'Modélisation de l\'effet d\'annonce vs effet de stock',
            'Arbitrage de courbure avec protection inflation'
          ],
          correct: 2
        },
        {
          question: 'Comment construire un indicateur composite de stress financier intégrant marchés actions, crédit, change et matières premières ?',
          options: [
            'Analyse en composantes principales pondérée',
            'Modèle VAR avec identification structurelle',
            'Indice de corrélation dynamique multi-marchés',
            'Agrégation par copules avec queues épaisses'
          ],
          correct: 0
        }
      ]
    },
    crypto: {
      title: 'Quiz Crypto - Niveau Expert',
      totalQuestions: 50,
      questions: [
        {
          question: 'Dans un protocole DeFi utilisant un AMM (Automated Market Maker), comment calculer l\'impermanent loss pour une position LP dans une pool ETH/USDC avec une variation de prix de 300% sur ETH ?',
          options: [
            'IL = 2√(r)/(1+r) - 1, où r = 4 (300% + 100%)',
            'IL = √(r)/(1+√r) - 1/2, où r = 4',
            'IL = 2√(4)/(1+4) - 1 = 0.6 - 1 = -40%',
            'IL = (√4 - 1)/(√4 + 1) = 0.33 soit 33%'
          ],
          correct: 0
        },
        {
          question: 'En arbitrage triangulaire sur les exchanges décentralisés, comment optimiser une stratégie MEV (Maximal Extractable Value) tout en gérant les risques de front-running ?',
          options: [
            'Utiliser des flashloans avec commit-reveal schemes',
            'Implémenter des dark pools avec zk-SNARKs',
            'Deployer des contrats avec timelock et slippage adaptatif',
            'Combiner batching transactions et priority gas auctions'
          ],
          correct: 0
        },
        {
          question: 'Comment l\'algorithme de consensus Proof-of-Stake d\'Ethereum 2.0 influence-t-il la valorisation des tokens stakés et quelle prime/décote appliquer ?',
          options: [
            'Prime de liquidité basée sur la période de lock-up',
            'Décote liée au risque de slashing et à la dilution',
            'Valorisation neutre avec yield ajusté du risque',
            'Prime de gouvernance proportionnelle au stake'
          ],
          correct: 1
        },
        {
          question: 'Dans les protocoles de lending DeFi, comment calculer le taux de liquidation optimal pour minimiser le risque systémique tout en maximisant l\'utilisation du capital ?',
          options: [
            'LTV = σ × √(T) × Φ⁻¹(confidence level)',
            'Ratio de liquidation = 1 - (Volatilité × Time decay)',
            'Threshold = Price × (1 - Liquidation penalty) / Collateral ratio',
            'Seuil dynamique basé sur la volatilité réalisée 30j'
          ],
          correct: 3
        },
        {
          question: 'Comment évaluer la sécurité économique d\'un réseau PoS en analysant les incitations des validateurs et les risques de centralisation ?',
          options: [
            'Ratio coût d\'attaque / capitalisation réseau',
            'Indice de Nakamoto pondéré par les rewards',
            'Analyse des coûts opportunité du staking',
            'Modélisation game-théorique des coalitions'
          ],
          correct: 0
        },
        {
          question: 'En trading de volatilité sur options crypto, comment ajuster les modèles traditionnels pour tenir compte de l\'asymétrie et des sauts de prix ?',
          options: [
            'Modèle de Heston avec sauts de Merton',
            'SABR étendu avec fat tails et skew',
            'Variance Gamma avec paramètres crypto-spécifiques',
            'Calibration par machine learning sur données intraday'
          ],
          correct: 1
        },
        {
          question: 'Comment construire un indice de sentiment crypto en combinant données on-chain, réseaux sociaux et flux de capitaux institutionnels ?',
          options: [
            'Weighted composite des métriques NVT, MVRV et social volume',
            'Modèle factoriel avec PCA sur 50+ variables',
            'Sentiment score par NLP + Network value indicators',
            'Machine learning avec features engineered multi-sources'
          ],
          correct: 1
        },
        {
          question: 'Dans une stratégie de yield farming multi-chaînes, comment optimiser l\'allocation tout en gérant les risques de smart contracts et de bridge ?',
          options: [
            'Portfolio théory appliqué aux pools DeFi',
            'Optimisation de Kelly avec contrainte de risque technique',
            'Diversification par protocole, chaîne et type de token',
            'Allocation dynamique basée sur TVL et audit scores'
          ],
          correct: 2
        },
        {
          question: 'Comment analyser la tokenomics d\'un projet pour évaluer la soutenabilité à long terme et les pressions inflationnaires/déflationnaires ?',
          options: [
            'Modèle stock-to-flow adapté avec utility demand',
            'Analyse des flux : emission schedule vs burn mechanisms',
            'Velocity of money theory appliquée aux tokens',
            'DCF des cash flows futurs du protocole'
          ],
          correct: 1
        },
        {
          question: 'En MEV (Maximal Extractable Value), comment quantifier et capturer les opportunités d\'arbitrage dans un environnement multi-DEX ?',
          options: [
            'Graph theory pour path optimization entre AMMs',
            'Linear programming avec contraintes de gas',
            'Bellman-Ford algorithm pour negative cycles',
            'Deep reinforcement learning pour strategies adaptatives'
          ],
          correct: 0
        },
        {
          question: 'Comment évaluer l\'impact des mises à jour protocolaires (hard forks) sur la valorisation et développer des stratégies d\'événements ?',
          options: [
            'Event study methodology adaptée aux cryptos',
            'Modélisation des probabilités de fork par sentiment',
            'Analysis des précédents historiques avec machine learning',
            'Monte Carlo simulation des scenarii post-fork'
          ],
          correct: 0
        },
        {
          question: 'Dans les NFTs et metaverse, comment construire des modèles de valorisation tenant compte de la rareté, utilité et dynamiques communautaires ?',
          options: [
            'Hedonic pricing models avec attributs pondérés',
            'Network effects + scarcity premium modeling',
            'Comparable sales analysis avec ajustements qualitatifs',
            'Community engagement metrics × utility functions'
          ],
          correct: 1
        }
      ]
    },
    immobilier: {
      title: 'Quiz Immobilier - Niveau Expert',
      totalQuestions: 50,
      questions: [
        {
          question: 'Dans une analyse DCF d\'un immeuble de bureaux, comment intégrer l\'obsolescence technologique et réglementaire (RE2020, BACS) dans le calcul de la valeur terminale ?',
          options: [
            'Décote progressive de 2% par an sur les loyers futurs',
            'CAPEX additionnel étalé sur 10 ans + prime de risque',
            'Réduction du yield de sortie de 25bp par non-conformité',
            'Obsolescence = (Coût mise conformité / VAN) × facteur temps'
          ],
          correct: 1
        },
        {
          question: 'En structuration d\'un fonds immobilier (SCPI/OPPCI), comment optimiser la structure de portage avec effet de levier tout en respectant les ratios prudentiels ?',
          options: [
            'LTV max 65% avec covenant de 60% et cash-sweep',
            'Financement mezzanine à 15% + dette senior 50%',
            'Utilisation de swaps de taux + collar sur immobilier',
            'Structuration en parts privilégiées/ordinaires'
          ],
          correct: 0
        },
        {
          question: 'Comment calculer l\'impact fiscal d\'une opération de défiscalisation Pinel avec cession anticipée et plus-value latente dans un contexte de marché baissier ?',
          options: [
            'Récupération intégrale + taxation PV à 19% + PS 17.2%',
            'Récupération prorata temporis + abattement durée détention',
            'Reprise avantage fiscal + taxation PV avec abattement',
            'Provision pour risque fiscal + étalement sur 3 ans'
          ],
          correct: 0
        },
        {
          question: 'En valorisation d\'actifs immobiliers commerciaux, comment intégrer les clauses d\'indexation triple net et les break options dans un modèle DCF ?',
          options: [
            'Modélisation par arbres binomiaux des options réelles',
            'Ajustement du taux d\'actualisation par prime de risque',
            'Monte Carlo avec corrélations inflation/taux/vacancy',
            'Valorisation séparée des cash flows et des options'
          ],
          correct: 2
        },
        {
          question: 'Comment optimiser la stratégie de rénovation énergétique d\'un patrimoine en intégrant les aides publiques, l\'évolution réglementaire et l\'impact sur les loyers ?',
          options: [
            'NPV des travaux incluant aides + premium loyer - coûts transitionnels',
            'Optimization sous contrainte de budget avec priorité DPE',
            'Modèle multi-critères : rentabilité, conformité, ESG',
            'Real options approach pour timing optimal des travaux'
          ],
          correct: 0
        },
        {
          question: 'Dans une opération de sale & lease back corporate, comment structurer l\'opération pour optimiser le bilan du vendeur tout en sécurisant l\'investisseur ?',
          options: [
            'Prix = Valeur vénale × 95% + garantie locative 9 ans',
            'Structuration avec put/call à parité après 10 ans',
            'Sale à 100% valeur + loyer market × 1.1 avec indexation',
            'Optimisation via holding pour crédit-bail immobilier'
          ],
          correct: 0
        },
        {
          question: 'Comment évaluer l\'impact des nouvelles mobilités (télétravail, micro-mobilité) sur la valorisation des bureaux et des commerces de centre-ville ?',
          options: [
            'Décote de 15% sur les bureaux périphériques vs centraux',
            'Modèle gravitationnel adapté aux nouvelles mobilités',
            'Analyse des corrélations flux piétons/CA commerces',
            'Révision des yield prime selon accessibility index'
          ],
          correct: 1
        },
        {
          question: 'En gestion d\'actifs immobiliers institutionnels, comment construire un benchmark de performance ajusté des risques et des styles d\'investissement ?',
          options: [
            'IPD index ajusté par secteur, géographie et leverage',
            'Peer group analysis avec attribution de performance',
            'Benchmark composite pondéré par AUM et stratégie',
            'Risk-adjusted returns avec Sharpe ratio immobilier'
          ],
          correct: 0
        },
        {
          question: 'Comment modéliser les risques climatiques physiques et de transition dans la valorisation d\'actifs immobiliers côtiers ?',
          options: [
            'Actualisation des cash flows par probabilité d\'événements',
            'Intégration de scenarios climatiques NGFS dans DCF',
            'Prime de risque additive au yield basée sur exposition',
            'Modèle d\'assurance catastrophe adapté à l\'immobilier'
          ],
          correct: 1
        },
        {
          question: 'Dans une stratégie d\'investissement immobilier pan-européenne, comment gérer les risques de change et optimiser la couverture ?',
          options: [
            'Natural hedge par diversification géographique',
            'Couverture systématique à 100% des expositions non-EUR',
            'Hedge ratio optimal basé sur corrélations immobilier/FX',
            'Options sur devises avec strike protection 90%'
          ],
          correct: 2
        },
        {
          question: 'Comment évaluer et pricer les droits de surélévation et la densification d\'actifs immobiliers en zone tendue ?',
          options: [
            'Option réelle sur développement avec timing optimal',
            'Residual land value method adapté à la surélévation',
            'Comparable transactions par m² de SHON créé',
            'DCF des cash flows incrémentaux post-densification'
          ],
          correct: 0
        },
        {
          question: 'En PropTech et smart buildings, comment quantifier la valeur ajoutée des technologies et leur impact sur les loyers et yields ?',
          options: [
            'Premium loyer de 5-15% selon niveau technologique',
            'Yield compression de 25-50bp pour immobilier connecté',
            'ROI des investissements tech via réduction charges/vacance',
            'Modèle hédonique avec scoring digital du bâtiment'
          ],
          correct: 3
        }
      ]
    },
    fiscalite: {
      title: 'Quiz Fiscalité - Niveau Expert',
      totalQuestions: 50,
      questions: [
        {
          question: 'Dans le cadre d\'une transmission transgénérationnelle avec démembrement temporaire, comment optimiser la valorisation des parts d\'une holding patrimoniale soumise à l\'IFI ?',
          options: [
            'Décote de contrôle 20% + décote liquidité 15% + usufruits temporaires',
            'Pacte Dutreil sur titres + engagement conservation 6 ans',
            'Donation-partage avec réserve d\'usufruit et clause de retour',
            'Fiducie-gestion avec bénéficiaire subsidiaire conditionnel'
          ],
          correct: 0
        },
        {
          question: 'Comment structurer une opération de LBO avec management package pour optimiser la fiscalité des dirigeants tout en respectant les nouvelles règles anti-abus ?',
          options: [
            'Attribution d\'actions gratuites avec période d\'acquisition 4 ans',
            'Souscription BSPCE avec exercise conditionnel à la performance',
            'Portage via holding personnelle avec CGA différé',
            'Mécanisme de ratchet avec seuils IRR progressifs'
          ],
          correct: 1
        },
        {
          question: 'En présence d\'un foyer fiscal multi-juridictionnel, comment appliquer les conventions fiscales pour éviter la double imposition sur les dividendes d\'une filiale luxembourgeoise ?',
          options: [
            'Régime mère-fille UE avec crédit d\'impôt résiduel',
            'Application directive 2011/96/UE + ruling préalable',
            'Structuration via société holding néerlandaise',
            'Mécanisme de transparence fiscale avec exit tax'
          ],
          correct: 1
        },
        {
          question: 'Dans une restructuration de groupe avec apport-scission, comment optimiser l\'imposition des plus-values tout en préservant les reports déficitaires ?',
          options: [
            'Apport à une société contrôlée sous régime spécial',
            'Scission partielle avec soulte limitée à 10%',
            'TUP préalable puis apport-fusion simultané',
            'Utilisation de l\'article 210 B du CGI'
          ],
          correct: 0
        },
        {
          question: 'Comment calculer l\'impact fiscal d\'une opération de carried interest dans un fonds d\'investissement soumis aux nouvelles règles de taxation ?',
          options: [
            'Taxation au barème progressif avec abattement de 50%',
            'Flat tax de 30% si détention > 3 ans et seuil de 120k€',
            'Plus-values professionnelles avec régime des dirigeants',
            'Régime spécial carried interest à 19% + prélèvements sociaux'
          ],
          correct: 1
        },
        {
          question: 'En optimisation de l\'IFI pour un patrimoine immobilier professionnel, quelle stratégie permet de maximiser l\'exonération tout en conservant le contrôle ?',
          options: [
            'Démembrement avec usufruit industriel et commercial',
            'SCI soumise à l\'IS avec gérance majoritaire',
            'Holding animatrice avec filiales immobilières opérationnelles',
            'Trust anglo-saxon avec settlor français non-résident'
          ],
          correct: 2
        },
        {
          question: 'Comment structurer une donation-partage transgénérationnelle pour optimiser les droits de mutation tout en gérant les rapports successoraux ?',
          options: [
            'Donation-partage cumulative avec réserve héréditaire',
            'Partage d\'ascendant avec soulte entre cohéritiers',
            'Donation-partage conjonctive grands-parents/petits-enfants',
            'Libéralités-partages en avancement d\'hoirie'
          ],
          correct: 2
        },
        {
          question: 'Dans une opération de private equity avec ratchet management, comment calculer l\'assiette fiscale des gains réalisés par les dirigeants ?',
          options: [
            'Plus-value = Prix de cession - Prix de souscription initial',
            'Gain imposable = Valeur action finale - Investissement réel',
            'Assiette = Différentiel de valorisation × % détention finale',
            'Base fiscale = IRR réalisé × Capital investi × Durée détention'
          ],
          correct: 1
        },
        {
          question: 'Comment optimiser la fiscalité d\'une cession d\'entreprise avec complément de prix (earn-out) étalé sur plusieurs exercices ?',
          options: [
            'Étalement fiscal sur 3 ans avec provision pour impôt',
            'Taxation intégrale année de cession sur base prix garanti',
            'Imposition au fur et à mesure des compléments perçus',
            'Option pour taxation globale avec abattement temporel'
          ],
          correct: 2
        },
        {
          question: 'En présence d\'un trust étranger avec bénéficiaire français, comment appliquer les règles de transparence fiscale et calculer l\'imposition ?',
          options: [
            'Taxation du constituant français sur les revenus distribués',
            'Transparence totale avec imposition directe du bénéficiaire',
            'Régime spécial trusts avec taxation différée + majoration',
            'Application conventions fiscales selon résidence du trust'
          ],
          correct: 2
        },
        {
          question: 'Comment calculer l\'avantage fiscal optimal d\'un investissement FCPI/FIP en tenant compte des nouvelles règles de plafonnement ?',
          options: [
            'Réduction d\'impôt = 25% × versement dans limite 12k€',
            'Avantage net = Réduction IR - Manque à gagner rendement',
            'Optimisation sous contrainte plafond niches fiscales 10k€',
            'Calcul TRI après impôt sur 8 ans avec hypothèses sortie'
          ],
          correct: 3
        },
        {
          question: 'Dans une opération de LBO avec ORA (Obligations Remboursables en Actions), comment traiter fiscalement la conversion et optimiser la structure ?',
          options: [
            'Plus-value différée jusqu\'à cession des actions reçues',
            'Taxation immédiate sur la différence valeur conversion/nominal',
            'Neutralité fiscale si conversion dans les 5 ans',
            'Régime spécial titres hybrides avec étalement possible'
          ],
          correct: 0
        }
      ]
    }
  };

  const intermediateQuizzes = {
    bourse: {
      title: 'Quiz Bourse - Niveau Intermédiaire',
      totalQuestions: 50,
      level: 'intermediate',
      questions: [
        {
          question: 'Quelle est la différence principale entre un ordre au marché et un ordre à cours limité ?',
          options: [
            'L\'ordre au marché garantit le prix d\'exécution',
            'L\'ordre à cours limité garantit l\'exécution immédiate',
            'L\'ordre au marché garantit l\'exécution mais pas le prix',
            'Il n\'y a aucune différence pratique'
          ],
          correct: 2
        },
        {
          question: 'Comment calcule-t-on le ratio cours/bénéfice (PER) d\'une action ?',
          options: [
            'Capitalisation boursière / Chiffre d\'affaires',
            'Prix de l\'action / Bénéfice par action',
            'Dividende / Prix de l\'action',
            'Actif net / Nombre d\'actions'
          ],
          correct: 1
        },
        {
          question: 'Qu\'est-ce qu\'un support en analyse technique ?',
          options: [
            'Un niveau de prix où la demande tend à dépasser l\'offre',
            'Un niveau de prix où l\'offre tend à dépasser la demande',
            'Le prix le plus haut atteint par une action',
            'Le volume moyen de transactions'
          ],
          correct: 0
        },
        {
          question: 'Que signifie la volatilité d\'une action ?',
          options: [
            'La tendance haussière ou baissière du cours',
            'L\'amplitude des variations de prix sur une période',
            'Le volume moyen de transactions quotidiennes',
            'La corrélation avec l\'indice de référence'
          ],
          correct: 1
        },
        {
          question: 'Comment fonctionne un stop-loss ?',
          options: [
            'Il limite automatiquement les gains potentiels',
            'Il déclenche une vente quand le cours baisse sous un seuil',
            'Il garantit un prix minimum de vente',
            'Il bloque temporairement les ordres de vente'
          ],
          correct: 1
        },
        {
          question: 'Qu\'est-ce que le ratio de Sharpe mesure ?',
          options: [
            'Le rendement d\'un investissement',
            'Le risque d\'un portefeuille',
            'La performance ajustée du risque',
            'La corrélation avec le marché'
          ],
          correct: 2
        },
        {
          question: 'Dans l\'analyse fondamentale, que représente le free cash flow ?',
          options: [
            'Les liquidités disponibles en banque',
            'Le cash flow opérationnel moins les investissements',
            'Les dividendes distribués aux actionnaires',
            'Le chiffre d\'affaires moins les charges'
          ],
          correct: 1
        },
        {
          question: 'Qu\'est-ce qu\'une résistance en analyse technique ?',
          options: [
            'Un niveau où les vendeurs deviennent plus actifs',
            'Un niveau où les acheteurs dominent',
            'Le cours le plus bas de la séance',
            'L\'écart entre le bid et l\'ask'
          ],
          correct: 0
        },
        {
          question: 'Comment calcule-t-on le rendement d\'un dividende ?',
          options: [
            'Dividende annuel / Prix de l\'action × 100',
            'Prix de l\'action / Dividende annuel × 100',
            'Dividende / Bénéfice par action × 100',
            'Capitalisation / Dividendes totaux × 100'
          ],
          correct: 0
        },
        {
          question: 'Qu\'est-ce que la capitalisation boursière ?',
          options: [
            'Le total des actifs de l\'entreprise',
            'Le nombre d\'actions × cours de l\'action',
            'Le chiffre d\'affaires annuel',
            'La valeur comptable de l\'entreprise'
          ],
          correct: 1
        },
        {
          question: 'Dans quel cas utilise-t-on un ordre stop ?',
          options: [
            'Pour acheter au meilleur prix disponible',
            'Pour limiter les pertes ou protéger les gains',
            'Pour garantir un prix d\'exécution fixe',
            'Pour acheter seulement si le prix monte'
          ],
          correct: 1
        },
        {
          question: 'Que mesure le coefficient beta d\'une action ?',
          options: [
            'Sa volatilité absolue',
            'Sa sensibilité aux mouvements du marché',
            'Son rendement potentiel',
            'Sa liquidité sur le marché'
          ],
          correct: 1
        }
      ]
    },
    crypto: {
      title: 'Quiz Crypto - Niveau Intermédiaire',
      totalQuestions: 50,
      level: 'intermediate',
      questions: [
        {
          question: 'Qu\'est-ce qu\'une blockchain ?',
          options: [
            'Un type de cryptomonnaie',
            'Une base de données décentralisée et sécurisée',
            'Un portefeuille numérique',
            'Un exchange de cryptomonnaies'
          ],
          correct: 1
        },
        {
          question: 'Que signifie "HODL" dans le monde crypto ?',
          options: [
            'Hold On for Dear Life - garder ses cryptos long terme',
            'High Order Digital Ledger',
            'Hash Output Data Link',
            'Hybrid Online Digital Lending'
          ],
          correct: 0
        },
        {
          question: 'Qu\'est-ce que le minage de cryptomonnaies ?',
          options: [
            'L\'achat de cryptomonnaies sur un exchange',
            'Le processus de validation des transactions et création de nouveaux blocs',
            'Le stockage de cryptomonnaies dans un portefeuille',
            'L\'échange de cryptomonnaies contre des devises fiat'
          ],
          correct: 1
        },
        {
          question: 'Quelle est la différence entre un hot wallet et un cold wallet ?',
          options: [
            'Hot wallet = connecté à internet, Cold wallet = hors ligne',
            'Hot wallet = gratuit, Cold wallet = payant',
            'Hot wallet = pour Bitcoin, Cold wallet = pour Ethereum',
            'Il n\'y a pas de différence'
          ],
          correct: 0
        },
        {
          question: 'Qu\'est-ce que DeFi (Decentralized Finance) ?',
          options: [
            'Un type de cryptomonnaie',
            'Services financiers basés sur la blockchain sans intermédiaires',
            'Une méthode de minage',
            'Un exchange centralisé'
          ],
          correct: 1
        },
        {
          question: 'Que représente la market cap d\'une cryptomonnaie ?',
          options: [
            'Le prix d\'un token',
            'Le nombre total de tokens × prix unitaire',
            'Le volume de trading quotidien',
            'Les frais de transaction'
          ],
          correct: 1
        },
        {
          question: 'Qu\'est-ce qu\'un smart contract ?',
          options: [
            'Un contrat papier numérisé',
            'Un programme qui s\'exécute automatiquement selon des conditions',
            'Un type de portefeuille crypto',
            'Une méthode de paiement'
          ],
          correct: 1
        },
        {
          question: 'Que signifie "staking" en crypto ?',
          options: [
            'Vendre ses cryptomonnaies',
            'Bloquer ses tokens pour sécuriser le réseau et recevoir des récompenses',
            'Acheter des NFTs',
            'Faire du trading à effet de levier'
          ],
          correct: 1
        },
        {
          question: 'Qu\'est-ce qu\'un exchange décentralisé (DEX) ?',
          options: [
            'Une plateforme d\'échange sans autorité centrale',
            'Un type de blockchain',
            'Un portefeuille crypto',
            'Une méthode de minage'
          ],
          correct: 0
        },
        {
          question: 'Que sont les gas fees sur Ethereum ?',
          options: [
            'Les frais pour créer un nouveau token',
            'Les coûts de transaction pour utiliser le réseau',
            'Les récompenses des mineurs',
            'Les frais d\'exchange'
          ],
          correct: 1
        },
        {
          question: 'Qu\'est-ce qu\'un NFT (Non-Fungible Token) ?',
          options: [
            'Une cryptomonnaie comme Bitcoin',
            'Un token unique représentant la propriété d\'un actif numérique',
            'Un type de smart contract',
            'Une méthode de minage'
          ],
          correct: 1
        },
        {
          question: 'Que signifie l\'acronyme "DYOR" ?',
          options: [
            'Do Your Own Research - faire ses propres recherches',
            'Diversify Your Online Resources',
            'Digital Yield Optimization Ratio',
            'Decentralized Yearly Operations Report'
          ],
          correct: 0
        }
      ]
    },
    immobilier: {
      title: 'Quiz Immobilier - Niveau Intermédiaire',
      totalQuestions: 50,
      level: 'intermediate',
      questions: [
        {
          question: 'Comment calcule-t-on la rentabilité brute d\'un investissement locatif ?',
          options: [
            '(Loyers annuels / Prix d\'achat) × 100',
            '(Loyers mensuels / Prix d\'achat) × 100',
            '(Prix d\'achat / Loyers annuels) × 100',
            '(Charges - Loyers) / Prix d\'achat'
          ],
          correct: 0
        },
        {
          question: 'Qu\'est-ce que l\'effet de levier en immobilier ?',
          options: [
            'Acheter plusieurs biens simultanément',
            'Utiliser un crédit pour amplifier sa capacité d\'investissement',
            'Vendre rapidement pour faire des profits',
            'Investir uniquement avec ses fonds propres'
          ],
          correct: 1
        },
        {
          question: 'Que représente le cash-flow en investissement immobilier ?',
          options: [
            'Le prix d\'achat du bien',
            'La différence entre les revenus locatifs et les charges',
            'La plus-value à la revente',
            'Valeur locative - Prix d\'achat'
          ],
          correct: 1
        },
        {
          question: 'Qu\'est-ce que la rentabilité nette d\'un investissement locatif ?',
          options: [
            'Loyers - (charges, taxes, intérêts) / Prix d\'achat',
            'Loyers annuels / Prix d\'achat',
            'Plus-value / Prix d\'achat',
            'Loyers / Mensualités de crédit'
          ],
          correct: 0
        },
        {
          question: 'Que signifie "meublé non professionnel" (MNP) ?',
          options: [
            'Location de moins de 3 mois par an',
            'Revenus locatifs inférieurs aux revenus professionnels',
            'Location sans contrat de bail',
            'Investissement sans apport personnel'
          ],
          correct: 1
        },
        {
          question: 'Comment fonctionne l\'amortissement comptable en location meublée ?',
          options: [
            'Déduction des charges réelles uniquement',
            'Dépréciation comptable du bien et du mobilier',
            'Réduction d\'impôt forfaitaire',
            'Exonération totale des revenus'
          ],
          correct: 1
        },
        {
          question: 'Qu\'est-ce qu\'une SCI (Société Civile Immobilière) ?',
          options: [
            'Un crédit immobilier spécialisé',
            'Une structure juridique pour détenir de l\'immobilier',
            'Un type d\'assurance habitation',
            'Une taxe sur les revenus locatifs'
          ],
          correct: 1
        },
        {
          question: 'Dans quels cas utilise-t-on le régime fiscal du déficit foncier ?',
          options: [
            'Quand les charges dépassent les revenus locatifs',
            'Pour les investissements neufs uniquement',
            'En cas de vente à perte',
            'Pour les résidences principales'
          ],
          correct: 0
        },
        {
          question: 'Que représente le GRM (Gross Rent Multiplier) ?',
          options: [
            'Prix d\'achat / Loyer annuel brut',
            'Loyer / Prix au m²',
            'Rendement net après impôts',
            'Ratio dette / fonds propres'
          ],
          correct: 0
        },
        {
          question: 'Qu\'est-ce que la loi Pinel ?',
          options: [
            'Réduction d\'impôt pour investissement locatif neuf',
            'Encadrement des loyers dans certaines zones',
            'Protection des locataires',
            'Taxe sur les logements vacants'
          ],
          correct: 0
        },
        {
          question: 'Comment évalue-t-on un bien immobilier par la méthode comparative ?',
          options: [
            'Actualisation des revenus futurs',
            'Comparaison avec des biens similaires vendus récemment',
            'Coût de reconstruction',
            'Valeur locative × multiplicateur'
          ],
          correct: 1
        },
        {
          question: 'Qu\'est-ce que la vacance locative ?',
          options: [
            'Période sans locataire entre deux baux',
            'Logement en mauvais état',
            'Réduction de loyer accordée au locataire',
            'Taxe sur les logements vides'
          ],
          correct: 0
        }
      ]
    },
    fiscalite: {
      title: 'Quiz Fiscalité - Niveau Intermédiaire',
      totalQuestions: 50,
      level: 'intermediate',
      questions: [
        {
          question: 'À partir de quel montant doit-on déclarer ses plus-values mobilières ?',
          options: [
            'Dès le premier euro',
            'À partir de 500€',
            'Seuil de cession annuel de 50 000€',
            'À partir de 1 000€'
          ],
          correct: 2
        },
        {
          question: 'Qu\'est-ce que l\'abattement pour durée de détention ?',
          options: [
            'Une réduction d\'impôt fixe',
            'Une réduction de la plus-value selon la durée de détention',
            'Une exonération totale après 5 ans',
            'Un crédit d\'impôt'
          ],
          correct: 1
        },
        {
          question: 'Comment fonctionne le PEA (Plan d\'Épargne en Actions) ?',
          options: [
            'Imposition immédiate des gains',
            'Exonération d\'impôt sur les gains après 5 ans de détention',
            'Réduction d\'impôt à l\'ouverture',
            'Déduction des versements du revenu imposable'
          ],
          correct: 1
        },
        {
          question: 'Que représente le quotient familial ?',
          options: [
            'Le nombre de personnes dans le foyer fiscal',
            'Le revenu moyen par personne du foyer',
            'Un mécanisme d\'atténuation de la progressivité de l\'impôt',
            'Une déduction forfaitaire'
          ],
          correct: 2
        },
        {
          question: 'Qu\'est-ce que la flat tax (PFU) ?',
          options: [
            'Prélèvement forfaitaire unique de 30% sur les revenus du capital',
            'Taxe sur les transactions financières',
            'Impôt forfaitaire pour les non-résidents',
            'Prélèvement à la source'
          ],
          correct: 0
        },
        {
          question: 'Dans quels cas peut-on opter pour l\'imposition au barème progressif ?',
          options: [
            'Jamais, la flat tax est obligatoire',
            'Quand cela est plus avantageux fiscalement',
            'Seulement pour les revenus supérieurs à 10 000€',
            'Uniquement pour les non-résidents'
          ],
          correct: 1
        },
        {
          question: 'Qu\'est-ce que l\'IFI (Impôt sur la Fortune Immobilière) ?',
          options: [
            'Taxe sur les revenus locatifs',
            'Impôt sur le patrimoine immobilier net supérieur à 1,3M€',
            'Taxe sur les plus-values immobilières',
            'Contribution sur les résidences secondaires'
          ],
          correct: 1
        },
        {
          question: 'Comment fonctionne le crédit d\'impôt pour emploi à domicile ?',
          options: [
            'Déduction de 100% des dépenses',
            'Crédit d\'impôt de 50% des dépenses dans certaines limites',
            'Réduction forfaitaire de 1000€',
            'Exonération des charges sociales'
          ],
          correct: 1
        },
        {
          question: 'Qu\'est-ce que la décote en matière d\'impôt sur le revenu ?',
          options: [
            'Une réduction pour les revenus modestes',
            'Un abattement proportionnel',
            'Une exonération totale',
            'Un étalement du paiement'
          ],
          correct: 0
        },
        {
          question: 'Comment sont imposés les dividendes en France ?',
          options: [
            'Exonération totale',
            'Flat tax 30% ou barème progressif avec abattement 40%',
            'Imposition au taux de 19% uniquement',
            'Taxation progressive sans abattement'
          ],
          correct: 1
        },
        {
          question: 'Qu\'est-ce que l\'avoir fiscal ?',
          options: [
            'Un crédit d\'impôt sur les dividendes (supprimé)',
            'Une avance sur impôt',
            'Un report de déficit',
            'Une provision pour impôt'
          ],
          correct: 0
        },
        {
          question: 'Dans quel délai doit-on déclarer une plus-value immobilière ?',
          options: [
            'Dans les 30 jours suivant la vente',
            'Lors de la signature de l\'acte de vente',
            'Avant le 31 décembre de l\'année',
            'Dans les 3 mois suivant la vente'
          ],
          correct: 1
        }
      ]
    }
  };

  const formations = [
    {
      id: 1,
      title: 'Bourse Débutant',
      subtitle: 'Bases des marchés financiers et analyse technique',
      description: 'Apprenez les fondamentaux des marchés boursiers avec des simulations pratiques et des stratégies éprouvées.',
      category: 'bourse',
      duration: '6 semaines',
      level: 'Débutant',
      progress: 0,
      lessons: 24,
      students: 1847,
      rating: 4.8,
      price: 'Gratuit',
      image: 'https://readdy.ai/api/search-image?query=stock%20market%20education%20interface%20with%20financial%20charts%2C%20graphs%2C%2202020, BACS) dans le calcul de la valeur terminale ?',
      features: ['Bases du trading', 'Analyse technique', 'Gestion des risques', 'Simulations pratiques']
    },
    {
      id: 2,
      title: 'Bourse Avancée',
      subtitle: 'Stratégies professionnelles et algorithmes',
      description: 'Maîtrisez les techniques avancées de trading avec des outils professionnels et des algorithmes personnalisés.',
      category: 'bourse',
      duration: '10 semaines',
      level: 'Avancé',
      progress: 0,
      lessons: 45,
      students: 892,
      rating: 4.9,
      price: '297€',
      image: 'https://readdy.ai/api/search-image?query=advanced%20stock%20trading%20platform%20with%20complex%20charts%2C%20algorithms%2C%20and%20professional%20analytics%20tools%2C%20sophisticated%20dark%20interface%20with%20multiple%20screens%2C%20expert%20level%20financial%20trading%20setup&width=400&height=240&seq=stock-advanced-001&orientation=landscape',
      features: ['Algorithmes de trading', 'Analyse quantitative', 'Options avancées', 'Backtesting']
    },
    {
      id: 3,
      title: 'Crypto-monnaies',
      subtitle: 'Blockchain et investissement crypto',
      description: 'Découvrez l\'univers des cryptomonnaies, de la blockchain et des opportunités d\'investissement.',
      category: 'crypto',
      duration: '8 semaines',
      level: 'Intermédiaire',
      progress: 0,
      lessons: 32,
      students: 2156,
      rating: 4.7,
      price: '197€',
      image: 'https://readdy.ai/api/search-image?query=cryptocurrency%20and%20blockchain%20education%20interface%20with%20bitcoin%2C%20ethereum%20charts%2C%20modern%22020, BACS) dans le calcul de la valeur terminale ?',
      features: ['Blockchain', 'Trading crypto', 'Portefeuilles', 'Analyse fondamentale']
    },
    {
      id: 4,
      title: 'Immobilier Locatif',
      subtitle: 'Investissement et gestion patrimoniale',
      description: 'Optimisez vos investissements immobiliers avec nos outils d\'analyse et simulateurs de rentabilité.',
      category: 'immobilier',
      duration: '12 semaines',
      level: 'Intermédiaire',
      progress: 0,
      lessons: 38,
      students: 1423,
      rating: 4.6,
      price: '397€',
      image: 'https://readdy.ai/api/search-image?query=real%20estate%20investment%20education%20with%20property%20analysis%20tools%2C%20rental%20yield%20calculators%2C%20and%20market%20data%2C%22020, BACS) dans le calcul de la valeur terminale ?',
      features: ['Analyse de rentabilité', 'Gestion locative', 'Fiscalité', 'Financement']
    },
    {
      id: 5,
      title: 'Fiscalité Optimisée',
      subtitle: 'Stratégies d\'optimisation fiscale',
      description: 'Apprenez à optimiser votre fiscalité avec des stratégies légales et des outils de simulation.',
      category: 'fiscalite',
      duration: '6 semaines',
      level: 'Avancé',
      progress: 0,
      lessons: 28,
      students: 756,
      rating: 4.8,
      price: '247€',
      image: 'https://readdy.ai/api/search-image?query=tax%20optimization%20education%20interface%20with%20calculators%2C%20forms%2C%20and%22020, BACS) dans le calcul de la valeur terminale ?',
      features: ['Optimisation patrimoniale', 'Transmission', 'Investissement', 'Simulations fiscales']
    },
    {
      id: 6,
      title: 'Analyse Technique',
      subtitle: 'Maîtrise des graphiques et indicateurs',
      description: 'Perfectionnez vos compétences en analyse technique avec des outils professionnels.',
      category: 'bourse',
      duration: '8 semaines',
      level: 'Intermédiaire',
      progress: 0,
      lessons: 35,
      students: 1654,
      rating: 4.9,
      price: '197€',
      image: 'https://readdy.ai/api/search-image?query=technical%20analysis%20education%20with%20candlestick%20charts%2C%20indicators%2C%20and%20trading%20patterns%2C%20professional%22020, BACS) dans le calcul de la valeur terminale ?',
      features: ['Graphiques', 'Indicateurs techniques', 'Patterns de trading', 'Gestion du risque']
    }
  ];

  const filteredFormations = selectedCategory === 'all'
    ? formations
    : formations.filter(f => f.category === selectedCategory);

  const getLevelColor = (level) => {
    switch(level) {
      case 'Débutant':
        return 'bg-green-500/20 text-green-400';
      case 'Intermédiaire':
        return 'bg-yellow-500/20 text-yellow-400';
      case 'Avancé':
        return 'bg-red-500/20 text-red-400';
      default:
        return 'bg-gray-500/20 text-gray-400';
    }
  };

  const openQuiz = (category, level = 'expert') => {
    const quizData = level === 'expert' ? complexQuizzes[category] : intermediateQuizzes[category];
    const randomQuestions = getRandomQuestions(quizData.questions, 10);
    setCurrentQuiz({
      ...quizData,
      questions: randomQuestions
    });
    setShowQuiz(true);
  };

  const QuizModal = ({ quiz, onClose }) => {
    const [currentQuestion, setCurrentQuestion] = useState(0);
    const [selectedAnswers, setSelectedAnswers] = useState({});
    const [showResults, setShowResults] = useState(false);

    const handleAnswerSelect = (questionIndex, answerIndex) => {
      setSelectedAnswers(prev => ({
        ...prev,
        [questionIndex]: answerIndex
      }));
    };

    const calculateScore = () => {
      let correct = 0;
      quiz.questions.forEach((question, index) => {
        if (selectedAnswers[index] === question.correct) {
          correct++;
        }
      });
      return (correct / quiz.questions.length) * 100;
    };

    const nextQuestion = () => {
      if (currentQuestion < quiz.questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
      } else {
        setShowResults(true);
      }
    };

    const startNewQuiz = () => {
      setShowResults(false);
      setCurrentQuestion(0);
      setSelectedAnswers({});
      
      const category = Object.keys(complexQuizzes).find(key =>
        complexQuizzes[key].title === quiz.title
      ) || Object.keys(intermediateQuizzes).find(key =>
        intermediateQuizzes[key].title === quiz.title
      );

      if (category) {
        const isExpert = complexQuizzes[category]?.title === quiz.title;
        const quizData = isExpert ? complexQuizzes[category] : intermediateQuizzes[category];

        const randomQuestions = getRandomQuestions(quizData.questions, 10);
        setCurrentQuiz({
          ...quizData,
          questions: randomQuestions
        });
      }
    };

    if (showResults) {
      const score = calculateScore();
      const correctCount = Math.round(score * quiz.questions.length / 100);

      // Démarrer automatiquement un nouveau quiz après 3 secondes
      setTimeout(() => {
        startNewQuiz();
      }, 3000);

      return (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-800 rounded-2xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="text-center">
              <h2 className="text-2xl font-bold text-white mb-4">Résultats du Quiz</h2>
              <div className="text-6xl font-bold text-yellow-400 mb-4">
                {score.toFixed(0)}%
              </div>
              <p className="text-gray-300 mb-6">
                Vous avez répondu correctement à {correctCount} questions sur {quiz.questions.length}
              </p>
              <p className="text-gray-400 mb-6">
                {score >= 80 ? 'Excellent ! Vous maîtrisez parfaitement le sujet.' :
                 score >= 60 ? 'Bien ! Quelques révisions peuvent être bénéfiques.' :
                 'Il est recommandé de revoir les concepts fondamentaux.'}
              </p>
              <div className="bg-yellow-500/20 text-yellow-400 px-4 py-2 rounded-lg mb-6">
                <p className="text-sm">
                  Nouveau quiz automatique dans 3 secondes avec 10 nouvelles questions...
                </p>
              </div>
              <div className="flex gap-4 justify-center">
                <button
                  onClick={startNewQuiz}
                  className="bg-blue-500 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-400 transition-colors whitespace-nowrap"
                >
                  Nouveau Quiz Maintenant
                </button>
                <button
                  onClick={onClose}
                  className="bg-yellow-500 text-black px-6 py-3 rounded-lg font-semibold hover:bg-yellow-400 transition-colors whitespace-nowrap"
                >
                  Fermer
                </button>
              </div>
            </div>
          </div>
        </div>
      );
    }

    const question = quiz.questions[currentQuestion];

    return (
      <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
        <div className="bg-gray-800 rounded-2xl p-8 max-w-4xl w-full max-h-[95vh] overflow-y-auto">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-bold text-white">{quiz.title}</h2>
              <p className="text-gray-400 text-sm mt-1">
                10 questions sélectionnées aléatoirement parmi {quiz.totalQuestions} disponibles
              </p>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white transition-colors"
            >
              <i className="ri-close-line text-2xl"></i>
            </button>
          </div>

          <div className="mb-6">
            <div className="flex justify-between items-center mb-4">
              <span className="text-yellow-400 font-semibold">
                Question {currentQuestion + 1} / {quiz.questions.length}
              </span>
              <div className="bg-gray-700 rounded-full h-2 w-48">
                <div 
                  className="bg-yellow-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${((currentQuestion + 1) / quiz.questions.length) * 100}%` }}
                ></div>
              </div>
            </div>

            <h3 className="text-xl text-white mb-6 leading-relaxed">
              {question.question}
            </h3>

            <div className="space-y-4">
              {question.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleAnswerSelect(currentQuestion, index)}
                  className={`w-full text-left p-4 rounded-lg border-2 transition-all ${ 
                    selectedAnswers[currentQuestion] === index
                      ? 'border-yellow-500 bg-yellow-500/10 text-yellow-400'
                      : 'border-gray-600 bg-gray-700/50 text-gray-300 hover:border-gray-500'
                  }`}
                >
                  <div className="flex items-start">
                    <span className="font-semibold mr-3 text-lg">
                      {String.fromCharCode(65 + index)}.
                    </span>
                    <span className="flex-1 leading-relaxed">{option}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="flex justify-between">
            <button
              onClick={() => setCurrentQuestion(Math.max(0, currentQuestion - 1))}
              disabled={currentQuestion === 0}
              className="bg-gray-700 text-gray-300 px-6 py-3 rounded-lg font-semibold hover:bg-gray-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Précédent
            </button>
            <button
              onClick={nextQuestion}
              disabled={selectedAnswers[currentQuestion] === undefined}
              className="bg-yellow-500 text-black px-6 py-3 rounded-lg font-semibold hover:bg-yellow-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {currentQuestion === quiz.questions.length - 1 ? 'Terminer' : 'Suivant'}
            </button>
          </div>
        </div>
      </div>
    );
  };

  const getRandomQuestions = (allQuestions, count = 10) => {
    const questionsCopy = [...allQuestions];
    for (let i = questionsCopy.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [questionsCopy[i], questionsCopy[j]] = [questionsCopy[j], questionsCopy[i]];
    }
    return questionsCopy.slice(0, count);
  };

  return (
    <div className="min-h-screen bg-gray-900">
      <header className="bg-black/80 border-b border-gray-800 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="text-2xl font-bold text-white">
              <span style={{ fontFamily: '"Pacifico", serif' }}>logo</span>
            </Link>
            <nav className="hidden md:flex space-x-8">
              <Link href="/dashboard" className="text-gray-300 hover:text-yellow-400 transition-colors">
                Dashboard
              </Link>
              <Link href="/academy" className="text-gray-300 hover:text-yellow-400 transition-colors">
                Académie
              </Link>
              <Link href="/indicators" className="text-gray-300 hover:text-yellow-400 transition-colors">
                Indicateurs
              </Link>
            </nav>
            <div className="flex items-center space-x-4">
              <button className="bg-yellow-500 text-black px-6 py-2 rounded-lg font-semibold hover:bg-yellow-400 transition-colors whitespace-nowrap">
                Mon Profil
              </button>
            </div>
          </div>
        </div>
      </header>

      <section className="relative py-20 bg-gradient-to-br from-gray-900 via-black to-gray-900">
        <div className="absolute inset-0 bg-gradient-to-r from-yellow-500/10 to-transparent"></div>
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
              Formation <span className="text-yellow-400">Interactive</span>
            </h1>
            <p className="text-xl text-gray-400 mb-8 max-w-2xl mx-auto">
              Apprenez la finance, la bourse et l'investissement avec nos modules gamifiés et nos simulateurs pratiques.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-yellow-500 text-black px-8 py-4 rounded-lg font-semibold text-lg hover:bg-yellow-400 transition-colors whitespace-nowrap">
                Commencer Gratuitement
              </button>
              <button className="bg-transparent border-2 border-yellow-500 text-yellow-400 px-8 py-4 rounded-lg font-semibold text-lg hover:bg-yellow-500 hover:text-black transition-colors whitespace-nowrap">
                Voir les Formations
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 bg-black/30">
        <div className="container mx-auto px-6">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-white mb-4">
              Quiz <span className="text-yellow-400">Intermédiaires</span>
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Testez vos connaissances avec nos quiz niveau intermédiaire. 10 questions sélectionnées aléatoirement parmi 50 par thématique.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {Object.entries(intermediateQuizzes).map(([category, quiz]) => (
              <div key={category} className="bg-gray-800/50 rounded-xl border border-gray-700/50 overflow-hidden hover:border-yellow-500/30 transition-all group">
                <div className="text-center">
                  <div className="w-16 h-16 bg-yellow-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className={`${categories.find(c => c.id === category)?.icon} text-2xl text-yellow-400`}></i>
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2">{quiz.title}</h3>
                  <p className="text-gray-400 text-sm mb-2">
                    {quiz.totalQuestions} questions disponibles
                  </p>
                  <p className="text-yellow-400 text-xs mb-4">
                    10 questions aléatoires par session
                  </p>
                  <button
                    onClick={() => openQuiz(category, 'intermediate')}
                    className="bg-yellow-500 text-black px-4 py-2 rounded-lg font-semibold hover:bg-yellow-400 transition-colors whitespace-nowrap text-sm"
                  >
                    Commencer Quiz
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 bg-black/30">
        <div className="container mx-auto px-6">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-white mb-4">
              Quiz <span className="text-red-400">Experts</span>
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Testez vos connaissances avec nos quiz complexes niveau expert. 10 questions sélectionnées aléatoirement parmi 50 par thématique.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {Object.entries(complexQuizzes).map(([category, quiz]) => (
              <div key={category} className="bg-gray-800/50 rounded-xl border border-gray-700/50 p-6 hover:border-red-500/30 transition-all group">
                <div className="text-center">
                  <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className={`${categories.find(c => c.id === category)?.icon} text-2xl text-red-400`}></i>
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2">{quiz.title}</h3>
                  <p className="text-gray-400 text-sm mb-2">
                    {quiz.totalQuestions} questions disponibles
                  </p>
                  <p className="text-red-400 text-xs mb-4">
                    10 questions aléatoires par session
                  </p>
                  <button
                    onClick={() => openQuiz(category, 'expert')}
                    className="bg-red-500 text-white px-4 py-2 rounded-lg font-semibold hover:bg-red-400 transition-colors whitespace-nowrap text-sm"
                  >
                    Commencer Quiz
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-black/30">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-white mb-4">
              Choisissez votre <span className="text-yellow-400">Domaine</span>
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              Sélectionnez une catégorie pour découvrir les formations disponibles
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {categories.filter(cat => cat.id !== 'all').map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`relative group h-64 rounded-2xl border-2 transition-all duration-300 overflow-hidden cursor-pointer ${ 
                  selectedCategory === category.id
                    ? 'border-yellow-500 bg-yellow-500/20'
                    : 'border-gray-700 bg-gray-800/50 hover:border-yellow-500/50'
                }`}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-yellow-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>

                <div className="relative h-full flex flex-col items-center justify-center p-8">
                  <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-6 transition-all ${ 
                    selectedCategory === category.id
                      ? 'bg-yellow-500 text-black'
                      : 'bg-gray-700 text-yellow-400 group-hover:bg-yellow-500 group-hover:text-black'
                  }`}>
                    <i className={`${category.icon} text-3xl`}></i>
                  </div>

                  <h3 className="text-2xl font-bold text-white mb-3">{category.name}</h3>

                  <p className="text-gray-400 text-center text-sm mb-4">
                    {category.id === 'bourse' && 'Marchés financiers, analyse technique et stratégies de trading'}
                    {category.id === 'crypto' && 'Blockchain, cryptomonnaies et investissement numérique'}
                    {category.id === 'immobilier' && 'Investissement locatif et gestion patrimoniale'}
                    {category.id === 'fiscalite' && 'Optimisation fiscale et stratégies légales'}
                  </p>

                  <div className="text-yellow-400 font-semibold">
                    {formations.filter(f => f.category === category.id).length} formations disponibles
                  </div>
                </div>
              </button>
            ))}

            <button
              onClick={() => setSelectedCategory('all')}
              className={`relative group h-64 rounded-2xl border-2 transition-all duration-300 overflow-hidden cursor-pointer ${ 
                selectedCategory === 'all'
                  ? 'border-yellow-500 bg-yellow-500/20'
                  : 'border-gray-700 bg-gray-800/50 hover:border-yellow-500/50'
              }`}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-yellow-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>

              <div className="relative h-full flex flex-col items-center justify-center p-8">
                <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-6 transition-all ${ 
                  selectedCategory === 'all'
                    ? 'bg-yellow-500 text-black'
                    : 'bg-gray-700 text-yellow-400 group-hover:bg-yellow-500 group-hover:text-black'
                }`}>
                  <i className="ri-apps-line text-3xl"></i>
                </div>

                <h3 className="text-2xl font-bold text-white mb-3">Toutes les formations</h3>

                <p className="text-gray-400 text-center text-sm mb-4">
                  Découvrez l'ensemble de nos formations disponibles
                </p>

                <div className="text-yellow-400 font-semibold">
                  {formations.length} formations au total
                </div>
              </div>
            </button>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-900">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">
              Formations 
              <span className="text-yellow-400">
                {selectedCategory === 'all' ? ' Disponibles' : ` ${categories.find(c => c.id === selectedCategory)?.name}`}
              </span>
            </h2>
            <p className="text-gray-400">
              {filteredFormations.length} formation{filteredFormations.length > 1 ? 's' : ''} 
              {selectedCategory === 'all' ? '' : ` en ${categories.find(c => c.id === selectedCategory)?.name.toLowerCase()}`}
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredFormations.map((formation) => (
              <div key={formation.id} className="bg-gray-800/50 rounded-2xl border border-gray-700/50 overflow-hidden hover:border-yellow-500/30 transition-all group">
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={formation.image}
                    alt={formation.title}
                    className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                  <div className="absolute top-4 left-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getLevelColor(formation.level)}`}>
                      {formation.level}
                    </span>
                  </div>
                  <div className="absolute top-4 right-4">
                    <span className="bg-yellow-500 text-black px-3 py-1 rounded-full text-sm font-bold">
                      {formation.price}
                    </span>
                  </div>
                </div>

                <div className="p-6">
                  <h3 className="text-xl font-bold text-white mb-2">{formation.title}</h3>
                  <p className="text-yellow-400 text-sm mb-3">{formation.subtitle}</p>
                  <p className="text-gray-400 text-sm mb-4 line-clamp-2">{formation.description}</p>

                  <div className="flex items-center justify-between mb-4 text-sm text-gray-400">
                    <div className="flex items-center space-x-4">
                      <span className="flex items-center">
                        <i className="ri-time-line mr-1"></i>
                        {formation.duration}
                      </span>
                      <span className="flex items-center">
                        <i className="ri-book-line mr-1"></i>
                        {formation.lessons} leçons
                      </span>
                    </div>
                    <div className="flex items-center">
                      <i className="ri-star-fill text-yellow-400 mr-1"></i>
                      <span className="text-white">{formation.rating}</span>
                    </div>
                  </div>

                  <div className="mb-6">
                    <div className="flex flex-wrap gap-2">
                      {formation.features.slice(0, 3).map((feature, index) => (
                        <span key={index} className="bg-gray-700/50 text-gray-300 px-2 py-1 rounded text-xs">
                          {feature}
                        </span>
                      ))}
                      {formation.features.length > 3 && (
                        <span className="bg-gray-700/50 text-gray-300 px-2 py-1 rounded text-xs">
                          +{formation.features.length - 3} autres
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-gray-400">Progression</span>
                      <span className="text-sm text-yellow-400" suppressHydrationWarning={true}>
                        {formation.progress}%
                      </span>
                    </div>
                    <div className="w-full bg-gray-700/50 rounded-full h-2">
                      <div 
                        className="bg-yellow-500 h-2 rounded-full transition-all duration-500"
                        style={{ width: `${formation.progress}%` }}
                      ></div>
                    </div>
                  </div>

                  <button className="w-full bg-yellow-500 text-black py-3 rounded-lg font-semibold hover:bg-yellow-400 transition-colors whitespace-nowrap">
                    {formation.progress > 0 ? 'Continuer' : 'Commencer'}
                  </button>

                  <div className="mt-4 text-center">
                    <span className="text-xs text-gray-500" suppressHydrationWarning={true}>
                      {formation.students.toLocaleString()} étudiants inscrits
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-r from-yellow-500/10 to-transparent">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Prêt à commencer votre formation ?
          </h2>
          <p className="text-gray-400 text-lg mb-8 max-w-2xl mx-auto">
            Rejoignez des milliers d'étudiants qui ont déjà transformé leur approche des marchés financiers.
          </p>
          <button className="bg-yellow-500 text-black px-8 py-4 rounded-lg font-semibold text-lg hover:bg-yellow-400 transition-colors whitespace-nowrap">
            Découvrir toutes les formations
          </button>
        </div>
      </section>

      {showQuiz && currentQuiz && (
        <QuizModal
          quiz={currentQuiz}
          onClose={() => {
            setShowQuiz(false);
            setCurrentQuiz(null);
          }}
        />
      )}
    </div>
  );
}
