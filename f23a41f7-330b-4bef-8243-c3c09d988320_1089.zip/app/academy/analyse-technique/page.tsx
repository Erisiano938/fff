
'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function AnalyseTechniquePage() {
  const [selectedCategory, setSelectedCategory] = useState('Tous');
  const [searchTerm, setSearchTerm] = useState('');

  const categories = ['Tous', 'Indicateurs', 'Patterns', 'Support/Résistance', 'Chandelles', 'Stratégies'];

  const videos = [
    {
      id: '1',
      title: 'Introduction à l\'Analyse Technique',
      description: 'Les fondamentaux de l\'analyse graphique et l\'importance des prix dans l\'analyse des marchés.',
      duration: '16:30',
      category: 'Indicateurs',
      level: 'Débutant',
      views: '3.2k',
      thumbnail: 'https://readdy.ai/api/search-image?query=Technical%20analysis%20fundamentals%20with%20candlestick%20charts%2C%20trend%20lines%2C%20trading%20graphs%20on%20computer%20screens%2C%20professional%20financial%20analysis%20workspace%2C%20blue%20and%20cyan%20color%20scheme%2C%20modern%20trading%20environment&width=640&height=360&seq=tech-intro&orientation=landscape'
    },
    {
      id: '2',
      title: 'Moyennes Mobiles et Tendances',
      description: 'Maîtrisez les moyennes mobiles simples et exponentielles pour identifier les tendances.',
      duration: '22:15',
      category: 'Indicateurs',
      level: 'Débutant',
      views: '2.8k',
      thumbnail: 'https://readdy.ai/api/search-image?query=Moving%20averages%20on%20financial%20charts%20with%20trend%20lines%2C%20exponential%20and%20simple%20moving%20averages%20visualization%2C%20price%20action%20analysis%2C%20professional%20trading%20interface%2C%20blue%20and%20teal%20color%20palette&width=640&height=360&seq=moving-averages&orientation=landscape'
    },
    {
      id: '3',
      title: 'RSI et Oscillateurs de Momentum',
      description: 'Utilisez le RSI, MACD et autres oscillateurs pour détecter les retournements.',
      duration: '19:45',
      category: 'Indicateurs',
      level: 'Intermédiaire',
      views: '2.1k',
      thumbnail: 'https://readdy.ai/api/search-image?query=RSI%20and%20MACD%20oscillators%20on%20trading%20charts%2C%20momentum%20indicators%20with%20overbought%20oversold%20signals%2C%20technical%20analysis%20tools%2C%20professional%20trading%20platform%2C%20blue%20and%20navy%20color%20scheme&width=640&height=360&seq=rsi-oscillators&orientation=landscape'
    },
    {
      id: '4',
      title: 'Patterns de Retournement',
      description: 'Identifiez les têtes-épaules, doubles tops/bottoms et autres patterns de retournement.',
      duration: '24:18',
      category: 'Patterns',
      level: 'Intermédiaire',
      views: '1.9k',
      thumbnail: 'https://readdy.ai/api/search-image?query=Chart%20patterns%20analysis%20with%20head%20and%20shoulders%2C%20double%20tops%20and%20bottoms%20formations%2C%20reversal%20patterns%20on%20price%20charts%2C%20technical%20analysis%20education%2C%20blue%20and%20azure%20color%20palette&width=640&height=360&seq=reversal-patterns&orientation=landscape'
    },
    {
      id: '5',
      title: 'Support et Résistance Dynamiques',
      description: 'Tracez et utilisez efficacement les niveaux de support et résistance.',
      duration: '20:35',
      category: 'Support/Résistance',
      level: 'Intermédiaire',
      views: '2.4k',
      thumbnail: 'https://readdy.ai/api/search-image?query=Support%20and%20resistance%20levels%20on%20trading%20charts%2C%20horizontal%20lines%20marking%20key%20price%20levels%2C%20dynamic%20support%20resistance%20analysis%2C%20professional%20chart%20analysis%2C%20blue%20and%20cyan%20color%20scheme&width=640&height=360&seq=support-resistance&orientation=landscape'
    },
    {
      id: '6',
      title: 'Analyse des Chandeliers Japonais',
      description: 'Décodez les patterns de chandelles : doji, marteau, étoile du soir et plus.',
      duration: '26:42',
      category: 'Chandelles',
      level: 'Avancé',
      views: '1.7k',
      thumbnail: 'https://readdy.ai/api/search-image?query=Japanese%20candlestick%20patterns%20analysis%20with%20doji%2C%20hammer%2C%20shooting%20star%20formations%2C%20candlestick%20chart%20patterns%2C%20technical%20analysis%20education%2C%20blue%20and%20indigo%20color%20palette&width=640&height=360&seq=candlestick-patterns&orientation=landscape'
    },
    {
      id: '7',
      title: 'Fibonacci et Retracements',
      description: 'Utilisez les niveaux de Fibonacci pour anticiper les retracements et extensions.',
      duration: '18:55',
      category: 'Support/Résistance',
      level: 'Avancé',
      views: '1.5k',
      thumbnail: 'https://readdy.ai/api/search-image?query=Fibonacci%20retracement%20levels%20on%20trading%20charts%2C%20golden%20ratio%20analysis%2C%20price%20retracement%20tools%2C%20technical%20analysis%20with%20mathematical%20precision%2C%20blue%20and%20turquoise%20color%20scheme&width=640&height=360&seq=fibonacci&orientation=landscape'
    },
    {
      id: '8',
      title: 'Stratégies de Breakout',
      description: 'Développez des stratégies rentables basées sur les cassures de niveaux clés.',
      duration: '23:10',
      category: 'Stratégies',
      level: 'Avancé',
      views: '1.3k',
      thumbnail: 'https://readdy.ai/api/search-image?query=Breakout%20trading%20strategies%20with%20price%20breaking%20through%20resistance%20levels%2C%20volume%20analysis%2C%20trading%20signals%20and%20entry%20points%2C%20professional%20strategy%20development%2C%20blue%20and%20steel%20color%20palette&width=640&height=360&seq=breakout-strategies&orientation=landscape'
    },
    {
      id: '9',
      title: 'Volume et Force du Mouvement',
      description: 'Analysez le volume pour confirmer la validité des mouvements de prix.',
      duration: '21:28',
      category: 'Indicateurs',
      level: 'Avancé',
      views: '1.8k',
      thumbnail: 'https://readdy.ai/api/search-image?query=Volume%20analysis%20on%20trading%20charts%20with%20volume%20bars%2C%20price-volume%20correlation%2C%20volume%20indicators%20and%20momentum%20confirmation%2C%20technical%20analysis%20tools%2C%20blue%20and%20cobalt%20color%20scheme&width=640&height=360&seq=volume-analysis&orientation=landscape'
    }
  ];

  const filteredVideos = videos.filter(video => {
    const matchesCategory = selectedCategory === 'Tous' || video.category === selectedCategory;
    const matchesSearch = (video.title || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (video.description || '').toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const stats = [
    { label: 'Formations', value: '12', icon: 'ri-play-circle-line' },
    { label: 'Heures de contenu', value: '6.5h', icon: 'ri-time-line' },
    { label: 'Niveau', value: 'Tous niveaux', icon: 'ri-bar-chart-line' },
    { label: 'Certificat', value: 'Inclus', icon: 'ri-award-line' }
  ];

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-br from-blue-900/20 to-cyan-900/20 border-b border-blue-500/20">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center">
            {/* Bouton retour */}
            <div className="mb-6">
              <Link 
                href="/academy" 
                className="inline-flex items-center px-4 py-2 text-blue-400 hover:text-blue-300 transition-colors cursor-pointer"
              >
                <i className="ri-arrow-left-line mr-2"></i>
                Retour à l'Académie
              </Link>
            </div>

            <div className="inline-flex items-center gap-2 bg-blue-500/20 border border-blue-500/30 rounded-full px-4 py-2 mb-6">
              <i className="ri-line-chart-line text-blue-400"></i>
              <span className="text-blue-300 text-sm font-medium">Formation Spécialisée</span>
            </div>
            
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
              Analyse <span className="text-blue-400">Technique</span>
            </h1>
            
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              Maîtrisez l'art de lire les graphiques et d'anticiper les mouvements de prix. 
              Apprenez les indicateurs, patterns et stratégies des traders professionnels.
            </p>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
              {stats.map((stat, index) => (
                <div key={index} className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-4">
                  <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center mb-3 mx-auto">
                    <i className={`${stat.icon} text-blue-400 text-lg`}></i>
                  </div>
                  <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
                  <div className="text-sm text-gray-400">{stat.label}</div>
                </div>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap">
                Commencer la Formation
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Filters Section */}
      <section className="py-8 bg-gray-800/50 border-b border-gray-700">
        <div className="container mx-auto px-6">
          <div className="flex flex-col lg:flex-row gap-6 items-center justify-between">
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap ${
                    selectedCategory === category
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
            
            <div className="relative w-full lg:w-80">
              <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
              <input
                type="text"
                placeholder="Rechercher une formation..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-500 text-sm"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Videos Grid */}
      <section className="py-12">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredVideos.map((video) => (
              <div key={video.id} className="bg-gray-800 border border-gray-700 rounded-xl overflow-hidden hover:border-blue-500/50 transition-all duration-300 group">
                <div className="relative">
                  <img
                    src={video.thumbnail}
                    alt={video.title}
                    className="w-full h-48 object-cover object-top"
                  />
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-all duration-300"></div>
                  <div className="absolute top-4 left-4">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      video.level === 'Débutant' ? 'bg-green-500/20 text-green-400 border border-green-500/30' :
                      video.level === 'Intermédiaire' ? 'bg-orange-500/20 text-orange-400 border border-orange-500/30' :
                      'bg-red-500/20 text-red-400 border border-red-500/30'
                    }`}>
                      {video.level}
                    </span>
                  </div>
                  <div className="absolute bottom-4 right-4 bg-black/80 text-white px-2 py-1 rounded text-sm">
                    {video.duration}
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="w-16 h-16 bg-blue-500/90 rounded-full flex items-center justify-center">
                      <i className="ri-play-fill text-white text-2xl"></i>
                    </div>
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs text-blue-400 bg-blue-500/20 border border-blue-500/30 px-2 py-1 rounded">
                      {video.category}
                    </span>
                    <span className="text-xs text-gray-500">{video.views} vues</span>
                  </div>
                  
                  <h3 className="text-lg font-bold text-white mb-2 group-hover:text-blue-400 transition-colors">
                    {video.title}
                  </h3>
                  
                  <p className="text-gray-400 text-sm leading-relaxed mb-4">
                    {video.description}
                  </p>
                  
                  <button className="flex items-center gap-2 text-blue-400 hover:text-blue-300 font-medium text-sm whitespace-nowrap">
                    <i className="ri-play-circle-line"></i>
                    Regarder maintenant
                  </button>
                </div>
              </div>
            ))}

            {filteredVideos.length === 0 && (
              <div className="text-center py-12">
                <i className="ri-search-line text-6xl text-gray-600 mb-4"></i>
                <h3 className="text-xl font-bold text-gray-400 mb-2">Aucune formation trouvée</h3>
                <p className="text-gray-500">Essayez de modifier vos critères de recherche.</p>
              </div>
            )}
          </div>

        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-blue-900/20 to-cyan-900/20 border-t border-blue-500/20">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Prêt à Maîtriser l' <span className="text-blue-400">Analyse Technique</span> ?
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Rejoignez des milliers de traders qui ont appris à lire les graphiques comme des professionnels.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap">
              Commencer Maintenant
            </button>
            <Link href="/contact" className="border border-blue-500/30 hover:border-blue-500/50 text-blue-400 px-8 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap">
              Nous Contacter
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
