'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { getPlans, type Plan } from '../lib/plansStorage';

export default function SubscriptionPlans() {
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    try {
      const loadedPlans = getPlans().filter(plan => plan.active).sort((a, b) => a.order - b.order);
      setPlans(loadedPlans);
    } catch (error) {
      console.error('Erreur lors du chargement des plans:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  if (loading) {
    return (
      <section className="py-16 bg-gray-900">
        <div className="container mx-auto px-6">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-yellow-500 mx-auto mb-4"></div>
            <p className="text-gray-400">Chargement des abonnements...</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 bg-gray-900">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">
            Nos <span className="text-yellow-400">Abonnements</span>
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Choisissez le plan qui correspond à vos ambitions de trader et accédez à nos formations premium.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {plans.map((plan) => (
            <div
              key={plan.id}
              className={`relative bg-black/50 p-8 rounded-2xl border-2 transition-all duration-300 hover:scale-105 cursor-pointer ${
                plan.popular 
                  ? 'border-yellow-500/50 ring-2 ring-yellow-500/20' 
                  : 'border-yellow-500/20 hover:border-yellow-500/40'
              }`}
            >
              {plan.popular && plan.badge && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-yellow-500 text-black px-4 py-2 rounded-full text-sm font-bold">
                    {plan.badge}
                  </span>
                </div>
              )}

              <div className="text-center mb-8">
                <div 
                  className="w-20 h-20 mx-auto mb-6 rounded-2xl flex items-center justify-center"
                  style={{ backgroundColor: plan.color + '20' }}
                >
                  <i 
                    className={`${plan.icon} text-4xl`} 
                    style={{ color: plan.color }}
                  ></i>
                </div>
                
                <h3 className="text-2xl font-bold text-white mb-3">{plan.name}</h3>
                <p className="text-gray-400 text-sm mb-6 leading-relaxed">{plan.description}</p>
                
                <div className="flex items-center justify-center mb-6">
                  <span 
                    className="text-5xl font-bold"
                    style={{ color: plan.color }}
                  >
                    {plan.price}
                  </span>
                  <span className="text-gray-400 ml-2 text-lg">{plan.period}</span>
                </div>
              </div>

              <div className="space-y-4 mb-8">
                {plan.features.map((feature, index) => (
                  <div key={index} className="flex items-start">
                    <div className="w-6 h-6 flex items-center justify-center mr-3 mt-0.5">
                      <i 
                        className="ri-check-line text-lg" 
                        style={{ color: plan.color }}
                      ></i>
                    </div>
                    <span className="text-gray-300 leading-relaxed">{feature}</span>
                  </div>
                ))}
              </div>

              <Link href="/payment" className="block">
                <button
                  className={`w-full py-4 rounded-xl font-bold text-lg transition-all duration-300 hover:scale-105 whitespace-nowrap ${
                    plan.popular
                      ? 'text-black hover:shadow-lg hover:shadow-yellow-500/25'
                      : 'text-white border-2 hover:text-black'
                  }`}
                  style={{
                    backgroundColor: plan.popular ? plan.color : 'transparent',
                    borderColor: plan.color,
                    ...(plan.popular ? {} : {
                      ':hover': {
                        backgroundColor: plan.color
                      }
                    })
                  }}
                  onMouseEnter={(e) => {
                    if (!plan.popular) {
                      e.currentTarget.style.backgroundColor = plan.color;
                      e.currentTarget.style.color = '#000000';
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!plan.popular) {
                      e.currentTarget.style.backgroundColor = 'transparent';
                      e.currentTarget.style.color = '#ffffff';
                    }
                  }}
                >
                  {plan.buttonText}
                </button>
              </Link>
            </div>
          ))}
        </div>

        {plans.length === 0 && (
          <div className="text-center py-12">
            <div className="w-24 h-24 mx-auto mb-6 bg-gray-800 rounded-full flex items-center justify-center">
              <i className="ri-price-tag-3-line text-4xl text-gray-400"></i>
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">Aucun abonnement disponible</h3>
            <p className="text-gray-400 mb-6">
              Les plans d'abonnement sont en cours de configuration. Revenez bientôt !
            </p>
          </div>
        )}

        <div className="text-center mt-16">
          <div className="bg-black/50 p-8 rounded-xl border border-yellow-500/20 max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold text-white mb-4">Besoin d'aide pour choisir ?</h3>
            <p className="text-gray-400 mb-6">
              Notre équipe est là pour vous conseiller et vous aider à choisir le plan parfait selon vos objectifs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/contact">
                <button className="bg-transparent border-2 border-yellow-500 text-yellow-500 hover:bg-yellow-500 hover:text-black px-8 py-3 rounded-lg font-semibold transition-all duration-300 cursor-pointer whitespace-nowrap">
                  Nous Contacter
                </button>
              </Link>
              <Link href="/payment">
                <button className="bg-yellow-500 text-black hover:bg-yellow-400 px-8 py-3 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap">
                  Voir Tous les Plans
                </button>
              </Link>
            </div>
          </div>
        </div>

        <div className="text-center mt-12">
          <div className="inline-flex items-center space-x-8 px-8 py-4 rounded-xl bg-black/30 border border-yellow-500/10">
            <div className="flex items-center space-x-2">
              <i className="ri-shield-check-line text-yellow-400"></i>
              <span className="text-gray-300 text-sm">Paiement Sécurisé</span>
            </div>
            <div className="flex items-center space-x-2">
              <i className="ri-refund-line text-yellow-400"></i>
              <span className="text-gray-300 text-sm">Remboursement 30 jours</span>
            </div>
            <div className="flex items-center space-x-2">
              <i className="ri-customer-service-line text-yellow-400"></i>
              <span className="text-gray-300 text-sm">Support 24/7</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}