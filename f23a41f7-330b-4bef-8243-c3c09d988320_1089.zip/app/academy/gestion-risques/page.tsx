'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function GestionRisquesPage() {
  const [selectedCategory, setSelectedCategory] = useState('Tous');
  const [searchTerm, setSearchTerm] = useState('');

  const categories = ['Tous', 'Money Management', 'Ratio Risque/Rendement', 'Diversification', 'Psychologie', 'Outils'];

  const videos = [
    {
      id: '1',
      title: 'Introduction à la Gestion des Risques',
      description: 'Les bases essentielles pour protéger votre capital et survivre sur les marchés financiers.',
      duration: '14:25',
      category: 'Money Management',
      level: 'Débutant',
      views: '2.1k',
      thumbnail: 'https://readdy.ai/api/search-image?query=Financial%20risk%20management%20concept%20with%20protective%20shield%20over%20investment%20portfolio%2C%20charts%20showing%20risk%20assessment%20graphs%2C%20calculator%20and%20financial%20documents%2C%20professional%20business%20environment%2C%20pink%20and%20white%20color%20scheme%2C%20risk%20protection%20visualization&width=640&height=360&seq=risk-intro&orientation=landscape'
    },
    {
      id: '2',
      title: 'Calcul de la Taille de Position',
      description: 'Comment déterminer précisément la taille optimale de vos positions selon votre capital.',
      duration: '18:42',
      category: 'Money Management',
      level: 'Intermédiaire',
      views: '1.8k',
      thumbnail: 'https://readdy.ai/api/search-image?query=Position%20sizing%20calculation%20with%20mathematical%20formulas%2C%20financial%20calculator%2C%20pie%20charts%20showing%20portfolio%20allocation%20percentages%2C%20spreadsheet%20with%20risk%20calculations%2C%20professional%20trading%20desk%2C%20pink%20and%20rose%20color%20palette&width=640&height=360&seq=position-sizing&orientation=landscape'
    },
    {
      id: '3',
      title: 'Ratio Risque/Rendement Optimal',
      description: 'Maîtrisez les ratios 1:2, 1:3 et apprenez à optimiser vos prises de profit et stop loss.',
      duration: '16:33',
      category: 'Ratio Risque/Rendement',
      level: 'Intermédiaire',
      views: '1.5k',
      thumbnail: 'https://readdy.ai/api/search-image?query=Risk%20reward%20ratio%20visualization%20with%20balanced%20scales%2C%20profit%20and%20loss%20charts%2C%20mathematical%20ratios%20displayed%2C%20trading%20signals%20with%20stop%20loss%20and%20take%20profit%20levels%2C%20professional%20financial%20analysis%2C%20pink%20and%20magenta%20color%20scheme&width=640&height=360&seq=risk-reward&orientation=landscape'
    },
    {
      id: '4',
      title: 'Diversification de Portefeuille',
      description: 'Les stratégies de diversification pour réduire les risques et optimiser les rendements.',
      duration: '20:15',
      category: 'Diversification',
      level: 'Intermédiaire',
      views: '1.9k',
      thumbnail: 'https://readdy.ai/api/search-image?query=Portfolio%20diversification%20concept%20with%20multiple%20asset%20classes%2C%20stocks%20bonds%20commodities%20real%20estate%20icons%2C%20pie%20chart%20showing%20balanced%20allocation%2C%20professional%20investment%20strategy%2C%20pink%20and%20coral%20color%20palette&width=640&height=360&seq=diversification&orientation=landscape'
    },
    {
      id: '5',
      title: 'Stop Loss et Take Profit Avancés',
      description: 'Techniques avancées de placement des stops et objectifs pour maximiser vos gains.',
      duration: '22:18',
      category: 'Outils',
      level: 'Avancé',
      views: '1.3k',
      thumbnail: 'https://readdy.ai/api/search-image?query=Advanced%20stop%20loss%20and%20take%20profit%20strategies%20on%20trading%20charts%2C%20multiple%20order%20types%2C%20trailing%20stops%20visualization%2C%20professional%20trading%20platform%20interface%2C%20technical%20analysis%20tools%2C%20pink%20and%20rose%20color%20scheme&width=640&height=360&seq=advanced-stops&orientation=landscape'
    },
    {
      id: '6',
      title: 'Gestion des Émotions et Discipline',
      description: 'Comment maintenir votre discipline de gestion des risques même sous pression émotionnelle.',
      duration: '17:45',
      category: 'Psychologie',
      level: 'Intermédiaire',
      views: '2.3k',
      thumbnail: 'https://readdy.ai/api/search-image?query=Trading%20psychology%20and%20emotional%20discipline%20concept%2C%20zen%20meditation%20with%20financial%20charts%2C%20balanced%20mind%20and%20risk%20management%2C%20stress%20management%20for%20traders%2C%20calm%20professional%20atmosphere%2C%20soft%20pink%20and%20white%20colors&width=640&height=360&seq=risk-psychology&orientation=landscape'
    },
    {
      id: '7',
      title: 'Hedging et Couverture de Positions',
      description: 'Stratégies de couverture pour protéger vos positions contre les mouvements défavorables.',
      duration: '19:52',
      category: 'Outils',
      level: 'Avancé',
      views: '1.1k',
      thumbnail: 'https://readdy.ai/api/search-image?query=Financial%20hedging%20strategies%20with%20protective%20umbrella%20over%20investment%20portfolio%2C%20correlation%20charts%2C%20derivatives%20and%20options%20contracts%2C%20sophisticated%20risk%20management%20tools%2C%20professional%20trading%20environment%2C%20pink%20and%20burgundy%20colors&width=640&height=360&seq=hedging&orientation=landscape'
    },
    {
      id: '8',
      title: 'Backtesting de Stratégies',
      description: 'Comment tester historiquement vos stratégies pour évaluer leurs risques réels.',
      duration: '24:30',
      category: 'Outils',
      level: 'Avancé',
      views: '987',
      thumbnail: 'https://readdy.ai/api/search-image?query=Backtesting%20software%20interface%20with%20historical%20data%20analysis%2C%20performance%20metrics%20charts%2C%20risk%20statistics%2C%20Monte%20Carlo%20simulations%2C%20professional%20quantitative%20analysis%20tools%2C%20pink%20and%20purple%20color%20palette&width=640&height=360&seq=backtesting&orientation=landscape'
    },
    {
      id: '9',
      title: 'Corrélations et Risque Systémique',
      description: 'Comprendre les corrélations entre actifs et gérer le risque systémique du marché.',
      duration: '21:07',
      category: 'Diversification',
      level: 'Avancé',
      views: '1.4k',
      thumbnail: 'https://readdy.ai/api/search-image?query=Financial%20correlation%20matrix%20with%20heat%20map%20visualization%2C%20systemic%20risk%20analysis%2C%20interconnected%20global%20markets%2C%20correlation%20coefficients%20display%2C%20advanced%20risk%20management%20analytics%2C%20professional%20financial%20interface%2C%20pink%20and%20crimson%20colors&width=640&height=360&seq=correlations&orientation=landscape'
    }
  ];

  const filteredVideos = videos.filter(video => {
    const matchesCategory = selectedCategory === 'Tous' || video.category === selectedCategory;
    const matchesSearch = video.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         video.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const stats = [
    { label: 'Formations', value: '15', icon: 'ri-play-circle-line' },
    { label: 'Heures de contenu', value: '8.5h', icon: 'ri-time-line' },
    { label: 'Niveau', value: 'Tous niveaux', icon: 'ri-bar-chart-line' },
    { label: 'Certificat', value: 'Inclus', icon: 'ri-award-line' }
  ];

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-br from-pink-900/20 to-rose-900/20 border-b border-pink-500/20">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center">
            {/* Bouton retour ajouté */}
            <div className="mb-6">
              <Link 
                href="/academy" 
                className="inline-flex items-center px-4 py-2 text-pink-400 hover:text-pink-300 transition-colors cursor-pointer"
              >
                <i className="ri-arrow-left-line mr-2"></i>
                Retour à l'Académie
              </Link>
            </div>

            <div className="inline-flex items-center gap-2 bg-pink-500/20 border border-pink-500/30 rounded-full px-4 py-2 mb-6">
              <i className="ri-shield-line text-pink-400"></i>
              <span className="text-pink-300 text-sm font-medium">Formation Spécialisée</span>
            </div>
            
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
              Gestion des <span className="text-pink-400">Risques</span>
            </h1>
            
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              Maîtrisez l'art de protéger votre capital avec des stratégies de gestion des risques éprouvées. 
              Apprenez à survivre et prospérer sur les marchés financiers.
            </p>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
              {stats.map((stat, index) => (
                <div key={index} className="bg-pink-500/10 border border-pink-500/20 rounded-xl p-4">
                  <div className="w-10 h-10 bg-pink-500/20 rounded-lg flex items-center justify-center mb-3 mx-auto">
                    <i className={`${stat.icon} text-pink-400 text-lg`}></i>
                  </div>
                  <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
                  <div className="text-sm text-gray-400">{stat.label}</div>
                </div>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-pink-500 hover:bg-pink-600 text-white px-8 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap">
                Commencer la Formation
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Filters Section */}
      <section className="py-8 bg-gray-800/50 border-b border-gray-700">
        <div className="container mx-auto px-6">
          <div className="flex flex-col lg:flex-row gap-6 items-center justify-between">
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap ${
                    selectedCategory === category
                      ? 'bg-pink-500 text-white'
                      : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
            
            <div className="relative w-full lg:w-80">
              <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
              <input
                type="text"
                placeholder="Rechercher une formation..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-pink-500 text-sm"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Videos Grid */}
      <section className="py-12">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredVideos.map((video) => (
              <div key={video.id} className="bg-gray-800 border border-gray-700 rounded-xl overflow-hidden hover:border-pink-500/50 transition-all duration-300 group">
                <div className="relative">
                  <img
                    src={video.thumbnail}
                    alt={video.title}
                    className="w-full h-48 object-cover object-top"
                  />
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-all duration-300"></div>
                  <div className="absolute top-4 left-4">
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      video.level === 'Débutant' ? 'bg-green-500/20 text-green-400 border border-green-500/30' :
                      video.level === 'Intermédiaire' ? 'bg-orange-500/20 text-orange-400 border border-orange-500/30' :
                      'bg-red-500/20 text-red-400 border border-red-500/30'
                    }`}>
                      {video.level}
                    </span>
                  </div>
                  <div className="absolute bottom-4 right-4 bg-black/80 text-white px-2 py-1 rounded text-sm">
                    {video.duration}
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="w-16 h-16 bg-pink-500/90 rounded-full flex items-center justify-center">
                      <i className="ri-play-fill text-white text-2xl"></i>
                    </div>
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs text-pink-400 bg-pink-500/20 border border-pink-500/30 px-2 py-1 rounded">
                      {video.category}
                    </span>
                    <span className="text-xs text-gray-500">{video.views} vues</span>
                  </div>
                  
                  <h3 className="text-lg font-bold text-white mb-2 group-hover:text-pink-400 transition-colors">
                    {video.title}
                  </h3>
                  
                  <p className="text-gray-400 text-sm leading-relaxed mb-4">
                    {video.description}
                  </p>
                  
                  <button className="flex items-center gap-2 text-pink-400 hover:text-pink-300 font-medium text-sm whitespace-nowrap">
                    <i className="ri-play-circle-line"></i>
                    Regarder maintenant
                  </button>
                </div>
              </div>
            ))}
          </div>

          {filteredVideos.length === 0 && (
            <div className="text-center py-12">
              <i className="ri-search-line text-6xl text-gray-600 mb-4"></i>
              <h3 className="text-xl font-bold text-gray-400 mb-2">Aucune formation trouvée</h3>
              <p className="text-gray-500">Essayez de modifier vos critères de recherche.</p>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-pink-900/20 to-rose-900/20 border-t border-pink-500/20">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Prêt à Maîtriser la <span className="text-pink-400">Gestion des Risques</span> ?
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Rejoignez des milliers de traders qui ont appris à protéger leur capital grâce à nos formations spécialisées.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-pink-500 hover:bg-pink-600 text-white px-8 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap">
              Commencer Maintenant
            </button>
            <Link href="/contact" className="border border-pink-500/30 hover:border-pink-500/50 text-pink-400 px-8 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap">
              Nous Contacter
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
