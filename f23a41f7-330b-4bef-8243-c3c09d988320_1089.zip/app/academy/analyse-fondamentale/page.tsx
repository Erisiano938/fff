
'use client';

import Link from 'next/link';
import Header from '../../components/Header';
import Footer from '../../components/Footer';

export default function AnalyseFondamentalePage() {
  const videos = [
    {
      id: 1,
      title: 'Introduction à l\'Analyse Fondamentale',
      description: 'Comprendre les bases de l\'évaluation des entreprises et des actifs financiers',
      duration: '45 min',
      level: 'Débutant',
      thumbnail: 'https://readdy.ai/api/search-image?query=Professional%20financial%20analyst%20examining%20company%20reports%20and%20financial%20statements%20on%20computer%20screen%2C%20clean%20modern%20office%20environment%2C%20purple%20theme%20colors%2C%20business%20professional%20atmosphere%2C%20detailed%20charts%20and%20graphs%20visible&width=320&height=180&seq=fund1&orientation=landscape',
      category: 'Fondamentaux'
    },
    {
      id: 2,
      title: 'Analyse des États Financiers',
      description: 'Décrypter les bilans, comptes de résultat et flux de trésorerie',
      duration: '1h 15min',
      level: 'Intermédiaire',
      thumbnail: 'https://readdy.ai/api/search-image?query=Close-up%20view%20of%20financial%20statements%20and%20balance%20sheets%20spread%20on%20desk%2C%20calculator%20and%20pen%20nearby%2C%20purple%20accent%20lighting%2C%20professional%20business%20setting%2C%20detailed%20financial%20documents%20visible&width=320&height=180&seq=fund2&orientation=landscape',
      category: 'États Financiers'
    },
    {
      id: 3,
      title: 'Ratios Financiers Essentiels',
      description: 'Maîtriser les ratios de rentabilité, liquidité et endettement',
      duration: '52 min',
      level: 'Intermédiaire',
      thumbnail: 'https://readdy.ai/api/search-image?query=Financial%20ratios%20and%20calculations%20displayed%20on%20computer%20screen%20with%20charts%2C%20purple%20themed%20business%20interface%2C%20professional%20analyst%20workspace%2C%20mathematical%20formulas%20and%20graphs%20visible&width=320&height=180&seq=fund3&orientation=landscape',
      category: 'Ratios'
    },
    {
      id: 4,
      title: 'Valorisation par DCF',
      description: 'Méthode des flux de trésorerie actualisés pour évaluer une entreprise',
      duration: '1h 8min',
      level: 'Avancé',
      thumbnail: 'https://readdy.ai/api/search-image?query=Complex%20DCF%20model%20spreadsheet%20on%20computer%20screen%2C%20financial%20calculator%20and%20documents%2C%20purple%20business%20theme%2C%20sophisticated%20valuation%20analysis%2C%20detailed%20cash%20flow%20projections%20visible&width=320&height=180&seq=fund4&orientation=landscape',
      category: 'Valorisation'
    },
    {
      id: 5,
      title: 'Analyse Sectorielle',
      description: 'Comprendre les spécificités et cycles de chaque secteur d\'activité',
      duration: '38 min',
      level: 'Intermédiaire',
      thumbnail: 'https://readdy.ai/api/search-image?query=Industry%20sector%20analysis%20charts%20and%20infographics%20on%20screen%2C%20purple%20themed%20business%20dashboard%2C%20market%20sectors%20comparison%2C%20professional%20analytical%20workspace%20with%20sector%20data%20visible&width=320&height=180&seq=fund5&orientation=landscape',
      category: 'Secteurs'
    },
    {
      id: 6,
      title: 'Indicateurs Macroéconomiques',
      description: 'Impact des données économiques sur les marchés financiers',
      duration: '42 min',
      level: 'Intermédiaire',
      thumbnail: 'https://readdy.ai/api/search-image?query=Economic%20indicators%20dashboard%20with%20GDP%2C%20inflation%20and%20employment%20data%2C%20purple%20themed%20interface%2C%20macroeconomic%20charts%20and%20graphs%2C%20professional%20financial%20analysis%20environment&width=320&height=180&seq=fund6&orientation=landscape',
      category: 'Macroéconomie'
    },
    {
      id: 7,
      title: 'Analyse Concurrentielle',
      description: 'Évaluer la position concurrentielle et les avantages compétitifs',
      duration: '55 min',
      level: 'Avancé',
      thumbnail: 'https://readdy.ai/api/search-image?query=Competitive%20analysis%20framework%20on%20computer%20with%20company%20comparisons%2C%20purple%20business%20theme%2C%20market%20share%20charts%2C%20strategic%20positioning%20analysis%20visible%20on%20screen&width=320&height=180&seq=fund7&orientation=landscape',
      category: 'Concurrence'
    },
    {
      id: 8,
      title: 'Modèles de Valorisation Avancés',
      description: 'Multiples sectoriels, sum-of-the-parts et autres méthodes',
      duration: '1h 22min',
      level: 'Expert',
      thumbnail: 'https://readdy.ai/api/search-image?query=Advanced%20valuation%20models%20and%20complex%20financial%20formulas%20on%20multiple%20screens%2C%20purple%20themed%20professional%20setup%2C%20sophisticated%20analytical%20tools%2C%20detailed%20valuation%20spreadsheets%20visible&width=320&height=180&seq=fund8&orientation=landscape',
      category: 'Valorisation'
    },
    {
      id: 9,
      title: 'ESG et Investissement Durable',
      description: 'Intégrer les critères environnementaux, sociaux et de gouvernance',
      duration: '48 min',
      level: 'Intermédiaire',
      thumbnail: 'https://readdy.ai/api/search-image?query=ESG%20sustainability%20dashboard%20with%20environmental%20and%20social%20metrics%2C%20purple%20themed%20interface%2C%20sustainable%20investment%20analysis%2C%20green%20business%20indicators%20on%20professional%20screen&width=320&height=180&seq=fund9&orientation=landscape',
      category: 'ESG'
    }
  ];

  const categories = [
    { name: 'Tous', count: videos.length, active: true },
    { name: 'Fondamentaux', count: 3, active: false },
    { name: 'États Financiers', count: 2, active: false },
    { name: 'Valorisation', count: 2, active: false },
    { name: 'Secteurs', count: 1, active: false },
    { name: 'ESG', count: 1, active: false }
  ];

  const stats = [
    { label: 'Vidéos', value: '18', icon: 'ri-play-circle-line' },
    { label: 'Heures de contenu', value: '12h', icon: 'ri-time-line' },
    { label: 'Analyses complètes', value: '25', icon: 'ri-file-text-line' },
    { label: 'Outils pratiques', value: '8', icon: 'ri-tools-line' }
  ];

  return (
    <div className="min-h-screen bg-black text-white">
      <Header />
      
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-br from-purple-900/30 to-black overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width=60 height=60 viewBox=0 0 60 60 xmlns=http://www.w3.org/2000/svg%3E%3Cg fill=none fill-rule=evenodd%3E%3Cg fill=%23a855f7 fill-opacity=0.1%3E%3Ccircle cx=30 cy=30 r=2/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-30"></div>
        <div className="relative container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center">
            {/* Bouton retour ajouté */}
            <div className="mb-6">
              <Link 
                href="/academy" 
                className="inline-flex items-center px-4 py-2 text-purple-400 hover:text-purple-300 transition-colors cursor-pointer"
              >
                <i className="ri-arrow-left-line mr-2"></i>
                Retour à l'Académie
              </Link>
            </div>

            <div className="inline-flex items-center px-4 py-2 rounded-full bg-purple-500/20 border border-purple-500/30 mb-6">
              <i className="ri-file-text-line text-purple-400 mr-2"></i>
              <span className="text-purple-300 font-medium">Analyse Fondamentale</span>
            </div>
            <h1 className="text-5xl font-bold mb-6">
              Maîtrisez l'<span className="text-purple-400">Évaluation</span> des Actifs
            </h1>
            <p className="text-xl text-gray-400 mb-8 leading-relaxed">
              Découvrez comment analyser la valeur intrinsèque des entreprises et prendre des décisions d'investissement éclairées grâce à l'analyse fondamentale.
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center mx-auto mb-2">
                    <i className={`${stat.icon} text-2xl text-purple-400`}></i>
                  </div>
                  <div className="text-2xl font-bold text-white">{stat.value}</div>
                  <div className="text-sm text-gray-400">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Navigation */}
      <section className="py-8 bg-gray-900/50">
        <div className="container mx-auto px-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <i className="ri-filter-line text-gray-400"></i>
              <span className="text-gray-400">Filtrer par :</span>
            </div>
            <Link href="/academy" className="inline-flex items-center text-purple-400 hover:text-purple-300 transition-colors">
              <i className="ri-arrow-left-line mr-2"></i>
              Retour à l'Académie
            </Link>
          </div>
          <div className="flex flex-wrap gap-3">
            {categories.map((category, index) => (
              <button
                key={index}
                className={`px-4 py-2 rounded-full transition-all whitespace-nowrap cursor-pointer ${
                  category.active
                    ? 'bg-purple-500 text-white'
                    : 'bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-purple-400'
                }`}
              >
                {category.name} ({category.count})
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Videos Grid */}
      <section className="py-16">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {videos.map((video) => (
              <div key={video.id} className="bg-gray-900 rounded-xl overflow-hidden hover:scale-105 transition-all duration-300 cursor-pointer">
                <div className="relative">
                  <img 
                    src={video.thumbnail} 
                    alt={video.title}
                    className="w-full h-48 object-cover object-top"
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                    <div className="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center">
                      <i className="ri-play-fill text-2xl text-white"></i>
                    </div>
                  </div>
                  <div className="absolute top-4 left-4">
                    <span className="px-2 py-1 bg-purple-500/90 text-white text-xs rounded font-medium">
                      {video.category}
                    </span>
                  </div>
                  <div className="absolute bottom-4 right-4">
                    <span className="px-2 py-1 bg-black/80 text-white text-xs rounded">
                      {video.duration}
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <div className="flex items-center gap-2 mb-3">
                    <span className={`px-2 py-1 text-xs rounded font-medium ${
                      video.level === 'Débutant' ? 'bg-green-500/20 text-green-400' :
                      video.level === 'Intermédiaire' ? 'bg-yellow-500/20 text-yellow-400' :
                      video.level === 'Avancé' ? 'bg-orange-500/20 text-orange-400' :
                      'bg-red-500/20 text-red-400'
                    }`}>
                      {video.level}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2">{video.title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed mb-4">{video.description}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center text-gray-500 text-sm">
                      <i className="ri-eye-line mr-1"></i>
                      <span>2.4k vues</span>
                    </div>
                    <button className="text-purple-400 hover:text-purple-300 font-semibold cursor-pointer whitespace-nowrap">
                      Regarder →
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Load More */}
          <div className="text-center mt-12">
            <button className="px-8 py-3 bg-purple-500 hover:bg-purple-600 text-white rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap">
              Charger plus de contenu
            </button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
