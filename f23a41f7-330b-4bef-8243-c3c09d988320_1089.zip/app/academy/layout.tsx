
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Académie de Trading',
  description: 'Formation complète au trading et à l\'investissement. Cours en ligne, analyse technique, psychologie du trading et stratégies avancées.',
  keywords: 'formation trading, cours trading, académie financière, analyse technique, psychologie trading, stratégies investissement',
  openGraph: {
    title: 'Académie de Trading | CMV Finance',
    description: 'Apprenez le trading et l\'investissement avec nos cours professionnels et formations certifiées.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Académie de Trading | CMV Finance',
    description: 'Apprenez le trading et l\'investissement avec nos cours professionnels et formations certifiées.',
  },
};

export default function AcademyLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "EducationalOrganization",
            "name": "Académie CMV Finance",
            "description": "Formation complète au trading et à l'investissement",
            "url": `${process.env.NEXT_PUBLIC_SITE_URL}/academy`,
            "provider": {
              "@type": "Organization",
              "name": "CMV Finance",
              "url": process.env.NEXT_PUBLIC_SITE_URL
            },
            "hasOfferCatalog": {
              "@type": "OfferCatalog",
              "name": "Formations Trading",
              "itemListElement": [
                {
                  "@type": "Course",
                  "name": "Trading pour Débutants",
                  "description": "Initiation complète au trading pour les débutants",
                  "provider": {
                    "@type": "Organization",
                    "name": "CMV Finance"
                  }
                },
                {
                  "@type": "Course",
                  "name": "Analyse Technique Avancée",
                  "description": "Maîtrisez les outils d'analyse technique professionnels",
                  "provider": {
                    "@type": "Organization",
                    "name": "CMV Finance"
                  }
                },
                {
                  "@type": "Course",
                  "name": "Psychologie du Trading",
                  "description": "Développez votre mental de trader professionnel",
                  "provider": {
                    "@type": "Organization",
                    "name": "CMV Finance"
                  }
                }
              ]
            }
          })
        }}
      />
      {children}
    </>
  );
}
