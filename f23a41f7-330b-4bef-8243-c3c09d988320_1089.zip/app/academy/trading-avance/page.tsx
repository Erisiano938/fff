
'use client';

import { useState } from 'react';
import Link from 'next/link';
import Header from '../../components/Header';
import Footer from '../../components/Footer';

export default function TradingAvancePage() {
  const [selectedCategory, setSelectedCategory] = useState('tous');
  const [searchTerm, setSearchTerm] = useState('');

  const videos = [
    {
      id: 1,
      title: 'Algorithmic Trading : Développer ses propres robots',
      duration: '45:20',
      views: '15.2k',
      category: 'algorithmic',
      level: 'Expert',
      thumbnail: 'https://readdy.ai/api/search-image?query=Professional%20algorithmic%20trading%20setup%20with%20multiple%20monitors%20displaying%20complex%20financial%20charts%2C%20trading%20algorithms%20code%20on%20screens%2C%20modern%20trading%20desk%20environment%20with%20sophisticated%20technology%2C%20dark%20professional%20atmosphere%20with%20blue%20and%20purple%20lighting&width=400&height=225&seq=1001&orientation=landscape',
      description: 'Apprenez à créer vos propres algorithmes de trading automatisé'
    },
    {
      id: 2,
      title: 'Options Strategies : Iron Condor & Butterfly',
      duration: '38:15',
      views: '12.8k',
      category: 'options',
      level: 'Expert',
      thumbnail: 'https://readdy.ai/api/search-image?query=Complex%20options%20trading%20strategies%20visualization%20with%20butterfly%20and%20condor%20spread%20diagrams%2C%20professional%20financial%20charts%20showing%20profit%20loss%20curves%2C%20sophisticated%20trading%20interface%20with%20multiple%20option%20chains%2C%20modern%20dark%20trading%20environment&width=400&height=225&seq=1002&orientation=landscape',
      description: 'Maîtrisez les stratégies d\'options les plus sophistiquées'
    },
    {
      id: 3,
      title: 'High Frequency Trading : Techniques et Outils',
      duration: '52:30',
      views: '9.4k',
      category: 'hft',
      level: 'Expert',
      thumbnail: 'https://readdy.ai/api/search-image?query=High%20frequency%20trading%20setup%20with%20ultra-fast%20execution%20systems%2C%20real-time%20market%20data%20feeds%2C%20millisecond%20timing%20displays%2C%20professional%20trading%20infrastructure%20with%20server%20racks%2C%20cutting-edge%20technology%20environment&width=400&height=225&seq=1003&orientation=landscape',
      description: 'Découvrez les secrets du trading haute fréquence'
    },
    {
      id: 4,
      title: 'Portfolio Optimization : Modèles Quantitatifs',
      duration: '41:45',
      views: '11.6k',
      category: 'quant',
      level: 'Expert',
      thumbnail: 'https://readdy.ai/api/search-image?query=Quantitative%20portfolio%20optimization%20with%20mathematical%20models%2C%20correlation%20matrices%2C%20risk%20analysis%20charts%2C%20sophisticated%20financial%20modeling%20software%20interface%2C%20professional%20quantitative%20analysis%20environment&width=400&height=225&seq=1004&orientation=landscape',
      description: 'Optimisez vos portefeuilles avec des modèles mathématiques avancés'
    },
    {
      id: 5,
      title: 'Market Making : Stratégies de Liquidité',
      duration: '35:50',
      views: '8.9k',
      category: 'market-making',
      level: 'Expert',
      thumbnail: 'https://readdy.ai/api/search-image?query=Market%20making%20strategies%20with%20order%20book%20depth%20analysis%2C%20bid-ask%20spread%20management%2C%20liquidity%20provision%20systems%2C%20professional%20trading%20platform%20showing%20market%20depth%2C%20dark%20sophisticated%20trading%20environment&width=400&height=225&seq=1005&orientation=landscape',
      description: 'Apprenez les techniques des market makers professionnels'
    },
    {
      id: 6,
      title: 'Derivatives Pricing : Black-Scholes Avancé',
      duration: '49:10',
      views: '10.3k',
      category: 'derivatives',
      level: 'Expert',
      thumbnail: 'https://readdy.ai/api/search-image?query=Advanced%20derivatives%20pricing%20models%20with%20Black-Scholes%20equations%2C%20volatility%20surfaces%2C%20Greeks%20calculations%2C%20sophisticated%20financial%20mathematics%20on%20screens%2C%20professional%20quantitative%20trading%20desk&width=400&height=225&seq=1006&orientation=landscape',
      description: 'Maîtrisez la valorisation des produits dérivés complexes'
    },
    {
      id: 7,
      title: 'Risk Management : VaR et Stress Testing',
      duration: '44:25',
      views: '13.7k',
      category: 'risk-management',
      level: 'Expert',
      thumbnail: 'https://readdy.ai/api/search-image?query=Advanced%20risk%20management%20systems%20with%20Value%20at%20Risk%20calculations%2C%20stress%20testing%20scenarios%2C%20risk%20matrices%2C%20sophisticated%20risk%20analysis%20software%2C%20professional%20risk%20monitoring%20environment&width=400&height=225&seq=1007&orientation=landscape',
      description: 'Techniques avancées de gestion des risques institutionnels'
    },
    {
      id: 8,
      title: 'Macro Trading : Analyse des Banques Centrales',
      duration: '56:40',
      views: '14.1k',
      category: 'macro',
      level: 'Expert',
      thumbnail: 'https://readdy.ai/api/search-image?query=Macroeconomic%20trading%20analysis%20with%20central%20bank%20policy%20charts%2C%20global%20economic%20indicators%2C%20currency%20correlation%20matrices%2C%20professional%20macro%20trading%20desk%20with%20multiple%20economic%20data%20feeds&width=400&height=225&seq=1008&orientation=landscape',
      description: 'Trading macro-économique et analyse des politiques monétaires'
    },
    {
      id: 9,
      title: 'Arbitrage Strategies : Cross-Market Opportunities',
      duration: '39:30',
      views: '7.8k',
      category: 'arbitrage',
      level: 'Expert',
      thumbnail: 'https://readdy.ai/api/search-image?query=Cross-market%20arbitrage%20opportunities%20with%20price%20discrepancies%20across%20multiple%20exchanges%2C%20sophisticated%20arbitrage%20detection%20systems%2C%20real-time%20price%20comparison%20tools%2C%20professional%20arbitrage%20trading%20setup&width=400&height=225&seq=1009&orientation=landscape',
      description: 'Exploitez les opportunités d\'arbitrage inter-marchés'
    }
  ];

  const categories = [
    { id: 'tous', name: 'Tous les sujets', count: videos.length },
    { id: 'algorithmic', name: 'Trading Algorithmique', count: videos.filter(v => v.category === 'algorithmic').length },
    { id: 'options', name: 'Stratégies Options', count: videos.filter(v => v.category === 'options').length },
    { id: 'quant', name: 'Finance Quantitative', count: videos.filter(v => v.category === 'quant').length },
    { id: 'risk-management', name: 'Gestion des Risques', count: videos.filter(v => v.category === 'risk-management').length },
    { id: 'macro', name: 'Trading Macro', count: videos.filter(v => v.category === 'macro').length }
  ];

  const filteredVideos = videos.filter(video => {
    const matchesCategory = selectedCategory === 'tous' || video.category === selectedCategory;
    const matchesSearch = (video.title || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (video.description || '').toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const stats = [
    { label: 'Stratégies Avancées', value: '25+', icon: 'ri-line-chart-line' },
    { label: 'Heures de Formation', value: '180h', icon: 'ri-time-line' },
    { label: 'Experts Formateurs', value: '12', icon: 'ri-user-star-line' },
    { label: 'Étudiants Certifiés', value: '3.2k', icon: 'ri-award-line' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-950 via-black to-indigo-950">
      <Header />
      
      <section className="pt-24 pb-16">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            {/* Bouton retour ajouté */}
            <div className="mb-6">
              <Link 
                href="/academy" 
                className="inline-flex items-center px-4 py-2 text-purple-400 hover:text-purple-300 transition-colors cursor-pointer"
              >
                <i className="ri-arrow-left-line mr-2"></i>
                Retour à l'Académie
              </Link>
            </div>

            <div className="inline-flex items-center space-x-3 bg-purple-500/20 px-6 py-3 rounded-full border border-purple-500/30 mb-6">
              <div className="w-8 h-8 bg-purple-500/30 rounded-lg flex items-center justify-center">
                <i className="ri-trophy-line text-lg text-purple-400"></i>
              </div>
              <span className="text-purple-300 font-semibold">Trading Avancé</span>
            </div>
            
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              <span className="text-white">Maîtrise </span>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-indigo-400">
                Professionnelle
              </span>
            </h1>
            
            <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
              Stratégies institutionnelles, trading algorithmique et techniques quantitatives 
              pour les traders expérimentés
            </p>

            <div className="grid md:grid-cols-4 gap-6 max-w-4xl mx-auto">
              {stats.map((stat, index) => (
                <div key={index} className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-purple-500/20">
                  <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center mb-4 mx-auto">
                    <i className={`${stat.icon} text-2xl text-purple-400`}></i>
                  </div>
                  <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
                  <div className="text-gray-400 text-sm">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white/5 backdrop-blur-sm rounded-2xl border border-purple-500/20 p-8">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8 space-y-4 lg:space-y-0">
              <div className="flex items-center space-x-4">
                <h2 className="text-2xl font-bold text-white">Formations Expert</h2>
                <span className="bg-purple-500/20 text-purple-300 px-3 py-1 rounded-full text-sm font-semibold">
                  {filteredVideos.length} Formation{filteredVideos.length > 1 ? 's' : ''}
                </span>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Rechercher une formation..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full lg:w-80 pl-10 pr-4 py-3 bg-black/30 border border-purple-500/30 rounded-lg text-white text-sm placeholder-gray-400 focus:border-purple-500 focus:outline-none"
                  />
                  <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-3 mb-8">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`px-4 py-2 rounded-full font-semibold transition-all whitespace-nowrap ${
                    selectedCategory === category.id
                      ? 'bg-gradient-to-r from-purple-500 to-indigo-500 text-white shadow-lg'
                      : 'bg-white/10 text-gray-300 hover:bg-white/20 hover:text-white border border-purple-500/20'
                  }`}
                >
                  {category.name}
                  <span className="ml-2 text-xs opacity-75">({category.count})</span>
                </button>
              ))}
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredVideos.map((video) => (
                <div key={video.id} className="group bg-white/5 rounded-xl overflow-hidden border border-purple-500/20 hover:border-purple-500/40 transition-all duration-300 hover:transform hover:scale-[1.02]">
                  <div className="relative">
                    <img
                      src={video.thumbnail}
                      alt={video.title}
                      className="w-full h-48 object-cover object-top"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                    <div className="absolute top-4 left-4">
                      <span className="bg-purple-500 text-white px-2 py-1 rounded text-xs font-semibold">
                        {video.level}
                      </span>
                    </div>
                    <div className="absolute bottom-4 right-4">
                      <span className="bg-black/70 text-white px-2 py-1 rounded text-xs font-semibold">
                        {video.duration}
                      </span>
                    </div>
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="w-16 h-16 bg-purple-500/80 rounded-full flex items-center justify-center cursor-pointer hover:bg-purple-500 transition-colors">
                        <i className="ri-play-fill text-2xl text-white ml-1"></i>
                      </div>
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-lg font-bold text-white mb-2 group-hover:text-purple-300 transition-colors">
                      {video.title}
                    </h3>
                    <p className="text-gray-400 text-sm mb-4 line-clamp-2">
                      {video.description}
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-gray-400">
                        <span className="flex items-center space-x-1">
                          <i className="ri-eye-line"></i>
                          <span>{video.views}</span>
                        </span>
                      </div>
                      <button className="bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-600 hover:to-indigo-600 text-white px-4 py-2 rounded-lg font-semibold transition-all whitespace-nowrap">
                        Regarder
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {filteredVideos.length === 0 && (
              <div className="text-center py-16">
                <div className="w-20 h-20 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <i className="ri-search-line text-3xl text-purple-400"></i>
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Aucune formation trouvée</h3>
                <p className="text-gray-400">
                  Essayez de modifier vos critères de recherche ou explorez d\'autres catégories.
                </p>
              </div>
            )}
          </div>

          <div className="mt-16 text-center">
            <div className="bg-gradient-to-r from-purple-500/20 to-indigo-500/20 rounded-2xl p-8 border border-purple-500/30">
              <h3 className="text-2xl font-bold text-white mb-4">
                Prêt pour le Trading Professionnel ?
              </h3>
              <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
                Accédez à nos stratégies institutionnelles et rejoignez l\'élite des traders quantitatifs
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button className="bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-600 hover:to-indigo-600 text-white px-8 py-3 rounded-lg font-semibold transition-all whitespace-nowrap">
                  Commencer Formation
                </button>
                <Link href="/contact" className="bg-white/10 hover:bg-white/20 text-white border border-purple-500/30 px-8 py-3 rounded-lg font-semibold transition-all whitespace-nowrap">
                  Nous Contacter
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
