
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { wordpressApi, WordPressPost } from '../../../../lib/wordpress';

interface ArticleDetailProps {
  articleId: string;
}

export default function ArticleDetail({ articleId }: ArticleDetailProps) {
  const [article, setArticle] = useState<WordPressPost | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchArticle() {
      try {
        setLoading(true);
        const post = await wordpressApi.getPost(articleId);
        
        if (post) {
          setArticle(post);
        } else {
          setError('Article introuvable');
        }
      } catch (err) {
        setError('Erreur lors du chargement de l\'article');
        console.error('Erreur:', err);
      } finally {
        setLoading(false);
      }
    }

    fetchArticle();
  }, [articleId]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 py-16">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-300 rounded mb-4"></div>
            <div className="h-4 bg-gray-300 rounded mb-2"></div>
            <div className="h-4 bg-gray-300 rounded mb-2"></div>
            <div className="h-64 bg-gray-300 rounded mb-8"></div>
            <div className="space-y-4">
              <div className="h-4 bg-gray-300 rounded"></div>
              <div className="h-4 bg-gray-300 rounded"></div>
              <div className="h-4 bg-gray-300 rounded w-3/4"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !article) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 flex items-center justify-center">
            <i className="ri-file-search-line text-4xl text-gray-400"></i>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-4">
            {error || 'Article introuvable'}
          </h1>
          <p className="text-gray-600 mb-8">
            L'article que vous recherchez n'existe pas ou a été supprimé.
          </p>
          <Link 
            href="/academy"
            className="inline-flex items-center px-6 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap cursor-pointer"
          >
            <i className="ri-arrow-left-line mr-2"></i>
            Retour à l'académie
          </Link>
        </div>
      </div>
    );
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getAuthor = () => {
    return article._embedded?.author?.[0];
  };

  const getFeaturedImage = () => {
    return article._embedded?.['wp:featuredmedia']?.[0];
  };

  const getCategories = () => {
    return article._embedded?.['wp:term']?.[0] || [];
  };

  const author = getAuthor();
  const featuredImage = getFeaturedImage();
  const categories = getCategories();

  return (
    <div className="min-h-screen bg-white">
      {/* Breadcrumb */}
      <div className="bg-gray-50 border-b">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <nav className="flex items-center space-x-2 text-sm">
            <Link href="/" className="text-gray-500 hover:text-gray-700 cursor-pointer">
              Accueil
            </Link>
            <i className="ri-arrow-right-s-line text-gray-400"></i>
            <Link href="/academy" className="text-gray-500 hover:text-gray-700 cursor-pointer">
              Académie
            </Link>
            <i className="ri-arrow-right-s-line text-gray-400"></i>
            <span className="text-gray-900 font-medium truncate">
              {article.title.rendered}
            </span>
          </nav>
        </div>
      </div>

      <article className="max-w-4xl mx-auto px-4 py-12">
        {/* Header */}
        <header className="mb-8">
          {/* Categories */}
          {categories.length > 0 && (
            <div className="mb-4">
              <div className="flex flex-wrap gap-2">
                {categories.map((category) => (
                  <span
                    key={category.id}
                    className="px-3 py-1 bg-blue-100 text-blue-800 text-sm font-medium rounded-full"
                  >
                    {category.name}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Title */}
          <h1 
            className="text-4xl font-bold text-gray-900 mb-6 leading-tight"
            dangerouslySetInnerHTML={{ __html: article.title.rendered }}
          />

          {/* Meta */}
          <div className="flex items-center space-x-6 text-gray-600">
            {author && (
              <div className="flex items-center space-x-3">
                <img
                  src={author.avatar_urls[96]}
                  alt={author.name}
                  className="w-10 h-10 rounded-full object-cover"
                />
                <div>
                  <p className="font-medium text-gray-900">{author.name}</p>
                </div>
              </div>
            )}
            <div className="flex items-center space-x-2">
              <i className="ri-calendar-line"></i>
              <span>{formatDate(article.date)}</span>
            </div>
          </div>
        </header>

        {/* Featured Image */}
        {featuredImage && (
          <div className="mb-8">
            <img
              src={featuredImage.source_url}
              alt={featuredImage.alt_text || article.title.rendered}
              className="w-full h-64 md:h-96 object-cover rounded-lg"
            />
          </div>
        )}

        {/* Content */}
        <div 
          className="prose prose-lg max-w-none prose-blue prose-headings:font-bold prose-headings:text-gray-900 prose-p:text-gray-700 prose-a:text-blue-600 prose-a:no-underline hover:prose-a:underline prose-strong:text-gray-900 prose-code:bg-gray-100 prose-code:px-2 prose-code:py-1 prose-code:rounded prose-pre:bg-gray-900 prose-pre:text-gray-100 prose-blockquote:border-blue-500 prose-blockquote:bg-blue-50 prose-blockquote:p-4 prose-blockquote:rounded-lg prose-ul:list-disc prose-ol:list-decimal prose-li:mb-2"
          dangerouslySetInnerHTML={{ __html: article.content.rendered }}
        />

        {/* Actions */}
        <div className="mt-12 pt-8 border-t border-gray-200">
          <div className="flex flex-col sm:flex-row gap-4 justify-between items-start">
            <Link 
              href="/academy"
              className="inline-flex items-center px-6 py-3 bg-gray-100 text-gray-700 font-medium rounded-lg hover:bg-gray-200 transition-colors whitespace-nowrap cursor-pointer"
            >
              <i className="ri-arrow-left-line mr-2"></i>
              Retour à l'académie
            </Link>

            <div className="flex items-center gap-4">
              <button className="inline-flex items-center px-4 py-2 bg-white border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors whitespace-nowrap cursor-pointer">
                <i className="ri-share-line mr-2"></i>
                Partager
              </button>
              <button className="inline-flex items-center px-4 py-2 bg-white border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors whitespace-nowrap cursor-pointer">
                <i className="ri-bookmark-line mr-2"></i>
                Sauvegarder
              </button>
            </div>
          </div>
        </div>
      </article>
    </div>
  );
}
