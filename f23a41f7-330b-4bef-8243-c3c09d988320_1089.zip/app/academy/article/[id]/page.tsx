
import ArticleDetail from './ArticleDetail';

export async function generateStaticParams() {
  return [
    { id: '1' },
    { id: '2' },
    { id: '3' },
    { id: 'strategies-diversification-portefeuille' },
    { id: 'analyse-technique-debutants' },
    { id: 'gestion-risques-trading' },
    { id: 'psychologie-trading' },
    { id: 'indicateurs-techniques-essentiels' },
  ];
}

export default function ArticlePage({ params }: { params: { id: string } }) {
  return <ArticleDetail articleId={params.id} />;
}
