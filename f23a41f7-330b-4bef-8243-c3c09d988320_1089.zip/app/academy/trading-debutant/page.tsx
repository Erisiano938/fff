
'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function TradingDebutantPage() {
  const [selectedFilter, setSelectedFilter] = useState('tous');

  const formations = [
    {
      id: 1,
      title: 'Introduction au Trading',
      description: 'Découvrez les bases du trading financier et les premiers concepts essentiels.',
      duration: '2h 30min',
      lessons: 8,
      category: 'bases',
      difficulty: 'Débutant',
      image: 'https://readdy.ai/api/search-image?query=Professional%20trading%20introduction%20course%20with%20beginner-friendly%20interface%2C%20financial%20charts%20basics%2C%20educational%20trading%20platform%2C%20green%20and%20white%20modern%20design%2C%20clean%20learning%20environment&width=400&height=225&seq=trading-intro-basics&orientation=landscape'
    },
    {
      id: 2,
      title: 'Comprendre les Marchés Financiers',
      description: 'Apprenez à naviguer dans les différents marchés : Forex, Actions, Crypto.',
      duration: '3h 15min',
      lessons: 12,
      category: 'marches',
      difficulty: 'Débutant',
      image: 'https://readdy.ai/api/search-image?query=Financial%20markets%20overview%20with%20world%20map%2C%20various%20market%20symbols%2C%20forex%20pairs%20EUR%20USD%2C%20stock%20market%20indices%2C%20cryptocurrency%20icons%2C%20global%20trading%20concept%2C%20professional%20educational%20design&width=400&height=225&seq=financial-markets-overview&orientation=landscape'
    },
    {
      id: 3,
      title: 'Types d\'Ordres et Exécution',
      description: 'Maîtrisez les différents types d\'ordres : Market, Limit, Stop Loss.',
      duration: '1h 45min',
      lessons: 6,
      category: 'ordres',
      difficulty: 'Débutant',
      image: 'https://readdy.ai/api/search-image?query=Trading%20order%20types%20interface%20with%20buy%20sell%20buttons%2C%20market%20orders%2C%20limit%20orders%2C%20stop%20loss%20visualization%2C%20clean%20trading%20platform%20design%2C%20green%20buy%20red%20sell%20colors&width=400&height=225&seq=trading-orders-types&orientation=landscape'
    },
    {
      id: 4,
      title: 'Gestion du Capital pour Débutants',
      description: 'Protégez votre capital avec les règles de base du money management.',
      duration: '2h 00min',
      lessons: 7,
      category: 'gestion',
      difficulty: 'Débutant',
      image: 'https://readdy.ai/api/search-image?query=Capital%20management%20concept%20with%20portfolio%20allocation%20charts%2C%20risk%20management%20visualization%2C%20money%20protection%20symbols%2C%20calculator%20and%20financial%20planning%20tools%2C%20professional%20educational%20design&width=400&height=225&seq=capital-management-beginner&orientation=landscape'
    },
    {
      id: 5,
      title: 'Première Analyse de Graphiques',
      description: 'Lisez vos premiers graphiques et identifiez les tendances simples.',
      duration: '2h 20min',
      lessons: 9,
      category: 'analyse',
      difficulty: 'Débutant',
      image: 'https://readdy.ai/api/search-image?query=Simple%20chart%20analysis%20for%20beginners%20with%20trend%20lines%2C%20basic%20candlestick%20patterns%2C%20support%20resistance%20levels%20highlighted%2C%20clean%20educational%20interface%2C%20beginner-friendly%20visualization&width=400&height=225&seq=chart-analysis-beginner&orientation=landscape'
    },
    {
      id: 6,
      title: 'Psychologie du Trading Débutant',
      description: 'Contrôlez vos émotions et développez un bon mindset de trader.',
      duration: '1h 30min',
      lessons: 5,
      category: 'psychologie',
      difficulty: 'Débutant',
      image: 'https://readdy.ai/api/search-image?query=Trading%20psychology%20for%20beginners%20with%20balanced%20mind%20concept%2C%20emotional%20control%20visualization%2C%20zen%20trading%20mindset%2C%20calm%20professional%20atmosphere%2C%20meditation%20and%20focus%20elements&width=400&height=225&seq=trading-psychology-beginner&orientation=landscape'
    },
    {
      id: 7,
      title: 'Choisir son Courtier',
      description: 'Sélectionnez le bon broker selon vos besoins et votre profil.',
      duration: '1h 15min',
      lessons: 4,
      category: 'plateforme',
      difficulty: 'Débutant',
      image: 'https://readdy.ai/api/search-image?query=Broker%20selection%20guide%20with%20comparison%20charts%2C%20trading%20platform%20interfaces%2C%20regulation%20symbols%2C%20security%20features%2C%20professional%20broker%20evaluation%20design&width=400&height=225&seq=broker-selection-guide&orientation=landscape'
    },
    {
      id: 8,
      title: 'Votre Premier Trade',
      description: 'Passez votre première opération en suivant notre guide étape par étape.',
      duration: '2h 45min',
      lessons: 10,
      category: 'pratique',
      difficulty: 'Débutant',
      image: 'https://readdy.ai/api/search-image?query=First%20trade%20execution%20tutorial%20with%20step%20by%20step%20interface%2C%20trading%20platform%20walkthrough%2C%20buy%20sell%20process%20visualization%2C%20beginner-friendly%20trading%20guide%2C%20success%20achievement%20elements&width=400&height=225&seq=first-trade-tutorial&orientation=landscape'
    },
    {
      id: 9,
      title: 'Erreurs Communes à Éviter',
      description: 'Évitez les pièges classiques des traders débutants.',
      duration: '1h 50min',
      lessons: 6,
      category: 'erreurs',
      difficulty: 'Débutant',
      image: 'https://readdy.ai/api/search-image?query=Common%20trading%20mistakes%20prevention%20with%20warning%20signs%2C%20error%20examples%2C%20learning%20from%20mistakes%20concept%2C%20educational%20warning%20symbols%2C%20professional%20improvement%20guidance%20design&width=400&height=225&seq=trading-mistakes-prevention&orientation=landscape'
    }
  ];

  const categories = [
    { id: 'tous', name: 'Toutes les formations', count: formations.length },
    { id: 'bases', name: 'Bases du Trading', count: formations.filter(f => f.category === 'bases').length },
    { id: 'marches', name: 'Marchés Financiers', count: formations.filter(f => f.category === 'marches').length },
    { id: 'ordres', name: 'Ordres de Trading', count: formations.filter(f => f.category === 'ordres').length },
    { id: 'gestion', name: 'Gestion du Capital', count: formations.filter(f => f.category === 'gestion').length },
    { id: 'analyse', name: 'Analyse de Base', count: formations.filter(f => f.category === 'analyse').length }
  ];

  const filteredFormations = selectedFilter === 'tous' 
    ? formations 
    : formations.filter(formation => formation.category === selectedFilter);

  const stats = [
    { label: 'Formations', value: formations.length.toString(), icon: 'ri-book-open-line' },
    { label: 'Heures de contenu', value: '18h', icon: 'ri-time-line' },
    { label: 'Étudiants actifs', value: '2.8k', icon: 'ri-user-line' },
    { label: 'Taux de réussite', value: '94%', icon: 'ri-trophy-line' }
  ];

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 border-b border-green-500/20">
        <div className="container mx-auto px-4 py-12">
          {/* Bouton retour */}
          <Link href="/academy" className="inline-flex items-center text-green-400 hover:text-green-300 mb-6 transition-colors cursor-pointer">
            <i className="ri-arrow-left-line mr-2"></i>
            Retour à l'Académie
          </Link>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center space-x-4 mb-6">
                <div className="w-16 h-16 bg-green-500/20 rounded-xl flex items-center justify-center">
                  <i className="ri-rocket-line text-3xl text-green-400"></i>
                </div>
                <div>
                  <h1 className="text-5xl font-bold mb-2">Trading pour Débutants</h1>
                  <p className="text-xl text-green-400">Votre parcours vers l'indépendance financière</p>
                </div>
              </div>

              <p className="text-gray-300 text-lg mb-8 leading-relaxed">
                Découvrez le monde du trading avec nos formations conçues spécialement pour les débutants. 
                Apprenez les bases, évitez les erreurs communes et construisez des fondations solides pour 
                votre carrière de trader.
              </p>

              <div className="flex flex-wrap gap-6">
                <div className="flex items-center space-x-2 text-gray-300">
                  <i className="ri-check-line text-green-400"></i>
                  <span>Formations progressives</span>
                </div>
                <div className="flex items-center space-x-2 text-gray-300">
                  <i className="ri-check-line text-green-400"></i>
                  <span>Support personnalisé</span>
                </div>
                <div className="flex items-center space-x-2 text-gray-300">
                  <i className="ri-check-line text-green-400"></i>
                  <span>Exercices pratiques</span>
                </div>
              </div>
            </div>

            <div className="relative">
              <img
                src="https://readdy.ai/api/search-image?query=Beginner%20trader%20learning%20at%20computer%20with%20financial%20charts%2C%20modern%20trading%20education%20setup%2C%20clean%20and%20professional%20learning%20environment%2C%20inspiring%20success%20journey%20visualization%2C%20green%20and%20white%20color%20scheme&width=600&height=400&seq=trading-beginner-hero&orientation=landscape"
                alt="Formation Trading Débutant"
                className="w-full rounded-2xl shadow-2xl object-cover object-top"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-2xl"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Statistiques */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {stats.map((stat, index) => (
            <div key={index} className="bg-gray-900 rounded-xl p-6 border border-green-500/20">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
                  <i className={`${stat.icon} text-2xl text-green-400`}></i>
                </div>
                <div>
                  <div className="text-2xl font-bold text-white">{stat.value}</div>
                  <div className="text-gray-400 text-sm">{stat.label}</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Filtres */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">Explorez nos formations</h2>
          <div className="flex flex-wrap gap-3">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedFilter(category.id)}
                className={`px-4 py-2 rounded-full font-medium transition-all whitespace-nowrap ${
                  selectedFilter === category.id
                    ? 'bg-green-500 text-black'
                    : 'bg-gray-800 text-gray-300 hover:bg-gray-700 hover:text-white'
                }`}
              >
                {category.name} ({category.count})
              </button>
            ))}
          </div>
        </div>

        {/* Grille des formations */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredFormations.map((formation) => (
            <div key={formation.id} className="bg-gray-900 rounded-xl overflow-hidden border border-gray-800 hover:border-green-500/40 transition-all cursor-pointer group">
              <div className="relative aspect-video overflow-hidden">
                <img
                  src={formation.image}
                  alt={formation.title}
                  className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-4 left-4 px-3 py-1 bg-green-500 text-black text-sm font-medium rounded-full">
                  DÉBUTANT
                </div>
                <div className="absolute bottom-4 right-4 px-2 py-1 bg-black/80 text-white text-xs rounded">
                  {formation.duration}
                </div>
              </div>

              <div className="p-6">
                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-green-400 transition-colors line-clamp-2">
                  {formation.title}
                </h3>

                <p className="text-gray-400 text-sm mb-4 line-clamp-3">
                  {formation.description}
                </p>

                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <span className="flex items-center space-x-1">
                    <i className="ri-play-circle-line"></i>
                    <span>{formation.lessons} leçons</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <i className="ri-time-line"></i>
                    <span>{formation.duration}</span>
                  </span>
                </div>

                <button className="w-full bg-green-500/20 hover:bg-green-500 hover:text-black text-green-400 py-3 rounded-lg font-semibold transition-all whitespace-nowrap">
                  Commencer la formation
                </button>
              </div>
            </div>
          ))}
        </div>

        {filteredFormations.length === 0 && (
          <div className="text-center py-16">
            <i className="ri-book-line text-6xl text-gray-600 mb-4"></i>
            <h3 className="text-xl font-bold text-white mb-2">Aucune formation trouvée</h3>
            <p className="text-gray-400">Aucune formation disponible pour cette catégorie</p>
          </div>
        )}
      </div>
    </div>
  );
}
