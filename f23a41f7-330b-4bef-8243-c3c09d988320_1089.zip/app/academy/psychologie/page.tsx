
'use client';

import { useState, useEffect } from 'react';
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import Link from 'next/link';
import { getPublishedVideos } from '../../lib/videoStorage';
import type { Video } from '../../lib/videoStorage';

export default function PsychologiePage() {
  const [videos, setVideos] = useState<Video[]>([]);
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [showVideoModal, setShowVideoModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'date' | 'views' | 'title'>('date');

  useEffect(() => {
    const allVideos = getPublishedVideos();
    const psychologyVideos = allVideos.filter(video => video.category === 'psychologie');
    
    // Si pas assez de vidéos existantes, ajouter des vidéos de démonstration
    if (psychologyVideos.length < 9) {
      const demoVideos: Video[] = [
        {
          id: 'psych-1',
          title: 'Maîtriser ses émotions en trading',
          description: 'Comprendre l\'impact des émotions sur vos décisions de trading et apprendre à les contrôler pour améliorer vos performances.',
          category: 'psychologie',
          duration: '18:45',
          views: 1247,
          publishedAt: new Date('2024-01-15').toISOString(),
          isPublished: true,
          thumbnail: 'https://readdy.ai/api/search-image?query=Trader%20meditating%20in%20front%20of%20multiple%20screens%2C%20peaceful%20office%20environment%2C%20soft%20lighting%2C%20mental%20clarity%20and%20focus%2C%20minimalist%20workspace%2C%20zen%20atmosphere%2C%20professional%20trading%20setup%20with%20calm%20colors&width=400&height=225&seq=psych1&orientation=landscape',
          videoUrl: ''
        },
        {
          id: 'psych-2',
          title: 'Gérer la peur et la cupidité',
          description: 'Les deux émotions principales qui sabotent les traders : comment les identifier et développer des stratégies pour les surmonter.',
          category: 'psychologie',
          duration: '22:15',
          views: 1089,
          publishedAt: new Date('2024-01-12').toISOString(),
          isPublished: true,
          thumbnail: 'https://readdy.ai/api/search-image?query=Balance%20scale%20with%20fear%20and%20greed%20symbols%2C%20psychological%20concept%20illustration%2C%20dark%20background%20with%20red%20and%20green%20lights%2C%20trading%20psychology%20theme%2C%20professional%20business%20atmosphere&width=400&height=225&seq=psych2&orientation=landscape',
          videoUrl: ''
        },
        {
          id: 'psych-3',
          title: 'Développer la discipline de trading',
          description: 'Construire des habitudes solides et maintenir la discipline nécessaire pour suivre votre plan de trading sans dévier.',
          category: 'psychologie',
          duration: '16:30',
          views: 956,
          publishedAt: new Date('2024-01-10').toISOString(),
          isPublished: true,
          thumbnail: 'https://readdy.ai/api/search-image?query=Disciplined%20trader%20writing%20in%20journal%2C%20organized%20desk%20with%20trading%20rules%20checklist%2C%20motivational%20quotes%20on%20wall%2C%20structured%20learning%20environment%2C%20professional%20mindset%20development&width=400&height=225&seq=psych3&orientation=landscape',
          videoUrl: ''
        },
        {
          id: 'psych-4',
          title: 'La psychologie des pertes',
          description: 'Accepter et gérer les pertes comme partie intégrante du trading. Techniques pour rebondir après des échecs.',
          category: 'psychologie',
          duration: '20:00',
          views: 823,
          publishedAt: new Date('2024-01-08').toISOString(),
          isPublished: true,
          thumbnail: 'https://readdy.ai/api/search-image?query=Phoenix%20rising%20from%20ashes%20metaphor%2C%20recovery%20and%20resilience%20concept%2C%20dark%20background%20with%20rising%20flames%2C%20trading%20comeback%20story%2C%20psychological%20strength%20visualization&width=400&height=225&seq=psych4&orientation=landscape',
          videoUrl: ''
        },
        {
          id: 'psych-5',
          title: 'Confiance vs surconfiance',
          description: 'Trouver l\'équilibre entre confiance nécessaire et surconfiance dangereuse dans vos décisions de trading.',
          category: 'psychologie',
          duration: '17:45',
          views: 734,
          publishedAt: new Date('2024-01-05').toISOString(),
          isPublished: true,
          thumbnail: 'https://readdy.ai/api/search-image?query=Tightrope%20walker%20balancing%20between%20confidence%20and%20overconfidence%2C%20metaphorical%20illustration%2C%20business%20professional%20theme%2C%20risk%20management%20concept%2C%20balanced%20mindset%20visualization&width=400&height=225&seq=psych5&orientation=landscape',
          videoUrl: ''
        },
        {
          id: 'psych-6',
          title: 'Routine et rituel de trading',
          description: 'Créer des routines pré-trading efficaces pour optimiser votre état d\'esprit et vos performances.',
          category: 'psychologie',
          duration: '14:20',
          views: 687,
          publishedAt: new Date('2024-01-03').toISOString(),
          isPublished: true,
          thumbnail: 'https://readdy.ai/api/search-image?query=Morning%20routine%20of%20successful%20trader%2C%20organized%20workspace%20setup%2C%20coffee%20and%20charts%2C%20systematic%20approach%20to%20trading%20preparation%2C%20professional%20morning%20ritual%20atmosphere&width=400&height=225&seq=psych6&orientation=landscape',
          videoUrl: ''
        },
        {
          id: 'psych-7',
          title: 'Stress et performance',
          description: 'Comprendre la relation entre stress et performance en trading. Techniques de gestion du stress haute performance.',
          category: 'psychologie',
          duration: '19:30',
          views: 592,
          publishedAt: new Date('2024-01-01').toISOString(),
          isPublished: true,
          thumbnail: 'https://readdy.ai/api/search-image?query=Calm%20trader%20under%20pressure%2C%20stress%20management%20techniques%2C%20serene%20professional%20environment%2C%20meditation%20and%20focus%2C%20high-performance%20mindset%20visualization%2C%20peaceful%20trading%20setup&width=400&height=225&seq=psych7&orientation=landscape',
          videoUrl: ''
        },
        {
          id: 'psych-8',
          title: 'Mental des traders gagnants',
          description: 'Analyse des traits psychologiques communs chez les traders les plus performants et comment les développer.',
          category: 'psychologie',
          duration: '25:15',
          views: 1156,
          publishedAt: new Date('2023-12-28').toISOString(),
          isPublished: true,
          thumbnail: 'https://readdy.ai/api/search-image?query=Winner%20mindset%20visualization%2C%20champion%20trader%20celebrating%20success%2C%20golden%20trophy%20and%20charts%2C%20achievement%20psychology%2C%20mental%20strength%20and%20determination%2C%20success%20mindset%20development&width=400&height=225&seq=psych8&orientation=landscape',
          videoUrl: ''
        },
        {
          id: 'psych-9',
          title: 'Surmonter la paralysie décisionnelle',
          description: 'Techniques pour prendre des décisions rapides et efficaces même dans l\'incertitude des marchés financiers.',
          category: 'psychologie',
          duration: '21:00',
          views: 845,
          publishedAt: new Date('2023-12-25').toISOString(),
          isPublished: true,
          thumbnail: 'https://readdy.ai/api/search-image?query=Decision-making%20crossroads%2C%20multiple%20paths%20and%20choices%2C%20business%20decision%20concept%2C%20clear%20thinking%20under%20pressure%2C%20decisive%20action%20visualization%2C%20professional%20choice-making%20environment&width=400&height=225&seq=psych9&orientation=landscape',
          videoUrl: ''
        }
      ];
      
      setVideos([...psychologyVideos, ...demoVideos.slice(0, 9 - psychologyVideos.length)]);
    } else {
      setVideos(psychologyVideos);
    }
  }, []);

  const handleVideoPlay = (video: Video) => {
    setSelectedVideo(video);
    setShowVideoModal(true);
  };

  const closeVideoModal = () => {
    setShowVideoModal(false);
    setTimeout(() => {
      setSelectedVideo(null);
    }, 100);
  };

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && showVideoModal) {
        closeVideoModal();
      }
    };

    if (showVideoModal) {
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    }

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'auto';
    };
  }, [showVideoModal]);

  const filteredVideos = videos.filter(video =>
    (video.title || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (video.description || '').toLowerCase().includes(searchTerm.toLowerCase())
  );

  const sortedVideos = [...filteredVideos].sort((a, b) => {
    switch (sortBy) {
      case 'views':
        return b.views - a.views;
      case 'title':
        return a.title.localeCompare(b.title);
      case 'date':
      default:
        return new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime();
    }
  });

  return (
    <>
      <div className="min-h-screen bg-black text-white">
        <Header />
        
        {/* Hero Section */}
        <section className="py-20 bg-gradient-to-br from-red-600/20 to-red-800/10">
          <div className="container mx-auto px-6">
            <div className="text-center">
              {/* Bouton retour ajouté */}
              <div className="mb-6">
                <Link 
                  href="/academy" 
                  className="inline-flex items-center px-4 py-2 text-red-400 hover:text-red-300 transition-colors cursor-pointer"
                >
                  <i className="ri-arrow-left-line mr-2"></i>
                  Retour à l'Académie
                </Link>
              </div>

              <div className="w-20 h-20 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-6 border border-red-500/30">
                <i className="ri-brain-line text-3xl text-red-400"></i>
              </div>
              <h1 className="text-5xl font-bold mb-6">
                Psychologie du <span className="text-red-400">Trading</span>
              </h1>
              <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
                Développez un mental de gagnant et maîtrisez vos émotions pour devenir un trader performant. 
                La psychologie représente 80% du succès en trading.
              </p>
              
              <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto mt-12">
                <div className="text-center">
                  <div className="text-3xl font-bold text-red-400 mb-2">{videos.length}</div>
                  <div className="text-gray-400">Formations</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-red-400 mb-2">4.8/5</div>
                  <div className="text-gray-400">Note Moyenne</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-red-400 mb-2">2,847</div>
                  <div className="text-gray-400">Étudiants</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Filtres et Recherche */}
        <section className="py-8 bg-gray-900/50">
          <div className="container mx-auto px-6">
            <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
              <div className="relative flex-1 max-w-md">
                <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                <input
                  type="text"
                  placeholder="Rechercher une formation..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-gray-800 border border-gray-700 rounded-lg focus:border-red-500 focus:outline-none text-sm"
                />
              </div>
              
              <div className="flex items-center space-x-4">
                <span className="text-sm text-gray-400">Trier par:</span>
                <div className="flex space-x-1 bg-gray-800 p-1 rounded-lg">
                  <button
                    onClick={() => setSortBy('date')}
                    className={`px-4 py-2 rounded-lg text-sm transition-all whitespace-nowrap ${
                      sortBy === 'date'
                        ? 'bg-red-500 text-white'
                        : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    Date
                  </button>
                  <button
                    onClick={() => setSortBy('views')}
                    className={`px-4 py-2 rounded-lg text-sm transition-all whitespace-nowrap ${
                      sortBy === 'views'
                        ? 'bg-red-500 text-white'
                        : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    Popularité
                  </button>
                  <button
                    onClick={() => setSortBy('title')}
                    className={`px-4 py-2 rounded-lg text-sm transition-all whitespace-nowrap ${
                      sortBy === 'title'
                        ? 'bg-red-500 text-white'
                        : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    Titre
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Liste des Vidéos */}
        <section className="py-16">
          <div className="container mx-auto px-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {sortedVideos.map((video) => (
                <div 
                  key={video.id} 
                  className="bg-gray-900 rounded-xl overflow-hidden border border-gray-800 hover:border-red-500/40 transition-all cursor-pointer group"
                  onClick={() => handleVideoPlay(video)}
                >
                  <div className="relative aspect-video bg-gray-800">
                    {video.thumbnail ? (
                      <img
                        src={video.thumbnail}
                        alt={video.title}
                        className="w-full h-full object-cover object-top"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <i className="ri-play-circle-line text-4xl text-gray-600"></i>
                      </div>
                    )}

                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all flex items-center justify-center">
                      <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                        <i className="ri-play-fill text-2xl text-white ml-1"></i>
                      </div>
                    </div>

                    <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/80 text-white text-xs rounded">
                      {video.duration}
                    </div>
                  </div>

                  <div className="p-6">
                    <div className="flex items-center justify-between mb-3">
                      <span className="px-3 py-1 bg-red-500/20 text-red-400 text-xs font-medium rounded-full">
                        Psychologie
                      </span>
                      <div className="flex items-center space-x-1 text-xs text-gray-500">
                        <i className="ri-eye-line"></i>
                        <span>{video.views}</span>
                      </div>
                    </div>

                    <h3 className="text-lg font-bold text-white mb-3 group-hover:text-red-400 transition-colors">
                      {video.title}
                    </h3>

                    {video.description && (
                      <p className="text-gray-400 text-sm mb-4 line-clamp-2">
                        {video.description}
                      </p>
                    )}

                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>{new Date(video.publishedAt).toLocaleDateString('fr-FR')}</span>
                      <div className="flex items-center space-x-2">
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <i key={i} className="ri-star-fill text-yellow-400 text-xs"></i>
                          ))}
                        </div>
                        <span>4.8</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {sortedVideos.length === 0 && (
              <div className="text-center py-12">
                <i className="ri-search-line text-4xl text-gray-600 mb-4"></i>
                <p className="text-gray-400">Aucune formation trouvée pour cette recherche</p>
              </div>
            )}
          </div>
        </section>

        <Footer />
      </div>

      {/* Modal Vidéo */}
      {showVideoModal && selectedVideo && (
        <div
          className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              closeVideoModal();
            }
          }}
        >
          <div className="bg-gray-900 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-hidden border border-red-500/20">
            <div className="flex items-center justify-between p-4 border-b border-gray-800">
              <h3 className="text-xl font-bold text-white">{selectedVideo.title}</h3>
              <button
                onClick={closeVideoModal}
                className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-800 transition-colors cursor-pointer"
              >
                <i className="ri-close-line text-xl text-gray-400 hover:text-white"></i>
              </button>
            </div>

            <div className="aspect-video bg-black">
              {selectedVideo.videoUrl ? (
                <video
                  key={selectedVideo.id}
                  src={selectedVideo.videoUrl}
                  controls
                  autoPlay
                  className="w-full h-full"
                  poster={selectedVideo.thumbnail}
                >
                  Votre navigateur ne supporte pas la lecture vidéo.
                </video>
              ) : (
                <div className="w-full h-full flex items-center justify-center text-gray-400">
                  <div className="text-center">
                    <i className="ri-video-line text-4xl mb-4"></i>
                    <p className="text-lg mb-2">Vidéo de démonstration</p>
                    <p className="text-sm">Cette formation sera disponible prochainement</p>
                  </div>
                </div>
              )}
            </div>

            <div className="p-6">
              <div className="flex items-center space-x-4 mb-4">
                <span className="px-3 py-1 bg-red-500/20 text-red-400 text-sm font-medium rounded-full">
                  Psychologie du Trading
                </span>
                <span className="text-gray-400 text-sm">{selectedVideo.duration}</span>
                <span className="flex items-center space-x-1 text-gray-400 text-sm">
                  <i className="ri-eye-line"></i>
                  <span>{selectedVideo.views} vues</span>
                </span>
              </div>

              {selectedVideo.description && (
                <p className="text-gray-300 leading-relaxed">
                  {selectedVideo.description}
                </p>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
