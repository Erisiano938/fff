'use client';

export default function LearningPath() {
  const learningSteps = [
    {
      step: '01',
      title: 'Fondamentaux',
      description: 'Comprenez les bases des marchés financiers et du trading',
      courses: 'Bases du Trading, Introduction aux Marchés',
      duration: '4 semaines'
    },
    {
      step: '02',
      title: 'Analyse Technique',
      description: 'Apprenez à lire les graphiques et utiliser les indicateurs',
      courses: 'Chartisme, Indicateurs Techniques, Patterns',
      duration: '6 semaines'
    },
    {
      step: '03',
      title: 'Stratégies',
      description: 'Développez vos propres stratégies de trading',
      courses: 'Swing Trading, Day Trading, Scalping',
      duration: '8 semaines'
    },
    {
      step: '04',
      title: 'Gestion des Risques',
      description: 'Maîtrisez la gestion du capital et des risques',
      courses: 'Money Management, Risk Management',
      duration: '4 semaines'
    },
    {
      step: '05',
      title: 'Trading Avancé',
      description: 'Techniques avancées et trading algorithmique',
      courses: 'Algo Trading, Options, Futures',
      duration: '10 semaines'
    }
  ];

  return (
    <section className="py-16 bg-gray-900">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">
            Parcours d\'<span className="text-yellow-400">Apprentissage</span>
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Un parcours structuré pour devenir un trader professionnel, étape par étape.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          {learningSteps.map((step, index) => (
            <div key={index} className="relative flex items-start mb-8 last:mb-0">
              <div className="flex flex-col items-center mr-8">
                <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center text-black font-bold text-lg mb-4">
                  {step.step}
                </div>
                {index < learningSteps.length - 1 && (
                  <div className="w-0.5 h-20 bg-yellow-500/30"></div>
                )}
              </div>
              
              <div className="flex-1 bg-black/50 p-6 rounded-xl border border-yellow-500/20 hover:border-yellow-500/40 transition-all cursor-pointer">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-2xl font-bold text-white">{step.title}</h3>
                  <span className="text-yellow-400 text-sm font-semibold">{step.duration}</span>
                </div>
                <p className="text-gray-400 mb-4 leading-relaxed">{step.description}</p>
                <div className="text-sm text-gray-500 mb-4">
                  <strong className="text-gray-400">Cours inclus:</strong> {step.courses}
                </div>
                <button className="text-yellow-400 hover:text-yellow-300 font-semibold cursor-pointer whitespace-nowrap">
                  Commencer cette étape →
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <div className="bg-black/50 p-8 rounded-xl border border-yellow-500/20 max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold text-white mb-4">Prêt à commencer ?</h3>
            <p className="text-gray-400 mb-6">
              Rejoignez plus de 25,000 étudiants qui ont déjà transformé leur approche du trading.
            </p>
            <button className="bg-yellow-500 text-black px-8 py-4 rounded-lg font-semibold hover:bg-yellow-400 transition-colors cursor-pointer whitespace-nowrap">
              Démarrer mon Parcours
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}