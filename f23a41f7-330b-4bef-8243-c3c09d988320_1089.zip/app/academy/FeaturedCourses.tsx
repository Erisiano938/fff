'use client';

import Link from 'next/link';

export default function FeaturedCourses() {
  const featuredCourses = [
    {
      title: 'Trading Forex pour Débutants',
      instructor: 'Jean-Michel Dubois',
      duration: '8h 30min',
      students: '12,450',
      rating: '4.9',
      price: 'Gratuit',
      level: 'Débutant',
      image: 'https://readdy.ai/api/search-image?query=Professional%20forex%20trading%20course%20interface%20with%20modern%20educational%20design%2C%20dark%20theme%20with%20golden%20accents%20showing%20currency%20charts%20and%20trading%20fundamentals%2C%20clean%20learning%20environment%20with%20forex%20market%20analysis%20displays%20and%20educational%20content&width=400&height=250&seq=course1&orientation=landscape'
    },
    {
      title: 'Maîtriser l\'Analyse Technique',
      instructor: 'Sophie Martin',
      duration: '12h 15min',
      students: '8,750',
      rating: '4.8',
      price: '199€',
      level: 'Intermédiaire',
      image: 'https://readdy.ai/api/search-image?query=Advanced%20technical%20analysis%20course%20interface%20with%20sophisticated%20chart%20patterns%20and%20indicators%2C%20dark%20themed%20educational%20platform%20with%20golden%20highlights%20showing%20complex%20trading%20analysis%20tools%20and%20market%20data%20visualization&width=400&height=250&seq=course2&orientation=landscape'
    },
    {
      title: 'Stratégies de Day Trading',
      instructor: 'Marc Lefebvre',
      duration: '15h 45min',
      students: '6,320',
      rating: '4.9',
      price: '299€',
      level: 'Avancé',
      image: 'https://readdy.ai/api/search-image?query=Day%20trading%20strategies%20course%20with%20multiple%20monitor%20setup%20showing%20real-time%20market%20data%2C%20professional%20trading%20environment%20with%20dark%20theme%20and%20golden%20accents%2C%20advanced%20trading%20platform%20interface%20with%20live%20charts%20and%20strategy%20displays&width=400&height=250&seq=course3&orientation=landscape'
    }
  ];

  return (
    <section className="py-16 bg-black">
      <div className="container mx-auto px-6">
        <div className="flex items-center justify-between mb-12">
          <div>
            <h2 className="text-4xl font-bold text-white mb-4">
              Cours <span className="text-yellow-400">Populaires</span>
            </h2>
            <p className="text-xl text-gray-400">
              Les formations les plus suivies par notre communauté.
            </p>
          </div>
          <button className="text-yellow-400 hover:text-yellow-300 font-semibold cursor-pointer whitespace-nowrap">
            Voir tous les cours →
          </button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredCourses.map((course, index) => (
            <div key={index} className="bg-gray-900/50 rounded-xl overflow-hidden border border-yellow-500/20 hover:border-yellow-500/40 transition-all duration-300 hover:scale-105 cursor-pointer">
              <div 
                className="h-48 bg-cover bg-center"
                style={{ backgroundImage: `url('${course.image}')` }}
              />
              <div className="p-6">
                <div className="flex items-center gap-2 mb-3">
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                    course.level === 'Débutant' ? 'bg-green-500/20 text-green-400' :
                    course.level === 'Intermédiaire' ? 'bg-blue-500/20 text-blue-400' :
                    'bg-purple-500/20 text-purple-400'
                  }`}>
                    {course.level}
                  </span>
                  <div className="flex items-center text-yellow-400 text-sm">
                    <i className="ri-star-fill mr-1"></i>
                    {course.rating}
                  </div>
                </div>
                
                <h3 className="text-xl font-bold text-white mb-2">{course.title}</h3>
                <p className="text-gray-400 text-sm mb-4">Par {course.instructor}</p>
                
                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <div className="flex items-center">
                    <i className="ri-time-line mr-1"></i>
                    {course.duration}
                  </div>
                  <div className="flex items-center">
                    <i className="ri-user-line mr-1"></i>
                    {course.students}
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="text-2xl font-bold text-yellow-400">{course.price}</div>
                  <Link href="/payment" className="bg-yellow-500 text-black px-6 py-2 rounded-lg font-semibold hover:bg-yellow-400 transition-colors cursor-pointer whitespace-nowrap">
                    S'inscrire
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}