
'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';

interface AcademyContent {
  id: string;
  title: string;
  description: string;
  category: string;
  type: 'video' | 'blog';
  isPublished: boolean;
}

export default function CourseCategories() {
  const [courseCounts, setCourseCounts] = useState({
    'trading-debutant': 0,
    'analyse-technique': 0,
    'analyse-fondamentale': 0,
    'gestion-risques': 0,
    'trading-avance': 0,
    'psychologie': 0
  });

  useEffect(() => {
    loadCourseCounts();
  }, []);

  // Actualiser automatiquement toutes les 10 secondes
  useEffect(() => {
    const interval = setInterval(() => {
      loadCourseCounts();
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  const loadCourseCounts = () => {
    // Charger depuis toutes les sources possibles
    let allContent: AcademyContent[] = [];

    // 1. Contenu de l'académie spécifique
    const savedContent = localStorage.getItem('cmv_academy_content');
    if (savedContent) {
      try {
        const academyContent = JSON.parse(savedContent);
        allContent = [...allContent, ...academyContent];
      } catch (e) {
        console.log('Erreur lors du chargement du contenu académie');
      }
    }

    // 2. Vidéos du système principal
    const savedVideos = localStorage.getItem('videos');
    if (savedVideos) {
      try {
        const videos = JSON.parse(savedVideos);
        const videoContent = videos.map((video: any) => ({
          id: `video-${video.id}`,
          title: video.title,
          category: video.category,
          type: 'video' as const,
          isPublished: video.isPublished
        }));
        allContent = [...allContent, ...videoContent];
      } catch (e) {
        console.log('Erreur lors du chargement des vidéos');
      }
    }

    // 3. Blogs du système principal
    const savedBlogs = localStorage.getItem('blog_posts');
    if (savedBlogs) {
      try {
        const blogs = JSON.parse(savedBlogs);
        const blogContent = blogs.map((blog: any) => ({
          id: `blog-${blog.id}`,
          title: blog.title,
          category: blog.category,
          type: 'blog' as const,
          isPublished: blog.isPublished
        }));
        allContent = [...allContent, ...blogContent];
      } catch (e) {
        console.log('Erreur lors du chargement des blogs');
      }
    }

    // Dédoublonner par titre et catégorie
    const uniqueContent = allContent.filter((content, index, self) => 
      index === self.findIndex((c) => c.title === content.title && c.category === content.category)
    );

    // Compter par catégorie (seulement le contenu publié)
    const counts = {
      'trading-debutant': 0,
      'analyse-technique': 0,
      'analyse-fondamentale': 0,
      'gestion-risques': 0,
      'trading-avance': 0,
      'psychologie': 0
    };

    const publishedContent = uniqueContent.filter(content => content.isPublished);
    
    publishedContent.forEach((content) => {
      if (counts.hasOwnProperty(content.category)) {
        counts[content.category as keyof typeof counts]++;
      }
    });

    console.log('Compteurs mis à jour:', counts);
    setCourseCounts(counts);
  };

  const categories = [
    {
      title: 'Trading pour Débutants',
      description: 'Apprenez les bases du trading et de l\'analyse financière',
      courseCount: `${courseCounts['trading-debutant']} cours`,
      icon: 'ri-rocket-line',
      color: 'bg-green-500/20 border-green-500/30',
      iconColor: 'text-green-400',
      href: '/academy/trading-debutant',
      category: 'trading-debutant'
    },
    {
      title: 'Analyse Technique',
      description: 'Maîtrisez les graphiques, indicateurs et patterns',
      courseCount: `${courseCounts['analyse-technique']} cours`,
      icon: 'ri-line-chart-line',
      color: 'bg-blue-500/20 border-blue-500/30',
      iconColor: 'text-blue-400',
      href: '/academy/analyse-technique',
      category: 'analyse-technique'
    },
    {
      title: 'Analyse Fondamentale',
      description: 'Évaluez la valeur intrinsèque des actifs',
      courseCount: `${courseCounts['analyse-fondamentale']} cours`,
      icon: 'ri-file-text-line',
      color: 'bg-purple-500/20 border-purple-500/30',
      iconColor: 'text-purple-400',
      href: '/academy/analyse-fondamentale',
      category: 'analyse-fondamentale'
    },
    {
      title: 'Gestion des Risques',
      description: 'Protégez votre capital avec des stratégies éprouvées',
      courseCount: `${courseCounts['gestion-risques']} cours`,
      icon: 'ri-shield-line',
      color: 'bg-red-500/20 border-red-500/30',
      iconColor: 'text-red-400',
      href: '/academy/gestion-risques',
      category: 'gestion-risques'
    },
    {
      title: 'Trading Avancé',
      description: 'Stratégies sophistiquées et trading algorithmique',
      courseCount: `${courseCounts['trading-avance']} cours`,
      icon: 'ri-settings-3-line',
      color: 'bg-yellow-500/20 border-yellow-500/30',
      iconColor: 'text-yellow-400',
      href: '/academy/trading-avance',
      category: 'trading-avance'
    },
    {
      title: 'Psychologie du Trading',
      description: 'Développez un mental de trader gagnant',
      courseCount: `${courseCounts['psychologie']} cours`,
      icon: 'ri-brain-line',
      color: 'bg-pink-500/20 border-pink-500/30',
      iconColor: 'text-pink-400',
      href: '/academy/psychologie',
      category: 'psychologie'
    }
  ];

  return (
    <section className="py-16 bg-gray-900">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">
            Catégories de <span className="text-yellow-400">Formation</span>
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Choisissez votre parcours d\'apprentissage selon votre niveau et vos objectifs.
          </p>
          <button 
            onClick={loadCourseCounts}
            className="mt-4 text-sm text-yellow-400 hover:text-yellow-300 cursor-pointer flex items-center justify-center mx-auto"
          >
            <i className="ri-refresh-line mr-1"></i>
            Actualiser les compteurs
          </button>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {categories.map((category, index) => (
            <div 
              key={index} 
              className={`${category.color} p-6 rounded-xl border hover:scale-105 transition-all duration-300 cursor-pointer`}
            >
              <div className={`w-12 h-12 ${category.color} rounded-lg flex items-center justify-center mb-4`}>
                <i className={`${category.icon} text-2xl ${category.iconColor}`}></i>
              </div>
              <h3 className="text-xl font-bold text-white mb-2">{category.title}</h3>
              <p className="text-gray-400 mb-4 leading-relaxed">{category.description}</p>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500 font-medium">{category.courseCount}</span>
                <Link href={category.href} className={`${category.iconColor} hover:opacity-80 font-semibold cursor-pointer whitespace-nowrap`}>
                  Explorer →
                </Link>
              </div>
            </div>
          ))}
        </div>

        {/* Message informatif */}
        <div className="mt-12 text-center">
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-4 max-w-2xl mx-auto">
            <p className="text-gray-400 text-sm">
              <i className="ri-information-line mr-2 text-blue-400"></i>
              Les compteurs se mettent à jour automatiquement avec les vidéos et articles que vous publiez dans l'administration
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
