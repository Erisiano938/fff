
'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { getAllPublishedArticles, getArticlesByCategory, searchArticles } from '../../lib/articleService';
import type { Article } from '../../lib/articleService';

export default function ExplorerPage() {
  const [articles, setArticles] = useState<Article[]>([]);
  const [filteredArticles, setFilteredArticles] = useState<Article[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [lastUpdateTime, setLastUpdateTime] = useState<string>('');

  // SYSTÈME DE DÉTECTION WORDPRESS-STYLE
  const loadArticles = async () => {
    try {
      setLoading(true);
      const startTime = Date.now();
      
      console.log('🔄 RECHARGEMENT DES ARTICLES - Style WordPress');
      
      // Lecture directe et immédiate du localStorage
      let blogPostsCount = 0;
      if (typeof window !== 'undefined') {
        try {
          const blogPosts = localStorage.getItem('blog_posts');
          const posts = blogPosts ? JSON.parse(blogPosts) : [];
          blogPostsCount = posts.length;
          console.log('📦 Articles dans localStorage:', blogPostsCount);
          console.log('📋 Détail des articles:', posts.map((p: any) => ({ id: p.id, title: p.title })));
        } catch (e) {
          console.warn('Erreur lecture localStorage:', e);
        }
      }
      
      // Charger via le service
      const allArticles = await getAllPublishedArticles();
      console.log('✅ Service retourne:', allArticles.length, 'articles');
      
      setArticles(allArticles);
      setFilteredArticles(allArticles);

      // Extraire les catégories uniques
      const uniqueCategories = [...new Set(allArticles.map(article => article.category))];
      setCategories(uniqueCategories);
      
      const loadTime = Date.now() - startTime;
      const updateTime = new Date().toLocaleTimeString('fr-FR');
      setLastUpdateTime(updateTime);
      
      console.log(`⚡ Chargement terminé en ${loadTime}ms à ${updateTime}`);
      console.log('🏷️ Catégories:', uniqueCategories);
      
    } catch (error) {
      console.error('❌ Erreur lors du chargement des articles:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    console.log('🚀 INITIALISATION DE L\'EXPLORER');
    loadArticles();

    // SYSTÈME D'ÉCOUTE WORDPRESS-STYLE
    
    // 1. Écoute des événements personnalisés (priorité maximale)
    const handleArticleUpdate = (event: Event) => {
      console.log('🔔 Événement articlesUpdated reçu:', event);
      setTimeout(loadArticles, 50); // Rechargement immédiat
    };

    const handleBlogPostCreated = (event: Event) => {
      console.log('🔔 Événement blogPostCreated reçu:', event);
      setTimeout(loadArticles, 50);
    };

    // 2. Écoute des changements de localStorage
    const handleStorageChange = (event: StorageEvent) => {
      console.log('🔔 Changement localStorage détecté:', {
        key: event.key,
        newValue: event.newValue ? 'Données présentes' : 'Pas de données'
      });
      
      if (event.key === 'blog_posts') {
        setTimeout(loadArticles, 100);
      }
    };

    // 3. Polling intelligent (comme WordPress)
    let lastKnownCount = 0;
    if (typeof window !== 'undefined') {
      try {
        const blogPosts = localStorage.getItem('blog_posts');
        lastKnownCount = blogPosts ? JSON.parse(blogPosts).length : 0;
      } catch (e) {}
    }

    const intelligentPolling = () => {
      if (typeof window !== 'undefined') {
        try {
          const blogPosts = localStorage.getItem('blog_posts');
          const currentCount = blogPosts ? JSON.parse(blogPosts).length : 0;
          
          if (currentCount !== lastKnownCount) {
            console.log(`📊 CHANGEMENT DÉTECTÉ: ${lastKnownCount} → ${currentCount} articles`);
            lastKnownCount = currentCount;
            loadArticles();
          }
        } catch (e) {
          console.warn('Erreur polling:', e);
        }
      }
    };

    // 4. Recharger au focus de la fenêtre
    const handleFocus = () => {
      console.log('👁️ Fenêtre récupère le focus, rechargement...');
      loadArticles();
    };

    // ENREGISTREMENT DES ÉCOUTEURS
    window.addEventListener('articlesUpdated', handleArticleUpdate);
    window.addEventListener('blogPostCreated', handleBlogPostCreated);
    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('focus', handleFocus);

    // Polling toutes les 3 secondes (comme WordPress)
    const pollingInterval = setInterval(intelligentPolling, 3000);

    // NETTOYAGE
    return () => {
      console.log('🧹 Nettoyage des écouteurs');
      window.removeEventListener('articlesUpdated', handleArticleUpdate);
      window.removeEventListener('blogPostCreated', handleBlogPostCreated);
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('focus', handleFocus);
      clearInterval(pollingInterval);
    };
  }, []);

  useEffect(() => {
    async function filterArticles() {
      let filtered = articles;

      // Filtrer par recherche
      if (searchQuery.trim()) {
        filtered = await searchArticles(searchQuery);
      }

      // Filtrer par catégorie
      if (selectedCategory !== 'all') {
        filtered = filtered.filter(article => article.category === selectedCategory);
      }

      setFilteredArticles(filtered);
    }

    filterArticles();
  }, [searchQuery, selectedCategory, articles]);

  // Fonction de rechargement manuel avec feedback amélioré
  const handleManualRefresh = async () => {
    console.log('🔄 ACTUALISATION MANUELLE FORCÉE');
    
    const button = document.querySelector('[data-refresh-btn]') as HTMLButtonElement;
    if (button) {
      button.innerHTML = '<i class="ri-loader-line mr-2 animate-spin"></i>Actualisation...';
      button.disabled = true;
    }
    
    try {
      await loadArticles();
      
      if (button) {
        button.innerHTML = '<i class="ri-check-line mr-2"></i>Actualisé !';
        setTimeout(() => {
          button.innerHTML = '<i class="ri-refresh-line mr-2"></i>Actualiser';
          button.disabled = false;
        }, 2000);
      }
    } catch (error) {
      console.error('Erreur lors de l\'actualisation:', error);
      if (button) {
        button.innerHTML = '<i class="ri-error-warning-line mr-2"></i>Erreur';
        setTimeout(() => {
          button.innerHTML = '<i class="ri-refresh-line mr-2"></i>Actualiser';
          button.disabled = false;
        }, 2000);
      }
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center mb-12">
            <div className="animate-pulse">
              <div className="h-12 bg-gray-800 rounded mb-4 w-1/3 mx-auto"></div>
              <div className="h-6 bg-gray-800 rounded w-1/2 mx-auto"></div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(9)].map((_, index) => (
              <div key={index} className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-xl p-6 animate-pulse">
                <div className="w-full h-48 bg-gray-800 rounded-lg mb-4"></div>
                <div className="h-4 bg-gray-800 rounded mb-2"></div>
                <div className="h-4 bg-gray-800 rounded w-3/4 mb-4"></div>
                <div className="h-3 bg-gray-800 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-950">
      {/* En-tête */}
      <div className="bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-white mb-4">Explorer les Articles</h1>
            <p className="text-xl text-gray-400 mb-8">
              Découvrez tous nos contenus éducatifs sur le trading et l'investissement
            </p>
            
            {/* Barre de recherche */}
            <div className="max-w-md mx-auto relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <i className="ri-search-line text-gray-400"></i>
              </div>
              <input
                type="text"
                placeholder="Rechercher un article..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-gray-900/50 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-yellow-500 transition-colors text-sm"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* PANNEAU DE CONTRÔLE WORDPRESS-STYLE */}
        <div className="mb-8 p-4 bg-gray-900/50 rounded-lg border border-gray-800">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center space-x-4">
              <button
                data-refresh-btn
                onClick={handleManualRefresh}
                className="inline-flex items-center px-4 py-2 bg-yellow-500 hover:bg-yellow-600 text-black font-medium rounded-lg transition-colors text-sm whitespace-nowrap"
              >
                <i className="ri-refresh-line mr-2"></i>
                Actualiser
              </button>
              
              <div className="text-sm text-gray-400">
                <span className="font-medium text-green-400">{articles.length}</span> articles chargés
              </div>
            </div>
            
            <div className="flex items-center space-x-4 text-xs text-gray-500">
              {lastUpdateTime && (
                <span>Dernière mise à jour: {lastUpdateTime}</span>
              )}
              <span>
                Blog posts: {typeof window !== 'undefined' ? (localStorage.getItem('blog_posts') ? JSON.parse(localStorage.getItem('blog_posts') || '[]').length : 0) : 0}
              </span>
            </div>
          </div>
        </div>

        {/* Filtres par catégorie */}
        <div className="mb-12">
          <div className="flex flex-wrap justify-center gap-4">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap ${
                selectedCategory === 'all'
                  ? 'bg-yellow-500 text-black'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              Tous ({articles.length})
            </button>
            {categories.map((category) => {
              const count = articles.filter(article => article.category === category).length;
              return (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-6 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap ${
                    selectedCategory === category
                      ? 'bg-yellow-500 text-black'
                      : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                  }`}
                >
                  {category} ({count})
                </button>
              );
            })}
          </div>
        </div>

        {/* Statistiques */}
        <div className="mb-8 text-center">
          <p className="text-gray-400">
            {filteredArticles.length} article{filteredArticles.length > 1 ? 's' : ''} trouvé{filteredArticles.length > 1 ? 's' : ''}
            {searchQuery && ` pour "${searchQuery}"`}
            {selectedCategory !== 'all' && ` dans la catégorie "${selectedCategory}"`}
          </p>
        </div>

        {/* Grille des articles */}
        {filteredArticles.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredArticles.map((article) => (
              <Link
                key={article.id}
                href={`/academy/article/${article.id}`}
                className="group"
              >
                <article className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-xl overflow-hidden hover:border-yellow-500/30 transition-all duration-300 group-hover:bg-gray-900/70 h-full flex flex-col">
                  {article.coverImage && (
                    <div className="aspect-video overflow-hidden">
                      <img 
                        src={article.coverImage} 
                        alt={article.title}
                        className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                  )}
                  <div className="p-6 flex-1 flex flex-col">
                    <div className="flex items-center justify-between mb-3">
                      <span className="inline-block px-3 py-1 bg-yellow-500/10 text-yellow-500 text-xs font-medium rounded-full">
                        {article.category}
                      </span>
                      <div className="flex items-center text-xs text-gray-400 space-x-3">
                        <span className="flex items-center">
                          <i className="ri-eye-line mr-1"></i>
                          {article.views || 0}
                        </span>
                        <span className="flex items-center">
                          <i className="ri-time-line mr-1"></i>
                          {article.readingTime || 5} min
                        </span>
                      </div>
                    </div>
                    <h3 className="font-bold text-white mb-2 group-hover:text-yellow-500 transition-colors line-clamp-2 flex-1">
                      {article.title}
                    </h3>
                    {article.description && (
                      <p className="text-gray-400 text-sm mb-4 line-clamp-3">
                        {article.description}
                      </p>
                    )}
                    <div className="flex items-center justify-between text-xs text-gray-500 mt-auto">
                      <span className="flex items-center">
                        <i className="ri-user-line mr-1"></i>
                        {article.author}
                      </span>
                      <span>{new Date(article.createdAt).toLocaleDateString('fr-FR')}</span>
                    </div>
                    
                    {/* Tags */}
                    {article.tags && article.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-3">
                        {article.tags.slice(0, 3).map((tag, index) => (
                          <span key={index} className="px-2 py-1 bg-gray-800 text-gray-400 text-xs rounded">
                            #{tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </article>
              </Link>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <div className="w-20 h-20 mx-auto mb-6 flex items-center justify-center">
              <i className="ri-search-line text-6xl text-gray-600"></i>
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">Aucun article trouvé</h3>
            <p className="text-gray-400 mb-8">
              {searchQuery 
                ? `Aucun résultat pour "${searchQuery}"` 
                : `Aucun article dans la catégorie "${selectedCategory}"`}
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
              }}
              className="inline-flex items-center px-6 py-3 bg-yellow-500 hover:bg-yellow-600 text-black font-semibold rounded-lg transition-colors whitespace-nowrap"
            >
              <i className="ri-refresh-line mr-2"></i>
              Voir tous les articles
            </button>
          </div>
        )}

        {/* Retour à l'académie */}
        <div className="text-center mt-16">
          <Link
            href="/academy"
            className="inline-flex items-center px-8 py-3 bg-gray-800 hover:bg-gray-700 text-white font-semibold rounded-lg transition-colors whitespace-nowrap"
          >
            <i className="ri-arrow-left-line mr-2"></i>
            Retour à l'académie
          </Link>
        </div>
      </div>
    </div>
  );
}
