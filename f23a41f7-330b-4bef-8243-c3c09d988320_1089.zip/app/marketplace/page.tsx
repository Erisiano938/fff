
'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function MarketplacePage() {
  const [activeCategory, setActiveCategory] = useState('notaires');
  const [selectedService, setSelectedService] = useState(null);
  const [showBooking, setShowBooking] = useState(false);

  const categories = [
    { id: 'notaires', name: 'Notaires', icon: 'ri-file-text-line' },
    { id: 'avocats', name: 'Avocats', icon: 'ri-scales-3-line' },
    { id: 'courtiers', name: 'Courtiers FX', icon: 'ri-exchange-line' },
    { id: 'assurances', name: 'Assurances', icon: 'ri-shield-check-line' }
  ];

  const services = {
    notaires: [
      {
        id: 1,
        name: 'Me. Sophie Dubois',
        speciality: 'Immobilier & Succession',
        rating: 4.9,
        reviews: 156,
        price: '180€/h',
        commission: '8%',
        availability: 'Disponible aujourd\'hui',
        location: 'Paris 8ème',
        features: ['Achat immobilier', 'Testament', 'Donation', 'Mariage']
      },
      {
        id: 2,
        name: 'Me. Pierre Martin',
        speciality: 'Droit des affaires',
        rating: 4.8,
        reviews: 89,
        price: '200€/h',
        commission: '10%',
        availability: 'Disponible demain',
        location: 'Lyon 2ème',
        features: ['Création société', 'Cession parts', 'Contrats', 'Bail commercial']
      },
      {
        id: 3,
        name: 'Me. Claire Rousseau',
        speciality: 'Famille & Patrimoine',
        rating: 4.7,
        reviews: 203,
        price: '160€/h',
        commission: '7%',
        availability: 'Disponible cette semaine',
        location: 'Marseille 1er',
        features: ['Divorce', 'Garde enfants', 'Pension alimentaire', 'Succession']
      }
    ],
    avocats: [
      {
        id: 4,
        name: 'Me. Antoine Leroy',
        speciality: 'Droit fiscal',
        rating: 4.9,
        reviews: 124,
        price: '220€/h',
        commission: '12%',
        availability: 'Disponible aujourd\'hui',
        location: 'Paris 16ème',
        features: ['Optimisation fiscale', 'Contrôle fiscal', 'ISF', 'Plus-values']
      },
      {
        id: 5,
        name: 'Me. Isabelle Moreau',
        speciality: 'Droit des affaires',
        rating: 4.8,
        reviews: 167,
        price: '250€/h',
        commission: '15%',
        availability: 'Disponible demain',
        location: 'Bordeaux',
        features: ['Contentieux commercial', 'Recouvrement', 'Contrats', 'Propriété intellectuelle']
      }
    ],
    courtiers: [
      {
        id: 8,
        name: 'FX Trading Pro',
        speciality: 'Trading Forex',
        rating: 4.8,
        reviews: 234,
        price: '0€',
        commission: '25%',
        availability: 'Inscription immédiate',
        location: 'En ligne',
        features: ['Spreads serrés', 'Effet de levier', 'Signaux trading', 'Formation']
      },
      {
        id: 9,
        name: 'Capital Markets',
        speciality: 'Actions & ETF',
        rating: 4.9,
        reviews: 345,
        price: '0€',
        commission: '30%',
        availability: 'Inscription immédiate',
        location: 'En ligne',
        features: ['0% commission', 'Fractionnaire', 'Dividendes', 'Options']
      }
    ],
    assurances: [
      {
        id: 10,
        name: 'Allianz Patrimoine',
        speciality: 'Assurance vie',
        rating: 4.7,
        reviews: 178,
        price: '0€',
        commission: '2.5%',
        availability: 'Souscription en ligne',
        location: 'Toute la France',
        features: ['Fonds euros', 'Unités de compte', 'Gestion pilotée', 'Rachat partiel']
      },
      {
        id: 11,
        name: 'Generali Epargne',
        speciality: 'Prévoyance',
        rating: 4.6,
        reviews: 134,
        price: '0€',
        commission: '3%',
        availability: 'Devis instantané',
        location: 'Toute la France',
        features: ['Invalidité', 'Décès', 'Arrêt travail', 'Rente']
      }
    ]
  };

  const handleBooking = (service) => {
    setSelectedService(service);
    setShowBooking(true);
  };

  const BookingModal = () => (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-6 max-w-md w-full mx-4">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">Réserver un rendez-vous</h3>
          <button onClick={() => setShowBooking(false)} className="text-gray-500 hover:text-gray-700">
            <i className="ri-close-line text-xl"></i>
          </button>
        </div>

        <div className="mb-4">
          <p className="font-medium">{selectedService?.name}</p>
          <p className="text-sm text-gray-600">{selectedService?.speciality}</p>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Date souhaitée</label>
            <input type="date" className="w-full p-2 border rounded-lg" />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Heure préférée</label>
            <select className="w-full p-2 border rounded-lg pr-8">
              <option>09:00</option>
              <option>10:00</option>
              <option>11:00</option>
              <option>14:00</option>
              <option>15:00</option>
              <option>16:00</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Motif de la consultation</label>
            <textarea className="w-full p-2 border rounded-lg" rows="3" maxLength="500"></textarea>
          </div>
        </div>

        <div className="mt-6 flex gap-3">
          <button 
            onClick={() => setShowBooking(false)}
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
          >
            Annuler
          </button>
          <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            Confirmer
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Marketplace de Services</h1>
              <p className="text-gray-600 mt-1">Trouvez et réservez des professionnels de confiance</p>
            </div>
            <Link href="/" className="text-blue-600 hover:text-blue-800">
              <i className="ri-arrow-left-line mr-2"></i>
              Retour à l'accueil
            </Link>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="lg:w-1/4">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="font-semibold mb-4">Catégories de services</h2>
              <div className="space-y-2">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setActiveCategory(category.id)}
                    className={`w-full flex items-center p-3 rounded-lg text-left transition-colors ${
                      activeCategory === category.id
                        ? 'bg-blue-50 text-blue-600 border-2 border-blue-200'
                        : 'hover:bg-gray-50 border-2 border-transparent'
                    }`}
                  >
                    <div className="w-6 h-6 flex items-center justify-center mr-3">
                      <i className={`${category.icon} text-lg`}></i>
                    </div>
                    <span className="font-medium">{category.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:w-3/4">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold capitalize">
                {categories.find(cat => cat.id === activeCategory)?.name}
              </h2>
              <div className="flex items-center gap-4">
                <select className="p-2 border rounded-lg pr-8">
                  <option>Trier par pertinence</option>
                  <option>Note la plus élevée</option>
                  <option>Prix croissant</option>
                  <option>Disponibilité</option>
                </select>
              </div>
            </div>

            <div className="grid gap-6">
              {services[activeCategory]?.map((service) => (
                <div key={service.id} className="bg-white rounded-lg shadow-sm p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">{service.name}</h3>
                      <p className="text-blue-600 font-medium">{service.speciality}</p>
                      <p className="text-sm text-gray-600 mt-1">{service.location}</p>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center mb-1">
                        <i className="ri-star-fill text-yellow-400 mr-1"></i>
                        <span className="font-medium">{service.rating}</span>
                        <span className="text-gray-500 ml-1">({service.reviews} avis)</span>
                      </div>
                      <p className="text-lg font-bold text-green-600">{service.price}</p>
                      <p className="text-sm text-gray-600">Commission: {service.commission}</p>
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="flex flex-wrap gap-2">
                      {service.features.map((feature, index) => (
                        <span key={index} className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm">
                          {feature}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <i className="ri-time-line text-green-500 mr-2"></i>
                      <span className="text-sm text-green-600 font-medium">{service.availability}</span>
                    </div>
                    <div className="flex gap-3">
                      <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 whitespace-nowrap">
                        <i className="ri-message-3-line mr-2"></i>
                        Contacter
                      </button>
                      <button 
                        onClick={() => handleBooking(service)}
                        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 whitespace-nowrap"
                      >
                        <i className="ri-calendar-check-line mr-2"></i>
                        Réserver
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {showBooking && <BookingModal />}
    </div>
  );
}
