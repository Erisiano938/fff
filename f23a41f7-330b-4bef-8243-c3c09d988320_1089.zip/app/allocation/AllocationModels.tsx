
'use client';

import { useState, useMemo, useCallback } from 'react';

export default function AllocationModels() {
  const [selectedModel, setSelectedModel] = useState(null);

  // Mémorisation des modèles d'allocation
  const allocationModels = useMemo(() => [
    {
      id: 'conservative',
      name: 'Conservateur',
      subtitle: 'Préservation du Capital',
      description: 'Priorité à la sécurité avec croissance modérée',
      targetReturn: '4-6%',
      volatility: 'Faible',
      horizon: '3-10 ans',
      icon: 'ri-shield-check-line',
      color: 'green',
      allocations: [
        { name: 'Obligations', percentage: 50, color: '#3B82F6' },
        { name: 'Actions défensives', percentage: 25, color: '#10B981' },
        { name: 'ETF diversifiés', percentage: 15, color: '#EAB308' },
        { name: 'REIT/Immobilier', percentage: 5, color: '#8B5CF6' },
        { name: 'Cash', percentage: 5, color: '#6B7280' }
      ],
      pros: [
        'Volatilité très limitée',
        'Protection contre l\'inflation',
        'Revenus réguliers',
        'Idéal pour pré-retraite'
      ],
      cons: [
        'Rendement potentiel limité',
        'Risque de sous-performance long terme',
        'Sensibilité aux taux d\'intérêt'
      ]
    },
    {
      id: 'balanced',
      name: 'Équilibré',
      subtitle: 'Croissance Modérée',
      description: 'Équilibre optimal entre rendement et sécurité',
      targetReturn: '6-8%',
      volatility: 'Modérée',
      horizon: '5-15 ans',
      icon: 'ri-scales-line',
      color: 'blue',
      allocations: [
        { name: 'Actions diversifiées', percentage: 40, color: '#EAB308' },
        { name: 'ETF internationaux', percentage: 25, color: '#10B981' },
        { name: 'Obligations', percentage: 20, color: '#3B82F6' },
        { name: 'REIT/Immobilier', percentage: 8, color: '#8B5CF6' },
        { name: 'Cash', percentage: 7, color: '#6B7280' }
      ],
      pros: [
        'Bon compromis risque/rendement',
        'Diversification optimale',
        'Résistance aux cycles économiques',
        'Stratégie éprouvée'
      ],
      cons: [
        'Volatilité modérée à accepter',
        'Performances variables court terme',
        'Nécessite rééquilibrage régulier'
      ]
    },
    {
      id: 'aggressive',
      name: 'Dynamique',
      subtitle: 'Croissance Agressive',
      description: 'Maximum de croissance avec acceptation de la volatilité',
      targetReturn: '8-12%',
      volatility: 'Élevée',
      horizon: '10+ ans',
      icon: 'ri-rocket-line',
      color: 'purple',
      allocations: [
        { name: 'Actions croissance', percentage: 50, color: '#EAB308' },
        { name: 'ETF émergents', percentage: 25, color: '#10B981' },
        { name: 'Small caps', percentage: 10, color: '#F59E0B' },
        { name: 'Crypto', percentage: 8, color: '#8B5CF6' },
        { name: 'Cash', percentage: 7, color: '#6B7280' }
      ],
      pros: [
        'Potentiel de rendement élevé',
        'Exposition à l\'innovation',
        'Protection contre inflation',
        'Croissance long terme'
      ],
      cons: [
        'Forte volatilité',
        'Risque de pertes importantes',
        'Nécessite discipline et patience',
        'Pas adapté court terme'
      ]
    }
  ], []);

  // Optimisation de la fonction d'application
  const applyModel = useCallback((model) => {
    const totalValue = 127544;
    const newAllocations = model.allocations.map(alloc => ({ 
      ...alloc,
      value: Math.round((totalValue * alloc.percentage) / 100)
    }));

    const portfolioData = {
      totalValue: totalValue,
      allocations: newAllocations.map((alloc, index) => ({ 
        id: index + 1,
        name: alloc.name,
        percentage: alloc.percentage,
        value: alloc.value,
        color: alloc.color,
        icon: getIconForAsset(alloc.name)
      })),
      lastUpdated: Date.now(),
      source: 'allocation_model'
    };

    const newConfig = {
      allocations: portfolioData.allocations,
      totalPortfolio: totalValue,
      lastUpdated: Date.now(),
      appliedModel: model.name
    };

    // Sauvegarder avec TOUS les marqueurs de synchronisation
    localStorage.setItem('portfolio_config', JSON.stringify(newConfig));
    localStorage.setItem('portfolio_data', JSON.stringify(portfolioData));
    localStorage.setItem('dashboard_portfolio_updated', Date.now().toString());
    localStorage.setItem('risk_analysis_sync', Date.now().toString());
    localStorage.setItem('allocation_model_applied', Date.now().toString());
    localStorage.setItem('portfolio_applied_model', JSON.stringify({
      name: model.name,
      timestamp: Date.now(),
      id: model.id
    }));

    // Déclencher TOUS les événements de synchronisation
    window.dispatchEvent(new CustomEvent('portfolioUpdated', {
      detail: { 
        source: 'allocation_model',
        data: portfolioData,
        config: newConfig
      }
    }));

    window.dispatchEvent(new CustomEvent('allocationUpdated', {
      detail: { 
        model: model.name,
        allocations: portfolioData.allocations
      }
    }));

    // Déclencher un événement spécifique pour l'analyse des risques
    window.dispatchEvent(new CustomEvent('riskAnalysisRefresh', {
      detail: { 
        reason: 'model_applied',
        model: model.name,
        timestamp: Date.now()
      }
    }));

    // Notification optimisée
    const notification = document.createElement('div');
    notification.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
    notification.innerHTML = `
      <div class="flex items-center space-x-2">
        <i class="ri-check-circle-line"></i>
        <span>Modèle "${model.name}" appliqué - Tests synchronisés !</span>
      </div>
    `;
    document.body.appendChild(notification);

    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 3000);
  }, []);

  const getIconForAsset = useCallback((name) => {
    const iconMap = {
      'Actions': 'ri-line-chart-line',
      'Actions défensives': 'ri-shield-line',
      'Actions croissance': 'ri-trending-up-line',
      'Actions diversifiées': 'ri-pie-chart-line',
      'Obligations': 'ri-file-chart-line',
      'ETF diversifiés': 'ri-fund-line',
      'ETF internationaux': 'ri-global-line',
      'ETF émergents': 'ri-rocket-line',
      'REIT/Immobilier': 'ri-home-line',
      'Crypto': 'ri-bit-coin-line',
      'Cash': 'ri-wallet-line',
      'Small caps': 'ri-bar-chart-box-line'
    };
    return iconMap[name] || 'ri-pie-chart-line';
  }, []);

  return (
    <div className="space-y-8">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-white mb-4">Modèles d'Allocation</h2>
        <p className="text-gray-400 max-w-2xl mx-auto">
          Choisissez parmi nos modèles d'allocation professionnels, conçus selon votre profil de risque et vos objectifs d'investissement.
        </p>
      </div>

      <div className="grid lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {allocationModels.map((model) => (
          <div key={model.id} className="bg-gray-900 rounded-xl p-6 border border-yellow-500/20 hover:border-yellow-500/40 transition-colors">
            <div className="flex items-center space-x-3 mb-4">
              <div className={`w-12 h-12 rounded-lg flex items-center justify-center bg-${model.color}-500/20`}>
                <i className={`${model.icon} text-2xl text-${model.color}-400`}></i>
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">{model.name}</h3>
                <p className="text-sm text-gray-400">{model.subtitle}</p>
              </div>
            </div>

            <p className="text-gray-300 mb-4">{model.description}</p>

            <div className="grid grid-cols-3 gap-4 mb-6 text-sm">
              <div>
                <span className="text-gray-400">Rendement</span>
                <div className="text-white font-semibold">{model.targetReturn}</div>
              </div>
              <div>
                <span className="text-gray-400">Volatilité</span>
                <div className="text-white font-semibold">{model.volatility}</div>
              </div>
              <div>
                <span className="text-gray-400">Horizon</span>
                <div className="text-white font-semibold">{model.horizon}</div>
              </div>
            </div>

            <div className="space-y-2 mb-6">
              <div className="text-sm font-medium text-white mb-2">Allocation:</div>
              {model.allocations.map((alloc, index) => (
                <div key={index} className="flex items-center justify-between text-sm">
                  <div className="flex items-center space-x-2">
                    <div 
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: alloc.color }}
                    ></div>
                    <span className="text-gray-300">{alloc.name}</span>
                  </div>
                  <span className="text-white font-medium">{alloc.percentage}%</span>
                </div>
              ))}
            </div>

            <div className="space-y-4">
              <button
                onClick={() => setSelectedModel(selectedModel === model.id ? null : model.id)}
                className="w-full bg-gray-800 hover:bg-gray-700 text-white py-2 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
              >
                {selectedModel === model.id ? 'Masquer détails' : 'Voir détails'}
              </button>

              {selectedModel === model.id && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-semibold text-green-400 mb-2">Avantages:</h4>
                      <ul className="space-y-1 text-sm text-gray-300">
                        {model.pros.map((pro, index) => (
                          <li key={index} className="flex items-start space-x-2">
                            <i className="ri-check-line text-green-400 mt-0.5 text-xs"></i>
                            <span>{pro}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-semibold text-orange-400 mb-2">Inconvénients:</h4>
                      <ul className="space-y-1 text-sm text-gray-300">
                        {model.cons.map((con, index) => (
                          <li key={index} className="flex items-start space-x-2">
                            <i className="ri-close-line text-orange-400 mt-0.5 text-xs"></i>
                            <span>{con}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <button
                    onClick={() => applyModel(model)}
                    className="w-full bg-yellow-500 hover:bg-yellow-600 text-black py-3 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap"
                  >
                    Appliquer ce Modèle
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
