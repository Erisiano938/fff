
'use client';

export default function AllocationHero() {
  return (
    <div 
      className="relative bg-gradient-to-br from-gray-900 via-black to-gray-900 py-20"
      style={{
        backgroundImage: `url('https://readdy.ai/api/search-image?query=Modern%20financial%20portfolio%20allocation%20visualization%20with%20elegant%20charts%20and%20graphs%2C%20professional%20investment%20dashboard%20interface%2C%20clean%20minimalist%20design%20with%20soft%20lighting%2C%20subtle%20geometric%20patterns%2C%20sophisticated%20color%20scheme%20in%20dark%20tones%20with%20golden%20accents%2C%20representing%20wealth%20management%20and%20strategic%20asset%20distribution&width=1200&height=600&seq=allocation-hero&orientation=landscape')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundBlendMode: 'overlay'
      }}
    >
      <div className="absolute inset-0 bg-black/70"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center space-x-2 bg-yellow-500/20 text-yellow-400 px-4 py-2 rounded-full text-sm font-medium mb-6">
            <i className="ri-pie-chart-line"></i>
            <span>Gestion Professionnelle de Portefeuille</span>
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Allocation d'Actifs
            <span className="block text-yellow-400 mt-2">Intelligente</span>
          </h1>
          
          <p className="text-xl text-gray-300 mb-8 leading-relaxed max-w-3xl mx-auto">
            Optimisez la répartition de votre portefeuille avec nos outils d'analyse avancés. 
            Réduisez les risques jusqu'à <strong className="text-yellow-400">40%</strong> tout en 
            maximisant vos rendements grâce à une diversification professionnelle.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
            <div className="flex items-center space-x-4">
              <div className="text-center">
                <div className="text-3xl font-bold text-yellow-400">-40%</div>
                <div className="text-sm text-gray-400">Réduction du risque</div>
              </div>
              <div className="w-px h-8 bg-gray-600"></div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-400">+25%</div>
                <div className="text-sm text-gray-400">Rendement optimisé</div>
              </div>
              <div className="w-px h-8 bg-gray-600"></div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-400">Global</div>
                <div className="text-sm text-gray-400">Diversification</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
