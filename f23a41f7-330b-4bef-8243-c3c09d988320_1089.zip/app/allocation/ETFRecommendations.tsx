
'use client';

import { useState } from 'react';

export default function ETFRecommendations() {
  const [selectedCategory, setSelectedCategory] = useState('global');
  const [selectedETF, setSelectedETF] = useState(null);
  const [sortBy, setSortBy] = useState('performance');
  const [filterPEA, setFilterPEA] = useState(false);

  const etfCategories = [
    { id: 'global', name: 'ETF Globaux', icon: 'ri-global-line' },
    { id: 'sectoral', name: 'Sectoriels', icon: 'ri-building-line' },
    { id: 'geographic', name: 'Géographiques', icon: 'ri-map-line' },
    { id: 'thematic', name: 'Thématiques', icon: 'ri-lightbulb-line' },
    { id: 'bonds', name: 'Obligations', icon: 'ri-file-chart-line' },
    { id: 'alternatives', name: 'Alternatifs', icon: 'ri-star-line' },
    { id: 'dividend', name: 'Dividendes', icon: 'ri-money-dollar-circle-line' },
    { id: 'smallcap', name: 'Small/Mid Cap', icon: 'ri-rocket-line' }
  ];

  const etfRecommendations = {
    global: [
      {
        id: 'ewld',
        name: 'Amundi MSCI World UCITS ETF',
        ticker: 'EWLD',
        category: 'ETF Monde',
        fees: '0.38%',
        aum: '2.8 Md€',
        description: 'Exposition aux 1600+ plus grandes entreprises des pays développés',
        allocation: 'USA 70%, Europe 15%, Japon 6%, Autres 9%',
        performance: { '1y': '+12.4%', '3y': '+8.2%', '5y': '+9.1%' },
        pros: ['PEA éligible', 'Très diversifié', 'Frais modérés', 'Liquide'],
        cons: ['Biais USA fort', 'Pas d\'émergents', 'Capitalisation uniquement'],
        rating: 4.5, risk: 4, dividend: '1.8%', peaEligible: true
      },
      {
        id: 'cw8',
        name: 'iShares Core MSCI World UCITS ETF',
        ticker: 'CW8',
        category: 'ETF Monde',
        fees: '0.20%',
        aum: '59.8 Md€',
        description: 'Le plus gros ETF monde avec frais très compétitifs',
        allocation: 'USA 68%, Europe 16%, Japon 6%, Autres 10%',
        performance: { '1y': '+12.1%', '3y': '+8.0%', '5y': '+8.9%' },
        pros: ['Frais très bas', 'Énorme liquidité', 'Réplication physique', 'Marque leader'],
        cons: ['Pas PEA éligible', 'Biais USA', 'Capitalisation uniquement'],
        rating: 4.8, risk: 4, dividend: '1.9%', peaEligible: false
      },
      {
        id: 'lcuw',
        name: 'Lyxor Core MSCI World UCITS ETF',
        ticker: 'LCUW',
        category: 'ETF Monde',
        fees: '0.12%',
        aum: '1.2 Md€',
        description: 'ETF monde aux frais les plus bas du marché',
        allocation: 'USA 69%, Europe 15%, Japon 6%, Autres 10%',
        performance: { '1y': '+12.0%', '3y': '+7.9%', '5y': '+8.8%' },
        pros: ['Frais exceptionnels', 'Réplication physique', 'Bonne liquidité'],
        cons: ['Pas PEA éligible', 'Encours modéré', 'Récent'],
        rating: 4.6, risk: 4, dividend: '1.8%', peaEligible: false
      },
      {
        id: 'paeem',
        name: 'Amundi MSCI Emerging Markets UCITS ETF',
        ticker: 'PAEEM',
        category: 'Marchés Émergents',
        fees: '0.20%',
        aum: '850 M€',
        description: 'Exposition aux marchés émergents avec frais très bas',
        allocation: 'Chine 32%, Taïwan 15%, Inde 13%, Corée 12%, Autres 28%',
        performance: { '1y': '+8.7%', '3y': '+3.2%', '5y': '+5.8%' },
        pros: ['Frais très bas', 'PEA éligible', 'Bonne diversification', 'Potentiel élevé'],
        cons: ['Volatilité élevée', 'Risque politique', 'Corrélation croissante'],
        rating: 4.2, risk: 6, dividend: '2.8%', peaEligible: true
      },
      {
        id: 'aeem',
        name: 'iShares MSCI EM UCITS ETF',
        ticker: 'AEEM',
        category: 'Marchés Émergents',
        fees: '0.18%',
        aum: '12.5 Md€',
        description: 'ETF émergents de référence avec excellent tracking',
        allocation: 'Chine 31%, Taïwan 15%, Inde 13%, Corée 13%, Autres 28%',
        performance: { '1y': '+8.4%', '3y': '+3.0%', '5y': '+5.6%' },
        pros: ['Frais très bas', 'Très liquide', 'Réplication optimisée', 'Distributeur'],
        cons: ['Pas PEA éligible', 'Volatilité élevée', 'Risque géopolitique'],
        rating: 4.4, risk: 6, dividend: '2.9%', peaEligible: false
      },
      {
        id: 'acwi',
        name: 'iShares MSCI ACWI UCITS ETF',
        ticker: 'ACWI',
        category: 'Monde + Émergents',
        fees: '0.20%',
        aum: '8.9 Md€',
        description: 'ETF monde incluant les marchés émergents en une seule ligne',
        allocation: 'USA 61%, Chine 4%, Japon 5%, Royaume-Uni 4%, Autres 26%',
        performance: { '1y': '+11.8%', '3y': '+7.5%', '5y': '+8.3%' },
        pros: ['Très diversifié', 'Monde + émergents', 'Frais raisonnables', 'Simplicité'],
        cons: ['Pas PEA éligible', 'Pondération émergents faible', 'Biais USA'],
        rating: 4.3, risk: 4, dividend: '2.0%', peaEligible: false
      },
      {
        id: 'ftse',
        name: 'Vanguard FTSE All-World UCITS ETF',
        ticker: 'VWCE',
        category: 'Monde + Émergents',
        fees: '0.22%',
        aum: '15.2 Md€',
        description: 'ETF tout-en-un de Vanguard couvrant le monde entier',
        allocation: 'USA 63%, Chine 4%, Japon 5%, Royaume-Uni 4%, Autres 24%',
        performance: { '1y': '+11.6%', '3y': '+7.3%', '5y': '+8.1%' },
        pros: ['Très diversifié', 'Marque Vanguard', 'Excellent tracking', 'Croissance forte'],
        cons: ['Pas PEA éligible', 'Frais moyens', 'Biais USA'],
        rating: 4.7, risk: 4, dividend: '1.9%', peaEligible: false
      }
    ],
    sectoral: [
      {
        id: 'tnzz',
        name: 'iShares Nasdaq-100 UCITS ETF',
        ticker: 'TNZZ',
        category: 'Technologie',
        fees: '0.33%',
        aum: '420 M€',
        description: 'Top 100 des valeurs technologiques du Nasdaq',
        allocation: 'Apple 12%, Microsoft 11%, Amazon 5%, Tesla 4%, Autres 68%',
        performance: { '1y': '+18.3%', '3y': '+12.8%', '5y': '+15.2%' },
        pros: ['Croissance élevée', 'Innovation', 'Leaders mondiaux', 'PEA éligible'],
        cons: ['Volatilité élevée', 'Concentration', 'Valorisations élevées'],
        rating: 4.4, risk: 6, dividend: '0.8%', peaEligible: true
      },
      {
        id: 'qqqm',
        name: 'Invesco QQQ Trust ETF',
        ticker: 'QQQ',
        category: 'Technologie',
        fees: '0.20%',
        aum: '195 Md$',
        description: 'ETF Nasdaq-100 de référence aux États-Unis',
        allocation: 'Apple 13%, Microsoft 12%, Amazon 6%, Tesla 4%, Google 8%',
        performance: { '1y': '+19.1%', '3y': '+13.2%', '5y': '+15.8%' },
        pros: ['Très liquide', 'Historique long', 'Frais bas', 'Performance'],
        cons: ['Pas PEA éligible', 'Volatilité', 'Concentration tech'],
        rating: 4.6, risk: 6, dividend: '0.6%', peaEligible: false
      },
      {
        id: 'heal',
        name: 'Lyxor MSCI World Health Care UCITS ETF',
        ticker: 'HEAL',
        category: 'Santé',
        fees: '0.30%',
        aum: '180 M€',
        description: 'Secteur de la santé et des biotechnologies mondial',
        allocation: 'Johnson & Johnson 8%, Pfizer 6%, Roche 5%, Novo Nordisk 4%',
        performance: { '1y': '+6.8%', '3y': '+7.1%', '5y': '+10.3%' },
        pros: ['Secteur défensif', 'Vieillissement population', 'Innovation', 'PEA éligible'],
        cons: ['Réglementation', 'R&D coûteuse', 'Concurrence'],
        rating: 4.1, risk: 3, dividend: '2.4%', peaEligible: true
      },
      {
        id: 'xlk',
        name: 'SPDR S&P 500 Technology Sector ETF',
        ticker: 'XLK',
        category: 'Technologie',
        fees: '0.10%',
        aum: '52 Md$',
        description: 'Secteur technologique du S&P 500',
        allocation: 'Apple 22%, Microsoft 20%, NVIDIA 6%, Google 4%',
        performance: { '1y': '+22.4%', '3y': '+14.8%', '5y': '+18.2%' },
        pros: ['Frais très bas', 'Très liquide', 'Pure tech', 'Performance'],
        cons: ['Pas PEA éligible', 'Concentration élevée', 'Volatilité'],
        rating: 4.5, risk: 6, dividend: '0.7%', peaEligible: false
      },
      {
        id: 'spyg',
        name: 'Lyxor STOXX Europe 600 Banks UCITS ETF',
        ticker: 'SXIR',
        category: 'Banques Européennes',
        fees: '0.30%',
        aum: '85 M€',
        description: 'Secteur bancaire européen',
        allocation: 'ASML 8%, Santander 7%, ING 6%, BNP Paribas 6%',
        performance: { '1y': '+15.2%', '3y': '+2.8%', '5y': '+1.4%' },
        pros: ['Dividendes élevés', 'Valorisations attractives', 'Reprise post-COVID'],
        cons: ['Cyclique', 'Risque réglementaire', 'Volatilité'],
        rating: 3.8, risk: 5, dividend: '4.2%', peaEligible: true
      },
      {
        id: 'fin',
        name: 'SPDR S&P 500 Financials Sector ETF',
        ticker: 'XLF',
        category: 'Services Financiers',
        fees: '0.10%',
        aum: '38 Md$',
        description: 'Secteur financier américain',
        allocation: 'Berkshire Hathaway 12%, JPMorgan 11%, Bank of America 8%',
        performance: { '1y': '+8.9%', '3y': '+6.2%', '5y': '+7.8%' },
        pros: ['Dividendes', 'Valorisations', 'Frais très bas', 'Liquide'],
        cons: ['Pas PEA éligible', 'Cyclique', 'Risque taux'],
        rating: 4.0, risk: 4, dividend: '2.8%', peaEligible: false
      }
    ],
    geographic: [
      {
        id: 'pceu',
        name: 'Amundi MSCI Europe UCITS ETF',
        ticker: 'PCEU',
        category: 'Europe',
        fees: '0.15%',
        aum: '1.1 Md€',
        description: 'Exposition aux grandes entreprises européennes',
        allocation: 'Suisse 15%, Royaume-Uni 14%, France 13%, Allemagne 12%',
        performance: { '1y': '+9.2%', '3y': '+6.8%', '5y': '+7.4%' },
        pros: ['Frais très bas', 'PEA éligible', 'Diversification', 'Dividendes élevés'],
        cons: ['Croissance plus lente', 'Défis structurels', 'Brexit'],
        rating: 4.0, risk: 3, dividend: '3.2%', peaEligible: true
      },
      {
        id: 'ceu',
        name: 'iShares Core MSCI Europe UCITS ETF',
        ticker: 'SMEA',
        category: 'Europe',
        fees: '0.12%',
        aum: '3.2 Md€',
        description: 'ETF Europe de référence avec frais ultra-bas',
        allocation: 'Suisse 16%, Royaume-Uni 13%, France 14%, Allemagne 11%',
        performance: { '1y': '+9.0%', '3y': '+6.6%', '5y': '+7.2%' },
        pros: ['Frais exceptionnels', 'Très liquide', 'Réplication physique'],
        cons: ['Pas PEA éligible', 'Croissance modérée', 'Défis structurels'],
        rating: 4.3, risk: 3, dividend: '3.1%', peaEligible: false
      },
      {
        id: 'cac',
        name: 'Amundi CAC 40 UCITS ETF',
        ticker: 'C40',
        category: 'France',
        fees: '0.25%',
        aum: '2.8 Md€',
        description: 'Les 40 plus grandes entreprises françaises',
        allocation: 'LVMH 11%, Nestlé 8%, L\'Oréal 6%, ASML 5%',
        performance: { '1y': '+5.8%', '3y': '+7.2%', '5y': '+6.8%' },
        pros: ['PEA éligible', 'Dividendes élevés', 'Marché domestique', 'Liquide'],
        cons: ['Concentration géographique', 'Croissance modérée', 'Risque politique'],
        rating: 3.9, risk: 3, dividend: '3.4%', peaEligible: true
      },
      {
        id: 'dax',
        name: 'iShares Core DAX UCITS ETF',
        ticker: 'EXS1',
        category: 'Allemagne',
        fees: '0.16%',
        aum: '6.1 Md€',
        description: 'Les 40 plus grandes entreprises allemandes',
        allocation: 'SAP 12%, Linde 8%, Siemens 6%, ASML 5%',
        performance: { '1y': '+12.4%', '3y': '+4.8%', '5y': '+5.2%' },
        pros: ['Économie solide', 'Exportateur', 'Frais bas', 'Très liquide'],
        cons: ['Pas PEA éligible', 'Énergie/Auto', 'Cyclique'],
        rating: 4.1, risk: 4, dividend: '2.8%', peaEligible: false
      },
      {
        id: 'jpn',
        name: 'iShares MSCI Japan UCITS ETF',
        ticker: 'IJPN',
        category: 'Japon',
        fees: '0.15%',
        aum: '2.9 Md€',
        description: 'Marché japonais avec réformes structurelles',
        allocation: 'Toyota 4%, Sony 3%, Keyence 2%, SoftBank 2%',
        performance: { '1y': '+14.2%', '3y': '+7.9%', '5y': '+6.1%' },
        pros: ['Réformes Abenomics', 'Valorisations attractives', 'Diversification'],
        cons: ['Pas PEA éligible', 'Démographie', 'Devise'],
        rating: 4.0, risk: 4, dividend: '2.1%', peaEligible: false
      },
      {
        id: 'usa',
        name: 'Amundi S&P 500 UCITS ETF',
        ticker: 'SP5',
        category: 'États-Unis',
        fees: '0.15%',
        aum: '4.2 Md€',
        description: 'Les 500 plus grandes entreprises américaines',
        allocation: 'Apple 7%, Microsoft 7%, Amazon 3%, Tesla 2%',
        performance: { '1y': '+13.8%', '3y': '+9.4%', '5y': '+11.2%' },
        pros: ['Marché le plus développé', 'Innovation', 'PEA éligible', 'Performance'],
        cons: ['Valorisations élevées', 'Concentration tech', 'Devise'],
        rating: 4.4, risk: 4, dividend: '1.6%', peaEligible: true
      },
      {
        id: 'spy',
        name: 'SPDR S&P 500 ETF Trust',
        ticker: 'SPY',
        category: 'États-Unis',
        fees: '0.09%',
        aum: '420 Md$',
        description: 'Le plus ancien et liquide ETF S&P 500',
        allocation: 'Apple 7%, Microsoft 7%, Amazon 3%, Tesla 2%',
        performance: { '1y': '+14.1%', '3y': '+9.6%', '5y': '+11.4%' },
        pros: ['Très liquide', 'Historique long', 'Référence', 'Options'],
        cons: ['Pas PEA éligible', 'Frais moyens', 'Biais tech'],
        rating: 4.6, risk: 4, dividend: '1.5%', peaEligible: false
      }
    ],
    thematic: [
      {
        id: 'rbot',
        name: 'Lyxor Robotics & AI UCITS ETF',
        ticker: 'RBOT',
        category: 'Robotique & IA',
        fees: '0.40%',
        aum: '95 M€',
        description: 'Entreprises leaders en robotique et intelligence artificielle',
        allocation: 'NVIDIA 8%, Tesla 6%, ABB 5%, Fanuc 4%',
        performance: { '1y': '+25.6%', '3y': '+15.3%', '5y': '+18.9%' },
        pros: ['Secteur d\'avenir', 'Croissance élevée', 'Innovation', 'Transformation digitale'],
        cons: ['Volatilité très élevée', 'Valorisations élevées', 'Risque technologique'],
        rating: 4.2, risk: 7, dividend: '0.5%', peaEligible: false
      },
      {
        id: 'inrg',
        name: 'iShares Global Clean Energy UCITS ETF',
        ticker: 'INRG',
        category: 'Énergies Renouvelables',
        fees: '0.65%',
        aum: '2.1 Md€',
        description: 'Entreprises des énergies propres et renouvelables',
        allocation: 'First Solar 4%, Vestas 4%, Orsted 3%, Enphase 3%',
        performance: { '1y': '-12.4%', '3y': '+8.9%', '5y': '+12.1%' },
        pros: ['Transition énergétique', 'Croissance long terme', 'ESG', 'Soutien politique'],
        cons: ['Volatilité extrême', 'Dépendance subventions', 'Concurrence'],
        rating: 3.8, risk: 7, dividend: '1.2%', peaEligible: false
      },
      {
        id: 'espo',
        name: 'VanEck Video Gaming and eSports UCITS ETF',
        ticker: 'ESPO',
        category: 'Gaming & eSports',
        fees: '0.55%',
        aum: '85 M€',
        description: 'Industrie du jeu vidéo et des sports électroniques',
        allocation: 'NVIDIA 9%, Tencent 8%, Sony 6%, Nintendo 5%',
        performance: { '1y': '+12.8%', '3y': '+8.4%', '5y': '+14.2%' },
        pros: ['Croissance structurelle', 'Démographie favorable', 'Innovation'],
        cons: ['Volatilité élevée', 'Réglementation', 'Concentration'],
        rating: 4.0, risk: 6, dividend: '1.1%', peaEligible: false
      },
      {
        id: 'water',
        name: 'Lyxor World Water UCITS ETF',
        ticker: 'WAT',
        category: 'Eau',
        fees: '0.60%',
        aum: '250 M€',
        description: 'Entreprises de l\'eau et des technologies liées',
        allocation: 'American Water Works 8%, Veolia 6%, Suez 5%, Xylem 4%',
        performance: { '1y': '+2.1%', '3y': '+5.8%', '5y': '+8.9%' },
        pros: ['Ressource essentielle', 'Défensif', 'ESG', 'Monopoles naturels'],
        cons: ['Croissance lente', 'Réglementé', 'Frais élevés'],
        rating: 3.7, risk: 3, dividend: '2.8%', peaEligible: false
      },
      {
        id: 'cyber',
        name: 'iShares Digital Security UCITS ETF',
        ticker: 'CYBR',
        category: 'Cybersécurité',
        fees: '0.40%',
        aum: '180 M€',
        description: 'Entreprises de cybersécurité et protection digitale',
        allocation: 'Palo Alto Networks 9%, CrowdStrike 8%, Fortinet 7%',
        performance: { '1y': '+18.5%', '3y': '+12.1%', '5y': '+16.8%' },
        pros: ['Secteur en croissance', 'Menaces croissantes', 'Récurrent', 'Margins élevées'],
        cons: ['Valorisations élevées', 'Concurrence', 'Volatilité'],
        rating: 4.3, risk: 5, dividend: '0.8%', peaEligible: false
      },
      {
        id: 'fintech',
        name: 'Global X FinTech UCITS ETF',
        ticker: 'FINX',
        category: 'FinTech',
        fees: '0.60%',
        aum: '120 M€',
        description: 'Technologies financières et paiements digitaux',
        allocation: 'PayPal 12%, Square 8%, Visa 7%, Mastercard 6%',
        performance: { '1y': '+8.4%', '3y': '+9.2%', '5y': '+13.8%' },
        pros: ['Disruption bancaire', 'Croissance digitale', 'Marges élevées'],
        cons: ['Réglementation', 'Concurrence', 'Valorisations'],
        rating: 4.1, risk: 5, dividend: '0.6%', peaEligible: false
      }
    ],
    bonds: [
      {
        id: 'aggh',
        name: 'iShares Core Global Aggregate Bond UCITS ETF',
        ticker: 'AGGH',
        category: 'Obligations Globales',
        fees: '0.10%',
        aum: '1.8 Md€',
        description: 'Obligations gouvernementales et corporate mondiales',
        allocation: 'USA 41%, Japon 15%, Allemagne 8%, France 6%',
        performance: { '1y': '-8.2%', '3y': '-2.1%', '5y': '+1.8%' },
        pros: ['Frais très bas', 'Très diversifié', 'Stabilité', 'Couverture devise'],
        cons: ['Rendement faible', 'Risque taux', 'Inflation'],
        rating: 4.0, risk: 2, dividend: '2.8%', peaEligible: false
      },
      {
        id: 'govt',
        name: 'Lyxor EuroMTS 10-15Y Investment Grade UCITS ETF',
        ticker: 'MT15',
        category: 'Obligations Gouvernementales',
        fees: '0.17%',
        aum: '420 M€',
        description: 'Obligations gouvernementales européennes 10-15 ans',
        allocation: 'Allemagne 28%, France 25%, Italie 18%, Espagne 12%',
        performance: { '1y': '-12.8%', '3y': '-3.2%', '5y': '+0.8%' },
        pros: ['PEA éligible', 'Sécurité', 'Duration longue', 'Frais bas'],
        cons: ['Risque taux élevé', 'Rendement faible', 'Inflation'],
        rating: 3.8, risk: 3, dividend: '1.2%', peaEligible: true
      },
      {
        id: 'corp',
        name: 'iShares Euro Corporate Bond UCITS ETF',
        ticker: 'IEAC',
        category: 'Obligations Corporate',
        fees: '0.20%',
        aum: '8.5 Md€',
        description: 'Obligations d\'entreprises européennes investment grade',
        allocation: 'Financières 35%, Utilities 12%, Télécom 10%, Industrielles 8%',
        performance: { '1y': '-9.8%', '3y': '-1.2%', '5y': '+2.4%' },
        pros: ['Rendement plus élevé', 'Qualité investment grade', 'Diversification'],
        cons: ['Risque crédit', 'Risque taux', 'Pas PEA'],
        rating: 4.1, risk: 3, dividend: '2.1%', peaEligible: false
      },
      {
        id: 'tips',
        name: 'iShares EUR Inflation Linked Govt Bond UCITS ETF',
        ticker: 'IBCI',
        category: 'Obligations Indexées Inflation',
        fees: '0.25%',
        aum: '1.2 Md€',
        description: 'Obligations européennes indexées sur l\'inflation',
        allocation: 'France 45%, Allemagne 25%, Italie 18%, Espagne 8%',
        performance: { '1y': '-5.8%', '3y': '+1.2%', '5y': '+2.8%' },
        pros: ['Protection inflation', 'Gouvernementales', 'Diversification'],
        cons: ['Rendement réel faible', 'Complexité', 'Liquide moindre'],
        rating: 3.9, risk: 2, dividend: '0.8%', peaEligible: false
      },
      {
        id: 'hy',
        name: 'iShares Euro High Yield Corporate Bond UCITS ETF',
        ticker: 'IHYG',
        category: 'High Yield',
        fees: '0.50%',
        aum: '2.8 Md€',
        description: 'Obligations d\'entreprises européennes à haut rendement',
        allocation: 'Cyclique 45%, Télécom 15%, Énergie 12%, Utilities 8%',
        performance: { '1y': '-8.2%', '3y': '+1.8%', '5y': '+3.2%' },
        pros: ['Rendement élevé', 'Moins sensible aux taux', 'Diversification'],
        cons: ['Risque crédit élevé', 'Volatilité', 'Défauts possibles'],
        rating: 3.6, risk: 5, dividend: '4.2%', peaEligible: false
      }
    ],
    alternatives: [
      {
        id: 'coal',
        name: 'Lyxor Commodities Thomson Reuters/CoreCommodity CRB UCITS ETF',
        ticker: 'COAL',
        category: 'Matières Premières',
        fees: '0.30%',
        aum: '65 M€',
        description: 'Panier diversifié de matières premières',
        allocation: 'Énergie 39%, Agriculture 32%, Métaux industriels 20%, Métaux précieux 9%',
        performance: { '1y': '+2.8%', '3y': '+8.9%', '5y': '+3.2%' },
        pros: ['Protection inflation', 'Décorrélation', 'Diversification', 'Réel'],
        cons: ['Volatilité élevée', 'Pas de dividendes', 'Complexité'],
        rating: 3.5, risk: 5, dividend: '0.0%', peaEligible: false
      },
      {
        id: 'gold',
        name: 'iShares Physical Gold ETC',
        ticker: 'SGLN',
        category: 'Or Physique',
        fees: '0.25%',
        aum: '12.8 Md€',
        description: 'Exposition directe au prix de l\'or physique',
        allocation: 'Or physique 100%',
        performance: { '1y': '+1.2%', '3y': '+8.4%', '5y': '+7.8%' },
        pros: ['Valeur refuge', 'Protection inflation', 'Géopolitique', 'Physique'],
        cons: ['Pas de dividendes', 'Volatilité', 'Stockage'],
        rating: 4.2, risk: 3, dividend: '0.0%', peaEligible: false
      },
      {
        id: 'epra',
        name: 'Amundi FTSE EPRA Europe Real Estate UCITS ETF',
        ticker: 'EPRA',
        category: 'Immobilier (REIT)',
        fees: '0.23%',
        aum: '280 M€',
        description: 'Foncières et REIT européennes',
        allocation: 'Unibail 12%, Vonovia 8%, Deutsche Wohnen 6%, Segro 6%',
        performance: { '1y': '-18.2%', '3y': '-2.8%', '5y': '+2.1%' },
        pros: ['Dividendes élevés', 'Protection inflation', 'Diversification', 'PEA éligible'],
        cons: ['Sensibilité taux', 'Volatilité', 'Risque secteur'],
        rating: 3.7, risk: 5, dividend: '4.8%', peaEligible: true
      },
      {
        id: 'reit',
        name: 'iShares Developed Markets Property Yield UCITS ETF',
        ticker: 'IWDP',
        category: 'REIT Mondiales',
        fees: '0.59%',
        aum: '1.2 Md€',
        description: 'REIT des marchés développés',
        allocation: 'USA 65%, Japon 8%, Australie 7%, Royaume-Uni 6%',
        performance: { '1y': '-22.8%', '3y': '-1.2%', '5y': '+1.8%' },
        pros: ['Diversification géographique', 'Dividendes élevés', 'Exposition immobilière'],
        cons: ['Volatilité très élevée', 'Sensibilité taux', 'Pas PEA'],
        rating: 3.4, risk: 6, dividend: '5.2%', peaEligible: false
      },
      {
        id: 'bitcoin',
        name: 'iShares Bitcoin Trust ETF',
        ticker: 'IBIT',
        category: 'Bitcoin',
        fees: '0.25%',
        aum: '18.5 Md$',
        description: 'Exposition directe au Bitcoin',
        allocation: 'Bitcoin 100%',
        performance: { '1y': '+145.8%', '3y': '+45.2%', '5y': '+892.1%' },
        pros: ['Adoption institutionnelle', 'Hedge inflation', 'Décorrélation', 'Révolution'],
        cons: ['Volatilité extrême', 'Réglementation', 'Pas PEA', 'Spéculatif'],
        rating: 3.2, risk: 7, dividend: '0.0%', peaEligible: false
      }
    ],
    dividend: [
      {
        id: 'dvyd',
        name: 'iShares EURO STOXX Select Dividend 30 UCITS ETF',
        ticker: 'EXX1',
        category: 'Dividendes Europe',
        fees: '0.31%',
        aum: '1.8 Md€',
        description: '30 entreprises européennes à plus haut dividende',
        allocation: 'Sanofi 5%, Total 4%, Eni 4%, Allianz 4%',
        performance: { '1y': '+1.2%', '3y': '+3.8%', '5y': '+4.2%' },
        pros: ['Dividendes très élevés', 'Revenus réguliers', 'PEA éligible', 'Défensif'],
        cons: ['Croissance faible', 'Secteurs cycliques', 'Piège à dividendes'],
        rating: 3.8, risk: 4, dividend: '6.2%', peaEligible: true
      },
      {
        id: 'vhyl',
        name: 'Vanguard FTSE All-World High Dividend Yield UCITS ETF',
        ticker: 'VHYL',
        category: 'Dividendes Monde',
        fees: '0.29%',
        aum: '3.2 Md€',
        description: 'Actions à haut dividende des marchés développés',
        allocation: 'USA 45%, Japon 12%, Royaume-Uni 9%, Canada 6%',
        performance: { '1y': '+8.4%', '3y': '+6.2%', '5y': '+7.1%' },
        pros: ['Diversification mondiale', 'Marque Vanguard', 'Dividendes élevés'],
        cons: ['Pas PEA éligible', 'Biais valeur', 'Secteurs traditionnels'],
        rating: 4.2, risk: 3, dividend: '4.8%', peaEligible: false
      },
      {
        id: 'spyd',
        name: 'SPDR S&P 500 High Dividend ETF',
        ticker: 'SPYD',
        category: 'Dividendes USA',
        fees: '0.07%',
        aum: '8.2 Md$',
        description: 'Top 80 des dividendes du S&P 500',
        allocation: 'Immobilier 18%, Utilities 16%, Financières 14%, Énergie 12%',
        performance: { '1y': '+9.8%', '3y': '+7.2%', '5y': '+8.4%' },
        pros: ['Frais très bas', 'Dividendes élevés', 'Qualité américaine'],
        cons: ['Pas PEA éligible', 'Concentration sectorielle', 'Cyclique'],
        rating: 4.0, risk: 3, dividend: '4.2%', peaEligible: false
      },
      {
        id: 'hdv',
        name: 'iShares Core High Dividend ETF',
        ticker: 'HDV',
        category: 'Dividendes Qualité USA',
        fees: '0.08%',
        aum: '9.5 Md$',
        description: 'Entreprises américaines à dividendes soutenables',
        allocation: 'Exxon Mobil 8%, Johnson & Johnson 7%, Verizon 6%',
        performance: { '1y': '+6.8%', '3y': '+8.1%', '5y': '+9.2%' },
        pros: ['Qualité dividendes', 'Frais très bas', 'Sélection rigoureuse'],
        cons: ['Pas PEA éligible', 'Croissance limitée', 'Biais secteurs'],
        rating: 4.3, risk: 3, dividend: '3.8%', peaEligible: false
      },
      {
        id: 'aristocrats',
        name: 'SPDR S&P 500 Dividend Aristocrats ETF',
        ticker: 'SPDR',
        category: 'Aristocrates Dividendes',
        fees: '0.35%',
        aum: '15.8 Md$',
        description: 'Entreprises ayant augmenté leurs dividendes 25+ années',
        allocation: 'Walmart 4%, Coca-Cola 3%, PepsiCo 3%, McDonald\'s 3%',
        performance: { '1y': '+11.2%', '3y': '+9.8%', '5y': '+10.4%' },
        pros: ['Qualité exceptionnelle', 'Croissance dividendes', 'Résilience'],
        cons: ['Pas PEA éligible', 'Frais moyens', 'Biais défensif'],
        rating: 4.5, risk: 3, dividend: '2.8%', peaEligible: false
      }
    ],
    smallcap: [
      {
        id: 'small',
        name: 'iShares MSCI World Small Cap UCITS ETF',
        ticker: 'IUSN',
        category: 'Small Cap Monde',
        fees: '0.35%',
        aum: '1.8 Md€',
        description: 'Petites capitalisations des marchés développés',
        allocation: 'USA 65%, Japon 12%, Royaume-Uni 8%, Canada 4%',
        performance: { '1y': '+8.2%', '3y': '+6.8%', '5y': '+8.9%' },
        pros: ['Potentiel croissance', 'Diversification', 'Moins suivies'],
        cons: ['Volatilité élevée', 'Liquidité moindre', 'Pas PEA'],
        rating: 4.0, risk: 5, dividend: '2.1%', peaEligible: false
      },
      {
        id: 'smalleur',
        name: 'iShares MSCI Europe Small Cap UCITS ETF',
        ticker: 'IEUS',
        category: 'Small Cap Europe',
        fees: '0.40%',
        aum: '850 M€',
        description: 'Petites capitalisations européennes',
        allocation: 'Royaume-Uni 25%, Allemagne 18%, France 12%, Italie 8%',
        performance: { '1y': '+4.2%', '3y': '+3.8%', '5y': '+6.1%' },
        pros: ['Potentiel croissance', 'Marché européen', 'Valorisations'],
        cons: ['Volatilité élevée', 'Liquide limitée', 'Pas PEA'],
        rating: 3.7, risk: 5, dividend: '2.8%', peaEligible: false
      },
      {
        id: 'russell',
        name: 'iShares Russell 2000 ETF',
        ticker: 'IWM',
        category: 'Small Cap USA',
        fees: '0.19%',
        aum: '58 Md$',
        description: 'Small caps américaines de référence',
        allocation: 'Financières 16%, Industrielles 15%, Santé 14%, Tech 13%',
        performance: { '1y': '+10.8%', '3y': '+2.4%', '5y': '+7.2%' },
        pros: ['Marché domestique USA', 'Très liquide', 'Diversification'],
        cons: ['Pas PEA éligible', 'Volatilité élevée', 'Sensible économie'],
        rating: 4.1, risk: 5, dividend: '1.8%', peaEligible: false
      },
      {
        id: 'midcap',
        name: 'SPDR S&P 400 Mid Cap ETF',
        ticker: 'MDY',
        category: 'Mid Cap USA',
        fees: '0.25%',
        aum: '18 Md$',
        description: 'Moyennes capitalisations américaines',
        allocation: 'Industrielles 18%, Financières 16%, Tech 14%, Santé 12%',
        performance: { '1y': '+12.8%', '3y': '+5.2%', '5y': '+8.8%' },
        pros: ['Sweet spot taille', 'Croissance', 'Moins volatiles que small'],
        cons: ['Pas PEA éligible', 'Moins liquides que large', 'Cyclique'],
        rating: 4.2, risk: 4, dividend: '1.9%', peaEligible: false
      },
      {
        id: 'growth',
        name: 'Vanguard S&P 500 Growth ETF',
        ticker: 'VOOG',
        category: 'Growth USA',
        fees: '0.10%',
        aum: '8.5 Md$',
        description: 'Valeurs de croissance du S&P 500',
        allocation: 'Apple 13%, Microsoft 12%, Amazon 6%, Tesla 3%',
        performance: { '1y': '+18.2%', '3y': '+11.8%', '5y': '+13.2%' },
        pros: ['Croissance élevée', 'Tech dominante', 'Frais très bas'],
        cons: ['Pas PEA éligible', 'Valorisations élevées', 'Volatilité'],
        rating: 4.4, risk: 5, dividend: '0.8%', peaEligible: false
      }
    ]
  };

  const currentETFs = etfRecommendations[selectedCategory] || [];

  const addToPortfolio = (etf) => {
    alert(`${etf.name} (${etf.ticker}) ajouté à votre liste de suivi !`);
  };

  // Fonction pour afficher les indicateurs de risque de 1 à 7
  const renderRiskIndicator = (riskLevel) => {
    const getRiskColor = (level) => {
      if (level <= 2) return 'text-green-400';
      if (level <= 4) return 'text-yellow-400';
      if (level <= 6) return 'text-orange-400';
      return 'text-red-400';
    };

    const getRiskLabel = (level) => {
      if (level === 1) return 'Très faible';
      if (level === 2) return 'Faible';
      if (level === 3) return 'Modéré';
      if (level === 4) return 'Modéré-élevé';
      if (level === 5) return 'Élevé';
      if (level === 6) return 'Très élevé';
      return 'Maximum';
    };

    return (
      <div className="flex items-center space-x-2">
        <div className="flex items-center">
          {[1, 2, 3, 4, 5, 6, 7].map((i) => (
            <div
              key={i}
              className={`w-2 h-4 mx-0.5 rounded-sm ${
                i <= riskLevel 
                  ? (i <= 2 ? 'bg-green-400' : i <= 4 ? 'bg-yellow-400' : i <= 6 ? 'bg-orange-400' : 'bg-red-400')
                  : 'bg-gray-600'
              }`}
            />
          ))}
        </div>
        <span className={`text-sm font-medium ${getRiskColor(riskLevel)}`}>
          {riskLevel}/7
        </span>
      </div>
    );
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-white mb-4">ETF Recommandés</h2>
        <p className="text-gray-400 max-w-2xl mx-auto">
          Sélection d'ETF performants pour diversifier votre portefeuille selon vos objectifs.
        </p>
      </div>

      <div className="flex flex-wrap justify-center gap-4">
        {etfCategories.map((category) => (
          <button
            key={category.id}
            onClick={() => setSelectedCategory(category.id)}
            className={`flex items-center space-x-2 px-4 py-3 rounded-lg font-medium transition-colors cursor-pointer whitespace-nowrap ${
              selectedCategory === category.id
                ? 'bg-yellow-500 text-black'
                : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
            }`}
          >
            <i className={category.icon}></i>
            <span>{category.name}</span>
          </button>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {currentETFs.map((etf) => (
          <div key={etf.id} className="bg-gray-900 rounded-xl p-6 border border-yellow-500/20">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-xl font-bold text-white mb-1">{etf.ticker}</h3>
                <p className="text-gray-400 text-sm">{etf.name}</p>
                <span className="inline-block bg-blue-500/20 text-blue-400 px-2 py-1 rounded text-xs mt-2">
                  {etf.category}
                </span>
              </div>
              <div className="flex items-center space-x-1">
                {[1, 2, 3, 4, 5].map((i) => (
                  <i
                    key={i}
                    className={`ri-star-${i <= etf.rating ? 'fill' : 'line'} text-yellow-400 text-sm`}
                  ></i>
                ))}
              </div>
            </div>

            <p className="text-gray-300 text-sm mb-4">{etf.description}</p>

            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <span className="text-xs text-gray-400">Frais annuels</span>
                <div className="text-lg font-bold text-white">{etf.fees}</div>
              </div>
              <div>
                <span className="text-xs text-gray-400">Encours</span>
                <div className="text-lg font-bold text-white">{etf.aum}</div>
              </div>
              <div>
                <span className="text-xs text-gray-400">Dividende</span>
                <div className="text-lg font-bold text-green-400">{etf.dividend}</div>
              </div>
              <div>
                <span className="text-xs text-gray-400">Risque</span>
                <div className="mt-1">
                  {renderRiskIndicator(etf.risk)}
                </div>
              </div>
            </div>

            <div className="mb-4">
              <h4 className="text-sm font-semibold text-white mb-2">Performance:</h4>
              <div className="flex justify-between text-sm">
                <div>
                  <span className="text-gray-400">1 an:</span>
                  <span
                    className={`ml-2 font-semibold ${
                      etf.performance['1y'].startsWith('+') ? 'text-green-400' : 'text-red-400'
                    }`}
                  >
                    {etf.performance['1y']}
                  </span>
                </div>
                <div>
                  <span className="text-gray-400">3 ans:</span>
                  <span
                    className={`ml-2 font-semibold ${
                      etf.performance['3y'].startsWith('+') ? 'text-green-400' : 'text-red-400'
                    }`}
                  >
                    {etf.performance['3y']}
                  </span>
                </div>
                <div>
                  <span className="text-gray-400">5 ans:</span>
                  <span
                    className={`ml-2 font-semibold ${
                      etf.performance['5y'].startsWith('+') ? 'text-green-400' : 'text-red-400'
                    }`}
                  >
                    {etf.performance['5y']}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-2 mb-4">
              {etf.peaEligible && (
                <span className="bg-green-500/20 text-green-400 px-2 py-1 rounded text-xs font-medium">
                  PEA Éligible
                </span>
              )}
              {etf.fees <= '0.20%' && (
                <span className="bg-blue-500/20 text-blue-400 px-2 py-1 rounded text-xs font-medium">
                  Frais Bas
                </span>
              )}
              {parseFloat(etf.dividend.replace('%', '')) > 3 && (
                <span className="bg-purple-500/20 text-purple-400 px-2 py-1 rounded text-xs font-medium">
                  Haut Dividende
                </span>
              )}
            </div>

            <div className="space-y-3">
              <button
                onClick={() => setSelectedETF(selectedETF === etf.id ? null : etf.id)}
                className="w-full bg-gray-800 hover:bg-gray-700 text-white py-2 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
              >
                {selectedETF === etf.id ? 'Masquer détails' : 'Voir détails'}
              </button>

              {selectedETF === etf.id && (
                <div className="space-y-4">
                  <div>
                    <h5 className="font-semibold text-white mb-2">Allocation géographique/sectorielle:</h5>
                    <p className="text-sm text-gray-300">{etf.allocation}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h5 className="font-semibold text-green-400 mb-2 text-sm">Avantages:</h5>
                      <ul className="space-y-1 text-xs text-gray-300">
                        {etf.pros.map((pro, index) => (
                          <li key={index} className="flex items-start space-x-1">
                            <i className="ri-check-line text-green-400 mt-0.5 text-xs"></i>
                            <span>{pro}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h5 className="font-semibold text-orange-400 mb-2 text-sm">Inconvénients:</h5>
                      <ul className="space-y-1 text-xs text-gray-300">
                        {etf.cons.map((con, index) => (
                          <li key={index} className="flex items-start space-x-1">
                            <i className="ri-close-line text-orange-400 mt-0.5 text-xs"></i>
                            <span>{con}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <button
                    onClick={() => addToPortfolio(etf)}
                    className="w-full bg-yellow-500 hover:bg-yellow-600 text-black py-2 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap"
                  >
                    Ajouter au Portefeuille
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="bg-gray-900 p-6 rounded-xl border border-yellow-500/20">
        <h3 className="text-xl font-bold text-white mb-6">Comparaison Rapide</h3>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-700">
                <th className="text-left py-3 text-gray-400">ETF</th>
                <th className="text-center py-3 text-gray-400">Frais</th>
                <th className="text-center py-3 text-gray-400">Perf. 1 an</th>
                <th className="text-center py-3 text-gray-400">Dividende</th>
                <th className="text-center py-3 text-gray-400">Risque</th>
                <th className="text-center py-3 text-gray-400">PEA</th>
              </tr>
            </thead>
            <tbody>
              {currentETFs.slice(0, 5).map((etf) => (
                <tr key={etf.id} className="border-b border-gray-800 hover:bg-gray-800/50">
                  <td className="py-3">
                    <div>
                      <div className="font-semibold text-white">{etf.ticker}</div>
                      <div className="text-xs text-gray-400">{etf.name}</div>
                    </div>
                  </td>
                  <td className="text-center py-3">
                    <span
                      className={`font-semibold ${
                        parseFloat(etf.fees.replace('%', '')) <= 0.2
                          ? 'text-green-400'
                          : parseFloat(etf.fees.replace('%', '')) <= 0.5
                          ? 'text-yellow-400'
                          : 'text-red-400'
                      }`}
                    >
                      {etf.fees}
                    </span>
                  </td>
                  <td className="text-center py-3">
                    <span
                      className={`font-semibold ${
                        etf.performance['1y'].startsWith('+') ? 'text-green-400' : 'text-red-400'
                      }`}
                    >
                      {etf.performance['1y']}
                    </span>
                  </td>
                  <td className="text-center py-3 text-purple-400 font-semibold">{etf.dividend}</td>
                  <td className="text-center py-3">
                    <div className="flex justify-center items-center">
                      <span className={`text-sm font-medium ${
                        etf.risk <= 2 ? 'text-green-400' : 
                        etf.risk <= 4 ? 'text-yellow-400' : 
                        etf.risk <= 6 ? 'text-orange-400' : 'text-red-400'
                      }`}>
                        {etf.risk}/7
                      </span>
                    </div>
                  </td>
                  <td className="text-center py-3">
                    {etf.peaEligible ? (
                      <i className="ri-check-circle-line text-green-400"></i>
                    ) : (
                      <i className="ri-close-circle-line text-red-400"></i>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 p-6 rounded-xl border border-blue-500/20">
        <h3 className="text-xl font-bold text-white mb-4 flex items-center">
          <i className="ri-lightbulb-line text-blue-400 mr-3"></i>
          Guide de Sélection d'ETF
        </h3>

        <div className="grid md:grid-cols-3 gap-6">
          <div>
            <h4 className="font-semibold text-green-400 mb-3">Pour Débutants</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li className="flex items-start space-x-2">
                <i className="ri-arrow-right-line text-green-400 mt-0.5"></i>
                <span>Commencez par EWLD ou CW8 (ETF World)</span>
              </li>
              <li className="flex items-start space-x-2">
                <i className="ri-arrow-right-line text-green-400 mt-0.5"></i>
                <span>Privilégiez les ETF PEA éligibles</span>
              </li>
              <li className="flex items-start space-x-2">
                <i className="ri-arrow-right-line text-green-400 mt-0.5"></i>
                <span>Frais &lt; 0.5% annuels maximum</span>
              </li>
              <li className="flex items-start space-x-2">
                <i className="ri-arrow-right-line text-green-400 mt-0.5"></i>
                <span>Encours &gt; 100M€ minimum</span>
              </li>
              <li className="flex items-start space-x-2">
                <i className="ri-arrow-right-line text-green-400 mt-0.5"></i>
                <span>Risque 1-4/7 pour commencer</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-blue-400 mb-3">Diversification</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li className="flex items-start space-x-2">
                <i className="ri-arrow-right-line text-blue-400 mt-0.5"></i>
                <span>Base: 70% ETF larges (World, Europe)</span>
              </li>
              <li className="flex items-start space-x-2">
                <i className="ri-arrow-right-line text-blue-400 mt-0.5"></i>
                <span>Satellites: 20% sectoriels/géographiques</span>
              </li>
              <li className="flex items-start space-x-2">
                <i className="ri-arrow-right-line text-blue-400 mt-0.5"></i>
                <span>Spéculatif: 10% thématiques max</span>
              </li>
              <li className="flex items-start space-x-2">
                <i className="ri-arrow-right-line text-blue-400 mt-0.5"></i>
                <span>Mixez géographies et secteurs</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-purple-400 mb-3">Échelle de Risque</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li className="flex items-center space-x-2">
                <span className="text-green-400 font-medium">1-2/7:</span>
                <span>Très faible à faible (Obligations)</span>
              </li>
              <li className="flex items-center space-x-2">
                <span className="text-yellow-400 font-medium">3-4/7:</span>
                <span>Modéré (Actions développées)</span>
              </li>
              <li className="flex items-center space-x-2">
                <span className="text-orange-400 font-medium">5-6/7:</span>
                <span>Élevé (Sectoriels, Émergents)</span>
              </li>
              <li className="flex items-center space-x-2">
                <span className="text-red-400 font-medium">7/7:</span>
                <span>Maximum (Crypto, Thématiques)</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
