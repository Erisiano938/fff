
'use client';

import { useState, useEffect, useMemo, useCallback } from 'react';
import { lazy, Suspense } from 'react';

// Lazy loading du simulateur lourd
const ScenarioSimulator = lazy(() => import('./ScenarioSimulator'));

export default function CurrentAllocation({ portfolioData }) {
  const [showDetails, setShowDetails] = useState(null);
  const [showScenarioSimulator, setShowScenarioSimulator] = useState(false);
  const [currentData, setCurrentData] = useState(portfolioData);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    setCurrentData(portfolioData);
  }, [portfolioData]);

  // Mémorisation du formatage des nombres
  const formatNumber = useCallback((num) => {
    if (!mounted) return Math.round(num || 0).toString();
    return new Intl.NumberFormat('fr-FR').format(Math.round(num || 0));
  }, [mounted]);

  // Mémorisation des calculs de portefeuille
  const calculatedData = useMemo(() => {
    if (!currentData || !currentData.allocations || currentData.allocations.length === 0) {
      return {
        totalValue: 0,
        allocations: [],
        totalCalculatedValue: 0,
        totalPercentage: 0
      };
    }

    const totalValue = currentData.totalValue || 0;
    const totalPercentage = currentData.allocations.reduce((sum, alloc) => sum + (alloc.percentage || 0), 0);

    const calculatedAllocations = currentData.allocations.map(alloc => {
      const percentage = alloc.percentage || 0;
      const calculatedValue = totalValue > 0 ? Math.round((totalValue * percentage) / 100) : 0;

      return {
        ...alloc,
        percentage: percentage,
        value: alloc.value || calculatedValue,
        calculatedValue: calculatedValue,
        calculatedPercentage: percentage
      };
    });

    const calculatedTotal = calculatedAllocations.reduce((sum, alloc) => sum + (alloc.value || 0), 0);
    const difference = totalValue - calculatedTotal;

    if (Math.abs(difference) > 1 && calculatedAllocations.length > 0) {
      const largestAllocationIndex = calculatedAllocations.reduce((maxIndex, current, index, array) =>
        (current.value || 0) > (array[maxIndex].value || 0) ? index : maxIndex, 0
      );
      if (calculatedAllocations[largestAllocationIndex]) {
        calculatedAllocations[largestAllocationIndex].value =
          (calculatedAllocations[largestAllocationIndex].value || 0) + difference;
      }
    }

    return {
      ...currentData,
      allocations: calculatedAllocations,
      totalCalculatedValue: calculatedAllocations.reduce((sum, alloc) => sum + (alloc.value || 0), 0),
      totalPercentage: totalPercentage
    };
  }, [currentData]);

  // Mémorisation du calcul du score de santé
  const healthScore = useMemo(() => {
    const totalPercentage = calculatedData.totalPercentage;
    const isBalanced = Math.abs(totalPercentage - 100) < 1;
    const hasGoodDiversification = calculatedData.allocations.length >= 4;
    const noOverConcentration = !calculatedData.allocations.some(alloc => (alloc.percentage || 0) > 60);

    let score = 0;
    if (isBalanced) score += 30;
    if (hasGoodDiversification) score += 35;
    if (noOverConcentration) score += 35;

    return score;
  }, [calculatedData.totalPercentage, calculatedData.allocations]);

  // Mémorisation des recommandations
  const recommendations = useMemo(() => {
    const recs = [];
    const totalPercentage = calculatedData.totalPercentage;

    if (Math.abs(totalPercentage - 100) > 1) {
      recs.push({
        type: 'warning',
        icon: 'ri-error-warning-line',
        title: 'Rééquilibrage nécessaire',
        description: `Votre allocation totale est de ${totalPercentage.toFixed(1)}%. Il faut rééquilibrer à 100%.`
      });
    }

    const overConcentrated = calculatedData.allocations.find(alloc => (alloc.percentage || 0) > 50);
    if (overConcentrated) {
      recs.push({
        type: 'warning',
        icon: 'ri-pie-chart-line',
        title: 'Sur-concentration détectée',
        description: `${overConcentrated.name} représente ${overConcentrated.percentage}% de votre portefeuille. Risque élevé.`
      });
    }

    const hasEmergingMarkets = calculatedData.allocations.some(alloc =>
      (alloc.name || '').toLowerCase().includes('émergent') || (alloc.name || '').toLowerCase().includes('emerging')
    );
    if (!hasEmergingMarkets) {
      recs.push({
        type: 'info',
        icon: 'ri-global-line',
        title: 'Diversification géographique',
        description: 'Considérez ajouter une exposition aux marchés émergents (5-15%).'
      });
    }

    if (recs.length === 0) {
      recs.push({
        type: 'success',
        icon: 'ri-check-circle-line',
        title: 'Allocation bien équilibrée',
        description: 'Votre portefeuille présente une diversification appropriée.'
      });
    }

    return recs;
  }, [calculatedData]);

  if (!calculatedData.allocations || calculatedData.allocations.length === 0) {
    return (
      <div className="bg-gray-900 p-6 rounded-xl border border-yellow-500/20">
        <div className="text-center">
          <i className="ri-pie-chart-line text-4xl text-gray-500 mb-4"></i>
          <h3 className="text-xl font-bold text-white mb-2">Aucune allocation trouvée</h3>
          <p className="text-gray-400 mb-4">
            Configurez votre portefeuille pour voir l'analyse d'allocation.
          </p>
          <button
            onClick={() => window.location.href = '/admin/portfolio-editor'}
            className="bg-yellow-500 hover:bg-yellow-600 text-black px-6 py-3 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap"
          >
            Configurer le portefeuille
          </button>
        </div>
      </div>
    );
  }

  if (!mounted) {
    return (
      <div className="bg-gray-900 p-6 rounded-xl border border-yellow-500/20">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-yellow-500 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-400">Chargement optimisé...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Score de santé du portefeuille - Version optimisée */}
      <div className="bg-gradient-to-r from-gray-900 to-gray-800 p-6 rounded-xl border border-yellow-500/30">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">Score de Santé du Portefeuille</h2>
            <p className="text-gray-400">Évaluation basée sur les meilleures pratiques de diversification</p>
          </div>
          <div className="text-right">
            <div className={`text-4xl font-bold mb-1 ${healthScore >= 80 ? 'text-green-400' : healthScore >= 60 ? 'text-yellow-400' : 'text-red-400'}`}>
              {healthScore}/100
            </div>
            <div className="text-sm text-gray-400">
              {healthScore >= 80 ? 'Excellent' : healthScore >= 60 ? 'Bon' : 'À améliorer'}
            </div>
          </div>
        </div>

        <div className="w-full bg-gray-700 rounded-full h-3 mb-4">
          <div
            className={`h-3 rounded-full transition-all duration-500 ${healthScore >= 80 ? 'bg-green-500' : healthScore >= 60 ? 'bg-yellow-500' : 'bg-red-500'}`}
            style={{ width: `${healthScore}%` }}
          />
        </div>

        <div className="grid md:grid-cols-3 gap-4 text-sm">
          <div className="flex items-center space-x-2">
            <i className="ri-check-circle-line text-green-400"></i>
            <span className="text-gray-300">Diversification</span>
          </div>
          <div className="flex items-center space-x-2">
            <i className="ri-scales-line text-blue-400"></i>
            <span className="text-gray-300">Équilibre</span>
          </div>
          <div className="flex items-center space-x-2">
            <i className="ri-shield-line text-purple-400"></i>
            <span className="text-gray-300">Gestion des risques</span>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Allocation actuelle - Version optimisée */}
        <div className="bg-gray-900 p-6 rounded-xl border border-yellow-500/20">
          <h3 className="text-xl font-bold text-white mb-6">Allocation Actuelle</h3>

          <div className="space-y-4">
            {calculatedData.allocations.map((allocation, index) => (
              <div key={`allocation-${index}-${allocation.name}`} className="space-y-3">
                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-3">
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: (allocation.color || '#6B7280') + '20' }}
                    >
                      <i className={`${allocation.icon || 'ri-pie-chart-line'} text-lg`} style={{ color: allocation.color || '#6B7280' }}></i>
                    </div>
                    <div>
                      <span className="text-white font-medium">{allocation.name || 'Actif'}</span>
                      <div className="text-sm text-gray-400" suppressHydrationWarning={true}>
                        €{formatNumber(allocation.value)}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-white font-semibold">{(allocation.percentage || 0).toFixed(1)}%</div>
                    <button
                      onClick={() => setShowDetails(showDetails === index ? null : index)}
                      className="text-xs text-yellow-400 hover:text-yellow-300 cursor-pointer"
                    >
                      {showDetails === index ? 'Masquer' : 'Détails'}
                    </button>
                  </div>
                </div>

                <div className="w-full bg-gray-800 rounded-full h-2">
                  <div
                    className="h-2 rounded-full transition-all duration-300"
                    style={{
                      width: `${Math.min(allocation.percentage || 0, 100)}%`,
                      backgroundColor: allocation.color || '#6B7280'
                    }}
                  />
                </div>

                {showDetails === index && (
                  <div className="bg-black/30 p-4 rounded-lg mt-3">
                    <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                      <div>
                        <span className="text-gray-400">Rendement attendu:</span>
                        <div className="text-white font-medium">
                          {allocation.name === 'Actions' ? '6-10%/an' :
                            allocation.name === 'Obligations' ? '3-5%/an' :
                              allocation.name === 'ETF' ? '5-8%/an' :
                                allocation.name === 'Crypto' ? '±50%/an' :
                                  '1-2%/an'}
                        </div>
                      </div>
                      <div>
                        <span className="text-gray-400">Volatilité:</span>
                        <div className={`font-medium ${allocation.name === 'Actions' || allocation.name === 'Crypto' ? 'text-red-400' : allocation.name === 'ETF' ? 'text-yellow-400' : 'text-green-400'}`}>
                          {allocation.name === 'Actions' ? 'Élevée' :
                            allocation.name === 'Obligations' || allocation.name === 'Cash' ? 'Faible' :
                              allocation.name === 'Crypto' ? 'Très élevée' :
                                'Modérée'}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="mt-6 pt-4 border-t border-gray-700">
            <div className="space-y-2 text-sm">
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Valeur totale:</span>
                <span className="text-white font-semibold" suppressHydrationWarning={true}>
                  €{formatNumber(currentData.totalValue)}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Total pourcentages:</span>
                <span className={`font-semibold ${Math.abs(calculatedData.totalPercentage - 100) < 0.1 ? 'text-green-400' : 'text-orange-400'}`}>
                  {calculatedData.totalPercentage.toFixed(1)}%
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Recommandations - Version optimisée */}
        <div className="bg-gray-900 p-6 rounded-xl border border-yellow-500/20">
          <h3 className="text-xl font-bold text-white mb-6">Recommandations</h3>

          <div className="space-y-4">
            {recommendations.map((rec, index) => (
              <div key={`rec-${index}-${rec.type}`} className={`p-4 rounded-lg border ${rec.type === 'success' ? 'bg-green-500/10 border-green-500/20' : rec.type === 'warning' ? 'bg-yellow-500/10 border-yellow-500/20' : 'bg-blue-500/10 border-blue-500/20'}`}>
                <div className="flex items-start space-x-3">
                  <i className={`${rec.icon} text-lg mt-0.5 ${rec.type === 'success' ? 'text-green-400' : rec.type === 'warning' ? 'text-yellow-400' : 'text-blue-400'}`}></i>
                  <div>
                    <h4 className="font-semibold text-white mb-1">{rec.title}</h4>
                    <p className="text-sm text-gray-300">{rec.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-6 space-y-3">
            <button className="w-full bg-yellow-500 hover:bg-yellow-600 text-black py-3 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap">
              Optimiser l'Allocation
            </button>
            <button
              onClick={() => setShowScenarioSimulator(true)}
              className="w-full bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 py-3 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap"
            >
              Simuler des Scénarios
            </button>
          </div>
        </div>
      </div>

      {/* Simulateur de scénarios avec Suspense */}
      {showScenarioSimulator && (
        <Suspense fallback={
          <div className="bg-gray-900 p-8 rounded-xl border border-yellow-500/20 text-center">
            <div className="animate-spin w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"></div>
            <p className="text-gray-400">Chargement du simulateur...</p>
          </div>
        }>
          <ScenarioSimulator
            isOpen={showScenarioSimulator}
            onClose={() => setShowScenarioSimulator(false)}
            portfolioData={calculatedData}
          />
        </Suspense>
      )}
    </div>
  );
}
