
"use client";

import { useState } from 'react';
import AllocationHero from './AllocationHero';
import AllocationModels from './AllocationModels';
import CurrentAllocation from './CurrentAllocation';
import ETFRecommendations from './ETFRecommendations';
import MifidRecommendations from './MifidRecommendations';
import RebalancingTools from './RebalancingTools';
import RiskAnalysis from './RiskAnalysis';
import ScenarioSimulator from './ScenarioSimulator';

export default function AllocationPage() {
  const [portfolioData] = useState({
    totalValue: 127544,
    allocations: [
      {
        id: 1,
        name: 'Actions',
        percentage: 45,
        value: 57395,
        color: '#EAB308',
        icon: 'ri-line-chart-line'
      },
      {
        id: 2,
        name: 'Obligations',
        percentage: 25,
        value: 31886,
        color: '#3B82F6',
        icon: 'ri-file-chart-line'
      },
      {
        id: 3,
        name: 'ETF',
        percentage: 20,
        value: 25509,
        color: '#10B981',
        icon: 'ri-fund-line'
      },
      {
        id: 4,
        name: 'Cash',
        percentage: 10,
        value: 12754,
        color: '#6B7280',
        icon: 'ri-wallet-line'
      }
    ]
  });

  return (
    <div className="min-h-screen bg-black">
      <AllocationHero />
      
      <div className="container mx-auto px-4 py-12 space-y-16">
        <CurrentAllocation portfolioData={portfolioData} />
        <AllocationModels />
        <ETFRecommendations />
        <RiskAnalysis />
        <MifidRecommendations />
        <RebalancingTools />
        <ScenarioSimulator />
      </div>
    </div>
  );
}
