'use client';

import { useState } from 'react';

export default function RebalancingTools({ portfolioData }) {
  const [rebalanceStrategy, setRebalanceStrategy] = useState('threshold');
  const [rebalanceResults, setRebalanceResults] = useState(null);

  // Vérifier si portfolioData et allocations existent
  if (!portfolioData || !portfolioData.allocations) {
    return (
      <div className="space-y-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Outils de Rééquilibrage</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Chargement des données du portefeuille...
          </p>
        </div>
        <div className="flex justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-yellow-500"></div>
        </div>
      </div>
    );
  }

  const [targetAllocations, setTargetAllocations] = useState(
    portfolioData.allocations.map(alloc => ({
      ...alloc,
      target: alloc.percentage
    }))
  );

  const calculateRebalancing = () => {
    const totalValue = portfolioData.totalValue;
    const results = targetAllocations.map(target => {
      const current = portfolioData.allocations.find(a => a.name === target.name);
      const targetValue = (totalValue * target.target) / 100;
      const currentValue = current ? current.value : 0;
      const difference = targetValue - currentValue;
      const action = difference > 0 ? 'Acheter' : difference < 0 ? 'Vendre' : 'Maintenir';
      
      return {
        name: target.name,
        current: current ? current.percentage : 0,
        target: target.target,
        currentValue,
        targetValue,
        difference: Math.abs(difference),
        action,
        color: target.color
      };
    });

    setRebalanceResults(results);
  };

  const applyRebalancing = () => {
    if (!rebalanceResults) return;
    
    const newConfig = {
      allocations: rebalanceResults.map((result, index) => ({
        id: index + 1,
        name: result.name,
        percentage: result.target,
        value: result.targetValue,
        color: result.color,
        icon: getIconForAsset(result.name)
      })),
      totalPortfolio: portfolioData.totalValue
    };
    
    localStorage.setItem('portfolio_config', JSON.stringify(newConfig));
    localStorage.setItem('dashboard_portfolio_updated', Date.now().toString());
    
    alert('Rééquilibrage appliqué avec succès !');
  };

  const getIconForAsset = (name) => {
    const iconMap = {
      'Actions': 'ri-line-chart-line',
      'Obligations': 'ri-file-chart-line',
      'ETF': 'ri-fund-line',
      'Crypto': 'ri-bit-coin-line',
      'Cash': 'ri-wallet-line'
    };
    return iconMap[name] || 'ri-pie-chart-line';
  };

  const strategies = [
    {
      id: 'threshold',
      name: 'Rééquilibrage par Seuils',
      description: 'Ajustement automatique quand un actif dépasse +/- 5% de sa cible',
      icon: 'ri-percent-line',
      pros: ['Réactif aux mouvements', 'Discipline automatique', 'Limite la dérive'],
      cons: ['Plus de transactions', 'Coûts de courtage', 'Timing complexe']
    },
    {
      id: 'calendar',
      name: 'Rééquilibrage Calendaire',
      description: 'Ajustement périodique (trimestriel, semestriel ou annuel)',
      icon: 'ri-calendar-line',
      pros: ['Simple à mettre en œuvre', 'Coûts prévisibles', 'Discipline régulière'],
      cons: ['Peut être sous-optimal', 'Ignore les opportunités', 'Timing fixe']
    },
    {
      id: 'tactical',
      name: 'Rééquilibrage Tactique',
      description: 'Ajustements basés sur les cycles de marché et les valorisations',
      icon: 'ri-line-chart-line',
      pros: ['Potentiel de surperformance', 'Flexibilité', 'Timing optimisé'],
      cons: ['Complexité élevée', 'Risque de timing errors', 'Subjectivité']
    }
  ];

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-white mb-4">Outils de Rééquilibrage</h2>
        <p className="text-gray-400 max-w-2xl mx-auto">
          Maintenez votre allocation cible avec nos outils professionnels de rééquilibrage.
        </p>
      </div>

      {/* Stratégies de rééquilibrage */}
      <div className="grid md:grid-cols-3 gap-6">
        {strategies.map((strategy) => (
          <div 
            key={strategy.id}
            className={`bg-gray-900 p-6 rounded-xl border cursor-pointer transition-all ${
              rebalanceStrategy === strategy.id 
                ? 'border-yellow-500 bg-yellow-500/5' 
                : 'border-gray-700 hover:border-gray-600'
            }`}
            onClick={() => setRebalanceStrategy(strategy.id)}
          >
            <div className="flex items-center space-x-3 mb-4">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                rebalanceStrategy === strategy.id ? 'bg-yellow-500/20' : 'bg-gray-800'
              }`}>
                <i className={`${strategy.icon} text-xl ${
                  rebalanceStrategy === strategy.id ? 'text-yellow-400' : 'text-gray-400'
                }`}></i>
              </div>
              <h3 className="font-bold text-white">{strategy.name}</h3>
            </div>
            
            <p className="text-gray-300 text-sm mb-4">{strategy.description}</p>
            
            <div className="space-y-3">
              <div>
                <h4 className="text-green-400 font-medium mb-1 text-sm">Avantages:</h4>
                <ul className="text-xs text-gray-400 space-y-1">
                  {strategy.pros.map((pro, index) => (
                    <li key={index} className="flex items-start space-x-1">
                      <i className="ri-check-line text-green-400 mt-0.5"></i>
                      <span>{pro}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              <div>
                <h4 className="text-orange-400 font-medium mb-1 text-sm">Inconvénients:</h4>
                <ul className="text-xs text-gray-400 space-y-1">
                  {strategy.cons.map((con, index) => (
                    <li key={index} className="flex items-start space-x-1">
                      <i className="ri-close-line text-orange-400 mt-0.5"></i>
                      <span>{con}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Configuration des allocations cibles */}
      <div className="bg-gray-900 p-6 rounded-xl border border-yellow-500/20">
        <h3 className="text-xl font-bold text-white mb-6">Allocations Cibles</h3>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h4 className="font-semibold text-white mb-4">Définir les Cibles</h4>
            <div className="space-y-4">
              {targetAllocations.map((target, index) => (
                <div key={index} className="flex items-center space-x-4">
                  <div 
                    className="w-6 h-6 rounded flex items-center justify-center"
                    style={{ backgroundColor: target.color + '20' }}
                  >
                    <div 
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: target.color }}
                    ></div>
                  </div>
                  <div className="flex-1">
                    <span className="text-white font-medium">{target.name}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="number"
                      value={target.target}
                      onChange={(e) => {
                        const newTargets = [...targetAllocations];
                        newTargets[index].target = parseFloat(e.target.value) || 0;
                        setTargetAllocations(newTargets);
                      }}
                      className="w-16 p-2 bg-gray-800 border border-gray-700 rounded text-white text-sm text-center focus:border-yellow-500 focus:outline-none"
                      step="0.5"
                      min="0"
                      max="100"
                    />
                    <span className="text-gray-400">%</span>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-4 pt-4 border-t border-gray-700">
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Total:</span>
                <span className={`font-semibold ${
                  targetAllocations.reduce((sum, t) => sum + t.target, 0) === 100 
                    ? 'text-green-400' 
                    : 'text-red-400'
                }`}>
                  {targetAllocations.reduce((sum, t) => sum + t.target, 0)}%
                </span>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-semibold text-white mb-4">Allocation Actuelle vs Cible</h4>
            <div className="space-y-3">
              {targetAllocations.map((target, index) => {
                const current = portfolioData.allocations.find(a => a.name === target.name);
                const currentPercentage = current ? current.percentage : 0;
                const difference = target.target - currentPercentage;
                
                return (
                  <div key={index} className="bg-black/30 p-3 rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-white font-medium">{target.name}</span>
                      <span className={`text-sm font-semibold ${
                        Math.abs(difference) < 1 ? 'text-green-400' :
                        Math.abs(difference) < 5 ? 'text-yellow-400' : 'text-red-400'
                      }`}>
                        {difference > 0 ? '+' : ''}{difference.toFixed(1)}%
                      </span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm">
                      <span className="text-gray-400">Actuel: {currentPercentage}%</span>
                      <span className="text-gray-500">→</span>
                      <span className="text-white">Cible: {target.target}%</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="flex space-x-4 mt-6">
          <button
            onClick={calculateRebalancing}
            className="flex-1 bg-blue-500 hover:bg-blue-600 text-white py-3 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap"
            disabled={targetAllocations.reduce((sum, t) => sum + t.target, 0) !== 100}
          >
            <i className="ri-calculator-line mr-2"></i>
            Calculer Rééquilibrage
          </button>
        </div>
      </div>

      {/* Résultats du rééquilibrage */}
      {rebalanceResults && (
        <div className="bg-gray-900 p-6 rounded-xl border border-yellow-500/20">
          <h3 className="text-xl font-bold text-white mb-6">Plan de Rééquilibrage</h3>
          
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-700">
                  <th className="text-left py-3 text-gray-400">Actif</th>
                  <th className="text-center py-3 text-gray-400">Actuel</th>
                  <th className="text-center py-3 text-gray-400">Cible</th>
                  <th className="text-center py-3 text-gray-400">Action</th>
                  <th className="text-center py-3 text-gray-400">Montant</th>
                </tr>
              </thead>
              <tbody>
                {rebalanceResults.map((result, index) => (
                  <tr key={index} className="border-b border-gray-800">
                    <td className="py-3">
                      <div className="flex items-center space-x-2">
                        <div 
                          className="w-4 h-4 rounded-full"
                          style={{ backgroundColor: result.color }}
                        ></div>
                        <span className="text-white font-medium">{result.name}</span>
                      </div>
                    </td>
                    <td className="text-center py-3 text-gray-300">
                      {result.current}%
                      <div className="text-xs text-gray-500">€{result.currentValue.toLocaleString()}</div>
                    </td>
                    <td className="text-center py-3 text-white">
                      {result.target}%
                      <div className="text-xs text-gray-400">€{result.targetValue.toLocaleString()}</div>
                    </td>
                    <td className="text-center py-3">
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        result.action === 'Acheter' ? 'bg-green-500/20 text-green-400' :
                        result.action === 'Vendre' ? 'bg-red-500/20 text-red-400' :
                        'bg-gray-500/20 text-gray-400'
                      }`}>
                        {result.action}
                      </span>
                    </td>
                    <td className="text-center py-3">
                      {result.difference > 0 && (
                        <span className={`font-semibold ${
                          result.action === 'Acheter' ? 'text-green-400' : 'text-red-400'
                        }`}>
                          €{result.difference.toLocaleString()}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex justify-between items-center mt-6 pt-4 border-t border-gray-700">
            <div className="text-sm text-gray-400">
              Coût estimé des transactions: €50-150
            </div>
            <button
              onClick={applyRebalancing}
              className="bg-yellow-500 hover:bg-yellow-600 text-black px-6 py-3 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-refresh-line mr-2"></i>
              Appliquer Rééquilibrage
            </button>
          </div>
        </div>
      )}

      {/* Conseils de rééquilibrage */}
      <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 p-6 rounded-xl border border-blue-500/20">
        <h3 className="text-xl font-bold text-white mb-4 flex items-center">
          <i className="ri-lightbulb-line text-blue-400 mr-3"></i>
          Conseils de Rééquilibrage
        </h3>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-semibold text-green-400 mb-3">Bonnes Pratiques</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li className="flex items-start space-x-2">
                <i className="ri-check-circle-line text-green-400 mt-0.5"></i>
                <span>Rééquilibrez quand l'écart dépasse 5-10%</span>
              </li>
              <li className="flex items-start space-x-2">
                <i className="ri-check-circle-line text-green-400 mt-0.5"></i>
                <span>Privilégiez les nouveaux apports pour rééquilibrer</span>
              </li>
              <li className="flex items-start space-x-2">
                <i className="ri-check-circle-line text-green-400 mt-0.5"></i>
                <span>Considérez les implications fiscales</span>
              </li>
              <li className="flex items-start space-x-2">
                <i className="ri-check-circle-line text-green-400 mt-0.5"></i>
                <span>Automatisez le processus quand possible</span>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-orange-400 mb-3">Pièges à Éviter</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li className="flex items-start space-x-2">
                <i className="ri-close-circle-line text-red-400 mt-0.5"></i>
                <span>Rééquilibrer trop fréquemment (coûts élevés)</span>
              </li>
              <li className="flex items-start space-x-2">
                <i className="ri-close-circle-line text-red-400 mt-0.5"></i>
                <span>Ignorer les frais de transaction</span>
              </li>
              <li className="flex items-start space-x-2">
                <i className="ri-close-circle-line text-red-400 mt-0.5"></i>
                <span>Faire du market timing</span>
              </li>
              <li className="flex items-start space-x-2">
                <i className="ri-close-circle-line text-red-400 mt-0.5"></i>
                <span>Changer constamment de stratégie</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}