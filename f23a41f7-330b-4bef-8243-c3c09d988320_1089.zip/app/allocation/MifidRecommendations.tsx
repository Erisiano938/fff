
'use client';

import { useState, useEffect } from 'react';

export default function MifidRecommendations() {
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [userProfile, setUserProfile] = useState(null);
  const [isLoadingProfile, setIsLoadingProfile] = useState(true);
  const [apiModel, setApiModel] = useState('local');
  const [apiKey, setApiKey] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [messageIdCounter, setMessageIdCounter] = useState(1);

  const generateUniqueId = () => {
    const newId = `msg_${Date.now()}_${messageIdCounter}`;
    setMessageIdCounter(prev => prev + 1);
    return newId;
  };

  useEffect(() => {
    loadUserProfile();
    loadApiSettings();
    
    // Générer l'ID initial une seule fois
    const initialId = `msg_${Date.now()}_1`;
    setMessageIdCounter(2);
    
    setMessages([
      {
        id: initialId,
        type: 'ai',
        content: "🤖 Assistant IA Open Source activé !\n\nJe peux répondre à toutes vos questions grâce à différents modèles IA :\n• Modèle local (par défaut) - Réponses rapides intégrées\n• OpenAI GPT - Intelligence avancée (clé API requise)\n• Anthropic Claude - Analyse approfondie (clé API requise)\n• Ollama - Modèles locaux open source\n\nComment puis-je vous aider aujourd'hui ?",
        timestamp: new Date().toLocaleTimeString()
      }
    ]);
  }, []);

  const loadApiSettings = () => {
    const savedModel = localStorage.getItem('aiModel') || 'local';
    const savedKey = localStorage.getItem('aiApiKey') || '';
    setApiModel(savedModel);
    setApiKey(savedKey);
  };

  const saveApiSettings = () => {
    localStorage.setItem('aiModel', apiModel);
    localStorage.setItem('aiApiKey', apiKey);
    setShowSettings(false);

    const settingsMessage = {
      id: generateUniqueId(),
      type: 'ai',
      content: ` Configuration sauvegardée !\n\nModèle actif : ${getModelName(apiModel)}\nStatut : ${apiKey && apiModel !== 'local' ? 'Clé API configurée' : 'Mode local actif'}\n\nVous pouvez maintenant poser vos questions !`,
      timestamp: new Date().toLocaleTimeString()
    };
    setMessages(prev => [...prev, settingsMessage]);
  };

  const getModelName = (model) => {
    const models = {
      'local': 'Assistant Local',
      'openai': 'OpenAI GPT-4',
      'claude': 'Anthropic Claude',
      'ollama': 'Ollama (Local)'
    };
    return models[model] || 'Assistant Local';
  };

  const loadUserProfile = () => {
    setIsLoadingProfile(true);

    const patrimoineProfile = localStorage.getItem('patrimoineProfile');
    const mifidProfile = localStorage.getItem('mifidProfile');

    let profile = null;

    if (patrimoineProfile) {
      try {
        const patrimoine = JSON.parse(patrimoineProfile);
        profile = {
          source: 'patrimoine',
          data: patrimoine,
          experience: patrimoine.investmentExperience || 'beginner',
          riskTolerance: patrimoine.riskTolerance || 5,
          income: patrimoine.annualIncome || 50000,
          savings: patrimoine.currentSavings || 10000,
          timeHorizon: patrimoine.timeHorizon || 'medium',
          age: patrimoine.age || 30
        };
      } catch (error) {
        console.error('Erreur profil patrimoine:', error);
      }
    } else if (mifidProfile) {
      try {
        const mifid = JSON.parse(mifidProfile);
        profile = {
          source: 'mifid',
          data: mifid,
          experience: mifid.investmentExperience || 'beginner',
          riskTolerance: mifid.riskTolerance === 'high' ? 8 : mifid.riskTolerance === 'medium' ? 5 : 3,
          income: mifid.income || 50000,
          savings: mifid.savings || 10000,
          timeHorizon: mifid.timeHorizon || 'medium',
          age: mifid.age || 30
        };
      } catch (error) {
        console.error('Erreur profil MiFID:', error);
      }
    }

    setUserProfile(profile);
    setIsLoadingProfile(false);

    setTimeout(() => {
      if (profile) {
        const welcomeId = `welcome_${Date.now()}_${Math.random()}`;
        const welcomeMessage = {
          id: welcomeId,
          type: 'ai',
          content: `🎯 Excellent ! J'ai synchronisé votre profil ${profile.source === 'patrimoine' ? 'gestion de patrimoine' : 'MiFID'}.\n\n**Votre profil :**\n• Expérience : ${profile.experience}\n• Tolérance au risque : ${profile.riskTolerance}/10\n• Âge : ${profile.age} ans\n• Horizon : ${profile.timeHorizon}\n\nJe peux maintenant vous donner des conseils personnalisés sur l'investissement, mais aussi répondre à toutes vos autres questions !\n\n**Exemples de questions :**\n• Questions financières personnalisées\n• Actualité économique et marchés\n• Stratégies d'investissement avancées  \n• Crypto-monnaies et nouvelles technologies\n• Fiscalité et optimisation\n• Sciences, technologie, histoire, culture\n• Conseils pratiques et bien plus encore !`,
          timestamp: new Date().toLocaleTimeString()
        };
        setMessages(prev => [...prev, welcomeMessage]);
      } else {
        const noProfileId = `no_profile_${Date.now()}_${Math.random()}`;
        const noProfileMessage = {
          id: noProfileId,
          type: 'ai',
          content: `🚀 **Assistant IA prêt !**\n\nJe peux répondre à toutes vos questions sur :\n• **Finance & Investissement** - allocations, ETF, actions, crypto\n• **Économie & Marchés** - analyses, tendances, prévisions\n• **Technologie** - IA, blockchain, innovations\n• **Sciences & Culture** - histoire, géographie, sciences\n• **Conseils pratiques** - vie quotidienne, carrière, projets\n• **Actualités** - événements récents, analyses\n\n**Astuce :** Pour des conseils financiers personnalisés, complétez d'abord votre profil investisseur dans les autres sections !`,
          timestamp: new Date().toLocaleTimeString()
        };
        setMessages(prev => [...prev, noProfileMessage]);
      }
    }, 1000);
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage = {
      id: generateUniqueId(),
      type: 'user',
      content: inputMessage,
      timestamp: new Date().toLocaleTimeString()
    };

    setMessages(prev => [...prev, userMessage]);
    const currentMessage = inputMessage;
    setInputMessage('');
    setIsTyping(true);

    try {
      let response;

      if (apiModel === 'openai' && apiKey) {
        response = await callOpenAI(currentMessage, userProfile);
      } else if (apiModel === 'claude' && apiKey) {
        response = await callClaude(currentMessage, userProfile);
      } else if (apiModel === 'ollama') {
        response = await callOllama(currentMessage, userProfile);
      } else {
        response = await generateLocalResponse(currentMessage, userProfile);
      }

      const aiResponse = {
        id: generateUniqueId(),
        type: 'ai',
        content: response,
        timestamp: new Date().toLocaleTimeString()
      };
      setMessages(prev => [...prev, aiResponse]);
    } catch (error) {
      console.error('Erreur génération réponse:', error);
      const errorMessage = {
        id: generateUniqueId(),
        type: 'ai',
        content: ` Erreur ${getModelName(apiModel)}\n\nImpossible de générer une réponse. Vérifiez :\n• Votre connexion internet\n• Votre clé API (si applicable)\n• Les paramètres du modèle\n\n*Basculement vers le modèle local...*`,
        timestamp: new Date().toLocaleTimeString()
      };
      setMessages(prev => [...prev, errorMessage]);

      try {
        const fallbackResponse = await generateLocalResponse(currentMessage, userProfile);
        const fallbackMessage = {
          id: generateUniqueId(),
          type: 'ai',
          content: fallbackResponse,
          timestamp: new Date().toLocaleTimeString()
        };
        setMessages(prev => [...prev, fallbackMessage]);
      } catch (fallbackError) {
        console.error('Erreur fallback:', fallbackError);
      }
    } finally {
      setIsTyping(false);
    }
  };

  const callOpenAI = async (message, profile) => {
    if (!apiKey) throw new Error('Clé API OpenAI manquante');

    const systemPrompt = `Tu es un assistant IA expert en finance, investissement et conseil général. ${profile ? `Profil utilisateur : âge ${profile.age}, tolérance risque ${profile.riskTolerance}/10, expérience ${profile.experience}. ` : ' '}Réponds de manière directe, concise et actionnable. Donne des conseils précis avec des ETF, pourcentages et stratégies concrètes.`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-4',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: message }
        ],
        max_tokens: 1000,
        temperature: 0.7
      })
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const data = await response.json();
    return `🧠 OpenAI GPT-4\n\n${data.choices[0].message.content}`;
  };

  const callClaude = async (message, profile) => {
    if (!apiKey) throw new Error('Clé API Claude manquante');

    const systemPrompt = `Tu es un assistant IA expert en finance et conseil général. ${profile ? `Profil : âge ${profile.age}, risque ${profile.riskTolerance}/10, expérience ${profile.experience}. ` : ' '}Sois direct, précis et actionnable dans tes réponses.`;

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': apiKey,
        'Content-Type': 'application/json',
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-3-sonnet-20240229',
        max_tokens: 1000,
        system: systemPrompt,
        messages: [
          { role: 'user', content: message }
        ]
      })
    });

    if (!response.ok) {
      throw new Error(`Claude API error: ${response.status}`);
    }

    const data = await response.json();
    return `🎭 Anthropic Claude\n\n${data.content[0].text}`;
  };

  const callOllama = async (message, profile) => {
    const systemPrompt = `Tu es un assistant IA expert en finance et conseil. ${profile ? `Profil : âge ${profile.age}, risque ${profile.riskTolerance}/10. ` : ' '}Réponds directement et précisément.`;

    try {
      const response = await fetch('http://localhost:11434/api/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'llama2',
          prompt: `${systemPrompt}\n\nQuestion: ${message}`,
          stream: false
        })
      });

      if (!response.ok) {
        throw new Error('Ollama non disponible');
      }

      const data = await response.json();
      return `🦙 Ollama Local\n\n${data.response}`;
    } catch (error) {
      throw new Error('Ollama non accessible (vérifiez que Ollama est lancé sur le port 11434)');
    }
  };

  const generateLocalResponse = async (message, profile) => {
    const lowerMessage = message.toLowerCase();

    if (lowerMessage.includes('allocation') || lowerMessage.includes('portefeuille')) {
      const riskLevel = profile?.riskTolerance || 5;
      if (riskLevel <= 4) {
        return `📊 Allocation Prudente\n\n• 30% Actions (CW8)\n• 50% Obligations (AGGH)\n• 20% Liquidités\n\nAction : DCA mensuel 200-500€`;
      } else if (riskLevel <= 7) {
        return `⚖️ Allocation Équilibrée\n\n• 60% Actions (CW8 35%, PAEEM 15%, MEUD 10%)\n• 30% Obligations (AGGH)\n• 10% Liquidités\n\nAction : DCA mensuel 300-800€`;
      } else {
        return `🚀 Allocation Dynamique\n\n• 80% Actions diversifiées\n• 15% Obligations\n• 5% Liquidités\n\nAction : DCA hebdomadaire possible`;
      }
    }

    if (lowerMessage.includes('crypto')) {
      return `₿ Crypto Strategy\n\nTop 3 :\n• Bitcoin (50%)\n• Ethereum (35%)\n• Solana (15%)\n\nMax allocation : 5-10% du portefeuille\nStratégie : DCA mensuel strict`;
    }

    return `🤖 Assistant IA Local\n\nQuestion : "${message}"\n\nRéponse directe :\nJe traite votre demande avec le modèle local. Pour des réponses plus avancées, configurez OpenAI, Claude ou Ollama dans les paramètres.\n\nConseil : Soyez plus spécifique pour une réponse précise :\n• "Allocation pour 30 ans, risque 7/10"\n• "ETF pour débuter avec 10k€"\n• "Crypto : 5% du portefeuille ?"`;
  };

  const aiModels = [
    { id: 'local', name: 'Assistant Local', description: 'Réponses rapides intégrées', icon: 'ri-cpu-line', free: true },
    { id: 'openai', name: 'OpenAI GPT-4', description: 'Intelligence avancée', icon: 'ri-openai-fill', free: false },
    { id: 'claude', name: 'Anthropic Claude', description: 'Analyse approfondie', icon: 'ri-brain-line', free: false },
    { id: 'ollama', name: 'Ollama Local', description: 'Modèles open source locaux', icon: 'ri-server-line', free: true }
  ];

  const quickQuestions = [
    "Allocation optimale pour mon profil",
    "Meilleurs ETF 2024",
    "Crypto : combien investir ?",
    "Stratégie DCA expliquée",
    "Marchés actuels : opportunités",
    "IA et investissement",
    "Erreurs à éviter",
    "Diversification géographique"
  ];

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-green-500/20 to-blue-500/20 p-6 rounded-xl border border-green-500/30">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-2xl font-bold text-white mb-2 flex items-center">
              <i className="ri-robot-line text-green-400 mr-3"></i>
              Chatbot IA Open Source
            </h3>
            <p className="text-gray-300">
              Assistant intelligent avec choix de modèles IA - Local ou API externes
            </p>
            <div className="mt-3 flex items-center space-x-4 text-sm">
              <div className="flex items-center text-green-400">
                <i className="ri-open-source-line mr-1"></i>
                100% Open Source
              </div>
              <div className="flex items-center text-blue-400">
                <i className="ri-cpu-line mr-1"></i>
                {getModelName(apiModel)}
              </div>
              <div className="flex items-center text-purple-400">
                <i className="ri-user-settings-line mr-1"></i>
                {userProfile ? 'Profil synchronisé' : 'Mode général'}
              </div>
            </div>
          </div>
          <button
            onClick={() => setShowSettings(!showSettings)}
            className="p-2 bg-gray-700 hover:bg-gray-600 rounded-lg text-gray-300 hover:text-white transition-colors cursor-pointer"
            title="Paramètres IA"
          >
            <i className="ri-settings-3-line"></i>
          </button>
        </div>
      </div>

      {showSettings && (
        <div className="bg-gray-900/70 p-6 rounded-xl border border-gray-700">
          <h4 className="text-white font-semibold mb-4 flex items-center">
            <i className="ri-settings-3-line text-blue-400 mr-2"></i>
            Configuration des modèles IA
          </h4>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            {aiModels.map((model) => (
              <div
                key={model.id}
                onClick={() => setApiModel(model.id)}
                className={`p-4 rounded-lg border cursor-pointer transition-all ${
                  apiModel === model.id
                    ? 'border-blue-500 bg-blue-500/10'
                    : 'border-gray-600 bg-gray-800/50 hover:border-gray-500'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <i
                      className={`${model.icon} text-xl mr-3 ${
                        apiModel === model.id ? 'text-blue-400' : 'text-gray-400'
                      }`}
                    ></i>
                    <div>
                      <h5 className="text-white font-medium">{model.name}</h5>
                      <p className="text-gray-400 text-sm">{model.description}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {model.free && (
                      <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded">
                        Gratuit
                      </span>
                    )}
                    {apiModel === model.id && (
                      <i className="ri-check-line text-blue-400"></i>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {(apiModel === 'openai' || apiModel === 'claude') && (
            <div className="mb-4">
              <label className="block text-white font-medium mb-2">
                Clé API {apiModel === 'openai' ? 'OpenAI' : 'Anthropic Claude'}
              </label>
              <input
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder={`Entrez votre clé API ${apiModel === 'openai' ? 'OpenAI' : 'Claude'}...`}
                className="w-full p-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:border-blue-500 focus:outline-none"
              />
              <p className="text-gray-400 text-sm mt-2">
                {apiModel === 'openai' ? (
                  <>Obtenez votre clé sur <a
                    href="https://platform.openai.com/api-keys"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-400 hover:underline"
                  >platform.openai.com</a></>
                ) : (
                  <>Obtenez votre clé sur <a
                    href="https://console.anthropic.com/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-400 hover:underline"
                  >console.anthropic.com</a></>
                )}
              </p>
            </div>
          )}

          {apiModel === 'ollama' && (
            <div className="mb-4 p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
              <h5 className="text-yellow-400 font-medium mb-2 flex items-center">
                <i className="ri-information-line mr-2"></i>
                Installation Ollama requise
              </h5>
              <p className="text-gray-300 text-sm mb-3">
                Pour utiliser Ollama, installez-le d'abord sur votre machine :
              </p>
              <div className="space-y-2 text-sm">
                <div className="bg-gray-800 p-2 rounded font-mono text-green-400">
                  curl -fsSL https://ollama.com/install.sh | sh
                </div>
                <div className="bg-gray-800 p-2 rounded font-mono text-green-400">
                  ollama run llama2
                </div>
              </div>
              <p className="text-gray-400 text-xs mt-2">
                Plus d'infos sur <a
                  href="https://ollama.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-400 hover:underline"
                >ollama.com</a>
              </p>
            </div>
          )}

          <div className="flex justify-end space-x-3">
            <button
              onClick={() => setShowSettings(false)}
              className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              Annuler
            </button>
            <button
              onClick={saveApiSettings}
              className="px-4 py-2 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-lg font-semibold hover:from-blue-400 hover:to-blue-500 transition-all cursor-pointer whitespace-nowrap"
            >
              Sauvegarder
            </button>
          </div>
        </div>
      )}

      <div className="bg-gray-900/50 rounded-xl border border-blue-500/20 overflow-hidden">
        <div className="h-96 overflow-y-auto p-6 space-y-4">
          {isLoadingProfile && (
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-blue-500/20 rounded-full flex items-center justify-center">
                <i className="ri-loader-4-line animate-spin text-blue-400"></i>
              </div>
              <div className="bg-gray-800/70 p-3 rounded-lg flex-1">
                <p className="text-gray-300">Chargement de votre profil...</p>
              </div>
            </div>
          )}

          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex items-start space-x-3 ${message.type === 'user' ? 'flex-row-reverse space-x-reverse' : ''}`}
            >
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center ${message.type === 'ai' ? 'bg-green-500/20' : 'bg-blue-500/20'}`}
              >
                <i
                  className={`${message.type === 'ai' ? 'ri-robot-line text-green-400' : 'ri-user-line text-blue-400'}`}
                ></i>
              </div>

              <div
                className={`max-w-[80%] p-4 rounded-lg ${message.type === 'ai' ? 'bg-gray-800/70' : 'bg-blue-600/80'}`}
              >
                <div className="whitespace-pre-line text-gray-200">{message.content}</div>
                <div className="text-xs text-gray-400 mt-2">{message.timestamp}</div>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-green-500/20 rounded-full flex items-center justify-center">
                <i className="ri-robot-line text-green-400"></i>
              </div>
              <div className="bg-gray-800/70 p-3 rounded-lg">
                <div className="flex items-center space-x-2">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-bounce"></div>
                    <div
                      className="w-2 h-2 bg-green-400 rounded-full animate-bounce"
                      style={{ animationDelay: '0.1s' }}
                    ></div>
                    <div
                      className="w-2 h-2 bg-green-400 rounded-full animate-bounce"
                      style={{ animationDelay: '0.2s' }}
                    ></div>
                  </div>
                  <span className="text-gray-400 text-sm">{getModelName(apiModel)} analyse...</span>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="border-t border-gray-700 p-4">
          <div className="mb-3">
            <h4 className="text-white font-medium mb-2 flex items-center">
              <i className="ri-question-line text-green-400 mr-2"></i>
              Questions suggérées :
            </h4>
            <div className="grid grid-cols-2 gap-2">
              {quickQuestions.map((question, index) => (
                <button
                  key={`quick-${index}`}
                  onClick={() => setInputMessage(question)}
                  className="text-sm bg-gray-700 hover:bg-gray-600 text-gray-300 px-3 py-2 rounded-lg transition-colors cursor-pointer text-left"
                >
                  {question}
                </button>
              ))}
            </div>
          </div>

          <div className="flex space-x-3">
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Posez n'importe quelle question..."
              className="flex-1 p-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:border-blue-500 focus:outline-none"
            />
            <button
              onClick={handleSendMessage}
              disabled={!inputMessage.trim() || isTyping}
              className="px-6 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-lg font-semibold hover:from-green-400 hover:to-green-500 transition-all cursor-pointer whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <i className="ri-send-plane-line"></i>
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gray-900/30 p-4 rounded-xl border border-gray-700">
          <h4 className="text-white font-semibold mb-3 flex items-center">
            <i className="ri-cpu-line text-green-400 mr-2"></i>
            Modèle actuel
          </h4>
          <div className="space-y-2 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-gray-400">IA active:</span>
              <span className="text-white">{getModelName(apiModel)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400">Statut:</span>
              <span className="flex items-center text-green-400">
                <i className="ri-check-line mr-1"></i>
                Opérationnel
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400">API:</span>
              <span className="text-white">
                {apiKey && apiModel !== 'local' ? 'Configurée' : 'Local'}
              </span>
            </div>
          </div>
        </div>

        {userProfile && (
          <div className="bg-gray-900/30 p-4 rounded-xl border border-gray-700">
            <h4 className="text-white font-semibold mb-3 flex items-center">
              <i className="ri-user-settings-line text-blue-400 mr-2"></i>
              Profil Synchronisé
            </h4>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <span className="text-gray-400">Source:</span>
                <span className="text-white ml-2 capitalize">{userProfile.source}</span>
              </div>
              <div>
                <span className="text-gray-400">Risque:</span>
                <span className="text-white ml-2">{userProfile.riskTolerance}/10</span>
              </div>
              <div>
                <span className="text-gray-400">Âge:</span>
                <span className="text-white ml-2">{userProfile.age} ans</span>
              </div>
              <div>
                <span className="text-gray-400">Horizon:</span>
                <span className="text-white ml-2 capitalize">{userProfile.timeHorizon}</span>
              </div>
            </div>
          </div>
        )}

        <div className="bg-gray-900/30 p-4 rounded-xl border border-gray-700">
          <h4 className="text-white font-semibold mb-3 flex items-center">
            <i className="ri-open-source-line text-purple-400 mr-2"></i>
            Open Source
          </h4>
          <div className="space-y-2 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-gray-400">Modèles:</span>
              <span className="text-white">4 disponibles</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400">Local:</span>
              <span className="text-green-400">Ollama</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-400">API:</span>
              <span className="text-blue-400">OpenAI, Claude</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
