
'use client';

import { useState, useEffect, useMemo, useCallback } from 'react';

export default function RiskAnalysis({ portfolioData = { totalValue: 0, allocations: [] } }) {
  const [selectedScenario, setSelectedScenario] = useState('recession');
  const [syncedData, setSyncedData] = useState(portfolioData);
  const [showAnalysis, setShowAnalysis] = useState(false);
  const [appliedModel, setAppliedModel] = useState(null);
  const [recommendations, setRecommendations] = useState([]);

  const applyRecommendation = useCallback((recommendation) => {
    try {
      const currentConfig = JSON.parse(localStorage.getItem('portfolio_config') || '{}');
      let allocations = currentConfig.allocations || syncedData.allocations || [];

      if (recommendation.newAllocation) {
        const { assetName, targetPercentage, sourceFrom } = recommendation.newAllocation;

        let targetAsset = allocations.find(a => a.name === assetName);
        let sourceAsset = sourceFrom ? allocations.find(a => a.name === sourceFrom) : null;

        if (!targetAsset && assetName) {
          targetAsset = {
            name: assetName,
            percentage: 0,
            value: 0,
            color: assetName === 'Obligations' ? '#3B82F6' : 
                   assetName === 'Cash' ? '#6B7280' : '#10B981',
            icon: assetName === 'Obligations' ? 'ri-money-dollar-circle-line' :
                  assetName === 'Cash' ? 'ri-wallet-line' : 'ri-fund-line'
          };
          allocations.push(targetAsset);
        }

        if (targetAsset) {
          const currentPercentage = targetAsset.percentage || 0;
          const difference = targetPercentage - currentPercentage;

          targetAsset.percentage = targetPercentage;
          targetAsset.value = ((syncedData.totalValue || 0) * targetPercentage) / 100;

          if (sourceAsset && difference > 0) {
            const newSourcePercentage = Math.max(0, sourceAsset.percentage - difference);
            sourceAsset.percentage = newSourcePercentage;
            sourceAsset.value = ((syncedData.totalValue || 0) * newSourcePercentage) / 100;
          }

          const totalPercentage = allocations.reduce((sum, a) => sum + a.percentage, 0);
          if (totalPercentage !== 100) {
            const factor = 100 / totalPercentage;
            allocations.forEach(a => {
              a.percentage = a.percentage * factor;
              a.value = ((syncedData.totalValue || 0) * a.percentage) / 100;
            });
          }
        }
      }

      if (recommendation.modelRebalancing) {
        Object.entries(recommendation.modelRebalancing).forEach(([assetName, targetPercentage]) => {
          let asset = allocations.find(a => a.name === assetName);
          if (!asset) {
            asset = {
              name: assetName,
              percentage: 0,
              value: 0,
              color: assetName === 'Obligations' ? '#3B82F6' : 
                     assetName === 'Cash' ? '#6B7280' : '#EAB308',
              icon: assetName === 'Obligations' ? 'ri-money-dollar-circle-line' :
                    assetName === 'Cash' ? 'ri-wallet-line' : 'ri-line-chart-line'
            };
            allocations.push(asset);
          }
          asset.percentage = targetPercentage;
          asset.value = ((syncedData.totalValue || 0) * targetPercentage) / 100;
        });
      }

      const updatedConfig = {
        ...currentConfig,
        allocations: allocations,
        lastUpdated: new Date().toISOString()
      };

      localStorage.setItem('portfolio_config', JSON.stringify(updatedConfig));
      localStorage.setItem('portfolio_data', JSON.stringify({
        totalValue: syncedData.totalValue || 0,
        allocations: allocations
      }));

      localStorage.setItem('dashboard_portfolio_updated', Date.now().toString());
      localStorage.setItem('risk_analysis_sync', Date.now().toString());
      localStorage.setItem('allocation_model_applied', Date.now().toString());

      window.dispatchEvent(new CustomEvent('portfolioUpdated', { 
        detail: { 
          data: { totalValue: syncedData.totalValue || 0, allocations },
          config: updatedConfig 
        } 
      }));
      window.dispatchEvent(new CustomEvent('allocationUpdated'));
      window.dispatchEvent(new CustomEvent('riskAnalysisRefresh'));

      setSyncedData({ totalValue: syncedData.totalValue || 0, allocations });

      alert('✅ Recommandation appliquée ! Tests synchronisés.');

      setTimeout(() => {
        const currentScenario = selectedScenario;
        setSelectedScenario(null);
        setTimeout(() => {
          setSelectedScenario(currentScenario);
        }, 200);
      }, 500);

    } catch (error) {
      console.error('Erreur lors de l\'application:', error);
      alert('❌ Erreur lors de l\'application de la recommandation');
    }
  }, [syncedData, selectedScenario]);

  // Fonction de synchronisation stable
  const syncPortfolioData = useCallback(() => {
    try {
      const dashboardData = localStorage.getItem('portfolio_data');
      const dashboardConfig = localStorage.getItem('portfolio_config');
      const modelInfo = localStorage.getItem('portfolio_applied_model');

      if (modelInfo) {
        try {
          const parsedModel = JSON.parse(modelInfo);
          setAppliedModel(parsedModel);
        } catch (error) {
          const config = JSON.parse(dashboardConfig || '{}');
          if (config.appliedModel) {
            setAppliedModel({ name: config.appliedModel, timestamp: Date.now() });
          }
        }
      }

      let newData = null;

      if (dashboardData) {
        const parsedData = JSON.parse(dashboardData);
        newData = {
          totalValue: parsedData.totalValue || 0,
          allocations: parsedData.allocations || []
        };
      } else if (dashboardConfig) {
        const config = JSON.parse(dashboardConfig);
        if (config.allocations && config.totalPortfolio) {
          newData = {
            totalValue: config.totalPortfolio || 0,
            allocations: config.allocations || []
          };
        }
      }

      if (!newData) {
        newData = {
          totalValue: portfolioData?.totalValue || 0,
          allocations: portfolioData?.allocations || []
        };
      }

      // Seulement mettre à jour si les données ont changé
      setSyncedData(prevData => {
        const hasChanged = 
          prevData.totalValue !== newData.totalValue ||
          JSON.stringify(prevData.allocations) !== JSON.stringify(newData.allocations);
        
        return hasChanged ? newData : prevData;
      });

    } catch (error) {
      console.error('Erreur synchronisation:', error);
      setSyncedData({
        totalValue: portfolioData?.totalValue || 0,
        allocations: portfolioData?.allocations || []
      });
    }
  }, [portfolioData]);

  // useEffect principal - sans dépendances qui changent constamment
  useEffect(() => {
    syncPortfolioData();

    const handleStorageChange = () => {
      syncPortfolioData();
    };

    const handlePortfolioUpdate = (event) => {
      console.log('Portfolio update detected:', event.detail);
      if (event.detail && event.detail.data) {
        setSyncedData(event.detail.data);
        if (event.detail.config && event.detail.config.appliedModel) {
          setAppliedModel({ 
            name: event.detail.config.appliedModel, 
            timestamp: Date.now() 
          });
        }
      } else {
        syncPortfolioData();
      }
    };

    const handleAllocationChange = () => {
      console.log('Allocation change detected, refreshing risk analysis...');
      syncPortfolioData();
    };

    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('portfolioUpdated', handlePortfolioUpdate);
    window.addEventListener('allocationUpdated', handleAllocationChange);

    const interval = setInterval(() => {
      const lastUpdate = localStorage.getItem('dashboard_portfolio_updated');
      const riskSync = localStorage.getItem('risk_analysis_sync');
      const allocationUpdate = localStorage.getItem('allocation_model_applied');

      if (lastUpdate || riskSync || allocationUpdate) {
        console.log('Detected changes, syncing risk analysis...');
        syncPortfolioData();
        localStorage.removeItem('dashboard_portfolio_updated');
        localStorage.removeItem('risk_analysis_sync');
        localStorage.removeItem('allocation_model_applied');
      }
    }, 1000);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('portfolioUpdated', handlePortfolioUpdate);
      window.removeEventListener('allocationUpdated', handleAllocationChange);
      clearInterval(interval);
    };
  }, [syncPortfolioData]);

  const riskMetrics = useMemo(() => {
    if (!showAnalysis) return null;

    const totalValue = syncedData?.totalValue || 0;
    const allocations = syncedData?.allocations || [];

    if (!allocations || allocations.length === 0) {
      return {
        volatility: 0.15,
        var95: totalValue * 0.15 * 1.65,
        maxDrawdown: 0.25,
        expectedReturn: 0.06,
        sharpeRatio: 0.8,
        needsRebalancing: true
      };
    }

    const volatilities = {
      'Actions': 0.18,
      'Obligations': 0.04,
      'ETF': 0.15,
      'Crypto': 0.80,
      'Cash': 0.01,
      'Actions défensives': 0.12,
      'Actions croissance': 0.25,
      'Actions diversifiées': 0.17,
      'ETF diversifiés': 0.14,
      'ETF internationaux': 0.16,
      'ETF émergents': 0.28,
      'REIT/Immobilier': 0.20,
      'Small caps': 0.32
    };

    const expectedReturns = {
      'Actions': 0.08,
      'Obligations': 0.03,
      'ETF': 0.07,
      'Crypto': 0.15,
      'Cash': 0.01,
      'Actions défensives': 0.06,
      'Actions croissance': 0.10,
      'Actions diversifiées': 0.08,
      'ETF diversifiés': 0.07,
      'ETF internationaux': 0.075,
      'ETF émergents': 0.09,
      'REIT/Immobilier': 0.065,
      'Small caps': 0.11
    };

    const correlations = {
      'Actions-Actions défensives': 0.8,
      'Actions-Actions croissance': 0.9,
      'Actions-Actions diversifiées': 0.95,
      'Actions-ETF': 0.85,
      'Actions-ETF diversifiés': 0.9,
      'Actions-ETF internationaux': 0.7,
      'Actions-ETF émergents': 0.6,
      'Actions-REIT/Immobilier': 0.5,
      'Actions-Small caps': 0.7,
      'Actions-Crypto': 0.3,
      'Actions-Obligations': -0.1,
      'Actions-Cash': 0.0,
      'Obligations-Cash': 0.1,
      'Crypto-Obligations': -0.2,
      'ETF émergents-ETF internationaux': 0.8
    };

    let portfolioVariance = 0;
    const weights = allocations.map(alloc => (alloc.percentage || (alloc.value / totalValue * 100)) / 100);

    for (let i = 0; i < allocations.length; i++) {
      for (let j = 0; j < allocations.length; j++) {
        const vol_i = volatilities[allocations[i].name] || 0.15;
        const vol_j = volatilities[allocations[j].name] || 0.15;

        let correlation = 1;
        if (i !== j) {
          const pair1 = `${allocations[i].name}-${allocations[j].name}`;
          const pair2 = `${allocations[j].name}-${allocations[i].name}`;
          correlation = correlations[pair1] || correlations[pair2] || 0.3; 
        }

        portfolioVariance += weights[i] * weights[j] * vol_i * vol_j * correlation;
      }
    }

    const portfolioVolatility = Math.sqrt(Math.max(0, portfolioVariance));
    const var95 = totalValue * portfolioVolatility * 1.65;
    const maxDrawdown = portfolioVolatility * 2.8;

    const expectedReturn = allocations.reduce((sum, alloc) => {
      const weight = (alloc.percentage || (alloc.value / totalValue * 100)) / 100;
      const ret = expectedReturns[alloc.name] || 0.06;
      return sum + ret * weight;
    }, 0);

    const riskFreeRate = 0.025;
    const sharpeRatio = (expectedReturn - riskFreeRate) / portfolioVolatility;

    const totalPercentage = allocations.reduce((sum, alloc) => sum + (alloc.percentage || 0), 0);
    const needsRebalancing = Math.abs(totalPercentage - 100) > 2;

    return {
      volatility: portfolioVolatility,
      var95,
      maxDrawdown,
      expectedReturn,
      sharpeRatio,
      needsRebalancing
    };
  }, [syncedData, showAnalysis]);

  const scenarios = useMemo(() => [
    {
      id: 'recession',
      name: 'Récession Économique',
      description: 'Récession modérée similaire à 2008-2009',
      icon: 'ri-arrow-down-line',
      color: 'red',
      impacts: [
        { asset: 'Actions', impact: -25, description: 'Correction boursière typique' },
        { asset: 'Actions défensives', impact: -15, description: 'Résistance relative' },
        { asset: 'Actions croissance', impact: -35, description: 'Plus forte correction' },
        { asset: 'Actions diversifiées', impact: -22, description: 'Diversification protège' },
        { asset: 'Obligations', impact: 5, description: 'Fuite vers la qualité' },
        { asset: 'ETF', impact: -20, description: 'Suit les marchés' },
        { asset: 'ETF diversifiés', impact: -18, description: 'Diversification aide' },
        { asset: 'ETF internationaux', impact: -23, description: 'Contagion mondiale' },
        { asset: 'ETF émergents', impact: -40, description: 'Fuite des capitaux' },
        { asset: 'Crypto', impact: -55, description: 'Actif risqué vendu' },
        { asset: 'REIT/Immobilier', impact: -30, description: 'Secteur cyclique' },
        { asset: 'Small caps', impact: -45, description: 'Plus volatiles' },
        { asset: 'Cash', impact: 0, description: 'Valeur préservée' }
      ]
    },
    {
      id: 'inflation',
      name: 'Poussée Inflationniste',
      description: 'Inflation à 5-6% comme en 2021-2022',
      icon: 'ri-fire-line',
      color: 'orange',
      impacts: [
        { asset: 'Actions', impact: -5, description: 'Impact mitigé taux vs profits' },
        { asset: 'Actions défensives', impact: -10, description: 'Sensibles aux taux' },
        { asset: 'Actions croissance', impact: -15, description: 'Multiples compressés' },
        { asset: 'Actions diversifiées', impact: -3, description: 'Diversification aide' },
        { asset: 'Obligations', impact: -12, description: 'Hausse des taux' },
        { asset: 'ETF', impact: -2, description: 'Diversification' },
        { asset: 'ETF diversifiés', impact: 0, description: 'Equilibré' },
        { asset: 'ETF internationaux', impact: 2, description: 'Diversification géo' },
        { asset: 'ETF émergents', impact: 8, description: 'Matières premières' },
        { asset: 'Crypto', impact: -20, description: 'Corrélation actions' },
        { asset: 'REIT/Immobilier', impact: 12, description: 'Actifs réels' },
        { asset: 'Small caps', impact: -8, description: 'Financement coûteux' },
        { asset: 'Cash', impact: -5, description: 'Érosion monétaire' }
      ]
    },
    {
      id: 'crisis',
      name: 'Crise Systémique',
      description: 'Crise majeure type 2008 ou Covid Mars 2020',
      icon: 'ri-alarm-warning-line',
      color: 'purple',
      impacts: [
        { asset: 'Actions', impact: -45, description: 'Krach majeur' },
        { asset: 'Actions défensives', impact: -30, description: 'Moins touchées' },
        { asset: 'Actions croissance', impact: -55, description: 'Forte dévalorisation' },
        { asset: 'Actions diversifiées', impact: -40, description: 'Contagion généralisée' },
        { asset: 'Obligations', impact: 8, description: 'Refuge qualité' },
        { asset: 'ETF', impact: -40, description: 'Suit les marchés' },
        { asset: 'ETF diversifiés', impact: -35, description: 'Diversification limite' },
        { asset: 'ETF internationaux', impact: -42, description: 'Crise mondiale' },
        { asset: 'ETF émergents', impact: -60, description: 'Fuite massive capitaux' },
        { asset: 'Crypto', impact: -75, description: 'Liquidation forcée' },
        { asset: 'REIT/Immobilier', impact: -50, description: 'Illiquidité' },
        { asset: 'Small caps', impact: -65, description: 'Accès crédit limité' },
        { asset: 'Cash', impact: 0, description: 'Liquidité premium' }
      ]
    },
    {
      id: 'growth',
      name: 'Croissance Forte',
      description: 'Cycle haussier fort comme 2017-2021',
      icon: 'ri-rocket-line',
      color: 'green',
      impacts: [
        { asset: 'Actions', impact: 25, description: 'Marché haussier' },
        { asset: 'Actions défensives', impact: 15, description: 'Performance modérée' },
        { asset: 'Actions croissance', impact: 40, description: 'Secteur favori' },
        { asset: 'Actions diversifiées', impact: 30, description: 'Performance équilibrée' },
        { asset: 'Obligations', impact: -8, description: 'Moins attractives' },
        { asset: 'ETF', impact: 20, description: 'Suit la tendance' },
        { asset: 'ETF diversifiés', impact: 25, description: 'Bonne exposition' },
        { asset: 'ETF internationaux', impact: 22, description: 'Croissance mondiale' },
        { asset: 'ETF émergents', impact: 35, description: 'Rattrapage' },
        { asset: 'Crypto', impact: 80, description: 'Adoption massive' },
        { asset: 'REIT/Immobilier', impact: 18, description: 'Demande forte' },
        { asset: 'Small caps', impact: 45, description: 'Plus de croissance' },
        { asset: 'Cash', impact: -2, description: 'Coût opportunité' }
      ]
    }
  ], []);

  const calculateScenarioImpact = useCallback((scenario) => {
    if (!scenario || !scenario.impacts) {
      return { totalImpact: 0, detailedImpacts: [] };
    }

    const impacts = scenario.impacts;
    let totalImpact = 0;
    let detailedImpacts = [];

    const allocations = syncedData?.allocations || [];
    const totalValue = syncedData?.totalValue || 0;

    allocations.forEach(alloc => {
      let impact = impacts.find(i => i.asset === alloc.name);

      if (!impact) {
        const defaultImpacts = {
          'recession': { 'Actions': -25, 'Obligations': 2, 'ETF': -20, 'Cash': 0, 'Crypto': -50 },
          'inflation': { 'Actions': -5, 'Obligations': -12, 'ETF': -2, 'Cash': -5, 'Crypto': -20 },
          'crisis': { 'Actions': -45, 'Obligations': 8, 'ETF': -40, 'Cash': 0, 'Crypto': -70 },
          'growth': { 'Actions': 25, 'Obligations': -8, 'ETF': 20, 'Cash': -2, 'Crypto': 80 }
        };

        const scenarioDefaults = defaultImpacts[scenario.id] || {};
        let defaultImpact = 0;

        if (alloc.name.includes('Actions') || alloc.name.includes('actions')) {
          defaultImpact = scenarioDefaults['Actions'] || 0;
        } else if (alloc.name.includes('Obligations') || alloc.name.includes('obligations')) {
          defaultImpact = scenarioDefaults['Obligations'] || 0;
        } else if (alloc.name.includes('ETF') || alloc.name.includes('etf')) {
          defaultImpact = scenarioDefaults['ETF'] || 0;
        } else if (alloc.name.includes('Cash') || alloc.name.includes('Liquidités')) {
          defaultImpact = scenarioDefaults['Cash'] || 0;
        } else if (alloc.name.includes('Crypto') || alloc.name.includes('crypto')) {
          defaultImpact = scenarioDefaults['Crypto'] || 0;
        }

        impact = {
          asset: alloc.name,
          impact: defaultImpact,
          description: 'Impact estimé selon catégorie'
        };
      }

      const allocValue = alloc.value || (totalValue * (alloc.percentage / 100));
      const impactValue = (allocValue * impact.impact) / 100;
      totalImpact += impactValue;

      detailedImpacts.push({
        ...alloc,
        impact: impact.impact,
        impactValue: impactValue,
        description: impact.description,
        newValue: allocValue + impactValue
      });
    });

    return { totalImpact, detailedImpacts };
  }, [syncedData]);

  const selectedScenarioData = scenarios.find(s => s.id === selectedScenario);

  const scenarioResult = useMemo(() => {
    if (!showAnalysis || !selectedScenarioData) return null;
    return calculateScenarioImpact(selectedScenarioData);
  }, [calculateScenarioImpact, selectedScenarioData, showAnalysis]);

  const newPortfolioValue = scenarioResult ? (syncedData?.totalValue || 0) + scenarioResult.totalImpact : 0;

  const generateScenarioRecommendations = useCallback((scenarioResults) => {
    if (!riskMetrics || !syncedData?.allocations || !scenarioResults) return [];

    const recs = [];
    const allocations = syncedData.allocations;
    const totalValue = syncedData.totalValue || 0;
    const impacts = scenarioResults.detailedImpacts;

    const vulnerabilities = impacts.filter(impact => impact.impact < -20);
    const resilientAssets = impacts.filter(impact => impact.impact > -10);
    const mostVulnerable = impacts.reduce((prev, current) => 
      (prev.impact < current.impact) ? prev : current
    );
    const mostResilient = impacts.reduce((prev, current) => 
      (prev.impact > current.impact) ? prev : current
    );

    if (vulnerabilities.length > 0 && mostVulnerable.percentage > 10) {
      const reductionAmount = Math.min(mostVulnerable.percentage * 0.3, 15); 
      const newPercentage = Math.max(5, mostVulnerable.percentage - reductionAmount);

      recs.push({
        type: 'protection',
        priority: 'high',
        title: `Réduire l'exposition à ${mostVulnerable.name}`,
        description: `Cet actif perd ${Math.abs(mostVulnerable.impact)}% dans le scénario "${selectedScenarioData?.name}".`,
        action: `Réduire de ${mostVulnerable.percentage.toFixed(1)}% à ${newPercentage.toFixed(1)}%`,
        category: 'risk_reduction',
        executable: true,
        newAllocation: {
          assetName: mostVulnerable.name,
          currentPercentage: mostVulnerable.percentage,
          targetPercentage: newPercentage,
          redistributeTo: resilientAssets.length > 0 ? resilientAssets[0].name : 'Cash'
        }
      });
    }

    if (resilientAssets.length > 0 && mostResilient.percentage < 40) {
      const increaseAmount = Math.min(10, 40 - mostResilient.percentage);
      const newPercentage = mostResilient.percentage + increaseAmount;

      recs.push({
        type: 'opportunity',
        priority: 'medium',
        title: `Renforcer ${mostResilient.name}`,
        description: `Excellente résistance avec seulement ${Math.abs(mostResilient.impact)}% d'impact.`,
        action: `Augmenter de ${mostResilient.percentage.toFixed(1)}% à ${newPercentage.toFixed(1)}%`,
        category: 'optimization',
        executable: true,
        newAllocation: {
          assetName: mostResilient.name,
          currentPercentage: mostResilient.percentage,
          targetPercentage: newPercentage,
          sourceFrom: vulnerabilities.length > 0 ? vulnerabilities[0].name : 'Cash'
        }
      });
    }

    const hasDefensiveAssets = allocations.some(a => 
      a.name.includes('défensives') || a.name.includes('Obligations') || a.name === 'Cash'
    );

    if (!hasDefensiveAssets && selectedScenario === 'recession') {
      recs.push({
        type: 'scenario_hedge',
        priority: 'high',
        title: 'Ajouter une couverture défensive',
        description: 'Aucun actif défensif détecté face au risque de récession.',
        action: 'Ajouter 15% d\'obligations ou actions défensives',
        category: 'scenario_protection',
        executable: true,
        newAllocation: {
          assetName: 'Obligations',
          currentPercentage: 0,
          targetPercentage: 15,
          sourceFrom: mostVulnerable.name
        }
      });
    }

    const cashPosition = allocations.find(a => a.name === 'Cash' || a.name.includes('Liquidités'));
    const currentCashPercentage = cashPosition ? cashPosition.percentage : 0;
    const portfolioImpactPercent = Math.abs(scenarioResults.totalImpact / totalValue * 100);

    if (portfolioImpactPercent > 15 && currentCashPercentage < 10) {
      const targetCashPercentage = Math.min(15, 10 + (portfolioImpactPercent - 15) * 0.3);

      recs.push({
        type: 'emergency',
        priority: 'high',
        title: 'Augmenter les liquidités de sécurité',
        description: `Impact total de ${portfolioImpactPercent.toFixed(1)}% nécessite plus de liquidités.`,
        action: `Passer de ${currentCashPercentage.toFixed(1)}% à ${targetCashPercentage.toFixed(1)}% de liquidités`,
        category: 'liquidity_management',
        executable: true,
        newAllocation: {
          assetName: 'Cash',
          currentPercentage: currentCashPercentage,
          targetPercentage: targetCashPercentage,
          sourceFrom: mostVulnerable.name
        }
      });
    }

    if (appliedModel) {
      const modelName = appliedModel.name;

      if (modelName === 'Conservateur' && portfolioImpactPercent > 12) {
        recs.push({
          type: 'model_specific',
          priority: 'medium',
          title: 'Réajustement modèle conservateur',
          description: `Impact de ${portfolioImpactPercent.toFixed(1)}% trop élevé pour un profil conservateur.`,
          action: 'Réduire les actions à 40% max, augmenter obligations à 50%',
          category: 'model_adjustment',
          executable: true,
          modelRebalancing: {
            'Actions': 40,
            'Actions diversifiées': 40,
            'Obligations': 50,
            'Cash': 10
          }
        });
      }
    }

    return recs.slice(0, 5);
  }, [riskMetrics, syncedData, selectedScenario, appliedModel, selectedScenarioData]);

  useEffect(() => {
    if (showAnalysis && scenarioResult) {
      const newRecommendations = generateScenarioRecommendations(scenarioResult);
      setRecommendations(newRecommendations);
    }
  }, [showAnalysis, scenarioResult, generateScenarioRecommendations]);

  if (!showAnalysis) {
    return (
      <div className="min-h-screen bg-black text-white">
        <div className="container mx-auto px-4 py-16">
          <div className="text-center max-w-4xl mx-auto">
            <div className="w-20 h-20 bg-gradient-to-br from-red-500/20 to-orange-600/20 rounded-full flex items-center justify-center mx-auto mb-8">
              <i className="ri-shield-line text-4xl text-red-400"></i>
            </div>

            <h2 className="text-4xl font-bold text-white mb-4">Analyse des Risques Tactique</h2>
            <p className="text-xl text-gray-400 mb-8 leading-relaxed">
              Testez la résistance de votre modèle d&apos;allocation face à différents scénarios de marché 
              et obtenez des recommandations tactiques pour optimiser votre portefeuille.
            </p>

            <div className="grid md:grid-cols-3 gap-6 mb-12">
              <div className="bg-gray-900/50 p-6 rounded-xl border border-red-500/20">
                <i className="ri-speed-line text-3xl text-red-400 mb-4"></i>
                <h3 className="text-lg font-bold text-white mb-2">Tests de Stress</h3>
                <p className="text-gray-400 text-sm">Simulez l&apos;impact de crises sur votre allocation</p>
              </div>
              <div className="bg-gray-900/50 p-6 rounded-xl border border-orange-500/20">
                <i className="ri-strategy-line text-3xl text-orange-400 mb-4"></i>
                <h3 className="text-lg font-bold text-white mb-2">Recommandations Tactiques</h3>
                <p className="text-gray-400 text-sm">Ajustements basés sur la résistance du modèle</p>
              </div>
              <div className="bg-gray-900/50 p-6 rounded-xl border border-purple-500/20">
                <i className="ri-line-chart-line text-3xl text-purple-400 mb-4"></i>
                <h3 className="text-lg font-bold text-white mb-2">Métriques Avancées</h3>
                <p className="text-gray-400 text-sm">VaR, volatilité, résistance par actif</p>
              </div>
            </div>

            <div className="bg-gradient-to-r from-yellow-500/10 via-orange-500/10 to-red-500/10 border border-yellow-500/30 rounded-xl p-8 mb-8">
              <h3 className="text-2xl font-bold text-white mb-4">Votre Modèle d&apos;allocation</h3>
              <div className="text-3xl font-bold text-yellow-400 mb-2">
                €{(syncedData?.totalValue || 0).toLocaleString('fr-FR')} 
                <span className="text-sm text-gray-400 ml-2">
                  ({(syncedData?.allocations || []).length} positions)
                </span>
              </div>
              <div className="text-gray-400 mb-4">
                {appliedModel ? `Modèle ${appliedModel.name}` : 'Allocation personnalisée'}
              </div>
              {appliedModel && (
                <div className="bg-blue-500/20 rounded-lg p-4 border border-blue-300/30">
                  <div className="flex items-center justify-center space-x-4">
                    <i className="ri-bookmark-line text-blue-400 text-xl"></i>
                    <div>
                      <div className="text-blue-300 font-semibold">Modèle appliqué: {appliedModel.name}</div>
                      <div className="text-blue-400 text-sm">Analyse basée sur ce modèle d&apos;allocation</div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <button
              onClick={() => setShowAnalysis(true)}
              className="bg-gradient-to-r from-red-500 to-orange-600 hover:from-red-400 hover:to-orange-500 text-white px-12 py-4 rounded-xl font-bold text-xl transition-all transform hover:scale-105 cursor-pointer whitespace-nowrap flex items-center space-x-3 mx-auto"
            >
              <i className="ri-play-line text-2xl"></i>
              <span>Lancer l&apos;Analyse Tactique</span>
            </button>

            <p className="text-gray-500 text-sm mt-4">
              Tests de résistance et recommandations d&apos;ajustement de votre modèle
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="sticky top-0 z-10 bg-black/95 backdrop-blur-sm border-b border-gray-800 py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <div className="text-center flex-1">
              <h2 className="text-3xl font-bold text-white mb-2">Analyse des Risques Tactique</h2>
              <p className="text-gray-400 max-w-2xl mx-auto mb-4">
                Tests de résistance de votre modèle d&apos;allocation avec recommandations tactiques pour équilibrer tous les scénarios.
              </p>
              <div className="flex items-center justify-center space-x-6">
                <div className="p-3 bg-gray-900/50 rounded-lg border border-yellow-500/20 inline-block">
                  <div className="text-sm text-gray-400">Portefeuille testé :</div>
                  <div className="text-lg font-semibold text-yellow-400">
                    €{(syncedData?.totalValue || 0).toLocaleString('fr-FR')} 
                    <span className="text-sm text-gray-400 ml-2">
                      ({(syncedData?.allocations || []).length} positions)
                    </span>
                  </div>
                </div>
                {appliedModel && (
                  <div className="p-3 bg-blue-500/10 rounded-lg border border-blue-500/20 inline-block">
                    <div className="text-sm text-blue-400">Modèle appliqué :</div>
                    <div className="text-lg font-semibold text-blue-300">
                      {appliedModel.name}
                    </div>
                  </div>
                )}
              </div>
            </div>
            <button
              onClick={() => setShowAnalysis(false)}
              className="ml-4 bg-gray-800 hover:bg-gray-700 text-white px-4 py-2 rounded-lg transition-colors cursor-pointer whitespace-nowrap flex items-center space-x-2"
            >
              <i className="ri-arrow-left-line"></i>
              <span>Retour</span>
            </button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 space-y-8">
        {riskMetrics && (
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-gray-900 p-6 rounded-xl border border-yellow-500/20 text-center">
              <div className="w-12 h-12 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-speed-line text-2xl text-red-400"></i>
              </div>
              <div className="text-2xl font-bold text-red-400 mb-1">
                {(riskMetrics.volatility * 100).toFixed(1)}%
              </div>
              <div className="text-sm text-gray-400">Volatilité du Portefeuille</div>
              <div className="text-xs text-gray-500 mt-1">
                {riskMetrics.volatility < 0.12 ? 'Faible' : riskMetrics.volatility < 0.20 ? 'Modérée' : 'Élevée'}
              </div>
            </div>

            <div className="bg-gray-900 p-6 rounded-xl border border-yellow-500/20 text-center">
              <div className="w-12 h-12 bg-orange-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-funds-line text-2xl text-orange-400"></i>
              </div>
              <div className="text-2xl font-bold text-orange-400 mb-1">
                €{Math.round(riskMetrics.var95).toLocaleString('fr-FR')}
              </div>
              <div className="text-sm text-gray-400">VaR 95% (1 mois)</div>
              <div className="text-xs text-gray-500 mt-1">
                Perte potentielle max
              </div>
            </div>

            <div className="bg-gray-900 p-6 rounded-xl border border-yellow-500/20 text-center">
              <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-line-chart-line text-2xl text-blue-400"></i>
              </div>
              <div className="text-2xl font-bold text-blue-400 mb-1">
                {riskMetrics.sharpeRatio.toFixed(2)}
              </div>
              <div className="text-sm text-gray-400">Ratio de Sharpe</div>
              <div className="text-xs text-blue-300 mt-1">
                {riskMetrics.sharpeRatio > 1 ? 'Excellent' : riskMetrics.sharpeRatio > 0.5 ? 'Bon' : 'À améliorer'}
              </div>
            </div>

            <div className="bg-gray-900 p-6 rounded-xl border border-yellow-500/20 text-center">
              <div className="w-12 h-12 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-arrow-down-line text-2xl text-purple-400"></i>
              </div>
              <div className="text-2xl font-bold text-purple-400 mb-1">
                -{(riskMetrics.maxDrawdown * 100).toFixed(1)}%
              </div>
              <div className="text-sm text-gray-400">Drawdown Estimé</div>
              <div className="text-xs text-gray-500 mt-1">
                Baisse max attendue
              </div>
            </div>
          </div>
        )}

        <div className="bg-gray-900 rounded-xl p-8 border border-gray-700">
          <h3 className="text-2xl font-bold text-white mb-6 text-center">Scénarios de Stress Test</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {scenarios.map((scenario) => (
              <button
                key={scenario.id}
                onClick={() => setSelectedScenario(scenario.id)}
                className={`p-6 rounded-xl border-2 transition-all cursor-pointer whitespace-nowrap ${
                  selectedScenario === scenario.id
                    ? `border-${scenario.color}-500 bg-${scenario.color}-500/10`
                    : 'border-gray-600 bg-gray-800 hover:border-gray-500'
                }`}
              >
                <div className={`w-12 h-12 bg-${scenario.color}-500/20 rounded-full flex items-center justify-center mx-auto mb-4`}>
                  <i className={`${scenario.icon} text-2xl text-${scenario.color}-400`}></i>
                </div>
                <h4 className="font-bold text-white mb-2">{scenario.name}</h4>
                <p className="text-sm text-gray-400">{scenario.description}</p>
              </button>
            ))}
          </div>

          {scenarioResult && selectedScenarioData && (
            <div className="space-y-6">
              <div className="bg-gray-800 rounded-xl p-6 border border-gray-600">
                <div className="text-center mb-6">
                  <h4 className="text-xl font-bold text-white mb-2">
                    Impact du scénario : {selectedScenarioData.name}
                  </h4>
                  <div className="flex items-center justify-center space-x-8">
                    <div>
                      <div className="text-sm text-gray-400">Valeur actuelle</div>
                      <div className="text-2xl font-bold text-white">
                        €{(syncedData?.totalValue || 0).toLocaleString('fr-FR')}
                      </div>
                    </div>
                    <div className="text-3xl text-gray-500">→</div>
                    <div>
                      <div className="text-sm text-gray-400">Valeur après impact</div>
                      <div className={`text-2xl font-bold ${scenarioResult.totalImpact >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        €{Math.round(newPortfolioValue).toLocaleString('fr-FR')}
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-400">Impact total</div>
                      <div className={`text-xl font-bold ${scenarioResult.totalImpact >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {scenarioResult.totalImpact >= 0 ? '+' : ''}€{Math.round(scenarioResult.totalImpact).toLocaleString('fr-FR')}
                        <span className="text-sm ml-1">
                          ({scenarioResult.totalImpact >= 0 ? '+' : ''}{((scenarioResult.totalImpact / (syncedData?.totalValue || 1)) * 100).toFixed(1)}%)
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="grid gap-4">
                  {scenarioResult.detailedImpacts.map((impact, index) => (
                    <div key={index} className="bg-gray-700 rounded-lg p-4 flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className={`w-3 h-3 rounded-full`} style={{ backgroundColor: impact.color }}></div>
                        <div>
                          <div className="font-semibold text-white">{impact.name}</div>
                          <div className="text-sm text-gray-400">{impact.description}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className={`font-bold ${impact.impact >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {impact.impact >= 0 ? '+' : ''}{impact.impact}%
                        </div>
                        <div className="text-sm text-gray-400">
                          {impact.impact >= 0 ? '+' : ''}€{Math.round(impact.impactValue).toLocaleString('fr-FR')}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {recommendations.length > 0 && (
                <div className="bg-gray-800 rounded-xl p-6 border border-gray-600">
                  <h4 className="text-xl font-bold text-white mb-6 text-center">
                    Recommandations Tactiques
                  </h4>
                  <div className="space-y-4">
                    {recommendations.map((rec, index) => (
                      <div key={index} className={`bg-gray-700 rounded-lg p-4 border-l-4 ${
                        rec.priority === 'high' ? 'border-red-500' : 
                        rec.priority === 'medium' ? 'border-yellow-500' : 'border-blue-500'
                      }`}>
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <span className={`px-2 py-1 rounded text-xs font-bold ${
                                rec.priority === 'high' ? 'bg-red-500/20 text-red-400' :
                                rec.priority === 'medium' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-blue-500/20 text-blue-400'
                              }`}>
                                {rec.priority === 'high' ? 'PRIORITÉ HAUTE' : 
                                 rec.priority === 'medium' ? 'PRIORITÉ MOYENNE' : 'PRIORITÉ FAIBLE'}
                              </span>
                              <span className="text-xs text-gray-500 uppercase">{rec.category}</span>
                            </div>
                            <h5 className="font-bold text-white mb-1">{rec.title}</h5>
                            <p className="text-sm text-gray-400 mb-2">{rec.description}</p>
                            <p className="text-sm text-blue-300 font-medium">{rec.action}</p>
                          </div>
                          {rec.executable && (
                            <button
                              onClick={() => applyRecommendation(rec)}
                              className="ml-4 bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap"
                            >
                              Appliquer
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
