
'use client';

import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/cjs/styles/prism';

interface MarkdownRendererProps {
  content: string;
  className?: string;
}

export default function MarkdownRenderer({ content, className = '' }: MarkdownRendererProps) {
  return (
    <div className={`prose prose-invert prose-lg max-w-none ${className}`}>
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          // Headings with premium styling
          h1: ({ children }) => (
            <h1 className="text-4xl font-bold text-yellow-400 mb-8 mt-12 leading-tight">
              {children}
            </h1>
          ),
          h2: ({ children }) => (
            <h2 className="text-3xl font-bold text-yellow-400 mb-6 mt-10 leading-tight">
              {children}
            </h2>
          ),
          h3: ({ children }) => (
            <h3 className="text-2xl font-bold text-yellow-400 mb-4 mt-8 leading-tight">
              {children}
            </h3>
          ),

          // Paragraphs with proper spacing - handle text content only
          p: ({ children, ...props }) => {
            // Check if paragraph contains only text/inline elements
            const hasBlockElements = React.Children.toArray(children).some(child => {
              if (React.isValidElement(child)) {
                return ['figure', 'img', 'div'].includes(child.type as string);
              }
              return false;
            });

            // If paragraph contains block elements, render as div
            if (hasBlockElements) {
              return <div className="my-6">{children}</div>;
            }

            return (
              <p className="text-gray-300 leading-relaxed mb-6 text-lg" {...props}>
                {children}
              </p>
            );
          },

          // Images with responsive design and captions - enhanced for Base64 and all formats
          img: ({ src, alt, title, ...props }) => {
            // Don't render image if src is empty or undefined
            if (!src || src.trim() === '') {
              return null;
            }

            // Handle both regular URLs and Base64 data URLs
            const isBase64 = src.startsWith('data:image/');
            const isValidUrl = src.startsWith('http') || isBase64;
            
            if (!isValidUrl) {
              return null;
            }

            return (
              <figure className="my-8 text-center">
                <img
                  src={src}
                  alt={alt || 'Image'}
                  className="w-full max-w-4xl mx-auto rounded-xl shadow-2xl border border-gray-700 object-cover"
                  style={{ maxHeight: '600px' }}
                  loading="lazy"
                  onError={(e) => {
                    console.log('Image loading error:', src);
                    // Hide broken images gracefully
                    (e.target as HTMLImageElement).style.display = 'none';
                  }}
                  {...props}
                />
                {(alt || title) && (
                  <figcaption className="text-center text-sm text-gray-400 mt-3 italic">
                    {title || alt}
                  </figcaption>
                )}
              </figure>
            );
          },

          // Links with premium styling
          a: ({ href, children }) => (
            <a
              href={href}
              className="text-yellow-400 hover:text-yellow-300 underline decoration-2 underline-offset-2 transition-colors"
              target={href?.startsWith('http') ? '_blank' : undefined}
              rel={href?.startsWith('http') ? 'noopener noreferrer' : undefined}
            >
              {children}
            </a>
          ),

          // Lists with better spacing
          ul: ({ children }) => (
            <ul className="text-gray-300 mb-6 space-y-2 list-disc ml-6">
              {children}
            </ul>
          ),
          ol: ({ children }) => (
            <ol className="text-gray-300 mb-6 space-y-2 list-decimal ml-6">
              {children}
            </ol>
          ),
          li: ({ children }) => (
            <li className="text-gray-300 leading-relaxed">
              {children}
            </li>
          ),

          // Blockquotes with enhanced styling
          blockquote: ({ children }) => (
            <blockquote className="border-l-4 border-yellow-500 pl-6 py-4 my-8 bg-gray-900/50 rounded-r-lg">
              <div className="text-gray-300 italic text-lg leading-relaxed">
                {children}
              </div>
            </blockquote>
          ),

          // Code blocks with syntax highlighting
          code: ({ inline, className, children, ...props }) => {
            const match = /language-(\w+)/.exec(className || '');
            return !inline && match ? (
              <div className="my-6">
                <SyntaxHighlighter
                  style={oneDark}
                  language={match[1]}
                  PreTag="div"
                  className="rounded-lg border border-gray-700"
                  {...props}
                >
                  {String(children).replace(/\n$/, '')}
                </SyntaxHighlighter>
              </div>
            ) : (
              <code
                className="bg-gray-800 text-yellow-300 px-2 py-1 rounded text-sm font-mono"
                {...props}
              >
                {children}
              </code>
            );
          },

          // Tables with premium styling
          table: ({ children }) => (
            <div className="my-8 overflow-x-auto">
              <table className="min-w-full border-collapse border border-gray-600 bg-gray-900/50 rounded-lg overflow-hidden">
                {children}
              </table>
            </div>
          ),
          thead: ({ children }) => (
            <thead className="bg-gray-800">
              {children}
            </thead>
          ),
          th: ({ children }) => (
            <th className="border border-gray-600 px-4 py-3 text-left font-bold text-yellow-400">
              {children}
            </th>
          ),
          td: ({ children }) => (
            <td className="border border-gray-600 px-4 py-3 text-gray-300">
              {children}
            </td>
          ),

          // Strong and emphasis
          strong: ({ children }) => (
            <strong className="text-yellow-300 font-semibold">
              {children}
            </strong>
          ),
          em: ({ children }) => (
            <em className="text-gray-300 italic">
              {children}
            </em>
          ),

          // Horizontal rule
          hr: () => (
            <hr className="my-8 border-t border-gray-700" />
          ),
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}
