'use client';

import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Image from '@tiptap/extension-image';
import Link from '@tiptap/extension-link';
import Table from '@tiptap/extension-table';
import TableRow from '@tiptap/extension-table-row';
import TableCell from '@tiptap/extension-table-cell';
import TableHeader from '@tiptap/extension-table-header';
import Placeholder from '@tiptap/extension-placeholder';
import TextAlign from '@tiptap/extension-text-align';
import Underline from '@tiptap/extension-underline';
import { useState, useCallback, useRef } from 'react';

interface TiptapEditorProps {
  content: string;
  onChange: (content: string) => void;
  placeholder?: string;
}

export default function TiptapEditor({ content, onChange, placeholder = "Commencez à écrire votre article..." }: TiptapEditorProps) {
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);
  const [imageUrl, setImageUrl] = useState('');
  const [imageAlt, setImageAlt] = useState('');
  const [imageDescription, setImageDescription] = useState('');
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [showImageUpload, setShowImageUpload] = useState(false);
  const [isUploadingFile, setIsUploadingFile] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        heading: {
          levels: [1, 2, 3],
        },
      }),
      Image.configure({
        HTMLAttributes: {
          class: 'rounded-lg shadow-lg max-w-full h-auto mx-auto my-6',
        },
        allowBase64: true,
      }),
      Link.configure({
        openOnClick: false,
        HTMLAttributes: {
          class: 'text-yellow-400 hover:text-yellow-300 underline',
        },
      }),
      Table.configure({
        resizable: true,
        HTMLAttributes: {
          class: 'border-collapse border border-gray-600 my-6',
        },
      }),
      TableRow.configure({
        HTMLAttributes: {
          class: 'border border-gray-600',
        },
      }),
      TableHeader.configure({
        HTMLAttributes: {
          class: 'border border-gray-600 bg-gray-800 font-bold p-3',
        },
      }),
      TableCell.configure({
        HTMLAttributes: {
          class: 'border border-gray-600 p-3',
        },
      }),
      Placeholder.configure({
        placeholder,
      }),
      TextAlign.configure({
        types: ['heading', 'paragraph'],
      }),
      Underline,
    ],
    content,
    onUpdate: ({ editor }) => {
      onChange(editor.getHTML());
    },
    editorProps: {
      attributes: {
        class: 'prose prose-lg max-w-none focus:outline-none min-h-96 p-6 text-gray-100',
      },
    },
  });

  // Fonction pour convertir un fichier en Base64
  const convertFileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        resolve(result);
      };
      reader.onerror = () => {
        reject(new Error('Erreur lors de la lecture du fichier'));
      };
      reader.readAsDataURL(file);
    });
  };

  // Gestion de l'upload de fichier
  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Vérifier le type de fichier
    if (!file.type.startsWith('image/')) {
      alert('Veuillez sélectionner un fichier image valide');
      return;
    }

    // Vérifier la taille du fichier (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      alert('La taille du fichier ne doit pas dépasser 5MB');
      return;
    }

    setIsUploadingFile(true);
    try {
      const base64String = await convertFileToBase64(file);
      const altText = imageAlt || file.name.split('.')[0];
      
      // Insérer l'image directement dans l'éditeur
      editor?.chain().focus().setImage({ 
        src: base64String,
        alt: altText,
        title: altText
      }).run();
      
      // Réinitialiser les champs
      setImageAlt('');
      setIsImageModalOpen(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (error) {
      console.error('Erreur lors de l\'upload:', error);
      alert('Erreur lors du traitement de l\'image');
    } finally {
      setIsUploadingFile(false);
    }
  };

  const generateAIImage = async () => {
    if (!imageDescription.trim()) return;
    
    setIsGeneratingImage(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      const uniqueId = Math.random().toString(36).substring(2, 15);
      const generatedUrl = `https://readdy.ai/api/search-image?query=$%7BencodeURIComponent%28imageDescription%29%7D&width=800&height=500&seq=${uniqueId}&orientation=landscape`;
      
      editor?.chain().focus().setImage({ 
        src: generatedUrl,
        alt: imageDescription,
        title: imageDescription
      }).run();
      
      setImageDescription('');
      setIsImageModalOpen(false);
    } catch (error) {
      console.error('Erreur génération image:', error);
    } finally {
      setIsGeneratingImage(false);
    }
  };

  const addImage = () => {
    if (!imageUrl.trim()) return;
    
    editor?.chain().focus().setImage({ 
      src: imageUrl,
      alt: imageAlt || 'Image',
      title: imageAlt || 'Image'
    }).run();
    
    setImageUrl('');
    setImageAlt('');
    setIsImageModalOpen(false);
  };

  // Bouton rapide pour uploader une image
  const quickImageUpload = () => {
    fileInputRef.current?.click();
  };

  const addLink = useCallback(() => {
    const previousUrl = editor?.getAttributes('link').href;
    const url = window.prompt('URL du lien:', previousUrl);

    if (url === null) {
      return;
    }

    if (url === '') {
      editor?.chain().focus().extendMarkRange('link').unsetLink().run();
      return;
    }

    editor?.chain().focus().extendMarkRange('link').setLink({ href: url }).run();
  }, [editor]);

  const insertTable = () => {
    editor?.chain().focus().insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run();
  };

  if (!editor) {
    return (
      <div className="bg-gray-900 rounded-lg p-6 min-h-96 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-yellow-500 mx-auto mb-4"></div>
          <p className="text-gray-400">Chargement de l'éditeur...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-900 rounded-lg overflow-hidden border border-gray-700">
      {/* Hidden file input */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileUpload}
        accept="image/*"
        className="hidden"
      />

      {/* Toolbar */}
      <div className="bg-gray-800 border-b border-gray-700 p-4">
        <div className="flex flex-wrap items-center gap-2">
          {/* Text Formatting */}
          <div className="flex items-center gap-1 border-r border-gray-600 pr-3">
            <button
              onClick={() => editor.chain().focus().toggleBold().run()}
              className={`p-2 rounded hover:bg-gray-700 transition-colors ${
                editor.isActive('bold') ? 'bg-yellow-600 text-black' : 'text-gray-300'
              }`}
              title="Gras (Ctrl+B)"
            >
              <i className="ri-bold w-4 h-4 flex items-center justify-center"></i>
            </button>
            <button
              onClick={() => editor.chain().focus().toggleItalic().run()}
              className={`p-2 rounded hover:bg-gray-700 transition-colors ${
                editor.isActive('italic') ? 'bg-yellow-600 text-black' : 'text-gray-300'
              }`}
              title="Italique (Ctrl+I)"
            >
              <i className="ri-italic w-4 h-4 flex items-center justify-center"></i>
            </button>
            <button
              onClick={() => editor.chain().focus().toggleUnderline().run()}
              className={`p-2 rounded hover:bg-gray-700 transition-colors ${
                editor.isActive('underline') ? 'bg-yellow-600 text-black' : 'text-gray-300'
              }`}
              title="Souligné (Ctrl+U)"
            >
              <i className="ri-underline w-4 h-4 flex items-center justify-center"></i>
            </button>
          </div>

          {/* Headings */}
          <div className="flex items-center gap-1 border-r border-gray-600 pr-3">
            <button
              onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}
              className={`px-3 py-2 rounded text-sm font-semibold hover:bg-gray-700 transition-colors ${
                editor.isActive('heading', { level: 1 }) ? 'bg-yellow-600 text-black' : 'text-gray-300'
              }`}
            >
              H1
            </button>
            <button
              onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
              className={`px-3 py-2 rounded text-sm font-semibold hover:bg-gray-700 transition-colors ${
                editor.isActive('heading', { level: 2 }) ? 'bg-yellow-600 text-black' : 'text-gray-300'
              }`}
            >
              H2
            </button>
            <button
              onClick={() => editor.chain().focus().toggleHeading({ level: 3 }).run()}
              className={`px-3 py-2 rounded text-sm font-semibold hover:bg-gray-700 transition-colors ${
                editor.isActive('heading', { level: 3 }) ? 'bg-yellow-600 text-black' : 'text-gray-300'
              }`}
            >
              H3
            </button>
          </div>

          {/* Lists */}
          <div className="flex items-center gap-1 border-r border-gray-600 pr-3">
            <button
              onClick={() => editor.chain().focus().toggleBulletList().run()}
              className={`p-2 rounded hover:bg-gray-700 transition-colors ${
                editor.isActive('bulletList') ? 'bg-yellow-600 text-black' : 'text-gray-300'
              }`}
              title="Liste à puces"
            >
              <i className="ri-list-unordered w-4 h-4 flex items-center justify-center"></i>
            </button>
            <button
              onClick={() => editor.chain().focus().toggleOrderedList().run()}
              className={`p-2 rounded hover:bg-gray-700 transition-colors ${
                editor.isActive('orderedList') ? 'bg-yellow-600 text-black' : 'text-gray-300'
              }`}
              title="Liste numérotée"
            >
              <i className="ri-list-ordered w-4 h-4 flex items-center justify-center"></i>
            </button>
          </div>

          {/* Alignment */}
          <div className="flex items-center gap-1 border-r border-gray-600 pr-3">
            <button
              onClick={() => editor.chain().focus().setTextAlign('left').run()}
              className={`p-2 rounded hover:bg-gray-700 transition-colors ${
                editor.isActive({ textAlign: 'left' }) ? 'bg-yellow-600 text-black' : 'text-gray-300'
              }`}
              title="Aligner à gauche"
            >
              <i className="ri-align-left w-4 h-4 flex items-center justify-center"></i>
            </button>
            <button
              onClick={() => editor.chain().focus().setTextAlign('center').run()}
              className={`p-2 rounded hover:bg-gray-700 transition-colors ${
                editor.isActive({ textAlign: 'center' }) ? 'bg-yellow-600 text-black' : 'text-gray-300'
              }`}
              title="Centrer"
            >
              <i className="ri-align-center w-4 h-4 flex items-center justify-center"></i>
            </button>
            <button
              onClick={() => editor.chain().focus().setTextAlign('right').run()}
              className={`p-2 rounded hover:bg-gray-700 transition-colors ${
                editor.isActive({ textAlign: 'right' }) ? 'bg-yellow-600 text-black' : 'text-gray-300'
              }`}
              title="Aligner à droite"
            >
              <i className="ri-align-right w-4 h-4 flex items-center justify-center"></i>
            </button>
          </div>

          {/* Other formatting */}
          <div className="flex items-center gap-1 border-r border-gray-600 pr-3">
            <button
              onClick={() => editor.chain().focus().toggleBlockquote().run()}
              className={`p-2 rounded hover:bg-gray-700 transition-colors ${
                editor.isActive('blockquote') ? 'bg-yellow-600 text-black' : 'text-gray-300'
              }`}
              title="Citation"
            >
              <i className="ri-double-quotes-r w-4 h-4 flex items-center justify-center"></i>
            </button>
            <button
              onClick={() => editor.chain().focus().toggleCodeBlock().run()}
              className={`p-2 rounded hover:bg-gray-700 transition-colors ${
                editor.isActive('codeBlock') ? 'bg-yellow-600 text-black' : 'text-gray-300'
              }`}
              title="Code"
            >
              <i className="ri-code-box-line w-4 h-4 flex items-center justify-center"></i>
            </button>
          </div>

          {/* Insert elements */}
          <div className="flex items-center gap-1">
            <button
              onClick={addLink}
              className={`p-2 rounded hover:bg-gray-700 transition-colors ${
                editor.isActive('link') ? 'bg-yellow-600 text-black' : 'text-gray-300'
              }`}
              title="Ajouter un lien"
            >
              <i className="ri-link w-4 h-4 flex items-center justify-center"></i>
            </button>
            
            {/* Bouton upload rapide */}
            <button
              onClick={quickImageUpload}
              disabled={isUploadingFile}
              className="p-2 rounded hover:bg-gray-700 transition-colors text-green-400 hover:text-green-300"
              title="Uploader une image"
            >
              {isUploadingFile ? (
                <i className="ri-loader-line w-4 h-4 flex items-center justify-center animate-spin"></i>
              ) : (
                <i className="ri-upload-line w-4 h-4 flex items-center justify-center"></i>
              )}
            </button>
            
            <button
              onClick={() => setIsImageModalOpen(true)}
              className="p-2 rounded hover:bg-gray-700 transition-colors text-gray-300"
              title="Options d'image avancées"
            >
              <i className="ri-image-line w-4 h-4 flex items-center justify-center"></i>
            </button>
            <button
              onClick={insertTable}
              className="p-2 rounded hover:bg-gray-700 transition-colors text-gray-300"
              title="Insérer un tableau"
            >
              <i className="ri-table-line w-4 h-4 flex items-center justify-center"></i>
            </button>
          </div>
        </div>
      </div>

      {/* Editor */}
      <div className="bg-gray-900 min-h-96">
        <EditorContent 
          editor={editor} 
          className="[&_.ProseMirror]:text-gray-100 [&_.ProseMirror_h1]:text-yellow-400 [&_.ProseMirror_h2]:text-yellow-400 [&_.ProseMirror_h3]:text-yellow-400 [&_.ProseMirror_blockquote]:border-l-4 [&_.ProseMirror_blockquote]:border-yellow-500 [&_.ProseMirror_blockquote]:pl-4 [&_.ProseMirror_blockquote]:italic [&_.ProseMirror_pre]:bg-gray-800 [&_.ProseMirror_pre]:p-4 [&_.ProseMirror_pre]:rounded [&_.ProseMirror_code]:bg-gray-800 [&_.ProseMirror_code]:px-2 [&_.ProseMirror_code]:py-1 [&_.ProseMirror_code]:rounded [&_.ProseMirror_img]:max-w-full [&_.ProseMirror_img]:h-auto [&_.ProseMirror_img]:rounded-lg [&_.ProseMirror_img]:shadow-lg [&_.ProseMirror_img]:mx-auto [&_.ProseMirror_img]:my-6"
        />
      </div>

      {/* Image Modal */}
      {isImageModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-800 rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold text-white mb-4">Ajouter une image</h3>
            
            <div className="space-y-4">
              {/* Upload de fichier */}
              <div>
                <button
                  onClick={() => {
                    setShowImageUpload(false);
                    fileInputRef.current?.click();
                  }}
                  disabled={isUploadingFile}
                  className="w-full p-4 rounded-lg border border-green-500 bg-green-500/10 text-green-400 hover:bg-green-500/20 transition-colors flex items-center justify-center"
                >
                  {isUploadingFile ? (
                    <>
                      <i className="ri-loader-line mr-2 animate-spin"></i>
                      Upload en cours...
                    </>
                  ) : (
                    <>
                      <i className="ri-upload-cloud-line mr-2"></i>
                      Uploader depuis mon ordinateur
                    </>
                  )}
                </button>
                <p className="text-xs text-gray-400 mt-2 text-center">
                  Formats acceptés: JPG, PNG, GIF, WebP (max 5MB)
                </p>
              </div>

              <div className="flex items-center">
                <div className="flex-1 h-px bg-gray-600"></div>
                <span className="px-3 text-gray-400 text-sm">ou</span>
                <div className="flex-1 h-px bg-gray-600"></div>
              </div>

              <div>
                <button
                  onClick={() => setShowImageUpload(!showImageUpload)}
                  className={`w-full p-3 rounded-lg border text-left transition-colors ${
                    showImageUpload 
                      ? 'border-yellow-500 bg-yellow-500/10 text-yellow-400' 
                      : 'border-gray-600 text-gray-300 hover:border-gray-500'
                  }`}
                >
                  <i className="ri-link mr-2"></i>
                  URL d'image
                </button>
                
                {showImageUpload && (
                  <div className="mt-3 space-y-3">
                    <input
                      type="url"
                      value={imageUrl}
                      onChange={(e) => setImageUrl(e.target.value)}
                      placeholder="https://exemple.com/image.jpg"
                      className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
                    />
                    <input
                      type="text"
                      value={imageAlt}
                      onChange={(e) => setImageAlt(e.target.value)}
                      placeholder="Description de l'image (optionnel)"
                      className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
                    />
                    <button
                      onClick={addImage}
                      disabled={!imageUrl.trim()}
                      className="w-full px-4 py-2 bg-yellow-600 hover:bg-yellow-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-black font-semibold rounded-lg transition-colors"
                    >
                      Ajouter l'image
                    </button>
                  </div>
                )}
              </div>

              <div>
                <button
                  onClick={() => setShowImageUpload(false)}
                  className={`w-full p-3 rounded-lg border text-left transition-colors ${
                    !showImageUpload 
                      ? 'border-yellow-500 bg-yellow-500/10 text-yellow-400' 
                      : 'border-gray-600 text-gray-300 hover:border-gray-500'
                  }`}
                >
                  <i className="ri-magic-line mr-2"></i>
                  Générer avec IA
                </button>
                
                {!showImageUpload && (
                  <div className="mt-3 space-y-3">
                    <textarea
                      value={imageDescription}
                      onChange={(e) => setImageDescription(e.target.value)}
                      placeholder="Décrivez l'image que vous souhaitez générer..."
                      rows={3}
                      className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:ring-2 focus:ring-yellow-500 focus:border-transparent resize-none"
                    />
                    <button
                      onClick={generateAIImage}
                      disabled={!imageDescription.trim() || isGeneratingImage}
                      className="w-full px-4 py-2 bg-yellow-600 hover:bg-yellow-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-black font-semibold rounded-lg transition-colors"
                    >
                      {isGeneratingImage ? (
                        <>
                          <i className="ri-loader-line mr-2 animate-spin"></i>
                          Génération...
                        </>
                      ) : (
                        <>
                          <i className="ri-magic-line mr-2"></i>
                          Générer l'image
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>
            </div>

            <div className="flex justify-end mt-6">
              <button
                onClick={() => setIsImageModalOpen(false)}
                className="px-4 py-2 text-gray-400 hover:text-white transition-colors"
              >
                Annuler
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}