'use client';

import { usePathname } from 'next/navigation';
import Link from 'next/link';
import { useEffect, useState } from 'react';

interface BreadcrumbItem {
  text: string;
  url: string;
  isLast: boolean;
}

const translations: Record<string, string> = {
  'admin': 'Administration',
  'dashboard': 'Tableau de Bord',
  'trading': 'Trading',
  'academy': 'Académie',
  'indicators': 'Indicateurs',
  'allocation': 'Allocation',
  'opportunities': 'Opportunités',
  'auth': 'Authentification',
  'login': 'Connexion',
  'register': 'Inscription',
  'contact': 'Contact',
  'privacy': 'Confidentialité',
  'cookies': 'Cookies',
  'payment': 'Paiement',
  'marketplace': 'Marché',
  'formation-interactive': 'Formation Interactive',
  'analyse-fondamentale': 'Analyse Fondamentale',
  'analyse-technique': 'Analyse Technique',
  'gestion-risques': 'Gestion des Risques',
  'psychologie': 'Psychologie du Trading',
  'trading-avance': 'Trading Avancé',
  'trading-debutant': 'Trading Débutant',
  'explorer': 'Explorer',
  'user-management': 'Gestion Utilisateurs',
  'plans-manager': 'Gestion des Plans',
  'academy-manager': 'Gestion Académie',
  'site-builder': 'Constructeur de Site',
  'crm-client': 'CRM Client',
  'unified-dashboard': 'Dashboard Unifié',
  'security-settings': 'Paramètres Sécurité',
  'portfolio-editor': 'Éditeur Portfolio',
  'payment-history': 'Historique Paiements',
  'access-codes': 'Codes d\'Accès',
  'contact-manager': 'Gestionnaire Contacts',
  'create-blog': 'Créer Blog',
  'indicators-manager': 'Gestion Indicateurs',
  'settings': 'Paramètres'
};

const customTitles: Record<string, string> = {
  '/': 'Accueil',
  '/dashboard': 'Tableau de Bord',
  '/trading': 'Trading',
  '/academy': 'Académie',
  '/indicators': 'Indicateurs',
  '/allocation': 'Allocation',
  '/opportunities': 'Opportunités',
  '/formation-interactive': 'Formation Interactive',
  '/marketplace': 'Marketplace',
  '/contact': 'Contact',
  '/privacy': 'Confidentialité',
  '/cookies': 'Cookies',
  '/payment': 'Paiement',
  '/auth/login': 'Connexion',
  '/auth/register': 'Inscription',
  '/admin': 'Administration',
  '/admin/dashboard': 'Dashboard Admin'
};

export default function Breadcrumb() {
  const pathname = usePathname();
  const [breadcrumbItems, setBreadcrumbItems] = useState<BreadcrumbItem[]>([]);

  useEffect(() => {
    const segments = pathname.split('/').filter(segment => segment !== '');
    
    const items: BreadcrumbItem[] = [{
      text: 'CMV Finance',
      url: '/',
      isLast: pathname === '/'
    }];

    let currentPath = '';
    
    segments.forEach((segment, index) => {
      currentPath += '/' + segment;
      
      const cleanSegment = cleanSegmentName(segment);
      const title = getPageTitle(cleanSegment, currentPath, segment);
      
      items.push({
        text: title,
        url: currentPath,
        isLast: index === segments.length - 1
      });
    });

    setBreadcrumbItems(items);
  }, [pathname]);

  const cleanSegmentName = (segment: string): string => {
    if (translations[segment]) {
      return translations[segment];
    }
    
    return decodeURIComponent(segment)
      .replace(/-/g, ' ')
      .replace(/_/g, ' ')
      .toLowerCase()
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  };

  const getPageTitle = (cleanSegment: string, path: string, originalSegment: string): string => {
    if (customTitles[path]) {
      return customTitles[path];
    }
    
    if (customTitles[originalSegment]) {
      return customTitles[originalSegment];
    }

    return cleanSegment;
  };

  if (breadcrumbItems.length <= 1) {
    return null;
  }

  return (
    <nav aria-label="Fil d'Ariane" className="breadcrumb-nav">
      <div className="breadcrumb">
        <ol className="breadcrumb__list" itemScope itemType="https://schema.org/BreadcrumbList">
          {breadcrumbItems.map((item, index) => (
            <li 
              key={item.url}
              className={`breadcrumb__item ${item.isLast ? 'breadcrumb__item--current' : ''}`}
              itemProp="itemListElement" 
              itemScope 
              itemType="https://schema.org/ListItem"
            >
              {item.isLast ? (
                <span 
                  className="breadcrumb__text breadcrumb__text--current" 
                  itemProp="name"
                >
                  {item.text}
                </span>
              ) : (
                <Link href={item.url} className="breadcrumb__link" itemProp="item">
                  <span itemProp="name">{item.text}</span>
                </Link>
              )}
              <meta itemProp="position" content={String(index + 1)} />
              {!item.isLast && (
                <span className="breadcrumb__separator" aria-hidden="true">›</span>
              )}
            </li>
          ))}
        </ol>
      </div>
    </nav>
  );
}